<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de las solicitudes y su historial.
namespace App\Models;

use App\Core\Model;

class Request extends Model {
    protected string $table = 'requests';

    // Devuelve una lista enriquecida con relaciones y datos descriptivos de las solicitudes y su historial.
    public function getDetailedList(array $filters = []): array {
        $sql = "
            SELECT r.*, 
                   u.full_name AS applicant_name, u.position AS applicant_position,
                   a.name AS area_name, a.code AS area_code,
                   (SELECT COUNT(*) FROM request_items ri WHERE ri.request_id = r.id) AS items_count
            FROM requests r
            LEFT JOIN users u ON u.id = r.applicant_id
            LEFT JOIN areas a ON a.id = r.area_id
            WHERE 1=1
        ";
        $params = [];

        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (!empty($filters['applicant_id'])) {
            $sql .= " AND r.applicant_id = ?";
            $params[] = $filters['applicant_id'];
        }

        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (!empty($filters['area_id'])) {
            $sql .= " AND r.area_id = ?";
            $params[] = $filters['area_id'];
        }

        // Verifica el estado actual para impedir cambios fuera del flujo permitido.
        if (!empty($filters['status'])) {
            $sql .= " AND r.status = ?";
            $params[] = $filters['status'];
        }

        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (!empty($filters['search'])) {
            $sql .= " AND (r.code LIKE ? OR r.correspondence_number LIKE ? OR u.full_name LIKE ?)";
            $term = "%{$filters['search']}%";
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
        }

        $sql .= " ORDER BY r.id DESC";

        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql, $params);
    }

    // Recupera un registro con sus datos relacionados de las solicitudes y su historial.
    public function getWithDetails(int $id): ?array {
        $sql = "
            SELECT r.*, 
                   u.full_name AS applicant_name, u.position AS applicant_position, u.ci AS applicant_ci,
                   a.name AS area_name, a.code AS area_code
            FROM requests r
            LEFT JOIN users u ON u.id = r.applicant_id
            LEFT JOIN areas a ON a.id = r.area_id
            WHERE r.id = ?
            LIMIT 1
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchOne($sql, [$id]);
    }

    // Consulta el detalle de productos relacionados con las solicitudes y su historial.
    public function getItems(int $requestId): array {
        $sql = "
            SELECT ri.*, p.code AS product_code, p.name AS product_name, p.stock_qty AS current_stock,
                   u.name AS unit_name, u.code AS unit_code
            FROM request_items ri
            INNER JOIN products p ON p.id = ri.product_id
            LEFT JOIN units u ON u.id = p.unit_id
            WHERE ri.request_id = ?
            ORDER BY ri.id ASC
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql, [$requestId]);
    }

    // Recupera los cambios de estado y responsables de la solicitud.
    public function getHistory(int $requestId): array {
        $sql = "
            SELECT h.*, u.full_name AS actor_name, r.name AS role_name
            FROM request_history h
            LEFT JOIN users u ON u.id = h.actor_id
            LEFT JOIN roles r ON r.id = h.role_id
            WHERE h.request_id = ?
            ORDER BY h.id ASC
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql, [$requestId]);
    }

    // Consulta las decisiones registradas en la ruta de aprobación.
    public function getApprovals(int $requestId): array {
        $sql = "
            SELECT a.*, u.full_name AS approver_name, r.name AS role_name
            FROM request_approvals a
            LEFT JOIN users u ON u.id = a.approver_user_id
            LEFT JOIN roles r ON r.id = a.role_id
            WHERE a.request_id = ?
            ORDER BY a.step_order ASC
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql, [$requestId]);
    }
}
