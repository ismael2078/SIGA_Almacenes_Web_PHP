<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de los periodos contables.

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Period extends Model
{
    protected static string $table = 'period_closes';

    /** @return array<int,array<string,mixed>> */
    public static function allOrdered(): array
    {
        return self::query(
            'SELECT p.*, u.full_name AS closed_by_name
             FROM period_closes p LEFT JOIN users u ON u.id = p.closed_by
             ORDER BY p.year DESC, p.month DESC'
        )->fetchAll();
    }

    // Busca o crea el periodo correspondiente al mes actual.
    public static function ensureCurrent(): array
    {
        $year = (int) date('Y');
        $month = (int) date('n');
        $period = self::first(
            'SELECT * FROM period_closes WHERE year = ? AND month = ? LIMIT 1',
            [$year, $month]
        );
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($period !== null) {
            return $period;
        }
        $id = self::insert([
            'year' => $year,
            'month' => $month,
            'status' => 'ABIERTO',
        ]);
        return self::find($id) ?? [];
    }

    // Comprueba si la fecha pertenece a un periodo cerrado.
    public static function isClosed(string $date): bool
    {
        $ts = strtotime($date);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($ts === false) {
            return false;
        }
        $status = self::scalar(
            'SELECT status FROM period_closes WHERE year = ? AND month = ? LIMIT 1',
            [(int) date('Y', $ts), (int) date('n', $ts)]
        );
        return $status === 'CERRADO';
    }
}
