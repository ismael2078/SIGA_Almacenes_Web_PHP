<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de los proveedores.
namespace App\Models;

use App\Core\Model;

class Supplier extends Model {
    protected string $table = 'suppliers';
}
