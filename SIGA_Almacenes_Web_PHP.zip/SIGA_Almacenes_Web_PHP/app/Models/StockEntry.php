<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de los ingresos de materiales.
namespace App\Models;

use App\Core\Model;

class StockEntry extends Model {
    protected string $table = 'stock_entries';

    // Devuelve una lista enriquecida con relaciones y datos descriptivos de los ingresos de materiales.
    public function getDetailedList(): array {
        $sql = "
            SELECT e.*, s.name AS supplier_name, s.nit AS supplier_nit, u.full_name AS creator_name,
                   (SELECT COUNT(*) FROM stock_entry_items ei WHERE ei.entry_id = e.id) AS items_count
            FROM stock_entries e
            LEFT JOIN suppliers s ON s.id = e.supplier_id
            LEFT JOIN users u ON u.id = e.created_by
            ORDER BY e.id DESC
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql);
    }

    // Consulta el detalle de productos relacionados con los ingresos de materiales.
    public function getItems(int $entryId): array {
        $sql = "
            SELECT ei.*, p.code AS product_code, p.name AS product_name, 
                   u.name AS unit_name, l.name AS location_name
            FROM stock_entry_items ei
            INNER JOIN products p ON p.id = ei.product_id
            LEFT JOIN units u ON u.id = p.unit_id
            LEFT JOIN locations l ON l.id = ei.location_id
            WHERE ei.entry_id = ?
            ORDER BY ei.id ASC
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql, [$entryId]);
    }
}
