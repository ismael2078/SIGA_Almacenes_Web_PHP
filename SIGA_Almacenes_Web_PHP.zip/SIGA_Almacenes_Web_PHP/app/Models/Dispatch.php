<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de los despachos de almacén.

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use App\Core\Model;
use RuntimeException;

final class Dispatch extends Model
{
    protected static string $table = 'stock_dispatches';

    /** @return array<int,array<string,mixed>> */
    public static function paginate(string $search = '', string $status = ''): array
    {
        $where = ['1=1'];
        $params = [];
        if ($search !== '') {
            $where[] = '(d.number LIKE ? OR r.code LIKE ? OR d.received_by LIKE ?)';
            $like = '%' . $search . '%';
            array_push($params, $like, $like, $like);
        }
        // Verifica el estado actual para impedir cambios fuera del flujo permitido.
        if ($status !== '') {
            $where[] = 'd.status = ?';
            $params[] = $status;
        }
        return self::query(
            'SELECT d.*, r.code AS request_code, r.correspondence_number, a.name AS area_name,
                    u.full_name AS applicant_name, us.full_name AS dispatched_by_name
             FROM stock_dispatches d
             LEFT JOIN requests r ON r.id = d.request_id
             LEFT JOIN areas a ON a.id = r.area_id
             LEFT JOIN users u ON u.id = r.applicant_id
             LEFT JOIN users us ON us.id = d.dispatched_by
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY d.dispatch_date DESC, d.id DESC LIMIT 500',
            $params
        )->fetchAll();
    }

    // Recupera la salida con información del solicitante y del despacho.
    public static function findDetailed(int $id): ?array
    {
        return self::first(
            'SELECT d.*, r.code AS request_code, r.correspondence_number, r.justification,
                    r.office, r.submitted_at, a.name AS area_name,
                    u.full_name AS applicant_name, us.full_name AS dispatched_by_name,
                    v.full_name AS voided_by_name
             FROM stock_dispatches d
             LEFT JOIN requests r ON r.id = d.request_id
             LEFT JOIN areas a ON a.id = r.area_id
             LEFT JOIN users u ON u.id = r.applicant_id
             LEFT JOIN users us ON us.id = d.dispatched_by
             LEFT JOIN users v ON v.id = d.voided_by
             WHERE d.id = ? LIMIT 1',
            [$id]
        );
    }

    /** @return array<int,array<string,mixed>> */
    public static function items(int $dispatchId): array
    {
        return self::query(
            'SELECT di.*, p.code AS product_code, p.name AS product_name, u.code AS unit_code
             FROM dispatch_items di
             INNER JOIN products p ON p.id = di.product_id
             LEFT JOIN units u ON u.id = p.unit_id
             WHERE di.dispatch_id = ? ORDER BY di.id ASC',
            [$dispatchId]
        )->fetchAll();
    }

    /** @return array<int,array<string,mixed>> */
    public static function pendingItems(int $requestId): array
    {
        return self::query(
            "SELECT ri.*, p.code AS product_code, p.name AS product_name, p.stock_qty,
                    u.code AS unit_code
             FROM request_items ri
             INNER JOIN products p ON p.id = ri.product_id
             LEFT JOIN units u ON u.id = p.unit_id
             WHERE ri.request_id = ?
             ORDER BY ri.id ASC",
            [$requestId]
        )->fetchAll();
    }

    /**
     * @param array<int,array{request_item_id:int,qty:float}> $items
     */
    public static function createFromRequest(int $requestId, array $user, array $items, string $receivedBy, string $receivedCi, string $notes = ''): array
    {
        if ($items === []) {
            throw new RuntimeException('Debe indicar al menos un ítem para despachar.');
        }
        if (trim($receivedBy) === '' || trim($receivedCi) === '') {
            throw new RuntimeException('El nombre y el CI de la persona que recibe son obligatorios.');
        }

        $year = (int) date('Y');
        $number = Sequence::next('SAL', $year);

        return Database::transaction(static function () use ($requestId, $user, $items, $receivedBy, $receivedCi, $notes, $number): array {
            $request = Request::first('SELECT * FROM requests WHERE id = ? FOR UPDATE', [$requestId]);
            // Comprueba el resultado recibido y evita continuar con datos inexistentes.
            if ($request === null) {
                throw new RuntimeException('Solicitud no encontrada.');
            }
            // Verifica el estado actual para impedir cambios fuera del flujo permitido.
            if ($request['status'] !== 'APROBADA') {
                throw new RuntimeException('La solicitud debe estar APROBADA para despachar. Estado actual: ' . $request['status']);
            }

            $dispatchId = self::insert([
                'number' => $number,
                'request_id' => $requestId,
                'dispatch_date' => date('Y-m-d H:i:s'),
                'dispatched_by' => (int) $user['id'],
                'received_by' => $receivedBy,
                'received_ci' => $receivedCi,
                'received_signature_at' => date('Y-m-d H:i:s'),
                'total_value' => '0.00',
                'status' => 'BORRADOR',
                'notes' => $notes ?: null,
            ]);

            $totalValue = 0.0;

            // Procesa cada producto por separado para registrar o calcular su movimiento.
            foreach ($items as $inputItem) {
                $requestItemId = (int) $inputItem['request_item_id'];
                $quantity = (float) $inputItem['qty'];
                if ($quantity <= 0) {
                    continue;
                }
                $requestItem = Request::first(
                    'SELECT * FROM request_items WHERE id = ? AND request_id = ? FOR UPDATE',
                    [$requestItemId, $requestId]
                );
                // Comprueba el resultado recibido y evita continuar con datos inexistentes.
                if ($requestItem === null) {
                    throw new RuntimeException('Ítem de solicitud no válido.');
                }

                $approvedQty = (float) $requestItem['qty_authorized'] > 0
                    ? (float) $requestItem['qty_authorized']
                    : (float) $requestItem['qty_approved'];
                if ($approvedQty <= 0) {
                    $approvedQty = (float) $requestItem['qty_requested'];
                }
                if ($quantity > $approvedQty + 0.0001) {
                    throw new RuntimeException('La cantidad a despachar (' . qty($quantity) . ') excede la autorizada (' . qty($approvedQty) . ').');
                }

                $productId = (int) $requestItem['product_id'];
                $layers = self::query(
                    "SELECT * FROM stock_layers
                     WHERE product_id = ? AND remaining_qty > 0 AND status = 'ABIERTA'
                     ORDER BY layer_date ASC, sequence ASC, id ASC FOR UPDATE",
                    [$productId]
                )->fetchAll();

                $available = 0.0;
                // Recorre los elementos de la colección y procesa cada registro.
                foreach ($layers as $layer) {
                    $available += (float) $layer['remaining_qty'];
                }
                if ($available + 0.0001 < $quantity) {
                    throw new RuntimeException('STOCK INSUFICIENTE: existencia ' . qty($available) . ', solicitado ' . qty($quantity) . '.');
                }

                $dispatchItemId = self::insert([
                    'dispatch_id' => $dispatchId,
                    'request_item_id' => $requestItemId,
                    'product_id' => $productId,
                    'qty' => number_format($quantity, 3, '.', ''),
                    'unit_cost' => '0.0000',
                    'total_value' => '0.00',
                ]);

                $remaining = $quantity;
                $lineCost = 0.0;
                // Recorre los elementos de la colección y procesa cada registro.
                foreach ($layers as $layer) {
                    if ($remaining <= 0.00001) {
                        break;
                    }
                    $take = min((float) $layer['remaining_qty'], $remaining);
                    $newRemaining = (float) $layer['remaining_qty'] - $take;
                    self::query(
                        'UPDATE stock_layers SET remaining_qty = ?, status = ? WHERE id = ?',
                        [
                            number_format($newRemaining, 3, '.', ''),
                            $newRemaining <= 0.0001 ? 'AGOTADA' : 'ABIERTA',
                            (int) $layer['id'],
                        ]
                    );
                    $lineValue = $take * (float) $layer['unit_cost'];
                    $lineCost += $lineValue;
                    self::query(
                        'INSERT INTO layer_consumptions (dispatch_item_id, layer_id, qty, unit_cost, total_value)
                         VALUES (?, ?, ?, ?, ?)',
                        [
                            $dispatchItemId,
                            (int) $layer['id'],
                            number_format($take, 3, '.', ''),
                            $layer['unit_cost'],
                            number_format($lineValue, 2, '.', ''),
                        ]
                    );
                    $remaining -= $take;
                }

                $unitCost = $lineCost / $quantity;
                self::query(
                    'UPDATE dispatch_items SET unit_cost = ?, total_value = ? WHERE id = ?',
                    [number_format($unitCost, 4, '.', ''), number_format($lineCost, 2, '.', ''), $dispatchItemId]
                );

                $product = Product::first('SELECT * FROM products WHERE id = ? FOR UPDATE', [$productId]);
                // Comprueba el resultado recibido y evita continuar con datos inexistentes.
                if ($product === null) {
                    throw new RuntimeException('Producto no encontrado.');
                }
                $newQty = (float) $product['stock_qty'] - $quantity;
                $newValue = (float) $product['stock_value'] - $lineCost;
                Product::update($productId, [
                    'stock_qty' => number_format(max(0, $newQty), 3, '.', ''),
                    'stock_value' => number_format(max(0, $newValue), 2, '.', ''),
                    'status' => $newQty <= 0.0001 ? 'INACTIVO' : 'ACTIVO',
                ]);

                Kardex::record([
                    'product_id' => $productId,
                    'movement_date' => date('Y-m-d H:i:s'),
                    'doc_type' => 'SALIDA',
                    'doc_id' => $dispatchId,
                    'reference' => $number,
                    'qty_out' => number_format($quantity, 3, '.', ''),
                    'unit_cost_out' => number_format($unitCost, 4, '.', ''),
                    'total_out' => number_format($lineCost, 2, '.', ''),
                    'balance_qty' => number_format(max(0, $newQty), 3, '.', ''),
                    'balance_value' => number_format(max(0, $newValue), 2, '.', ''),
                    'balance_unit_cost' => $newQty > 0 ? number_format(max(0, $newValue) / $newQty, 4, '.', '') : '0.0000',
                ]);

                self::query(
                    "UPDATE request_items SET qty_delivered = qty_delivered + ?, status = 'ENTREGADO' WHERE id = ?",
                    [number_format($quantity, 3, '.', ''), $requestItemId]
                );

                $totalValue += $lineCost;
            }

            // Controla los valores de cantidad o costo antes de continuar con el inventario.
            if ($totalValue <= 0) {
                throw new RuntimeException('No se pudo valorizar el despacho. Verifique las capas PEPS.');
            }

            self::update($dispatchId, [
                'status' => 'CONFIRMADO',
                'total_value' => number_format($totalValue, 2, '.', ''),
            ]);

            Request::transition($requestId, $user, 'ATENDIDA', 'Despacho ' . $number . ' confirmado');

            return ['id' => $dispatchId, 'number' => $number, 'total' => $totalValue];
        });
    }

    // Anula un despacho con controles y movimientos de reversión.
    public static function void(int $id, array $user, string $reason): void
    {
        if (mb_strlen(trim($reason)) < 15) {
            throw new RuntimeException('El motivo de anulación debe tener al menos 15 caracteres.');
        }

        Database::transaction(static function () use ($id, $user, $reason): void {
            $dispatch = self::first('SELECT * FROM stock_dispatches WHERE id = ? FOR UPDATE', [$id]);
            // Comprueba el resultado recibido y evita continuar con datos inexistentes.
            if ($dispatch === null) {
                throw new RuntimeException('Despacho no encontrado.');
            }
            // Verifica el estado actual para impedir cambios fuera del flujo permitido.
            if ($dispatch['status'] !== 'CONFIRMADO') {
                throw new RuntimeException('Solo se pueden anular despachos confirmados.');
            }

            $items = self::query('SELECT * FROM dispatch_items WHERE dispatch_id = ?', [$id])->fetchAll();
            // Procesa cada producto por separado para registrar o calcular su movimiento.
            foreach ($items as $item) {
                $consumptions = self::query(
                    'SELECT * FROM layer_consumptions WHERE dispatch_item_id = ? FOR UPDATE',
                    [(int) $item['id']]
                )->fetchAll();
                // Recorre los elementos de la colección y procesa cada registro.
                foreach ($consumptions as $consumption) {
                    self::query(
                        "UPDATE stock_layers SET remaining_qty = remaining_qty + ?, status = 'ABIERTA' WHERE id = ?",
                        [$consumption['qty'], (int) $consumption['layer_id']]
                    );
                }

                $product = Product::first('SELECT * FROM products WHERE id = ? FOR UPDATE', [(int) $item['product_id']]);
                // Comprueba el resultado recibido y evita continuar con datos inexistentes.
                if ($product !== null) {
                    $newQty = (float) $product['stock_qty'] + (float) $item['qty'];
                    $newValue = (float) $product['stock_value'] + (float) $item['total_value'];
                    Product::update((int) $product['id'], [
                        'stock_qty' => number_format($newQty, 3, '.', ''),
                        'stock_value' => number_format($newValue, 2, '.', ''),
                        'status' => 'ACTIVO',
                    ]);
                    Kardex::record([
                        'product_id' => (int) $item['product_id'],
                        'movement_date' => date('Y-m-d H:i:s'),
                        'doc_type' => 'ANULACION',
                        'doc_id' => $id,
                        'reference' => $dispatch['number'],
                        'qty_in' => $item['qty'],
                        'unit_cost_in' => $item['unit_cost'],
                        'total_in' => $item['total_value'],
                        'balance_qty' => number_format($newQty, 3, '.', ''),
                        'balance_value' => number_format($newValue, 2, '.', ''),
                        'balance_unit_cost' => $newQty > 0 ? number_format($newValue / $newQty, 4, '.', '') : '0.0000',
                    ]);
                }

                self::query(
                    'UPDATE request_items SET qty_delivered = GREATEST(0, qty_delivered - ?), status = ? WHERE id = ?',
                    [$item['qty'], 'APROBADO', (int) $item['request_item_id']]
                );
            }

            self::update($id, [
                'status' => 'ANULADO',
                'voided_by' => (int) $user['id'],
                'voided_at' => date('Y-m-d H:i:s'),
                'void_reason' => $reason,
            ]);

            $otherConfirmed = (int) self::scalar(
                "SELECT COUNT(*) FROM stock_dispatches WHERE request_id = ? AND status = 'CONFIRMADO' AND id <> ?",
                [(int) $dispatch['request_id'], $id]
            );
            if ($otherConfirmed === 0) {
                $request = Request::find((int) $dispatch['request_id']);
                // Verifica el estado actual para impedir cambios fuera del flujo permitido.
                if ($request !== null && $request['status'] === 'ATENDIDA') {
                    Request::update((int) $request['id'], ['status' => 'APROBADA', 'closed_at' => null]);
                    Request::query(
                        'INSERT INTO request_history (request_id, from_state, to_state, actor_id, role_id, comments) VALUES (?, ?, ?, ?, ?, ?)',
                        [(int) $request['id'], 'ATENDIDA', 'APROBADA', (int) $user['id'], (int) $user['role_id'], 'Despacho ' . $dispatch['number'] . ' anulado: ' . $reason]
                    );
                }
            }
        });
    }
}
