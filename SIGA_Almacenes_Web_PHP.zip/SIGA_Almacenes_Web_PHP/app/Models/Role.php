<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de los roles del sistema.

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Role extends Model
{
    protected static string $table = 'roles';

    /** @return array<int,array<string,mixed>> */
    public static function allOrdered(): array
    {
        return self::query('SELECT * FROM roles ORDER BY id ASC')->fetchAll();
    }
}
