<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de las categorías de productos.
namespace App\Models;

use App\Core\Model;

class Category extends Model {
    protected string $table = 'categories';
}
