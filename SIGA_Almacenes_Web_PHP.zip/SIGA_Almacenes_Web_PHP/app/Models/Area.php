<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de las áreas institucionales.
namespace App\Models;

use App\Core\Model;

class Area extends Model {
    protected string $table = 'areas';

    // Devuelve una lista enriquecida con relaciones y datos descriptivos de las áreas institucionales.
    public function getDetailedList(): array {
        $sql = "
            SELECT a.*, p.name AS parent_name
            FROM areas a
            LEFT JOIN areas p ON p.id = a.parent_id
            ORDER BY a.name ASC
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql);
    }
}
