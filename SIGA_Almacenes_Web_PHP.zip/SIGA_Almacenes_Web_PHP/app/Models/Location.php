<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de las ubicaciones del almacén.
namespace App\Models;

use App\Core\Model;

class Location extends Model {
    protected string $table = 'locations';
}
