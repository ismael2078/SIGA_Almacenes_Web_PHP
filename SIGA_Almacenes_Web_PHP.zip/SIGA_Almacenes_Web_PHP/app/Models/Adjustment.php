<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de los ajustes de inventario.
namespace App\Models;

use App\Core\Model;

class Adjustment extends Model {
    protected string $table = 'adjustments';

    // Devuelve una lista enriquecida con relaciones y datos descriptivos de los ajustes de inventario.
    public function getDetailedList(): array {
        $sql = "
            SELECT a.*, u.full_name AS creator_name,
                   (SELECT COUNT(*) FROM adjustment_items ai WHERE ai.adjustment_id = a.id) AS items_count,
                   (SELECT COALESCE(SUM(total_value), 0) FROM adjustment_items ai WHERE ai.adjustment_id = a.id) AS total_value
            FROM adjustments a
            LEFT JOIN users u ON u.id = a.created_by
            ORDER BY a.id DESC
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql);
    }

    // Consulta el detalle de productos relacionados con los ajustes de inventario.
    public function getItems(int $adjustmentId): array {
        $sql = "
            SELECT ai.*, p.code AS product_code, p.name AS product_name, u.name AS unit_name
            FROM adjustment_items ai
            INNER JOIN products p ON p.id = ai.product_id
            LEFT JOIN units u ON u.id = p.unit_id
            WHERE ai.adjustment_id = ?
            ORDER BY ai.id ASC
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql, [$adjustmentId]);
    }
}
