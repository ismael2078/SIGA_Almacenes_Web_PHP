<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de las cuentas y permisos de usuario.
namespace App\Models;

use App\Core\Model;

class User extends Model {
    protected string $table = 'users';

    // Busca el usuario y su rol mediante su nombre de acceso.
    public function findByUsername(string $username): ?array {
        $sql = "
            SELECT u.*, r.code AS role_code, r.name AS role_name, a.name AS area_name
            FROM users u
            LEFT JOIN roles r ON r.id = u.role_id
            LEFT JOIN areas a ON a.id = u.area_id
            WHERE u.username = ? AND u.is_active = 1
            LIMIT 1
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchOne($sql, [$username]);
    }

    // Devuelve una lista enriquecida con relaciones y datos descriptivos de las cuentas y permisos de usuario.
    public function getDetailedList(): array {
        $sql = "
            SELECT u.*, r.code AS role_code, r.name AS role_name, a.name AS area_name
            FROM users u
            LEFT JOIN roles r ON r.id = u.role_id
            LEFT JOIN areas a ON a.id = u.area_id
            ORDER BY u.full_name ASC
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql);
    }
}
