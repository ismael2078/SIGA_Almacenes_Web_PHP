<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de los productos y sus existencias.
namespace App\Models;

use App\Core\Model;

class Product extends Model {
    protected string $table = 'products';

    // Devuelve una lista enriquecida con relaciones y datos descriptivos de los productos y sus existencias.
    public function getDetailedList(array $filters = []): array {
        $sql = "
            SELECT p.*, 
                   c.name AS category_name, c.code AS category_code,
                   s.name AS subcategory_name, s.code AS subcategory_code,
                   u.name AS unit_name, u.code AS unit_code,
                   l.name AS location_name, l.code AS location_code
            FROM products p
            LEFT JOIN categories c ON c.id = p.category_id
            LEFT JOIN subcategories s ON s.id = p.subcategory_id
            LEFT JOIN units u ON u.id = p.unit_id
            LEFT JOIN locations l ON l.id = p.location_id
            WHERE 1=1
        ";
        $params = [];

        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (!empty($filters['search'])) {
            $sql .= " AND (p.name LIKE ? OR p.code LIKE ? OR p.brand LIKE ?)";
            $term = "%{$filters['search']}%";
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
        }

        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (!empty($filters['category_id'])) {
            $sql .= " AND p.category_id = ?";
            $params[] = $filters['category_id'];
        }

        // Verifica el estado actual para impedir cambios fuera del flujo permitido.
        if (!empty($filters['status'])) {
            $sql .= " AND p.status = ?";
            $params[] = $filters['status'];
        }

        $sql .= " ORDER BY p.name ASC";

        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql, $params);
    }

    // Recupera un registro con sus datos relacionados de los productos y sus existencias.
    public function getWithDetails(int $id): ?array {
        $sql = "
            SELECT p.*, 
                   c.name AS category_name, c.code AS category_code,
                   s.name AS subcategory_name, s.code AS subcategory_code,
                   u.name AS unit_name, u.code AS unit_code,
                   l.name AS location_name, l.code AS location_code
            FROM products p
            LEFT JOIN categories c ON c.id = p.category_id
            LEFT JOIN subcategories s ON s.id = p.subcategory_id
            LEFT JOIN units u ON u.id = p.unit_id
            LEFT JOIN locations l ON l.id = p.location_id
            WHERE p.id = ?
            LIMIT 1
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchOne($sql, [$id]);
    }

    // Consulta capas PEPS con existencias disponibles de un producto.
    public function getOpenLayers(int $productId): array {
        $sql = "
            SELECT l.*, e.number AS entry_number, e.type AS entry_type, e.doc_number
            FROM stock_layers l
            LEFT JOIN stock_entries e ON e.id = l.entry_id
            WHERE l.product_id = ? AND l.remaining_qty > 0 AND l.status = 'ABIERTA'
            ORDER BY l.layer_date ASC, l.sequence ASC
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql, [$productId]);
    }
}
