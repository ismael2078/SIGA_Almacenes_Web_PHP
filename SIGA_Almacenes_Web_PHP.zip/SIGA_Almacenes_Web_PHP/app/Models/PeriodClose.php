<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de el cierre del periodo.
namespace App\Models;

use App\Core\Model;

class PeriodClose extends Model {
    protected string $table = 'period_closes';

    // Consulta el periodo activo para los movimientos.
    public function getCurrentPeriod(): ?array {
        $year = (int)date('Y');
        $month = (int)date('n');
        // Consulta la base de datos y devuelve los registros necesarios para la operación.
        $row = $this->fetchOne("SELECT * FROM period_closes WHERE year = ? AND month = ? LIMIT 1", [$year, $month]);
        if (!$row) {
            // Auto crear periodo abierto si no existe
            $id = $this->create([
                'year' => $year,
                'month' => $month,
                'status' => 'ABIERTO'
            ]);
            return $this->find($id);
        }
        return $row;
    }
}
