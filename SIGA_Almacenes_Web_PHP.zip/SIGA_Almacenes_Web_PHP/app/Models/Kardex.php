<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de los movimientos de Kardex.

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Kardex extends Model
{
    protected static string $table = 'kardex_movements';

    // Registra un movimiento de inventario con sus cantidades y valores.
    public static function record(array $data): int
    {
        $data += [
            'movement_date' => date('Y-m-d H:i:s'),
            'qty_in' => 0,
            'qty_out' => 0,
            'unit_cost_in' => 0,
            'unit_cost_out' => 0,
            'total_in' => 0,
            'total_out' => 0,
        ];
        return self::insert($data);
    }

    /** @return array<int,array<string,mixed>> */
    public static function report(string $from, string $to, string $search = '', string $docType = ''): array
    {
        $where = ['m.movement_date >= ?', 'm.movement_date <= ?'];
        $params = [$from . ' 00:00:00', $to . ' 23:59:59'];
        if ($search !== '') {
            $where[] = '(p.name LIKE ? OR p.code LIKE ?)';
            $like = '%' . $search . '%';
            array_push($params, $like, $like);
        }
        if ($docType !== '') {
            $where[] = 'm.doc_type = ?';
            $params[] = $docType;
        }
        return self::query(
            'SELECT m.*, p.code AS product_code, p.name AS product_name, u.code AS unit_code
             FROM kardex_movements m
             INNER JOIN products p ON p.id = m.product_id
             LEFT JOIN units u ON u.id = p.unit_id
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY m.movement_date ASC, m.id ASC LIMIT 5000',
            $params
        )->fetchAll();
    }

    /** @return array<int,array<string,mixed>> */
    public static function summary(string $from, string $to, string $search = '', int $categoryId = 0): array
    {
        $where = ["p.status <> 'ARCHIVADO'"];
        $params = [];
        if ($search !== '') {
            $where[] = '(p.name LIKE ? OR p.code LIKE ?)';
            $like = '%' . $search . '%';
            array_push($params, $like, $like);
        }
        if ($categoryId > 0) {
            $where[] = 'p.category_id = ?';
            $params[] = $categoryId;
        }

        $fromDate = $from . ' 00:00:00';
        $toDate = $to . ' 23:59:59';

        return self::query(
            "SELECT p.id, p.code, p.name, c.name AS category_name, u.code AS unit_code,
                    COALESCE(prior.qty, 0) AS initial_qty,
                    COALESCE(curr.qty_in, 0) AS in_qty,
                    COALESCE(curr.qty_out, 0) AS out_qty,
                    (COALESCE(prior.qty, 0) + COALESCE(curr.qty_in, 0) - COALESCE(curr.qty_out, 0)) AS final_qty,
                    COALESCE(prior.val, 0) AS initial_val,
                    COALESCE(curr.val_in, 0) AS in_val,
                    COALESCE(curr.val_out, 0) AS out_val,
                    (COALESCE(prior.val, 0) + COALESCE(curr.val_in, 0) - COALESCE(curr.val_out, 0)) AS final_val
             FROM products p
             INNER JOIN categories c ON c.id = p.category_id
             LEFT JOIN units u ON u.id = p.unit_id
             LEFT JOIN (
                SELECT product_id, SUM(qty_in - qty_out) AS qty, SUM(total_in - total_out) AS val
                FROM kardex_movements WHERE movement_date < ?
                GROUP BY product_id
             ) prior ON prior.product_id = p.id
             LEFT JOIN (
                SELECT product_id, SUM(qty_in) AS qty_in, SUM(qty_out) AS qty_out,
                       SUM(total_in) AS val_in, SUM(total_out) AS val_out
                FROM kardex_movements WHERE movement_date >= ? AND movement_date <= ?
                GROUP BY product_id
             ) curr ON curr.product_id = p.id
             WHERE " . implode(' AND ', $where) . '
             ORDER BY p.code ASC',
            array_merge([$fromDate, $fromDate, $toDate], $params)
        )->fetchAll();
    }
}
