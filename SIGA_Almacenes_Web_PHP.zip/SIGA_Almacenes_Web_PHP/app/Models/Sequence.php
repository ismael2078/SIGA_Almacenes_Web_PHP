<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de los códigos correlativos.

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use App\Core\Model;

final class Sequence extends Model
{
    protected static string $table = 'sequences';

    /**
     * Siguiente correlativo atómico sin huecos por clave y gestión.
     */
    public static function next(string $key, int $year): string
    {
        $pdo = Database::connection();
        $ownTransaction = !$pdo->inTransaction();
        if ($ownTransaction) {
            // Inicia una transacción: todas las escrituras de esta operación deben confirmarse juntas.
            $pdo->beginTransaction();
        }
        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            self::query(
                'INSERT INTO sequences (sequence_key, year, current_value) VALUES (?, ?, 1)
                 ON DUPLICATE KEY UPDATE current_value = current_value + 1',
                [$key, $year]
            );
            $current = (int) self::scalar(
                'SELECT current_value FROM sequences WHERE sequence_key = ? AND year = ?',
                [$key, $year]
            );
            if ($ownTransaction) {
                // Confirma los cambios después de completar las validaciones y registros.
                $pdo->commit();
            }
        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (\Throwable $e) {
            if ($ownTransaction && $pdo->inTransaction()) {
                // Revierte los cambios pendientes si alguna etapa no se completó correctamente.
                $pdo->rollBack();
            }
            throw $e;
        }
        return $key . '-' . $year . '-' . str_pad((string) $current, 6, '0', STR_PAD_LEFT);
    }
}
