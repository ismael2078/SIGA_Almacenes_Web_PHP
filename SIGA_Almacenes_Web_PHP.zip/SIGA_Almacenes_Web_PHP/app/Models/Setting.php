<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de los parámetros del sistema.
namespace App\Models;

use App\Core\Model;

class Setting extends Model {
    protected string $table = 'settings';
    protected string $primaryKey = 'key';

    // Recupera un valor de configuración o sesión.
    public function get(string $key, $default = null) {
        $row = $this->findBy('key', $key);
        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if ($row && !empty($row['value'])) {
            $decoded = json_decode($row['value'], true);
            return $decoded['value'] ?? $decoded;
        }
        return $default;
    }

    // Guarda el valor indicado en la configuración o sesión.
    public function set(string $key, $value): void {
        $json = json_encode(['value' => $value], JSON_UNESCAPED_UNICODE);
        $exists = $this->findBy('key', $key);
        if ($exists) {
            $this->query("UPDATE settings SET `value` = ? WHERE `key` = ?", [$json, $key]);
        } else {
            $this->query("INSERT INTO settings (`key`, `value`) VALUES (?, ?)", [$key, $json]);
        }
    }
}
