<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de las subcategorías de productos.
namespace App\Models;

use App\Core\Model;

class Subcategory extends Model {
    protected string $table = 'subcategories';

    // Devuelve una lista enriquecida con relaciones y datos descriptivos de las subcategorías de productos.
    public function getDetailedList(): array {
        $sql = "
            SELECT s.*, c.name AS category_name, c.code AS category_code
            FROM subcategories s
            INNER JOIN categories c ON c.id = s.category_id
            ORDER BY c.name ASC, s.name ASC
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql);
    }
}
