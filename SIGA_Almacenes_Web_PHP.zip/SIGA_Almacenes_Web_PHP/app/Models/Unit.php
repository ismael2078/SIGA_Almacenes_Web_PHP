<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de las unidades de medida.
namespace App\Models;

use App\Core\Model;

class Unit extends Model {
    protected string $table = 'units';
}
