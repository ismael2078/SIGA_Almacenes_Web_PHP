<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de los datos de la sesión.

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Session extends Model
{
    protected static string $table = 'sessions';

    // Elimina las sesiones vencidas o revocadas.
    public static function purgeExpired(): void
    {
        self::query('DELETE FROM sessions WHERE expires_at < NOW() OR revoked_at IS NOT NULL');
    }
}
