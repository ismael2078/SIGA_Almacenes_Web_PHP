<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de los arqueos de productos.

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use App\Core\Model;
use RuntimeException;

final class PhysicalCount extends Model
{
    protected static string $table = 'physical_counts';

    /** @return array<int,array<string,mixed>> */
    public static function allOrdered(): array
    {
        return self::query(
            'SELECT pc.*, u.full_name AS created_by_name
             FROM physical_counts pc LEFT JOIN users u ON u.id = pc.created_by
             ORDER BY pc.count_date DESC, pc.id DESC LIMIT 100'
        )->fetchAll();
    }

    /** @return array<int,array<string,mixed>> */
    public static function items(int $countId): array
    {
        return self::query(
            'SELECT pci.*, p.code AS product_code, p.name AS product_name, u.code AS unit_code
             FROM physical_count_items pci
             INNER JOIN products p ON p.id = pci.product_id
             LEFT JOIN units u ON u.id = p.unit_id
             WHERE pci.count_id = ? ORDER BY p.code ASC',
            [$countId]
        )->fetchAll();
    }

    /**
     * @param array<int,array{product_id:int,counted_qty:float,observations?:string}> $items
     */
    public static function register(array $user, int $year, int $month, string $participants, array $items): array
    {
        if ($items === []) {
            throw new RuntimeException('Debe registrar al menos un producto contado.');
        }
        return Database::transaction(static function () use ($user, $year, $month, $participants, $items): array {
            $countId = self::insert([
                'period_year' => $year,
                'period_month' => $month,
                'count_date' => date('Y-m-d H:i:s'),
                'participants' => $participants !== '' ? json_encode(['detalle' => $participants], JSON_UNESCAPED_UNICODE) : null,
                'status' => 'REGISTRADO',
                'created_by' => (int) $user['id'],
            ]);

            // Procesa cada producto por separado para registrar o calcular su movimiento.
            foreach ($items as $item) {
                $product = Product::find((int) $item['product_id']);
                // Comprueba el resultado recibido y evita continuar con datos inexistentes.
                if ($product === null) {
                    continue;
                }
                $systemQty = (float) $product['stock_qty'];
                $countedQty = (float) $item['counted_qty'];
                $difference = $countedQty - $systemQty;
                $unitCost = (float) $product['reference_cost'];
                self::query(
                    'INSERT INTO physical_count_items
                     (count_id, product_id, system_qty, counted_qty, difference, unit_cost, difference_value, observations)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                    [
                        $countId,
                        (int) $item['product_id'],
                        number_format($systemQty, 3, '.', ''),
                        number_format($countedQty, 3, '.', ''),
                        number_format($difference, 3, '.', ''),
                        number_format($unitCost, 4, '.', ''),
                        number_format($difference * $unitCost, 2, '.', ''),
                        $item['observations'] ?? null,
                    ]
                );
            }

            return ['id' => $countId];
        });
    }
}
