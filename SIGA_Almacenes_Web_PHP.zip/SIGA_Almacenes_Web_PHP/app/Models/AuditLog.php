<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de los eventos de auditoría.
namespace App\Models;

use App\Core\Model;

class AuditLog extends Model {
    protected string $table = 'audit_log';

    // Devuelve una lista enriquecida con relaciones y datos descriptivos de los eventos de auditoría.
    public function getDetailedList(int $limit = 100): array {
        $sql = "
            SELECT a.*, u.full_name AS user_name, u.username
            FROM audit_log a
            LEFT JOIN users u ON u.id = a.user_id
            ORDER BY a.id DESC
            LIMIT " . (int)$limit;
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql);
    }
}
