<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de las salidas de productos.
namespace App\Models;

use App\Core\Model;

class StockDispatch extends Model {
    protected string $table = 'stock_dispatches';

    // Devuelve una lista enriquecida con relaciones y datos descriptivos de las salidas de productos.
    public function getDetailedList(): array {
        $sql = "
            SELECT d.*, r.code AS request_code, r.correspondence_number,
                   u.full_name AS dispatcher_name,
                   (SELECT COUNT(*) FROM dispatch_items di WHERE di.dispatch_id = d.id) AS items_count
            FROM stock_dispatches d
            LEFT JOIN requests r ON r.id = d.request_id
            LEFT JOIN users u ON u.id = d.dispatched_by
            ORDER BY d.id DESC
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql);
    }

    // Recupera un registro con sus datos relacionados de las salidas de productos.
    public function getWithDetails(int $id): ?array {
        $sql = "
            SELECT d.*, r.code AS request_code, r.correspondence_number, r.office, r.justification,
                   u.full_name AS dispatcher_name,
                   req_user.full_name AS applicant_name, req_user.position AS applicant_position,
                   area.name AS area_name
            FROM stock_dispatches d
            LEFT JOIN requests r ON r.id = d.request_id
            LEFT JOIN users u ON u.id = d.dispatched_by
            LEFT JOIN users req_user ON req_user.id = r.applicant_id
            LEFT JOIN areas area ON area.id = r.area_id
            WHERE d.id = ?
            LIMIT 1
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchOne($sql, [$id]);
    }

    // Consulta el detalle de productos relacionados con las salidas de productos.
    public function getItems(int $dispatchId): array {
        $sql = "
            SELECT di.*, p.code AS product_code, p.name AS product_name, u.name AS unit_name
            FROM dispatch_items di
            INNER JOIN products p ON p.id = di.product_id
            LEFT JOIN units u ON u.id = p.unit_id
            WHERE di.dispatch_id = ?
            ORDER BY di.id ASC
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql, [$dispatchId]);
    }
}
