<?php
// Gestiona las consultas y registros asociados con la base de datos. Se ocupa de los movimientos históricos de inventario.
namespace App\Models;

use App\Core\Model;

class KardexMovement extends Model {
    protected string $table = 'kardex_movements';

    // Recupera los movimientos históricos de un producto.
    public function getProductMovements(int $productId): array {
        $sql = "
            SELECT k.*, p.code AS product_code, p.name AS product_name, u.name AS unit_name
            FROM kardex_movements k
            INNER JOIN products p ON p.id = k.product_id
            LEFT JOIN units u ON u.id = p.unit_id
            WHERE k.product_id = ?
            ORDER BY k.movement_date ASC, k.id ASC
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql, [$productId]);
    }

    // Prepara un resumen consultable de los movimientos históricos de inventario.
    public function getSummaryList(): array {
        $sql = "
            SELECT 
                p.id AS product_id, p.code, p.name, p.reference_cost, p.stock_qty, p.stock_value,
                c.name AS category_name, u.name AS unit_name,
                COALESCE(SUM(k.qty_in), 0) AS total_qty_in,
                COALESCE(SUM(k.total_in), 0) AS total_val_in,
                COALESCE(SUM(k.qty_out), 0) AS total_qty_out,
                COALESCE(SUM(k.total_out), 0) AS total_val_out
            FROM products p
            LEFT JOIN categories c ON c.id = p.category_id
            LEFT JOIN units u ON u.id = p.unit_id
            LEFT JOIN kardex_movements k ON k.product_id = p.id
            GROUP BY p.id, p.code, p.name, p.reference_cost, p.stock_qty, p.stock_value, c.name, u.name
            ORDER BY p.name ASC
        ";
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->fetchAll($sql);
    }
}
