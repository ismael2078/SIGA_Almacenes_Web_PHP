<!-- Vista de auditoría: presenta la pantalla de listado y búsqueda y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Bitácora de Auditoría</h3>
        <p class="text-muted mb-0 fs-7">Registro inmutable de actividades, transacciones y eventos de seguridad</p>
    </div>
</div>

<div class="card shadow-sm">
    <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <span><i class="bi bi-shield-check me-2 text-success"></i>Eventos Registrados en Bitácora</span>
        <span class="badge bg-light text-dark border"><?= count($logs) ?> registros recientes</span>
    </div>
    <div class="card-body p-0">
        <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
        <div class="table-responsive">
            <!-- La tabla presenta los registros obtenidos por el controlador. -->
            <table class="table table-hover align-middle mb-0 fs-8">
                <thead class="table-light">
                    <tr>
                        <th style="width: 140px;">Fecha / Hora</th>
                        <th>Usuario</th>
                        <th>Acción Ejecutada</th>
                        <th>Entidad Afectada</th>
                        <th>ID Entidad</th>
                        <th>Dirección IP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                        <tr><td colspan="6" class="text-center text-muted py-4">No hay eventos en la bitácora de auditoría.</td></tr>
                    <?php else: ?>
                        <?php foreach ($logs as $l): ?>
                            <tr>
                                <td><?= date('d/m/Y H:i:s', strtotime($l['created_at'])) ?></td>
                                <td>
                                    <strong><?= htmlspecialchars($l['user_name'] ?? 'Sistema / Visitante') ?></strong>
                                    <?php if (!empty($l['username'])): ?>
                                        <small class="text-muted d-block">(<?= htmlspecialchars($l['username']) ?>)</small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-secondary-subtle text-dark border font-monospace"><?= htmlspecialchars($l['action']) ?></span>
                                </td>
                                <td><?= htmlspecialchars($l['entity'] ?? '-') ?></td>
                                <td><?= htmlspecialchars((string)($l['entity_id'] ?? '-')) ?></td>
                                <td class="text-muted"><?= htmlspecialchars($l['ip'] ?? '127.0.0.1') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
