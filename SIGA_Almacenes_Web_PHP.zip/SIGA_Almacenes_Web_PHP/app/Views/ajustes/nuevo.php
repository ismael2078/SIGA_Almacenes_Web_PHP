<!-- Vista de ajustes de existencias: presenta la pantalla de registro nuevo y sus controles. -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Registrar Ajuste Físico de Inventario</h3>
        <p class="text-muted mb-0 fs-7">Corrección formal de sobrantes o faltantes con acta de respaldo</p>
    </div>
    <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/ajustes" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left me-1"></i> Volver
    </a>
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form action="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/ajustes/guardar" method="POST">
            <?= csrf_field() ?>
    <div class="row g-4">
        <div class="col-12 col-lg-4">
            <div class="card shadow-sm mb-4">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header bg-navy text-white">
                    <i class="bi bi-info-circle me-2"></i>Datos del Acta de Ajuste
                </div>
                <div class="card-body fs-7 p-3">
                    <div class="mb-3">
                        <label class="form-label fw-semibold text-secondary mb-1">Tipo de Ajuste *</label>
                        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                        <select name="type" class="form-select form-select-sm" required>
                            <option value="FALTANTE">Faltante de Inventario (Merma / Pérdida)</option>
                            <option value="SOBRANTE">Sobrante de Inventario (Excedente detectado)</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold text-danger mb-1">N° de Acta de Conciliación *</label>
                        <input type="text" name="act_number" class="form-control form-control-sm" required placeholder="Ej: ACTA-AJ-2026-002">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold text-secondary mb-1">Fecha del Ajuste</label>
                        <input type="date" name="adjustment_date" class="form-control form-control-sm" value="<?= date('Y-m-d') ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold text-secondary mb-1">Motivo / Causa Detallada *</label>
                        <textarea name="reason" class="form-control form-control-sm" rows="3" required placeholder="Describa el motivo del descalce físico..."></textarea>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-lg-8">
            <div class="card shadow-sm">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-boxes me-2 text-primary"></i>Artículos a Ajustar</span>
                    <button type="button" class="btn btn-primary btn-sm" id="btnAgregarItemAjuste">
                        <i class="bi bi-plus-lg me-1"></i>Agregar Producto
                    </button>
                </div>
                <div class="card-body p-0">
                    <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                    <div class="table-responsive">
                        <!-- La tabla presenta los registros obtenidos por el controlador. -->
                        <table class="table table-bordered align-middle mb-0 fs-7" id="tablaItemsAjuste">
                            <thead class="table-light">
                                <tr>
                                    <th style="min-width: 250px;">Producto</th>
                                    <th style="width: 120px;" class="text-center">Cantidad *</th>
                                    <th style="width: 130px;" class="text-center">Costo Unit. (Bs) *</th>
                                    <th>Observación</th>
                                    <th style="width: 45px;"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Dinámica -->
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer bg-white d-flex justify-content-between align-items-center p-3">
                    <span class="text-muted fs-8">El ajuste requerirá aprobación para impactar en Kardex.</span>
                    <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                    <button type="submit" class="btn btn-secondary px-4 fw-semibold shadow-sm">
                        <i class="bi bi-save me-1"></i>Enviar Ajuste a Revisión
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const products = <?= json_encode($products) ?>;

    function addAjusteRow() {
        const tbody = document.querySelector('#tablaItemsAjuste tbody');
        const idx = tbody.children.length;
        const tr = document.createElement('tr');

        let options = '<option value="">-- Seleccionar producto --</option>';
        products.forEach(p => {
            options += `<option value="${p.id}" data-cost="${p.reference_cost}">${p.code} - ${p.name} (Stock: ${p.stock_qty})</option>`;
        });

        tr.innerHTML = `
            <td>
                <select name="items[${idx}][product_id]" class="form-select form-select-sm" required onchange="const cost = this.options[this.selectedIndex].getAttribute('data-cost') || '0'; document.getElementById('adj_cost_${idx}').value = parseFloat(cost).toFixed(4);">
                    ${options}
                </select>
            </td>
            <td>
                <input type="number" step="1" min="1" name="items[${idx}][qty]" class="form-control form-control-sm text-end" required value="1">
            </td>
            <td>
                <input type="number" step="0.0001" min="0.0001" name="items[${idx}][unit_cost]" id="adj_cost_${idx}" class="form-control form-control-sm text-end" required value="0.0000">
            </td>
            <td>
                <input type="text" name="items[${idx}][notes]" class="form-control form-control-sm" placeholder="Detalle">
            </td>
            <td class="text-center">
                <button type="button" class="btn btn-outline-danger btn-sm" onclick="this.closest('tr').remove()"><i class="bi bi-trash"></i></button>
            </td>
        `;
        tbody.appendChild(tr);
    }

    addAjusteRow();
    document.getElementById('btnAgregarItemAjuste').addEventListener('click', addAjusteRow);
});
</script>
