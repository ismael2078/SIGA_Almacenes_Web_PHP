<!-- Vista de ajustes de existencias: presenta la pantalla de listado y búsqueda y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Ajustes de Inventario</h3>
        <p class="text-muted mb-0 fs-7">Conciliación de faltantes y sobrantes mediante aprobación tripartita</p>
    </div>
    <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/ajustes/nuevo" class="btn btn-secondary shadow-sm">
        <i class="bi bi-plus-circle me-2"></i>Registrar Ajuste
    </a>
</div>

<div class="card shadow-sm">
    <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <span><i class="bi bi-sliders me-2 text-primary"></i>Historial de Ajustes</span>
        <span class="badge bg-light text-dark border"><?= count($adjustments) ?> ajustes</span>
    </div>
    <div class="card-body p-0">
        <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
        <div class="table-responsive">
            <!-- La tabla presenta los registros obtenidos por el controlador. -->
            <table class="table table-hover align-middle mb-0 fs-7">
                <thead class="table-light">
                    <tr>
                        <th>Número</th>
                        <th>Tipo</th>
                        <th>Motivo / Acta</th>
                        <th>Fecha Ajuste</th>
                        <th>Registrado por</th>
                        <th class="text-center">Ítems</th>
                        <th class="text-center">Estado</th>
                        <th class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($adjustments)): ?>
                        <tr><td colspan="8" class="text-center text-muted py-5">No hay ajustes registrados.</td></tr>
                    <?php else: ?>
                        <?php foreach ($adjustments as $a): ?>
                            <tr>
                                <td class="fw-bold text-navy"><?= htmlspecialchars($a['number']) ?></td>
                                <td>
                                    <span class="badge <?= ($a['type'] === 'SOBRANTE') ? 'bg-success' : 'bg-danger' ?>">
                                        <?= htmlspecialchars($a['type']) ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="fw-semibold"><?= htmlspecialchars($a['reason']) ?></div>
                                    <small class="text-muted">Acta: <?= htmlspecialchars($a['act_number'] ?? '-') ?></small>
                                </td>
                                <td><?= date('d/m/Y', strtotime($a['adjustment_date'])) ?></td>
                                <td><?= htmlspecialchars($a['creator_name']) ?></td>
                                <td class="text-center"><span class="badge bg-light text-dark border"><?= $a['items_count'] ?></span></td>
                                <td class="text-center">
                                    <span class="badge <?= ($a['status'] === 'APROBADO') ? 'bg-success' : 'bg-warning text-dark' ?>">
                                        <?= htmlspecialchars($a['status']) ?>
                                    </span>
                                </td>
                                <td class="text-end">
                                    <?php if ($a['status'] === 'EN_REVISION'): ?>
                                    <!-- El formulario recibe los datos que procesará el controlador. -->
                                    <form action="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/ajustes/<?= $a['id'] ?>/aprobar" method="POST" class="d-inline" onsubmit="return confirm('¿Aprobar el ajuste y aplicar su efecto contable en PEPS y Kardex?')">
            <?= csrf_field() ?>
                                        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                                        <button type="submit" class="btn btn-outline-success btn-sm py-0 px-2 fs-8">
                                            <i class="bi bi-check2 me-1"></i>Aprobar Firma
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
