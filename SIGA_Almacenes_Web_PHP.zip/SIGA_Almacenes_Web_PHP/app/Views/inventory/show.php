<?php
// Vista de catálogo de productos: presenta la pantalla de detalle del registro y sus controles.
/** @var array<string,mixed> $product */
/** @var array<int,array<string,mixed>> $layers */
/** @var array<int,array<string,mixed>> $movements */
/** @var bool $canValues */
?>
<div class="page-head">
    <div>
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <h1 class="page-title mb-0"><?= e($product['name']) ?></h1>
            <?= status_badge((string) $product['status']) ?>
        </div>
        <p class="page-sub">
            <span class="mono"><?= e($product['code']) ?></span> ·
            <?= e($product['category_name']) ?> / <?= e($product['subcategory_name']) ?> ·
            <?= e($product['unit_name'] ?? $product['unit_code']) ?>
        </p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <a href="<?= e(url('/inventario')) ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Inventario</a>
        <?php if (can('productos.editar')): ?>
            <a href="<?= e(url('/inventario/' . $product['id'] . '/editar')) ?>" class="btn btn-primary"><i class="bi bi-pencil me-1"></i>Editar</a>
        <?php endif; ?>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-8">
        <div class="card">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-info-circle me-1"></i>Ficha del producto</div>
            <div class="card-body">
                <div class="detail-grid">
                    <div class="detail-item"><div class="label">Código</div><div class="value mono"><?= e($product['code']) ?></div></div>
                    <div class="detail-item"><div class="label">Ubicación</div><div class="value"><?= e($product['location_name'] ?? 'Sin ubicación') ?></div></div>
                    <div class="detail-item"><div class="label">Marca / modelo</div><div class="value"><?= e(trim(($product['brand'] ?? '') . ' ' . ($product['model'] ?? '')) ?: '—') ?></div></div>
                    <div class="detail-item"><div class="label">Código de barras</div><div class="value mono"><?= e($product['barcode'] ?? '—') ?></div></div>
                    <div class="detail-item"><div class="label">Stock mínimo</div><div class="value"><?= e(qty($product['min_stock'])) ?> <?= e($product['unit_code']) ?></div></div>
                    <div class="detail-item"><div class="label">Stock máximo</div><div class="value"><?= e(qty($product['max_stock'])) ?> <?= e($product['unit_code']) ?></div></div>
                    <div class="detail-item"><div class="label">Costo de referencia</div><div class="value"><?= $canValues ? 'Bs ' . e(money($product['reference_cost'], 4)) : '—' ?></div></div>
                    <div class="detail-item"><div class="label">Creado</div><div class="value"><?= e(fecha($product['created_at'] ?? null)) ?></div></div>
                </div>
                <?php if (!empty($product['description'])): ?>
                    <hr>
                    <p class="mb-0 small text-muted"><?= e($product['description']) ?></p>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mt-3">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-layers me-1"></i>Capas PEPS</span>
                <span class="badge badge-soft"><?= count($layers) ?> capas</span>
            </div>
            <div class="card-body p-0">
                <?php if ($layers === []): ?>
                    <div class="empty-state"><i class="bi bi-layers"></i>El producto aún no tiene capas de inventario.</div>
                <?php else: ?>
                    <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                    <div class="table-responsive">
                        <!-- La tabla presenta los registros obtenidos por el controlador. -->
                        <table class="table table-hover mb-0">
                            <thead><tr><th>#</th><th>Fecha capa</th><th>Ingreso</th><th class="num">Original</th><th class="num">Disponible</th><th class="num">Costo unit.</th><th class="num">Valor disp.</th><th>Estado</th></tr></thead>
                            <tbody>
                                <?php foreach ($layers as $index => $layer): ?>
                                    <tr>
                                        <td><?= e($index + 1) ?></td>
                                        <td class="small"><?= e(fecha($layer['layer_date'])) ?></td>
                                        <td class="small mono"><?= e($layer['entry_number'] ?? 'Ajuste') ?></td>
                                        <td class="num"><?= e(qty($layer['original_qty'])) ?></td>
                                        <td class="num fw-semibold"><?= e(qty($layer['remaining_qty'])) ?></td>
                                        <td class="num"><?= $canValues ? e(money($layer['unit_cost'], 4)) : '—' ?></td>
                                        <td class="num"><?= $canValues ? e(money((float) $layer['remaining_qty'] * (float) $layer['unit_cost'])) : '—' ?></td>
                                        <td><?= status_badge((string) $layer['status']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mt-3">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-clock-history me-1"></i>Kardex del producto</div>
            <div class="card-body p-0">
                <?php if ($movements === []): ?>
                    <div class="empty-state"><i class="bi bi-journal-text"></i>No hay movimientos registrados.</div>
                <?php else: ?>
                    <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                    <div class="table-responsive">
                        <!-- Tabla de inventario: organiza los registros y sus acciones visibles. -->
                        <table class="table table-sm table-hover mb-0">
                            <thead><tr><th>Fecha</th><th>Tipo</th><th>Referencia</th><th class="num">Entrada</th><th class="num">Salida</th><th class="num">Costo unit.</th><th class="num">Saldo cant.</th><th class="num">Saldo valor</th></tr></thead>
                            <tbody>
                                <?php foreach ($movements as $movement): ?>
                                    <tr>
                                        <td class="small"><?= e(fecha($movement['movement_date'])) ?></td>
                                        <td><span class="badge badge-soft"><?= e(doc_type_label((string) $movement['doc_type'])) ?></span></td>
                                        <td class="small mono"><?= e($movement['reference'] ?? '—') ?></td>
                                        <td class="num text-success"><?= (float) $movement['qty_in'] > 0 ? e(qty($movement['qty_in'])) : '—' ?></td>
                                        <td class="num text-danger"><?= (float) $movement['qty_out'] > 0 ? e(qty($movement['qty_out'])) : '—' ?></td>
                                        <td class="num"><?= $canValues ? e(money((float) $movement['unit_cost_in'] > 0 ? $movement['unit_cost_in'] : $movement['unit_cost_out'], 4)) : '—' ?></td>
                                        <td class="num"><?= e(qty($movement['balance_qty'])) ?></td>
                                        <td class="num"><?= $canValues ? e(money($movement['balance_value'])) : '—' ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-bar-chart me-1"></i>Existencias y valuación</div>
            <div class="card-body">
                <div class="text-center py-2">
                    <div class="text-muted small text-uppercase">Stock disponible</div>
                    <div class="display-6 fw-bold" style="color: var(--siga-primary);"><?= e(qty($product['stock_qty'])) ?></div>
                    <div class="text-muted"><?= e($product['unit_name'] ?? $product['unit_code']) ?></div>
                </div>
                <hr>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted small">Valor total</span>
                    <span class="fw-bold"><?= $canValues ? 'Bs ' . e(money($product['stock_value'])) : '—' ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted small">Costo promedio</span>
                    <span class="fw-semibold"><?= $canValues && (float) $product['stock_qty'] > 0 ? 'Bs ' . e(money((float) $product['stock_value'] / (float) $product['stock_qty'], 4)) : '—' ?></span>
                </div>
                <div class="d-flex justify-content-between">
                    <span class="text-muted small">Capas abiertas</span>
                    <span class="fw-semibold"><?= e(count(array_filter($layers, static fn (array $layer): bool => $layer['status'] === 'ABIERTA'))) ?></span>
                </div>
            </div>
        </div>

        <div class="card mt-3">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-signpost-split me-1"></i>Acciones</div>
            <div class="card-body d-grid gap-2">
                <?php if (can('ingresos.crear')): ?>
                    <a class="btn btn-outline-primary" href="<?= e(url('/ingresos/nuevo')) ?>"><i class="bi bi-box-arrow-in-down me-1"></i>Registrar ingreso</a>
                <?php endif; ?>
                <?php if (can('ajustes.crear')): ?>
                    <a class="btn btn-outline-primary" href="<?= e(url('/ajustes/nuevo')) ?>"><i class="bi bi-sliders me-1"></i>Registrar ajuste</a>
                <?php endif; ?>
                <?php if (can('reportes.ver')): ?>
                    <a class="btn btn-outline-secondary" href="<?= e(url('/reportes/kardex?search=' . urlencode((string) $product['code']))) ?>"><i class="bi bi-journal-text me-1"></i>Ver kardex completo</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
