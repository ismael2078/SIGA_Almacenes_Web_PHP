<?php
// Vista de catálogo de productos: presenta la pantalla de listado y búsqueda y sus controles.
/** @var array<string,mixed> $filters */
/** @var array{items:array<int,array<string,mixed>>,total:int,page:int,pages:int} $result */
/** @var array<int,array<string,mixed>> $categories */
/** @var array<string,mixed> $stats */
/** @var bool $canValues */
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Inventario de productos</h1>
        <p class="page-sub"><?= e($result['total']) ?> productos · existencias, costos y capas PEPS</p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <?php if (can('productos.crear')): ?>
            <a href="<?= e(url('/inventario/nuevo')) ?>" class="btn btn-primary">
                <i class="bi bi-plus-lg me-1"></i>Nuevo producto
            </a>
        <?php endif; ?>
        <?php if (can('reportes.ver')): ?>
            <a href="<?= e(url('/reportes/inventario')) ?>" class="btn btn-outline-primary">
                <i class="bi bi-file-earmark-arrow-down me-1"></i>Exportar
            </a>
        <?php endif; ?>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-6 col-lg-3">
        <div class="stat-card"><div class="stat-icon"><i class="bi bi-box-seam"></i></div><div class="stat-value"><?= e((int) ($stats['total'] ?? 0)) ?></div><div class="stat-label">Productos</div></div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card success"><div class="stat-icon"><i class="bi bi-check2-circle"></i></div><div class="stat-value"><?= e((int) ($stats['with_stock'] ?? 0)) ?></div><div class="stat-label">Con existencia</div></div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card danger"><div class="stat-icon"><i class="bi bi-exclamation-triangle"></i></div><div class="stat-value"><?= e((int) ($stats['low_stock'] ?? 0)) ?></div><div class="stat-label">Stock bajo</div></div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card gold"><div class="stat-icon"><i class="bi bi-cash-stack"></i></div><div class="stat-value"><?= $canValues ? e(money($stats['total_value'] ?? 0)) : '—' ?></div><div class="stat-label">Valor total (Bs)</div></div>
    </div>
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form class="filter-bar row g-2 align-items-end" method="get" action="<?= e(url('/inventario')) ?>">
    <div class="col-md-4">
        <label class="form-label">Buscar</label>
        <input type="text" class="form-control" name="search" value="<?= e($filters['search']) ?>" placeholder="Código, nombre o descripción">
    </div>
    <div class="col-md-3">
        <label class="form-label">Categoría</label>
        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
        <select class="form-select" name="category">
            <option value="">Todas las categorías</option>
            <?php foreach ($categories as $category): ?>
                <option value="<?= e($category['id']) ?>" <?= selected($filters['category'], $category['id']) ?>><?= e($category['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-2">
        <label class="form-label">Estado</label>
        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
        <select class="form-select" name="status">
            <option value="">Todos</option>
            <option value="ACTIVO" <?= selected($filters['status'], 'ACTIVO') ?>>Activo</option>
            <option value="INACTIVO" <?= selected($filters['status'], 'INACTIVO') ?>>Inactivo</option>
            <option value="ARCHIVADO" <?= selected($filters['status'], 'ARCHIVADO') ?>>Archivado</option>
        </select>
    </div>
    <div class="col-md-2">
        <label class="form-label">Alertas</label>
        <div class="d-flex flex-column gap-1 pt-1">
            <div class="form-check mb-0">
                <input class="form-check-input" type="checkbox" name="low_stock" value="1" id="filterLowStock" <?= checked($filters['low_stock']) ?>>
                <label class="form-check-label small" for="filterLowStock">Stock bajo</label>
            </div>
            <div class="form-check mb-0">
                <input class="form-check-input" type="checkbox" name="no_stock" value="1" id="filterNoStock" <?= checked($filters['no_stock']) ?>>
                <label class="form-check-label small" for="filterNoStock">Sin stock</label>
            </div>
        </div>
    </div>
    <div class="col-md-1 d-grid">
        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
        <button class="btn btn-primary" type="submit"><i class="bi bi-search"></i></button>
    </div>
</form>

<div class="card">
    <div class="card-body p-0">
        <?php if ($result['items'] === []): ?>
            <div class="empty-state"><i class="bi bi-box"></i>No se encontraron productos con los filtros seleccionados.</div>
        <?php else: ?>
            <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
            <div class="table-responsive">
                <!-- La tabla presenta los registros obtenidos por el controlador. -->
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Producto</th>
                            <th>Categoría / subcategoría</th>
                            <th>Unidad</th>
                            <th class="num">Stock</th>
                            <th class="num">Mínimo</th>
                            <?php if ($canValues): ?><th class="num">Valor</th><?php endif; ?>
                            <th>Estado</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($result['items'] as $product): ?>
                            <tr>
                                <td class="mono fw-semibold"><?= e($product['code']) ?></td>
                                <td>
                                    <a href="<?= e(url('/inventario/' . $product['id'])) ?>" class="fw-semibold text-dark"><?= e($product['name']) ?></a>
                                    <div class="small text-muted"><?= e($product['location_code'] ?? 'Sin ubicación') ?></div>
                                </td>
                                <td class="small">
                                    <div><?= e($product['category_name']) ?></div>
                                    <div class="text-muted"><?= e($product['subcategory_name']) ?></div>
                                </td>
                                <td class="small"><?= e($product['unit_code']) ?></td>
                                <td class="num <?= (float) $product['stock_qty'] <= 0 ? 'text-danger' : ((float) $product['stock_qty'] <= (float) $product['min_stock'] ? 'text-warning' : '') ?>">
                                    <span class="fw-semibold"><?= e(qty($product['stock_qty'])) ?></span>
                                </td>
                                <td class="num text-muted"><?= e(qty($product['min_stock'])) ?></td>
                                <?php if ($canValues): ?><td class="num"><?= e(money($product['stock_value'])) ?></td><?php endif; ?>
                                <td><?= status_badge((string) $product['status']) ?></td>
                                <td class="text-end">
                                    <a class="btn btn-sm btn-outline-primary" href="<?= e(url('/inventario/' . $product['id'])) ?>" title="Ver detalle">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <?php if (can('productos.editar')): ?>
                                        <a class="btn btn-sm btn-outline-secondary" href="<?= e(url('/inventario/' . $product['id'] . '/editar')) ?>" title="Editar">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
    <?php if ($result['pages'] > 1): ?>
        <?php
        $query = array_filter([
            'search' => $filters['search'],
            'category' => $filters['category'],
            'status' => $filters['status'],
            'low_stock' => $filters['low_stock'],
            'no_stock' => $filters['no_stock'],
        ], static fn ($value): bool => $value !== '' && $value !== 0 && $value !== null);
        ?>
        <div class="card-footer bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
            <span class="small text-muted">Página <?= e($result['page']) ?> de <?= e($result['pages']) ?></span>
            <!-- Menú de navegación: muestra accesos a secciones según el usuario. -->
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <li class="page-item <?= $result['page'] <= 1 ? 'disabled' : '' ?>">
                        <a class="page-link" href="<?= e(url('/inventario?' . http_build_query($query + ['page' => max(1, $result['page'] - 1)]))) ?>">Anterior</a>
                    </li>
                    <?php for ($p = max(1, $result['page'] - 2); $p <= min($result['pages'], $result['page'] + 2); $p++): ?>
                        <li class="page-item <?= $p === $result['page'] ? 'active' : '' ?>">
                            <a class="page-link" href="<?= e(url('/inventario?' . http_build_query($query + ['page' => $p]))) ?>"><?= e($p) ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= $result['page'] >= $result['pages'] ? 'disabled' : '' ?>">
                        <a class="page-link" href="<?= e(url('/inventario?' . http_build_query($query + ['page' => min($result['pages'], $result['page'] + 1)]))) ?>">Siguiente</a>
                    </li>
                </ul>
            </nav>
        </div>
    <?php endif; ?>
</div>
