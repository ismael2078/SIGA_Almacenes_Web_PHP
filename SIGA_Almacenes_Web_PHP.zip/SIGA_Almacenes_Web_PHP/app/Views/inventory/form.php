<?php
// Vista de catálogo de productos: presenta la pantalla de formulario del producto y sus controles.
/** @var array<string,mixed>|null $product */
/** @var array<int,array<string,mixed>> $categories */
/** @var array<int,array<string,mixed>> $subcategories */
/** @var array<int,array<string,mixed>> $units */
/** @var array<int,array<string,mixed>> $locations */
?>
<div class="page-head">
    <div>
        <h1 class="page-title"><?= $product === null ? 'Nuevo producto' : 'Editar producto' ?></h1>
        <p class="page-sub"><?= $product === null ? 'Registre un nuevo ítem en el catálogo de inventario' : 'Actualice los datos del producto ' . e($product['code']) ?></p>
    </div>
    <a href="<?= e(url($product === null ? '/inventario' : '/inventario/' . $product['id'])) ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i>Volver
    </a>
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form method="post" action="<?= e(url($product === null ? '/inventario' : '/inventario/' . $product['id'])) ?>">
    <?= csrf_field() ?>
    <div class="row g-3">
        <div class="col-lg-8">
            <div class="card">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header"><i class="bi bi-box-seam me-1"></i>Datos del producto</div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label" for="code">Código *</label>
                            <input type="text" class="form-control mono" id="code" name="code" required maxlength="30"
                                   value="<?= e($product['code'] ?? '') ?>" placeholder="PAP-HOJ-001">
                        </div>
                        <div class="col-md-8">
                            <label class="form-label" for="name">Nombre *</label>
                            <input type="text" class="form-control" id="name" name="name" required maxlength="200"
                                   value="<?= e($product['name'] ?? '') ?>" placeholder="Descripción del producto">
                        </div>
                        <div class="col-12">
                            <label class="form-label" for="description">Descripción</label>
                            <textarea class="form-control" id="description" name="description" rows="2"><?= e($product['description'] ?? '') ?></textarea>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="brand">Marca</label>
                            <input type="text" class="form-control" id="brand" name="brand" value="<?= e($product['brand'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="model">Modelo</label>
                            <input type="text" class="form-control" id="model" name="model" value="<?= e($product['model'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="barcode">Código de barras</label>
                            <input type="text" class="form-control" id="barcode" name="barcode" value="<?= e($product['barcode'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="category_id">Categoría *</label>
                            <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                            <select class="form-select" id="category_id" name="category_id" required>
                                <option value="">Seleccione...</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?= e($category['id']) ?>" <?= selected($product['category_id'] ?? '', $category['id']) ?>><?= e($category['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="subcategory_id">Subcategoría *</label>
                            <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                            <select class="form-select" id="subcategory_id" name="subcategory_id" required>
                                <option value="">Seleccione...</option>
                                <?php foreach ($subcategories as $subcategory): ?>
                                    <option value="<?= e($subcategory['id']) ?>" data-category="<?= e($subcategory['category_id']) ?>"
                                        <?= selected($product['subcategory_id'] ?? '', $subcategory['id']) ?>>
                                        <?= e($subcategory['category_name'] . ' · ' . $subcategory['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="unit_id">Unidad de medida *</label>
                            <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                            <select class="form-select" id="unit_id" name="unit_id" required>
                                <option value="">Seleccione...</option>
                                <?php foreach ($units as $unit): ?>
                                    <option value="<?= e($unit['id']) ?>" <?= selected($product['unit_id'] ?? '', $unit['id']) ?>><?= e($unit['code'] . ' · ' . $unit['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="location_id">Ubicación física</label>
                            <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                            <select class="form-select" id="location_id" name="location_id">
                                <option value="">Sin ubicación</option>
                                <?php foreach ($locations as $location): ?>
                                    <option value="<?= e($location['id']) ?>" <?= selected($product['location_id'] ?? '', $location['id']) ?>><?= e($location['code'] . ' · ' . $location['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="status">Estado</label>
                            <select class="form-select" id="status" name="status">
                                <option value="ACTIVO" <?= selected($product['status'] ?? 'ACTIVO', 'ACTIVO') ?>>Activo</option>
                                <option value="INACTIVO" <?= selected($product['status'] ?? '', 'INACTIVO') ?>>Inactivo</option>
                                <option value="ARCHIVADO" <?= selected($product['status'] ?? '', 'ARCHIVADO') ?>>Archivado</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header"><i class="bi bi-calculator me-1"></i>Control de existencias</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label" for="min_stock">Stock mínimo</label>
                        <input type="number" step="1" min="0" class="form-control" id="min_stock" name="min_stock"
                               value="<?= e($product['min_stock'] ?? '0') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="max_stock">Stock máximo</label>
                        <input type="number" step="1" min="0" class="form-control" id="max_stock" name="max_stock"
                               value="<?= e($product['max_stock'] ?? '0') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="reference_cost">Costo de referencia (Bs)</label>
                        <input type="number" step="0.0001" min="0" class="form-control" id="reference_cost" name="reference_cost"
                               value="<?= e($product['reference_cost'] ?? '0') ?>">
                    </div>
                    <?php if ($product !== null): ?>
                        <div class="border-top pt-3 mt-3">
                            <div class="d-flex justify-content-between small">
                                <span class="text-muted">Stock actual</span>
                                <span class="fw-semibold"><?= e(qty($product['stock_qty'])) ?> <?= e($product['unit_code']) ?></span>
                            </div>
                            <div class="d-flex justify-content-between small">
                                <span class="text-muted">Valor actual</span>
                                <span class="fw-semibold">Bs <?= e(money($product['stock_value'])) ?></span>
                            </div>
                            <div class="form-text mt-2">El stock y su valor se modifican únicamente mediante ingresos, despachos y ajustes.</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="d-grid gap-2 mt-3">
                <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check2-circle me-1"></i><?= $product === null ? 'Crear producto' : 'Guardar cambios' ?>
                </button>
                <a href="<?= e(url($product === null ? '/inventario' : '/inventario/' . $product['id'])) ?>" class="btn btn-outline-secondary">Cancelar</a>
            </div>
        </div>
    </div>
</form>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const category = document.getElementById("category_id");
    const subcategory = document.getElementById("subcategory_id");
    if (!category || !subcategory) return;
    const filter = () => {
        const selectedCategory = category.value;
        Array.from(subcategory.options).forEach((option) => {
            if (!option.value) return;
            const belongs = !selectedCategory || option.dataset.category === selectedCategory;
            option.hidden = !belongs;
            if (!belongs && option.selected) {
                subcategory.value = "";
            }
        });
    };
    category.addEventListener("change", filter);
    filter();
});
</script>
