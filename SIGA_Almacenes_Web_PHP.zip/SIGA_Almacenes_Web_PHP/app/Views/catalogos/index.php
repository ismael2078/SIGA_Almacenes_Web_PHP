<!-- Vista de catálogos institucionales: presenta la pantalla de listado y búsqueda y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Catálogos Generales</h3>
        <p class="text-muted mb-0 fs-7">Estructura paramétrica institucional: categorías, unidades, ubicaciones, proveedores y áreas</p>
    </div>
</div>

<div class="card shadow-sm">
    <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
    <div class="card-header bg-white p-0">
        <ul class="nav nav-tabs card-header-tabs m-0 px-3" id="catalogoTabs" role="tablist">
            <li class="nav-item">
                <button class="nav-link active py-3" data-bs-toggle="tab" data-bs-target="#tabCategorias">
                    <i class="bi bi-tag me-1"></i>Categorías (<?= count($categories) ?>)
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link py-3" data-bs-toggle="tab" data-bs-target="#tabSubcategorias">
                    <i class="bi bi-tags me-1"></i>Subcategorías (<?= count($subcategories) ?>)
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link py-3" data-bs-toggle="tab" data-bs-target="#tabUnidades">
                    <i class="bi bi-rulers me-1"></i>Unidades (<?= count($units) ?>)
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link py-3" data-bs-toggle="tab" data-bs-target="#tabUbicaciones">
                    <i class="bi bi-geo-alt me-1"></i>Ubicaciones (<?= count($locations) ?>)
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link py-3" data-bs-toggle="tab" data-bs-target="#tabProveedores">
                    <i class="bi bi-truck me-1"></i>Proveedores (<?= count($suppliers) ?>)
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link py-3" data-bs-toggle="tab" data-bs-target="#tabAreas">
                    <i class="bi bi-diagram-2 me-1"></i>Áreas DDE (<?= count($areas) ?>)
                </button>
            </li>
        </ul>
    </div>
    <div class="card-body p-3">
        <div class="tab-content" id="catalogoTabsContent">
            <!-- Categorías -->
            <div class="tab-pane fade show active" id="tabCategorias">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- La tabla presenta los registros obtenidos por el controlador. -->
                    <table class="table table-hover align-middle fs-7">
                        <thead class="table-light"><tr><th>Código</th><th>Nombre de Categoría</th><th>Descripción</th><th>Estado</th></tr></thead>
                        <tbody>
                            <?php foreach ($categories as $c): ?>
                                <tr>
                                    <td class="fw-bold text-navy"><?= htmlspecialchars($c['code']) ?></td>
                                    <td class="fw-semibold"><?= htmlspecialchars($c['name']) ?></td>
                                    <td><?= htmlspecialchars($c['description'] ?? '') ?></td>
                                    <td><span class="badge bg-success">Activo</span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Subcategorías -->
            <div class="tab-pane fade" id="tabSubcategorias">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- Tabla de catálogos: organiza los registros y sus acciones visibles. -->
                    <table class="table table-hover align-middle fs-7">
                        <thead class="table-light"><tr><th>Código</th><th>Subcategoría</th><th>Categoría Principal</th><th>Estado</th></tr></thead>
                        <tbody>
                            <?php foreach ($subcategories as $sc): ?>
                                <tr>
                                    <td class="fw-bold text-navy"><?= htmlspecialchars($sc['code']) ?></td>
                                    <td class="fw-semibold"><?= htmlspecialchars($sc['name']) ?></td>
                                    <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($sc['category_name']) ?></span></td>
                                    <td><span class="badge bg-success">Activo</span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Unidades -->
            <div class="tab-pane fade" id="tabUnidades">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- Tabla de catálogos: organiza los registros y sus acciones visibles. -->
                    <table class="table table-hover align-middle fs-7">
                        <thead class="table-light"><tr><th>Código</th><th>Nombre</th><th>Estado</th></tr></thead>
                        <tbody>
                            <?php foreach ($units as $u): ?>
                                <tr>
                                    <td class="fw-bold text-navy"><?= htmlspecialchars($u['code']) ?></td>
                                    <td><?= htmlspecialchars($u['name']) ?></td>
                                    <td><span class="badge bg-success">Activo</span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Ubicaciones -->
            <div class="tab-pane fade" id="tabUbicaciones">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- Tabla de catálogos: organiza los registros y sus acciones visibles. -->
                    <table class="table table-hover align-middle fs-7">
                        <thead class="table-light"><tr><th>Código</th><th>Descripción de Ubicación / Estante</th><th>Estado</th></tr></thead>
                        <tbody>
                            <?php foreach ($locations as $l): ?>
                                <tr>
                                    <td class="fw-bold text-navy"><?= htmlspecialchars($l['code']) ?></td>
                                    <td><?= htmlspecialchars($l['name']) ?></td>
                                    <td><span class="badge bg-success">Activo</span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Proveedores -->
            <div class="tab-pane fade" id="tabProveedores">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <table class="table table-hover align-middle fs-7">
                        <thead class="table-light"><tr><th>NIT</th><th>Razón Social</th><th>Contacto</th><th>Teléfono</th><th>Email</th></tr></thead>
                        <tbody>
                            <?php foreach ($suppliers as $s): ?>
                                <tr>
                                    <td class="fw-bold text-navy"><?= htmlspecialchars($s['nit'] ?? '-') ?></td>
                                    <td class="fw-semibold"><?= htmlspecialchars($s['name']) ?></td>
                                    <td><?= htmlspecialchars($s['contact_name'] ?? '-') ?></td>
                                    <td><?= htmlspecialchars($s['phone'] ?? '-') ?></td>
                                    <td><?= htmlspecialchars($s['email'] ?? '-') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Áreas -->
            <div class="tab-pane fade" id="tabAreas">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <table class="table table-hover align-middle fs-7">
                        <thead class="table-light"><tr><th>Código</th><th>Nombre del Área / Unidad</th><th>Tipo</th><th>Dependencia Superior</th></tr></thead>
                        <tbody>
                            <?php foreach ($areas as $a): ?>
                                <tr>
                                    <td class="fw-bold text-navy"><?= htmlspecialchars($a['code']) ?></td>
                                    <td class="fw-semibold"><?= htmlspecialchars($a['name']) ?></td>
                                    <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($a['type']) ?></span></td>
                                    <td><?= htmlspecialchars($a['parent_name'] ?? 'Dirección Máxima') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
