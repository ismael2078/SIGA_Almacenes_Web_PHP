<?php
// Vista de solicitudes de materiales: presenta la pantalla de listado y búsqueda y sus controles.
/** @var array<int,array<string,mixed>> $requests */
/** @var string $scope */
/** @var string $status */
/** @var string $search */
/** @var bool $canAll */
/** @var bool $canArea */
/** @var bool $canCreate */
$statuses = ['', 'BORRADOR', 'EN_APROBACION', 'APROBADA', 'OBSERVADA', 'ATENDIDA', 'RECHAZADA', 'ANULADA'];
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Solicitudes de materiales</h1>
        <p class="page-sub"><?= e(count($requests)) ?> solicitudes visibles según su alcance y permisos</p>
    </div>
    <?php if ($canCreate): ?>
        <a href="<?= e(url('/solicitudes/nueva')) ?>" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Nueva solicitud</a>
    <?php endif; ?>
</div>

<ul class="nav nav-pills mb-3 gap-1">
    <li class="nav-item"><a class="nav-link <?= $scope === 'mine' ? 'active' : '' ?>" href="<?= e(url('/solicitudes?' . http_build_query(['scope' => 'mine', 'status' => $status, 'search' => $search]))) ?>"><i class="bi bi-person me-1"></i>Mis solicitudes</a></li>
    <?php if ($canArea): ?>
        <li class="nav-item"><a class="nav-link <?= $scope === 'area' ? 'active' : '' ?>" href="<?= e(url('/solicitudes?' . http_build_query(['scope' => 'area', 'status' => $status, 'search' => $search]))) ?>"><i class="bi bi-diagram-3 me-1"></i>Mi área</a></li>
    <?php endif; ?>
    <?php if ($canAll): ?>
        <li class="nav-item"><a class="nav-link <?= $scope === 'all' ? 'active' : '' ?>" href="<?= e(url('/solicitudes?' . http_build_query(['scope' => 'all', 'status' => $status, 'search' => $search]))) ?>"><i class="bi bi-globe2 me-1"></i>Todas</a></li>
    <?php endif; ?>
</ul>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form class="filter-bar row g-2 align-items-end" method="get" action="<?= e(url('/solicitudes')) ?>">
    <input type="hidden" name="scope" value="<?= e($scope) ?>">
    <div class="col-md-5">
        <label class="form-label">Buscar</label>
        <input type="text" class="form-control" name="search" value="<?= e($search) ?>" placeholder="Código, correspondencia, solicitante o justificación">
    </div>
    <div class="col-md-4">
        <label class="form-label">Estado</label>
        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
        <select class="form-select" name="status">
            <?php foreach ($statuses as $option): ?>
                <option value="<?= e($option) ?>" <?= selected($status, $option) ?>><?= $option === '' ? 'Todos los estados' : e(status_label($option)) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-3 d-grid">
        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
        <button class="btn btn-primary" type="submit"><i class="bi bi-search me-1"></i>Filtrar</button>
    </div>
</form>

<div class="card">
    <div class="card-body p-0">
        <?php if ($requests === []): ?>
            <div class="empty-state"><i class="bi bi-inbox"></i>No se encontraron solicitudes con los filtros seleccionados.</div>
        <?php else: ?>
            <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
            <div class="table-responsive">
                <!-- La tabla presenta los registros obtenidos por el controlador. -->
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Correspondencia</th>
                            <th>Solicitante / área</th>
                            <th>Justificación</th>
                            <th class="num">Paso</th>
                            <th>Estado</th>
                            <th>Fecha</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($requests as $request): ?>
                            <tr>
                                <td><a href="<?= e(url('/solicitudes/' . $request['id'])) ?>" class="fw-semibold mono"><?= e($request['code']) ?></a></td>
                                <td class="small mono"><?= e($request['correspondence_number']) ?></td>
                                <td>
                                    <div class="fw-semibold small"><?= e($request['applicant_name'] ?? '—') ?></div>
                                    <div class="small text-muted"><?= e($request['area_name'] ?? '—') ?></div>
                                </td>
                                <td class="small text-muted" style="max-width: 260px;"><?= e(mb_strimwidth((string) ($request['justification'] ?? '—'), 0, 90, '…')) ?></td>
                                <td class="num"><?= (int) $request['current_step'] > 0 && $request['status'] === 'EN_APROBACION' ? e($request['current_step']) : '—' ?></td>
                                <td><?= status_badge((string) $request['status']) ?></td>
                                <td class="small text-muted"><?= e(fecha($request['created_at'], false)) ?></td>
                                <td class="text-end">
                                    <a class="btn btn-sm btn-outline-primary" href="<?= e(url('/solicitudes/' . $request['id'])) ?>"><i class="bi bi-eye"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
