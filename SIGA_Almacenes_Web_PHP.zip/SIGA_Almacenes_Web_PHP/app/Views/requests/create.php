<?php
// Vista de solicitudes de materiales: presenta la pantalla de registro nuevo y sus controles.
/** @var string $mode */
/** @var array<string,mixed>|null $request */
/** @var array<int,array<string,mixed>> $items */
/** @var array<int,array<string,mixed>> $products */
/** @var array<string,mixed> $user */
$isEdit = $mode === 'edit' && $request !== null;
$rows = $items !== [] ? $items : [[]];
$action = $isEdit ? '/solicitudes/' . $request['id'] : '/solicitudes';
?>
<div class="page-head">
    <div>
        <h1 class="page-title"><?= $isEdit ? 'Editar solicitud ' . e($request['code']) : 'Nueva solicitud' ?></h1>
        <p class="page-sub"><?= $isEdit ? 'Actualice los ítems y vuelva a enviar al flujo de aprobación' : 'Registre el pedido de materiales para su área institucional' ?></p>
    </div>
    <a href="<?= e(url($isEdit ? '/solicitudes/' . $request['id'] : '/solicitudes')) ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form method="post" action="<?= e(url($action)) ?>" id="requestForm">
    <?= csrf_field() ?>
    <div class="row g-3">
        <div class="col-lg-8">
            <div class="card">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header"><i class="bi bi-file-earmark-text me-1"></i>Datos de la solicitud</div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-5">
                            <label class="form-label" for="correspondence_number">Número de correspondencia *</label>
                            <input type="text" class="form-control mono" id="correspondence_number" name="correspondence_number" maxlength="60"
                                   value="<?= e($request['correspondence_number'] ?? '') ?>" placeholder="CITE-UAA-2026-001">
                            <div class="form-text">Obligatorio al enviar la solicitud. Debe ser único.</div>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="office">Oficina / unidad solicitante</label>
                            <input type="text" class="form-control" id="office" name="office" maxlength="120"
                                   value="<?= e($request['office'] ?? ($user['office'] ?? '')) ?>" placeholder="Oficina del solicitante">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Área institucional</label>
                            <input type="text" class="form-control" value="<?= e($user['area_name'] ?? 'Sin área asignada') ?>" disabled>
                            <div class="form-text">Asignada a su usuario.</div>
                        </div>
                        <div class="col-12">
                            <label class="form-label" for="justification">Justificación *</label>
                            <textarea class="form-control" id="justification" name="justification" rows="3" maxlength="2000"
                                      placeholder="Detalle la necesidad institucional del pedido"><?= e($request['justification'] ?? '') ?></textarea>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mt-3" data-rows="#requestItems" data-template="#requestRowTemplate" data-add-row="#addRequestRow">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-list-ul me-1"></i>Productos solicitados</span>
                    <button type="button" class="btn btn-sm btn-outline-primary" id="addRequestRow"><i class="bi bi-plus-lg me-1"></i>Agregar fila</button>
                </div>
                <div class="card-body p-0">
                    <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                    <div class="table-responsive">
                        <!-- La tabla presenta los registros obtenidos por el controlador. -->
                        <table class="table table-sm mb-0">
                            <thead>
                                <tr>
                                    <th style="min-width: 320px;">Producto</th>
                                    <th>Unidad</th>
                                    <th class="num">Stock actual</th>
                                    <th style="width: 130px;">Cantidad solicitada</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="requestItems">
                                <?php foreach ($rows as $item): ?>
                                    <tr data-item-row>
                                        <td>
                                            <!-- Selector de productos: permite asociar artículos con el formulario. -->
                                            <select class="form-select form-select-sm product-select" name="product_id[]" required>
                                                <option value="" data-unit="" data-stock="0">Seleccione un producto...</option>
                                                <?php foreach ($products as $product): ?>
                                                    <option value="<?= e($product['id']) ?>"
                                                            data-unit="<?= e($product['unit_code']) ?>"
                                                            data-stock="<?= e($product['stock_qty']) ?>"
                                                        <?= selected($item['product_id'] ?? '', $product['id']) ?>>
                                                        <?= e($product['code'] . ' · ' . $product['name']) ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td><span class="badge badge-soft" data-unit-label><?= e($item['unit_code'] ?? '—') ?></span></td>
                                        <td class="num"><span data-stock-label><?= e(isset($item['current_stock']) ? qty($item['current_stock']) : '0') ?></span></td>
                                        <td><input type="number" step="1" min="0" class="form-control form-control-sm qty-input" name="qty_requested[]"
                                                   value="<?= e($item['qty_requested'] ?? '') ?>" required></td>
                                        <td class="text-end"><button type="button" class="btn btn-sm btn-outline-danger" data-remove-row><i class="bi bi-x-lg"></i></button></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header"><i class="bi bi-info-circle me-1"></i>Ruta de aprobación</div>
                <div class="card-body">
                    <div class="timeline">
                        <div class="timeline-item"><p class="timeline-title">1. Inmediato Superior</p><div class="timeline-meta">Aprobación del jefe del área</div></div>
                        <div class="timeline-item"><p class="timeline-title">2. Técnica de Almacenes</p><div class="timeline-meta">Verificación y propuesta de cantidades</div></div>
                        <div class="timeline-item"><p class="timeline-title">3. Jefatura de UAA</p><div class="timeline-meta">Autorización final de cantidades</div></div>
                    </div>
                    <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
                    <div class="alert alert-info small mb-0">
                        <i class="bi bi-info-circle me-1"></i>
                        Si su rol es Jefatura de UAA o Administrador, la solicitud se autoriza automáticamente.
                    </div>
                </div>
            </div>

            <div class="card mt-3">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header"><i class="bi bi-send me-1"></i>Acciones</div>
                <div class="card-body d-grid gap-2">
                    <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                    <button type="submit" name="submit_action" value="enviar" class="btn btn-primary">
                        <i class="bi bi-send me-1"></i><?= $isEdit ? 'Guardar y enviar' : 'Registrar y enviar' ?>
                    </button>
                    <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                    <button type="submit" name="submit_action" value="borrador" class="btn btn-outline-secondary">
                        <i class="bi bi-save me-1"></i>Guardar borrador
                    </button>
                    <a href="<?= e(url($isEdit ? '/solicitudes/' . $request['id'] : '/solicitudes')) ?>" class="btn btn-light">Cancelar</a>
                </div>
            </div>

            <div class="card mt-3">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header"><i class="bi bi-shield-check me-1"></i>Recomendaciones</div>
                <div class="card-body small text-muted">
                    <p class="mb-2">Verifique el stock disponible antes de solicitar. El sistema muestra la existencia actual al momento del registro.</p>
                    <p class="mb-0">Las cantidades pueden ser ajustadas por Técnica de Almacenes y autorizadas por Jefatura de UAA.</p>
                </div>
            </div>
        </div>
    </div>
</form>

<template id="requestRowTemplate">
    <tr data-item-row>
        <td>
            <!-- Selector de productos: permite asociar artículos con el formulario. -->
            <select class="form-select form-select-sm product-select" name="product_id[]" required>
                <option value="" data-unit="" data-stock="0">Seleccione un producto...</option>
                <?php foreach ($products as $product): ?>
                    <option value="<?= e($product['id']) ?>"
                            data-unit="<?= e($product['unit_code']) ?>"
                            data-stock="<?= e($product['stock_qty']) ?>">
                        <?= e($product['code'] . ' · ' . $product['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </td>
        <td><span class="badge badge-soft" data-unit-label>—</span></td>
        <td class="num"><span data-stock-label>0</span></td>
        <td><input type="number" step="1" min="0" class="form-control form-control-sm qty-input" name="qty_requested[]" required></td>
        <td class="text-end"><button type="button" class="btn btn-sm btn-outline-danger" data-remove-row><i class="bi bi-x-lg"></i></button></td>
    </tr>
</template>
