<?php
// Vista de solicitudes de materiales: presenta la pantalla de detalle del registro y sus controles.
/** @var array<string,mixed> $request */
/** @var array<int,array<string,mixed>> $items */
/** @var array<int,array<string,mixed>> $approvals */
/** @var array<int,array<string,mixed>> $history */
/** @var bool $canDecide */
/** @var bool $canEdit */
/** @var bool $canCancel */
/** @var array<string,mixed> $user */
$showQuantities = $canDecide && in_array($user['role_code'], ['TECNICO_ALMACEN', 'JEFE_UAA'], true);
$canPrint = true;
?>
<div class="page-head">
    <div>
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <h1 class="page-title mb-0">Solicitud <?= e($request['code']) ?></h1>
            <?= status_badge((string) $request['status']) ?>
        </div>
        <p class="page-sub"><?= e($request['correspondence_number']) ?> · <?= e($request['area_name'] ?? 'Sin área') ?> · registrada el <?= e(fecha($request['created_at'])) ?></p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <a href="<?= e(url('/solicitudes')) ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
        <?php if ($canPrint): ?>
            <a href="<?= e(url('/imprimir/solicitud/' . $request['id'])) ?>" target="_blank" class="btn btn-outline-primary"><i class="bi bi-printer me-1"></i>Imprimir</a>
        <?php endif; ?>
        <?php if ($canEdit): ?>
            <a href="<?= e(url('/solicitudes/' . $request['id'] . '/editar')) ?>" class="btn btn-primary"><i class="bi bi-pencil me-1"></i>Editar</a>
        <?php endif; ?>
    </div>
</div>

<?php if ($request['status'] === 'OBSERVADA' && !empty($request['observation'])): ?>
    <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
    <div class="alert alert-warning"><strong>Solicitud observada:</strong> <?= e($request['observation']) ?></div>
<?php endif; ?>
<?php if ($request['status'] === 'RECHAZADA' && !empty($request['rejection_reason'])): ?>
    <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
    <div class="alert alert-danger"><strong>Solicitud rechazada:</strong> <?= e($request['rejection_reason']) ?></div>
<?php endif; ?>

<div class="row g-3">
    <div class="col-lg-8">
        <div class="card">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-info-circle me-1"></i>Datos generales</div>
            <div class="card-body">
                <div class="detail-grid">
                    <div class="detail-item"><div class="label">Código</div><div class="value mono"><?= e($request['code']) ?></div></div>
                    <div class="detail-item"><div class="label">Correspondencia</div><div class="value mono"><?= e($request['correspondence_number']) ?></div></div>
                    <div class="detail-item"><div class="label">Solicitante</div><div class="value"><?= e($request['applicant_name'] ?? '—') ?></div></div>
                    <div class="detail-item"><div class="label">Cargo</div><div class="value"><?= e($request['applicant_position'] ?? '—') ?></div></div>
                    <div class="detail-item"><div class="label">Área</div><div class="value"><?= e($request['area_name'] ?? '—') ?></div></div>
                    <div class="detail-item"><div class="label">Oficina</div><div class="value"><?= e($request['office'] ?? '—') ?></div></div>
                    <div class="detail-item"><div class="label">Enviada</div><div class="value"><?= e(fecha($request['submitted_at'] ?? null)) ?></div></div>
                    <div class="detail-item"><div class="label">Aprobada</div><div class="value"><?= e(fecha($request['approved_at'] ?? null)) ?></div></div>
                    <div class="detail-item"><div class="label">Paso actual</div><div class="value"><?= $request['status'] === 'EN_APROBACION' ? 'Paso ' . e($request['current_step']) : '—' ?></div></div>
                    <div class="detail-item"><div class="label">Impresiones</div><div class="value"><?= e((int) $request['print_count']) ?></div></div>
                </div>
                <?php if (!empty($request['justification'])): ?>
                    <hr>
                    <div class="label small text-muted text-uppercase fw-bold">Justificación</div>
                    <p class="mb-0 small"><?= nl2br(e($request['justification'])) ?></p>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mt-3">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-list-ul me-1"></i>Detalle solicitado</span>
                <span class="badge badge-soft"><?= count($items) ?> ítems</span>
            </div>
            <div class="card-body p-0">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- La tabla presenta los registros obtenidos por el controlador. -->
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Producto</th>
                                <th class="num">Stock al solicitar</th>
                                <th class="num">Solicitado</th>
                                <th class="num">Propuesto</th>
                                <th class="num">Aprobado</th>
                                <th class="num">Autorizado</th>
                                <th class="num">Entregado</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                                <tr>
                                    <td>
                                        <div class="fw-semibold mono"><?= e($item['product_code']) ?></div>
                                        <div class="small text-muted"><?= e($item['product_name']) ?></div>
                                    </td>
                                    <td class="num text-muted"><?= e(qty($item['stock_at_request'])) ?></td>
                                    <td class="num"><?= e(qty($item['qty_requested'])) ?> <?= e($item['unit_code'] ?? '') ?></td>
                                    <td class="num"><?= e(qty($item['qty_proposed'])) ?></td>
                                    <td class="num"><?= e(qty($item['qty_approved'])) ?></td>
                                    <td class="num fw-semibold"><?= e(qty($item['qty_authorized'])) ?></td>
                                    <td class="num"><?= e(qty($item['qty_delivered'])) ?></td>
                                    <td><?= status_badge((string) $item['status']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="card mt-3">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-check2-square me-1"></i>Flujo de aprobación</div>
            <div class="card-body">
                <div class="timeline">
                    <?php foreach ($approvals as $approval): ?>
                        <?php
                        $stateClass = match ($approval['action']) {
                            'APROBADO' => 'done',
                            'RECHAZADO' => 'rejected',
                            default => ((int) $approval['step_order'] === (int) $request['current_step'] && $request['status'] === 'EN_APROBACION') ? '' : 'pending',
                        };
                        ?>
                        <div class="timeline-item <?= e($stateClass) ?>">
                            <p class="timeline-title">Paso <?= e($approval['step_order']) ?> · <?= e($approval['role_name']) ?></p>
                            <div class="timeline-meta">
                                <?= e($approval['approver_name'] ?? 'Pendiente') ?>
                                <?php if (!empty($approval['action_at'])): ?> · <?= e(fecha($approval['action_at'])) ?><?php endif; ?>
                                · <?= status_badge((string) $approval['action']) ?>
                            </div>
                            <?php if (!empty($approval['comments'])): ?>
                                <div class="timeline-comment"><?= e($approval['comments']) ?></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="card mt-3">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-clock-history me-1"></i>Historial de estados</div>
            <div class="card-body p-0">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- Tabla de gestión de solicitudes: organiza los registros y sus acciones visibles. -->
                    <table class="table table-sm mb-0">
                        <thead><tr><th>Fecha</th><th>De</th><th>A</th><th>Actor</th><th>Comentario</th></tr></thead>
                        <tbody>
                            <?php foreach ($history as $entry): ?>
                                <tr>
                                    <td class="small text-muted"><?= e(fecha($entry['created_at'])) ?></td>
                                    <td class="small"><?= status_badge((string) $entry['from_state']) ?></td>
                                    <td class="small"><?= status_badge((string) $entry['to_state']) ?></td>
                                    <td class="small"><?= e($entry['user_name'] ?? '—') ?><div class="text-muted"><?= e($entry['role_name'] ?? '') ?></div></td>
                                    <td class="small text-muted"><?= e($entry['comments'] ?? '—') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <?php if ($canDecide): ?>
            <div class="card border-warning">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header bg-warning-subtle"><i class="bi bi-check2-square me-1"></i>Decisión pendiente</div>
                <div class="card-body">
                    <p class="small text-muted">Usted debe decidir el paso <?= e($request['current_step']) ?> de esta solicitud.</p>
                    <!-- El formulario recibe los datos que procesará el controlador. -->
                    <form method="post" action="<?= e(url('/solicitudes/' . $request['id'] . '/decidir')) ?>" data-decision-form>
                        <?= csrf_field() ?>
                        <?php if ($showQuantities): ?>
                            <div class="mb-3">
                                <div class="form-label">Cantidades a aprobar</div>
                                <?php foreach ($items as $item): ?>
                                    <div class="d-flex align-items-center gap-2 mb-2">
                                        <div class="flex-grow-1 small">
                                            <div class="fw-semibold mono"><?= e($item['product_code']) ?></div>
                                            <div class="text-muted">Solicitado: <?= e(qty($item['qty_requested'])) ?></div>
                                        </div>
                                        <input type="number" step="1" min="0" class="form-control form-control-sm" style="width: 105px;"
                                               name="qty[<?= e($item['id']) ?>]"
                                               value="<?= e(number_format((float) ($user['role_code'] === 'TECNICO_ALMACEN' ? $item['qty_proposed'] : ((float) $item['qty_authorized'] > 0 ? $item['qty_authorized'] : $item['qty_proposed'])), 3, '.', '')) ?>">
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        <div class="mb-3">
                            <label class="form-label" for="decisionAction">Acción *</label>
                            <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                            <select class="form-select" id="decisionAction" name="action" required>
                                <option value="APROBAR">Aprobar</option>
                                <option value="DEVOLVER">Devolver para corrección</option>
                                <option value="RECHAZAR">Rechazar</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="decisionComments">Comentario</label>
                            <textarea class="form-control" id="decisionComments" name="comments" rows="3" placeholder="Comentario opcional"></textarea>
                        </div>
                        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                        <button type="submit" class="btn btn-primary w-100"><i class="bi bi-check2-circle me-1"></i>Registrar decisión</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        <div class="card <?= $canDecide ? 'mt-3' : '' ?>">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-signpost-split me-1"></i>Acciones</div>
            <div class="card-body d-grid gap-2">
                <?php if ($request['status'] === 'BORRADOR' && (int) $request['applicant_id'] === (int) $user['id']): ?>
                    <!-- Formulario de gestión de solicitudes; se enviará por POST al controlador encargado. -->
                    <form method="post" action="<?= e(url('/solicitudes/' . $request['id'] . '/enviar')) ?>" data-confirm="¿Enviar la solicitud al flujo de aprobación?">
                        <?= csrf_field() ?>
                        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                        <button class="btn btn-primary w-100" type="submit"><i class="bi bi-send me-1"></i>Enviar a aprobación</button>
                    </form>
                <?php endif; ?>
                <?php if ($request['status'] === 'APROBADA' && (can('salidas.preparar') || can('salidas.confirmar'))): ?>
                    <a class="btn btn-primary" href="<?= e(url('/salidas/nueva/' . $request['id'])) ?>"><i class="bi bi-box-arrow-up me-1"></i>Preparar despacho</a>
                <?php endif; ?>
                <a class="btn btn-outline-secondary" href="<?= e(url('/imprimir/solicitud/' . $request['id'])) ?>" target="_blank"><i class="bi bi-printer me-1"></i>Imprimir solicitud</a>
                <?php if ($canCancel && !in_array($request['status'], ['ATENDIDA', 'ANULADA', 'RECHAZADA'], true)): ?>
                    <button class="btn btn-outline-danger" type="button" data-bs-toggle="modal" data-bs-target="#cancelRequestModal"><i class="bi bi-x-octagon me-1"></i>Anular solicitud</button>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-header"><i class="bi bi-info-circle me-1"></i>Estado del flujo</div>
            <div class="card-body small text-muted">
                <p class="mb-2">La solicitud recorre tres niveles: jefe inmediato, técnica de almacenes y jefatura de UAA.</p>
                <p class="mb-0">Las cantidades autorizadas son las que se utilizan al momento del despacho PEPS.</p>
            </div>
        </div>
    </div>
</div>

<?php if ($canCancel && !in_array($request['status'], ['ATENDIDA', 'ANULADA', 'RECHAZADA'], true)): ?>
<div class="modal fade" id="cancelRequestModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <!-- Formulario de gestión de solicitudes; se enviará por POST al controlador encargado. -->
            <form method="post" action="<?= e(url('/solicitudes/' . $request['id'] . '/anular')) ?>">
                <?= csrf_field() ?>
                <div class="modal-header">
                    <h5 class="modal-title">Anular solicitud <?= e($request['code']) ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning small">La anulación no es posible si la solicitud ya tiene despachos registrados. Indique un motivo de al menos 10 caracteres.</div>
                    <label class="form-label" for="cancelReason">Motivo *</label>
                    <textarea class="form-control" id="cancelReason" name="reason" rows="3" minlength="10" required></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                    <button type="submit" class="btn btn-danger">Anular solicitud</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
