<!-- Vista de movimientos de Kardex: presenta la pantalla de resumen de movimientos y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Resumen General de Kardex</h3>
        <p class="text-muted mb-0 fs-7">Consolidado general de entradas, salidas y saldos físicos y valorados por producto</p>
    </div>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-printer me-1"></i>Imprimir Resumen
        </button>
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/reportes/exportar-csv" class="btn btn-outline-success btn-sm">
            <i class="bi bi-file-earmark-excel me-1"></i>Exportar Excel/CSV
        </a>
    </div>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-body p-3">
        <div class="input-group input-group-sm">
            <span class="input-group-text bg-light text-muted"><i class="bi bi-search"></i></span>
            <input type="text" data-table-search="tablaKardexResumen" class="form-control" placeholder="Filtrar por código o nombre de producto...">
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <span><i class="bi bi-journal-check me-2 text-primary"></i>Artículos con Movimiento Contable</span>
        <span class="badge bg-light text-dark border"><?= count($summary) ?> artículos</span>
    </div>
    <div class="card-body p-0">
        <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
        <div class="table-responsive">
            <!-- La tabla presenta los registros obtenidos por el controlador. -->
            <table class="table table-hover align-middle mb-0 fs-8" id="tablaKardexResumen">
                <thead class="table-light">
                    <tr>
                        <th>Código SKU</th>
                        <th>Descripción</th>
                        <th>Categoría</th>
                        <th class="text-center">Total Entradas</th>
                        <th class="text-center">Total Salidas</th>
                        <th class="text-center">Saldo Físico</th>
                        <th class="text-end">Costo Ref.</th>
                        <th class="text-end">Saldo Valorado (Bs)</th>
                        <th class="text-end">Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($summary as $s): ?>
                        <tr>
                            <td class="fw-bold text-navy"><?= htmlspecialchars($s['code']) ?></td>
                            <td class="fw-semibold"><?= htmlspecialchars($s['name']) ?></td>
                            <td><?= htmlspecialchars($s['category_name']) ?></td>
                            <td class="text-center text-success fw-semibold"><?= number_format((float)$s['total_qty_in'], 1) ?></td>
                            <td class="text-center text-danger fw-semibold"><?= number_format((float)$s['total_qty_out'], 1) ?></td>
                            <td class="text-center fw-bold text-primary"><?= number_format((float)$s['stock_qty'], 1) ?> <?= htmlspecialchars($s['unit_name']) ?></td>
                            <td class="text-end">Bs <?= number_format((float)$s['reference_cost'], 4) ?></td>
                            <td class="text-end fw-bold text-navy" data-bob-amount="<?= $s['stock_value'] ?>">
                                Bs <?= number_format((float)$s['stock_value'], 2) ?>
                            </td>
                            <td class="text-end">
                                <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/kardex/producto/<?= $s['product_id'] ?>" class="btn btn-outline-primary btn-sm py-0 px-2 fs-8">
                                    <i class="bi bi-eye me-1"></i>Kardex
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
