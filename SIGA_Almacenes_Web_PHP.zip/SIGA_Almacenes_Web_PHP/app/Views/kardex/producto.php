<!-- Vista de movimientos de Kardex: presenta la pantalla de Kardex por producto y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div class="d-flex align-items-center gap-3">
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/inventario/<?= $product['id'] ?>" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left"></i>
        </a>
        <div>
            <h3 class="fw-bold text-navy mb-0">Kardex Físico-Valorado (Método PEPS)</h3>
            <p class="text-muted mb-0 fs-7">Artículo: <strong><?= htmlspecialchars($product['code']) ?> - <?= htmlspecialchars($product['name']) ?></strong> &bull; Unidad: <?= htmlspecialchars($product['unit_name']) ?></p>
        </div>
    </div>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-printer me-1"></i>Imprimir Kardex
        </button>
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/kardex/resumen" class="btn btn-primary btn-sm">
            <i class="bi bi-list-ul me-1"></i>Ver Resumen General
        </a>
    </div>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-body p-3">
        <div class="row g-3 fs-7">
            <div class="col-6 col-md-3">
                <span class="text-muted fs-8 d-block">Categoría:</span>
                <strong><?= htmlspecialchars($product['category_name']) ?></strong>
            </div>
            <div class="col-6 col-md-3">
                <span class="text-muted fs-8 d-block">Ubicación Física:</span>
                <strong><?= htmlspecialchars($product['location_name'] ?? 'Almacén Central') ?></strong>
            </div>
            <div class="col-6 col-md-3">
                <span class="text-muted fs-8 d-block">Saldo Físico Actual:</span>
                <span class="fw-bold text-primary fs-6"><?= number_format((float)$product['stock_qty'], 1) ?> <?= htmlspecialchars($product['unit_code']) ?></span>
            </div>
            <div class="col-6 col-md-3">
                <span class="text-muted fs-8 d-block">Saldo Valorado Total:</span>
                <span class="fw-bold text-success fs-6" data-bob-amount="<?= $product['stock_value'] ?>">Bs <?= number_format((float)$product['stock_value'], 2) ?></span>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
    <div class="card-header bg-navy text-white d-flex justify-content-between align-items-center">
        <span><i class="bi bi-journal-text me-2"></i>Movimientos Físico-Contables Registrados</span>
        <span class="badge bg-gold text-dark"><?= count($movements) ?> registros</span>
    </div>
    <div class="card-body p-0">
        <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
        <div class="table-responsive">
            <!-- La tabla presenta los registros obtenidos por el controlador. -->
            <table class="table table-bordered table-hover align-middle mb-0 fs-8">
                <thead class="table-secondary text-center">
                    <tr>
                        <th rowspan="2" class="align-middle">Fecha</th>
                        <th rowspan="2" class="align-middle">Operación</th>
                        <th rowspan="2" class="align-middle">Referencia</th>
                        <th colspan="3" class="bg-success-subtle text-success">ENTRADAS</th>
                        <th colspan="3" class="bg-warning-subtle text-dark">SALIDAS</th>
                        <th colspan="3" class="bg-primary-subtle text-primary">SALDOS CONTABLES</th>
                    </tr>
                    <tr>
                        <th class="bg-success-subtle text-success">Cant.</th>
                        <th class="bg-success-subtle text-success">C/U</th>
                        <th class="bg-success-subtle text-success">Total</th>
                        <th class="bg-warning-subtle text-dark">Cant.</th>
                        <th class="bg-warning-subtle text-dark">C/U</th>
                        <th class="bg-warning-subtle text-dark">Total</th>
                        <th class="bg-primary-subtle text-primary">Cant.</th>
                        <th class="bg-primary-subtle text-primary">C/U Pond.</th>
                        <th class="bg-primary-subtle text-primary">Valor Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($movements)): ?>
                        <tr><td colspan="12" class="text-center text-muted py-4">No hay movimientos contables registrados en Kardex para este producto.</td></tr>
                    <?php else: ?>
                        <?php foreach ($movements as $m): ?>
                            <tr>
                                <td class="text-center"><?= date('d/m/Y', strtotime($m['movement_date'])) ?></td>
                                <td class="text-center fw-semibold"><?= htmlspecialchars($m['doc_type']) ?></td>
                                <td><?= htmlspecialchars($m['reference'] ?? '-') ?></td>
                                
                                <!-- Entradas -->
                                <td class="text-center text-success fw-semibold">
                                    <?= ((float)$m['qty_in'] > 0) ? number_format((float)$m['qty_in'], 1) : '-' ?>
                                </td>
                                <td class="text-end text-muted">
                                    <?= ((float)$m['qty_in'] > 0) ? number_format((float)$m['unit_cost_in'], 4) : '-' ?>
                                </td>
                                <td class="text-end text-success fw-semibold">
                                    <?= ((float)$m['qty_in'] > 0) ? number_format((float)$m['total_in'], 2) : '-' ?>
                                </td>

                                <!-- Salidas -->
                                <td class="text-center text-danger fw-semibold">
                                    <?= ((float)$m['qty_out'] > 0) ? number_format((float)$m['qty_out'], 1) : '-' ?>
                                </td>
                                <td class="text-end text-muted">
                                    <?= ((float)$m['qty_out'] > 0) ? number_format((float)$m['unit_cost_out'], 4) : '-' ?>
                                </td>
                                <td class="text-end text-danger fw-semibold">
                                    <?= ((float)$m['qty_out'] > 0) ? number_format((float)$m['total_out'], 2) : '-' ?>
                                </td>

                                <!-- Saldos -->
                                <td class="text-center fw-bold text-primary">
                                    <?= number_format((float)$m['balance_qty'], 1) ?>
                                </td>
                                <td class="text-end text-muted">
                                    <?= number_format((float)$m['balance_unit_cost'], 4) ?>
                                </td>
                                <td class="text-end fw-bold text-navy" data-bob-amount="<?= $m['balance_value'] ?>">
                                    Bs <?= number_format((float)$m['balance_value'], 2) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
