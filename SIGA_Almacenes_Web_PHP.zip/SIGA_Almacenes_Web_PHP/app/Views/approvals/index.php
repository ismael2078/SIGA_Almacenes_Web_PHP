<?php
// Vista de bandeja de aprobaciones: presenta la pantalla de listado y búsqueda y sus controles.
/** @var array<int,array<string,mixed>> $pending */
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Aprobaciones pendientes</h1>
        <p class="page-sub"><?= e(count($pending)) ?> solicitudes esperan su decisión</p>
    </div>
    <a href="<?= e(url('/solicitudes?scope=all')) ?>" class="btn btn-outline-primary"><i class="bi bi-list-ul me-1"></i>Ver todas las solicitudes</a>
</div>

<?php if ($pending === []): ?>
    <div class="card">
        <div class="card-body">
            <div class="empty-state"><i class="bi bi-check2-circle"></i>No tiene solicitudes pendientes de decisión.</div>
        </div>
    </div>
<?php else: ?>
    <div class="row g-3">
        <?php foreach ($pending as $request): ?>
            <div class="col-xl-6">
                <div class="card h-100">
                    <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div>
                            <a href="<?= e(url('/solicitudes/' . $request['id'])) ?>" class="fw-bold text-decoration-none"><?= e($request['code']) ?></a>
                            <div class="small text-muted"><?= e($request['correspondence_number']) ?></div>
                        </div>
                        <span class="badge badge-soft-gold">Paso <?= e($request['current_step']) ?></span>
                    </div>
                    <div class="card-body">
                        <div class="detail-grid mb-3">
                            <div class="detail-item"><div class="label">Solicitante</div><div class="value small"><?= e($request['applicant_name'] ?? '—') ?></div></div>
                            <div class="detail-item"><div class="label">Área</div><div class="value small"><?= e($request['area_name'] ?? '—') ?></div></div>
                            <div class="detail-item"><div class="label">Enviada</div><div class="value small"><?= e(fecha($request['submitted_at'] ?? null)) ?></div></div>
                            <div class="detail-item"><div class="label">Rol del paso</div><div class="value small"><?= e($request['role_name'] ?? '—') ?></div></div>
                        </div>
                        <?php if (!empty($request['items'])): ?>
                            <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                            <div class="table-responsive">
                                <!-- La tabla presenta los registros obtenidos por el controlador. -->
                                <table class="table table-sm table-compact mb-0">
                                    <thead><tr><th>Producto</th><th class="num">Solicitado</th><th class="num">Stock</th></tr></thead>
                                    <tbody>
                                        <?php foreach ($request['items'] as $item): ?>
                                            <tr>
                                                <td class="small"><span class="mono"><?= e($item['product_code']) ?></span> · <?= e($item['product_name']) ?></td>
                                                <td class="num"><?= e(qty($item['qty_requested'])) ?></td>
                                                <td class="num text-muted"><?= e(qty($item['current_stock'])) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer bg-white d-flex justify-content-between align-items-center gap-2 flex-wrap">
                        <a href="<?= e(url('/solicitudes/' . $request['id'])) ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye me-1"></i>Ver detalle</a>
                        <!-- El formulario recibe los datos que procesará el controlador. -->
                        <form method="post" action="<?= e(url('/aprobaciones/' . $request['id'] . '/decidir')) ?>" class="d-flex gap-2 align-items-center flex-wrap" data-decision-form>
                            <?= csrf_field() ?>
                            <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                            <select class="form-select form-select-sm" name="action" required style="width: 160px;">
                                <option value="APROBAR">Aprobar</option>
                                <option value="DEVOLVER">Devolver</option>
                                <option value="RECHAZAR">Rechazar</option>
                            </select>
                            <input type="text" class="form-control form-control-sm" name="comments" placeholder="Comentario" style="width: 190px;">
                            <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                            <button type="submit" class="btn btn-sm btn-primary">Decidir</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
