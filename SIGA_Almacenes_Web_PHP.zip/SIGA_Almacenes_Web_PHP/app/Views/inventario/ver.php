<!-- Vista de productos y existencias: presenta la pantalla de consulta de detalle y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div class="d-flex align-items-center gap-3">
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/inventario" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left"></i>
        </a>
        <div>
            <div class="d-flex align-items-center gap-2">
                <h3 class="fw-bold text-navy mb-0"><?= htmlspecialchars($product['name']) ?></h3>
                <span class="badge bg-success"><?= htmlspecialchars($product['status']) ?></span>
            </div>
            <p class="text-muted mb-0 fs-7">Código SKU: <strong><?= htmlspecialchars($product['code']) ?></strong> &bull; Categoría: <?= htmlspecialchars($product['category_name']) ?> &bull; Subcategoría: <?= htmlspecialchars($product['subcategory_name']) ?></p>
        </div>
    </div>
    <div>
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/kardex/producto/<?= $product['id'] ?>" class="btn btn-primary btn-sm">
            <i class="bi bi-journal-text me-1"></i>Ver Kardex Completo
        </a>
    </div>
</div>

<div class="row g-4">
    <!-- Ficha Técnica -->
    <div class="col-12 col-lg-4">
        <div class="card shadow-sm mb-4">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header bg-navy text-white">
                <i class="bi bi-info-circle me-2"></i>Ficha del Artículo
            </div>
            <div class="card-body fs-7 p-3">
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Unidad de Medida:</span>
                    <strong><?= htmlspecialchars($product['unit_name']) ?> (<?= htmlspecialchars($product['unit_code']) ?>)</strong>
                </div>
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Ubicación Física en Almacén:</span>
                    <span><?= htmlspecialchars($product['location_name'] ?? 'Almacén Central') ?> (<?= htmlspecialchars($product['location_code'] ?? 'A1') ?>)</span>
                </div>
                <hr class="my-2">
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Existencia Física Actual:</span>
                    <h4 class="fw-bold text-primary mb-0"><?= number_format((float)$product['stock_qty'], 1) ?> <?= htmlspecialchars($product['unit_code']) ?></h4>
                </div>
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Stock de Seguridad Mínimo:</span>
                    <span class="text-danger fw-semibold"><?= number_format((float)$product['min_stock'], 1) ?></span>
                </div>
                <hr class="my-2">
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Último Costo de Referencia:</span>
                    <span>Bs <?= number_format((float)$product['reference_cost'], 4) ?></span>
                </div>
                <div>
                    <span class="text-muted d-block fs-8">Saldo Valorado Total (PEPS):</span>
                    <h4 class="fw-bold text-success mb-0" data-bob-amount="<?= $product['stock_value'] ?>">
                        Bs <?= number_format((float)$product['stock_value'], 2) ?>
                    </h4>
                </div>
            </div>
        </div>
    </div>

    <!-- Capas PEPS Activas -->
    <div class="col-12 col-lg-8">
        <div class="card shadow-sm mb-4">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <span><i class="bi bi-layers me-2 text-primary"></i>Capas PEPS Activas (Orden de Consumo FIFO)</span>
                <span class="badge bg-primary"><?= count($layers) ?> capas abiertas</span>
            </div>
            <div class="card-body p-0">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- La tabla presenta los registros obtenidos por el controlador. -->
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light">
                            <tr>
                                <th>Fecha Capa</th>
                                <th>Ingreso Origen</th>
                                <th class="text-center">Cant. Original</th>
                                <th class="text-center">Cant. Remanente</th>
                                <th class="text-end">Costo Capa (Bs)</th>
                                <th class="text-end">Subtotal (Bs)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($layers)): ?>
                                <tr><td colspan="6" class="text-center text-muted py-3">No hay capas abiertas para este producto (Saldo 0).</td></tr>
                            <?php else: ?>
                                <?php foreach ($layers as $l): ?>
                                    <tr>
                                        <td><?= date('d/m/Y', strtotime($l['layer_date'])) ?></td>
                                        <td>
                                            <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/ingresos/<?= $l['entry_id'] ?>" class="text-decoration-none fw-semibold">
                                                <?= htmlspecialchars($l['entry_number'] ?? 'ING-Inicial') ?>
                                            </a>
                                        </td>
                                        <td class="text-center text-muted"><?= number_format((float)$l['original_qty'], 1) ?></td>
                                        <td class="text-center fw-bold text-success"><?= number_format((float)$l['remaining_qty'], 1) ?></td>
                                        <td class="text-end">Bs <?= number_format((float)$l['unit_cost'], 4) ?></td>
                                        <td class="text-end fw-bold">Bs <?= number_format((float)$l['remaining_qty'] * (float)$l['unit_cost'], 2) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Movimientos Recientes de Kardex -->
        <div class="card shadow-sm">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header bg-white">
                <i class="bi bi-journal-text me-2 text-secondary"></i>Últimos Movimientos de Kardex
            </div>
            <div class="card-body p-0">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- Tabla de inventario: organiza los registros y sus acciones visibles. -->
                    <table class="table table-hover align-middle mb-0 fs-8">
                        <thead class="table-light">
                            <tr>
                                <th>Fecha</th>
                                <th>Operación</th>
                                <th>Referencia</th>
                                <th class="text-center">Entrada</th>
                                <th class="text-center">Salida</th>
                                <th class="text-center">Saldo Físico</th>
                                <th class="text-end">Saldo Valorado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach (array_slice($movements, -5) as $m): ?>
                                <tr>
                                    <td><?= date('d/m/Y', strtotime($m['movement_date'])) ?></td>
                                    <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($m['doc_type']) ?></span></td>
                                    <td><?= htmlspecialchars($m['reference'] ?? '-') ?></td>
                                    <td class="text-center text-success"><?= ((float)$m['qty_in'] > 0) ? '+' . number_format((float)$m['qty_in'], 1) : '-' ?></td>
                                    <td class="text-center text-danger"><?= ((float)$m['qty_out'] > 0) ? '-' . number_format((float)$m['qty_out'], 1) : '-' ?></td>
                                    <td class="text-center fw-bold"><?= number_format((float)$m['balance_qty'], 1) ?></td>
                                    <td class="text-end fw-bold text-navy">Bs <?= number_format((float)$m['balance_value'], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
