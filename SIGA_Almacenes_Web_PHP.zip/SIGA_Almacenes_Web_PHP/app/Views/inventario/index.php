<!-- Vista de productos y existencias: presenta la pantalla de listado y búsqueda y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Catálogo de Productos y Existencias</h3>
        <p class="text-muted mb-0 fs-7">Control de inventario físico, valoración contable por capas PEPS y niveles de reposición</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/kardex/resumen" class="btn btn-outline-primary btn-sm">
            <i class="bi bi-journal-text me-1"></i>Resumen Kardex
        </a>
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/reportes" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-bar-chart me-1"></i>Reporte Valorado
        </a>
    </div>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-body p-3">
        <!-- El formulario recibe los datos que procesará el controlador. -->
        <form method="GET" action="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/inventario" class="row g-2 align-items-center">
            <div class="col-12 col-md-5">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-light text-muted"><i class="bi bi-search"></i></span>
                    <input type="text" name="search" data-table-search="tablaProductos" class="form-control" placeholder="Buscar por código SKU, descripción o marca en tiempo real..." value="<?= htmlspecialchars($filters['search'] ?? '') ?>">
                </div>
            </div>
            <div class="col-12 col-md-4">
                <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                <select name="category_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">-- Todas las categorías --</option>
                    <?php foreach ($categories as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= (($filters['category_id'] ?? '') == $c['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($c['name']) ?> (<?= htmlspecialchars($c['code']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-3 d-flex gap-2">
                <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                <button type="submit" class="btn btn-secondary btn-sm flex-grow-1">Filtrar</button>
                <?php if (!empty($filters['search']) || !empty($filters['category_id'])): ?>
                <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/inventario" class="btn btn-outline-secondary btn-sm"><i class="bi bi-x-circle"></i></a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <span><i class="bi bi-grid me-2 text-primary"></i>Artículos en Catálogo</span>
        <span class="badge bg-light text-dark border"><?= count($products) ?> productos</span>
    </div>
    <div class="card-body p-0">
        <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
        <div class="table-responsive">
            <!-- La tabla presenta los registros obtenidos por el controlador. -->
            <table class="table table-hover align-middle mb-0 fs-7" id="tablaProductos">
                <thead class="table-light">
                    <tr>
                        <th style="width: 130px;">Código SKU</th>
                        <th>Descripción del Producto</th>
                        <th>Categoría</th>
                        <th>Ubicación</th>
                        <th class="text-center">Existencia</th>
                        <th class="text-center">Mínimo</th>
                        <th class="text-end">Costo Ref. (Bs)</th>
                        <th class="text-end">Valor Stock (Bs)</th>
                        <th class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $p): ?>
                        <?php $isLow = (float)$p['stock_qty'] <= (float)$p['min_stock']; ?>
                        <tr class="<?= $isLow ? 'table-warning-subtle' : '' ?>">
                            <td class="fw-bold text-navy"><?= htmlspecialchars($p['code']) ?></td>
                            <td>
                                <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/inventario/<?= $p['id'] ?>" class="text-decoration-none fw-semibold text-navy d-block">
                                    <?= htmlspecialchars($p['name']) ?>
                                </a>
                                <small class="text-muted"><?= htmlspecialchars($p['subcategory_name'] ?? '') ?></small>
                            </td>
                            <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($p['category_code'] ?? '') ?></span></td>
                            <td><?= htmlspecialchars($p['location_code'] ?? 'A1') ?></td>
                            <td class="text-center">
                                <span class="badge <?= $isLow ? 'bg-danger' : 'bg-success' ?> fs-8">
                                    <?= number_format((float)$p['stock_qty'], 1) ?> <?= htmlspecialchars($p['unit_code'] ?? '') ?>
                                </span>
                            </td>
                            <td class="text-center text-muted"><?= number_format((float)$p['min_stock'], 1) ?></td>
                            <td class="text-end">Bs <?= number_format((float)$p['reference_cost'], 4) ?></td>
                            <td class="text-end fw-bold text-navy" data-bob-amount="<?= $p['stock_value'] ?>">
                                Bs <?= number_format((float)$p['stock_value'], 2) ?>
                            </td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/inventario/<?= $p['id'] ?>" class="btn btn-outline-primary" title="Ver ficha técnica">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/kardex/producto/<?= $p['id'] ?>" class="btn btn-outline-secondary" title="Ver Kardex">
                                        <i class="bi bi-journal-text"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
