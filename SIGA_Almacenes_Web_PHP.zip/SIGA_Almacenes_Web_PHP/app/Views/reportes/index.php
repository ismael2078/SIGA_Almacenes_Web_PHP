<!-- Vista de reportes de almacén: presenta la pantalla de listado y búsqueda y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Reportes Oficiales de Almacén</h3>
        <p class="text-muted mb-0 fs-7">Estados contables, inventario físico-valorado y valuación multi-divisa en tiempo real</p>
    </div>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-printer me-1"></i>Imprimir Reporte
        </button>
        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/reportes/exportar-csv" class="btn btn-success btn-sm shadow-sm">
            <i class="bi bi-file-earmark-excel me-1"></i>Exportar a Excel / CSV
        </a>
    </div>
</div>

<!-- Tarjeta de Resumen y Valorización Multi-Moneda con API Externa -->
<div class="card shadow-sm mb-4 border-primary-subtle">
    <div class="card-body p-3">
        <div class="row g-3 align-items-center">
            <div class="col-12 col-md-3">
                <span class="text-muted fs-8 d-block">Unidades Totales en Existencia:</span>
                <h4 class="fw-bold text-navy mb-0"><?= number_format($totalQty, 1) ?></h4>
                <small class="text-muted fs-8">En <?= count($products) ?> artículos registrados</small>
            </div>
            <div class="col-12 col-md-4 border-start-md">
                <span class="text-muted fs-8 d-block">Valor Total Contable (Moneda Nacional):</span>
                <h3 class="fw-bold text-success mb-0">Bs <?= number_format($totalValBob, 2) ?></h3>
                <small class="text-muted fs-8">Moneda oficial: Bolivianos (BOB)</small>
            </div>
            <div class="col-12 col-md-5 border-start-md">
                <div class="p-2 bg-light rounded-3 border">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <span class="badge bg-success-subtle text-success fs-8 border border-success-subtle">
                            <i class="bi bi-broadcast me-1"></i>API Divisas en Vivo
                        </span>
                        <small class="text-muted fs-8">T.C.: 1 USD = <?= number_format($exchangeRates['usd_to_bob'], 2) ?> BOB</small>
                    </div>
                    <span class="text-muted fs-8 d-block">Valor Equivalente en Moneda Extranjera:</span>
                    <h4 class="fw-bold text-primary mb-0">$ <?= number_format($totalValUsd, 2) ?> USD</h4>
                    <small class="text-muted fs-8">Fuente: <?= htmlspecialchars($exchangeRates['source']) ?></small>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-body p-3">
        <!-- El formulario recibe los datos que procesará el controlador. -->
        <form method="GET" action="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/reportes" class="row g-2 align-items-center">
            <div class="col-12 col-md-8">
                <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                <select name="category_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">-- Consolidado General (Todas las Categorías) --</option>
                    <?php foreach ($categories as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= ($selectedCatId == $c['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($c['name']) ?> (<?= htmlspecialchars($c['code']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-4">
                <input type="text" data-table-search="tablaReporte" class="form-control form-control-sm" placeholder="Filtrar en tabla...">
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <span><i class="bi bi-table me-2 text-primary"></i>Planilla de Inventario Físico-Valorado al <?= date('d/m/Y') ?></span>
        <span class="badge bg-light text-dark border"><?= count($products) ?> registros</span>
    </div>
    <div class="card-body p-0">
        <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
        <div class="table-responsive">
            <!-- La tabla presenta los registros obtenidos por el controlador. -->
            <table class="table table-hover align-middle mb-0 fs-8" id="tablaReporte">
                <thead class="table-light">
                    <tr>
                        <th style="width: 120px;">Código</th>
                        <th>Descripción</th>
                        <th>Categoría</th>
                        <th>Ubicación</th>
                        <th class="text-center">Existencia</th>
                        <th class="text-end">Costo Unit. (Bs)</th>
                        <th class="text-end">Valor Total (Bs)</th>
                        <th class="text-end">Equiv. (USD)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $p): ?>
                        <?php 
                        $valBob = (float)$p['stock_value'];
                        $valUsd = $valBob / ($exchangeRates['usd_to_bob'] ?: 6.96);
                        ?>
                        <tr>
                            <td class="fw-bold text-navy"><?= htmlspecialchars($p['code']) ?></td>
                            <td class="fw-semibold"><?= htmlspecialchars($p['name']) ?></td>
                            <td><?= htmlspecialchars($p['category_code']) ?></td>
                            <td><?= htmlspecialchars($p['location_code'] ?? 'A1') ?></td>
                            <td class="text-center fw-bold text-primary">
                                <?= number_format((float)$p['stock_qty'], 1) ?> <?= htmlspecialchars($p['unit_code']) ?>
                            </td>
                            <td class="text-end">Bs <?= number_format((float)$p['reference_cost'], 4) ?></td>
                            <td class="text-end fw-bold text-navy" data-bob-amount="<?= $valBob ?>">
                                Bs <?= number_format($valBob, 2) ?>
                            </td>
                            <td class="text-end text-muted">
                                $ <?= number_format($valUsd, 2) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
