<?php
// Vista de documentos imprimibles: presenta la pantalla de impresión de solicitud y sus controles.
/** @var array<string,mixed> $request */
/** @var array<int,array<string,mixed>> $items */
/** @var array<int,array<string,mixed>> $approvals */
$user = user();
$approvedQty = static function (array $item): float {
    foreach (['qty_authorized', 'qty_approved', 'qty_proposed', 'qty_requested'] as $field) {
        if (isset($item[$field]) && (float) $item[$field] > 0) {
            return (float) $item[$field];
        }
    }
    return 0.0;
};
$signatures = array_values(array_filter($approvals, static fn (array $a): bool => in_array($a['action'], ['APROBADO', 'RECHAZADO'], true)));
?>
<div class="print-header">
    <div class="logo">DDE</div>
    <div class="flex-grow-1">
        <h1>Dirección Departamental de Educación Cochabamba</h1>
        <p>Unidad Administrativa y Financiera · Almacenes e Inventarios</p>
        <p>Sistema Integrado de Gestión de Almacenes · SIGA-DDE</p>
    </div>
    <div class="text-end small">
        <div><strong><?= e($request['code']) ?></strong></div>
        <div><?= e(fecha($request['created_at'], false)) ?></div>
    </div>
</div>

<div class="print-title">Solicitud de materiales y/o bienes</div>

<!-- La tabla presenta los registros obtenidos por el controlador. -->
<table class="print-table mb-3">
    <tbody>
        <tr>
            <th style="width: 18%;">N° de correspondencia</th>
            <td style="width: 32%;"><?= e($request['correspondence_number']) ?></td>
            <th style="width: 18%;">Fecha de solicitud</th>
            <td style="width: 32%;"><?= e(fecha($request['created_at'], false)) ?></td>
        </tr>
        <tr>
            <th>Solicitante</th>
            <td><?= e($request['applicant_name'] ?? '—') ?></td>
            <th>Cargo</th>
            <td><?= e($request['applicant_position'] ?? '—') ?></td>
        </tr>
        <tr>
            <th>Área institucional</th>
            <td><?= e($request['area_name'] ?? '—') ?></td>
            <th>Oficina</th>
            <td><?= e($request['office'] ?? $request['applicant_office'] ?? '—') ?></td>
        </tr>
        <tr>
            <th>Estado</th>
            <td><?= e(status_label((string) $request['status'])) ?></td>
            <th>Aprobada el</th>
            <td><?= e(fecha($request['approved_at'] ?? null, false)) ?></td>
        </tr>
        <tr>
            <th>Justificación</th>
            <td colspan="3"><?= nl2br(e($request['justification'] ?? '—')) ?></td>
        </tr>
    </tbody>
</table>

<!-- Tabla de esta pantalla: organiza los registros y sus acciones visibles. -->
<table class="print-table">
    <thead>
        <tr>
            <th style="width: 4%;">N°</th>
            <th style="width: 12%;">Código</th>
            <th>Descripción del producto</th>
            <th style="width: 8%;">Unidad</th>
            <th class="num" style="width: 10%;">Solicitado</th>
            <th class="num" style="width: 10%;">Autorizado</th>
            <th class="num" style="width: 10%;">Entregado</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($items === []): ?>
            <tr><td colspan="7" class="text-center">Sin ítems registrados</td></tr>
        <?php else: ?>
            <?php foreach ($items as $index => $item): ?>
                <tr>
                    <td class="text-center"><?= e($index + 1) ?></td>
                    <td><?= e($item['product_code']) ?></td>
                    <td><?= e($item['product_name']) ?></td>
                    <td><?= e($item['unit_code'] ?? '—') ?></td>
                    <td class="num"><?= e(qty($item['qty_requested'])) ?></td>
                    <td class="num"><?= e(qty($approvedQty($item))) ?></td>
                    <td class="num"><?= e(qty($item['qty_delivered'] ?? 0)) ?></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>

<div class="print-signatures" style="grid-template-columns: repeat(4, 1fr);">
    <div class="print-signature">
        <div class="fw-semibold"><?= e($request['applicant_name'] ?? 'Solicitante') ?></div>
        <div>Solicitante</div>
    </div>
    <?php foreach ($signatures as $approval): ?>
        <div class="print-signature">
            <div class="fw-semibold"><?= e($approval['approver_name'] ?? 'Pendiente') ?></div>
            <div><?= e($approval['role_name']) ?></div>
            <div><?= e($approval['action'] === 'APROBADO' ? 'Aprobado' : 'Rechazado') ?><?= !empty($approval['action_at']) ? ' · ' . e(fecha($approval['action_at'], false)) : '' ?></div>
        </div>
    <?php endforeach; ?>
    <?php for ($i = count($signatures); $i < 3; $i++): ?>
        <div class="print-signature">
            <div class="fw-semibold">&nbsp;</div>
            <div><?= e(['Jefe Inmediato', 'Técnica de Almacenes', 'Jefatura de UAA'][$i] ?? 'Aprobación') ?></div>
            <div>Pendiente</div>
        </div>
    <?php endfor; ?>
</div>

<div class="print-footer">
    <span>Documento generado por SIGA-DDE · <?= e(fecha(date('Y-m-d H:i:s'))) ?></span>
    <span>Impreso por: <?= e($user['full_name'] ?? '—') ?> · Copia N° <?= e((int) ($request['print_count'] ?? 0) + 1) ?></span>
</div>
