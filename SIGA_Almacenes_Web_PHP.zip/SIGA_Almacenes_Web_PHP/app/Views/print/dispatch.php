<?php
// Vista de documentos imprimibles: presenta la pantalla de impresión de despacho y sus controles.
/** @var array<string,mixed> $dispatch */
/** @var array<int,array<string,mixed>> $items */
$user = user();
$total = 0.0;
foreach ($items as $item) {
    $total += (float) $item['total_value'];
}
?>
<div class="print-header">
    <div class="logo">DDE</div>
    <div class="flex-grow-1">
        <h1>Dirección Departamental de Educación Cochabamba</h1>
        <p>Unidad Administrativa y Financiera · Almacenes e Inventarios</p>
        <p>Sistema Integrado de Gestión de Almacenes · SIGA-DDE</p>
    </div>
    <div class="text-end small">
        <div><strong><?= e($dispatch['number']) ?></strong></div>
        <div><?= e(fecha($dispatch['dispatch_date'], false)) ?></div>
    </div>
</div>

<div class="print-title">Nota de entrega de materiales y/o bienes</div>

<!-- La tabla presenta los registros obtenidos por el controlador. -->
<table class="print-table mb-3">
    <tbody>
        <tr>
            <th style="width: 18%;">N° de despacho</th>
            <td style="width: 32%;"><?= e($dispatch['number']) ?></td>
            <th style="width: 18%;">Fecha de entrega</th>
            <td style="width: 32%;"><?= e(fecha($dispatch['dispatch_date'])) ?></td>
        </tr>
        <tr>
            <th>Solicitud</th>
            <td><?= e($dispatch['request_code'] ?? '—') ?></td>
            <th>Correspondencia</th>
            <td><?= e($dispatch['correspondence_number'] ?? '—') ?></td>
        </tr>
        <tr>
            <th>Solicitante</th>
            <td><?= e($dispatch['applicant_name'] ?? '—') ?></td>
            <th>Área</th>
            <td><?= e($dispatch['area_name'] ?? '—') ?></td>
        </tr>
        <tr>
            <th>Recibido por</th>
            <td><?= e($dispatch['received_by'] ?? '—') ?></td>
            <th>Cédula de identidad</th>
            <td><?= e($dispatch['received_ci'] ?? '—') ?></td>
        </tr>
        <tr>
            <th>Despachado por</th>
            <td><?= e($dispatch['dispatched_by_name'] ?? '—') ?></td>
            <th>Estado</th>
            <td><?= e(status_label((string) $dispatch['status'])) ?></td>
        </tr>
        <?php if (!empty($dispatch['notes'])): ?>
            <tr>
                <th>Observaciones</th>
                <td colspan="3"><?= nl2br(e($dispatch['notes'])) ?></td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<!-- Tabla de esta pantalla: organiza los registros y sus acciones visibles. -->
<table class="print-table">
    <thead>
        <tr>
            <th style="width: 4%;">N°</th>
            <th style="width: 12%;">Código</th>
            <th>Descripción del producto</th>
            <th style="width: 8%;">Unidad</th>
            <th class="num" style="width: 10%;">Cantidad</th>
            <th class="num" style="width: 13%;">Costo unit. (Bs)</th>
            <th class="num" style="width: 13%;">Valor (Bs)</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($items === []): ?>
            <tr><td colspan="7" class="text-center">Sin ítems registrados</td></tr>
        <?php else: ?>
            <?php foreach ($items as $index => $item): ?>
                <tr>
                    <td class="text-center"><?= e($index + 1) ?></td>
                    <td><?= e($item['product_code']) ?></td>
                    <td><?= e($item['product_name']) ?></td>
                    <td><?= e($item['unit_code'] ?? '—') ?></td>
                    <td class="num"><?= e(qty($item['qty'])) ?></td>
                    <td class="num"><?= e(money($item['unit_cost'], 4)) ?></td>
                    <td class="num"><?= e(money($item['total_value'])) ?></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
    <tfoot>
        <tr>
            <th colspan="6" class="text-end">Valor total del despacho</th>
            <th class="num"><?= e(money($total)) ?></th>
        </tr>
    </tfoot>
</table>

<div class="print-signatures" style="grid-template-columns: repeat(3, 1fr);">
    <div class="print-signature">
        <div class="fw-semibold"><?= e($dispatch['dispatched_by_name'] ?? '—') ?></div>
        <div>Técnica de Almacenes</div>
        <div>Entrega</div>
    </div>
    <div class="print-signature">
        <div class="fw-semibold"><?= e($dispatch['received_by'] ?? '—') ?></div>
        <div>CI: <?= e($dispatch['received_ci'] ?? '—') ?></div>
        <div>Recibe conforme</div>
    </div>
    <div class="print-signature">
        <div class="fw-semibold"><?= e($dispatch['applicant_name'] ?? '—') ?></div>
        <div><?= e($dispatch['area_name'] ?? 'Solicitante') ?></div>
        <div>Visto bueno</div>
    </div>
</div>

<div class="print-footer">
    <span>Documento generado por SIGA-DDE · <?= e(fecha(date('Y-m-d H:i:s'))) ?></span>
    <span>Impreso por: <?= e($user['full_name'] ?? '—') ?></span>
</div>
