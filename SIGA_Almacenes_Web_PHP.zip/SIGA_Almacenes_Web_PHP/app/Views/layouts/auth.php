<?php
// Vista de plantillas y menú general: presenta la pantalla de diseño del acceso y sus controles.
/** @var string $content */
/** @var string $title */

use App\Core\Session;

$title = $title ?? 'SIGA-DDE';
$flashes = Session::consumeFlash();
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title) ?> · SIGA-DDE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= e(asset('css/app.css')) ?>" rel="stylesheet">
</head>
<body class="auth-body">
    <div class="w-100" style="max-width: 460px;">
        <?php foreach ($flashes as $flash): ?>
            <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
            <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show js-auto-dismiss shadow-sm" role="alert">
                <i class="bi bi-info-circle me-1"></i><?= e($flash['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
            </div>
        <?php endforeach; ?>
        <?= $content ?>
        <p class="text-center text-white-50 small mt-3 mb-0">
            Dirección Departamental de Educación Cochabamba · <?= e(date('Y')) ?>
        </p>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>
