<?php
// Vista de plantillas y menú general: presenta la pantalla de estructura general de páginas y sus controles.
/** @var array<string,mixed>|null $user */
/** @var string $content */
/** @var string $title */
/** @var string $currentPath */

use App\Core\Session;

$user = $user ?? user();
$title = $title ?? 'SIGA-DDE';
$currentPath = $currentPath ?? current_path();
$flashes = Session::consumeFlash();

$initials = '';
if ($user !== null) {
    foreach (preg_split('/\s+/', (string) $user['full_name']) ?: [] as $word) {
        if ($word !== '') {
            $initials .= mb_substr($word, 0, 1);
        }
        if (mb_strlen($initials) >= 2) {
            break;
        }
    }
}
$initials = mb_strtoupper($initials !== '' ? $initials : 'US');

$mainNav = [
    ['href' => '/dashboard', 'label' => 'Panel de control', 'icon' => 'bi-grid-1x2', 'perm' => null],
    ['href' => '/inventario', 'label' => 'Inventario', 'icon' => 'bi-box-seam', 'perm' => ['productos.ver']],
    ['href' => '/ingresos', 'label' => 'Ingresos', 'icon' => 'bi-box-arrow-in-down', 'perm' => ['ingresos.ver']],
    ['href' => '/solicitudes', 'label' => 'Solicitudes', 'icon' => 'bi-file-earmark-text', 'perm' => ['solicitudes.crear', 'solicitudes.ver_propias', 'solicitudes.ver_todas', 'solicitudes.ver_area']],
    ['href' => '/aprobaciones', 'label' => 'Aprobaciones', 'icon' => 'bi-check2-square', 'perm' => ['aprobaciones.ver']],
    ['href' => '/salidas', 'label' => 'Salidas / despachos', 'icon' => 'bi-box-arrow-up', 'perm' => ['salidas.ver']],
    ['href' => '/ajustes', 'label' => 'Ajustes', 'icon' => 'bi-sliders', 'perm' => ['ajustes.ver']],
    ['href' => '/reportes', 'label' => 'Reportes', 'icon' => 'bi-bar-chart-line', 'perm' => ['reportes.ver']],
    ['href' => '/arqueo', 'label' => 'Arqueo y periodos', 'icon' => 'bi-clipboard-check', 'perm' => ['arqueo.ver']],
    ['href' => '/catalogos', 'label' => 'Catálogos', 'icon' => 'bi-tags', 'perm' => ['catalogos.ver']],
];

$adminNav = [
    ['href' => '/admin/usuarios', 'label' => 'Usuarios', 'icon' => 'bi-people', 'perm' => ['usuarios.ver']],
    ['href' => '/admin/auditoria', 'label' => 'Auditoría', 'icon' => 'bi-shield-check', 'perm' => ['auditoria.ver']],
    ['href' => '/admin/configuracion', 'label' => 'Configuración', 'icon' => 'bi-gear', 'perm' => ['config.ver']],
];
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
    <title><?= e($title) ?> · SIGA-DDE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= e(asset('css/app.css')) ?>" rel="stylesheet">
</head>
<body>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<div class="app-shell">
    <!-- Menú de navegación: muestra accesos a secciones según el usuario. -->
    <aside class="sidebar" id="sidebar">
        <a class="sidebar-brand" href="<?= e(url('/dashboard')) ?>">
            <span class="brand-logo"><i class="bi bi-boxes"></i></span>
            <span>
                <strong>SIGA-DDE</strong>
                <small>Gestión de Almacenes</small>
            </span>
        </a>
        <!-- Menú de navegación: muestra accesos a secciones según el usuario. -->
        <nav class="sidebar-nav">
            <div class="nav-section-label">Operación</div>
            <?php foreach ($mainNav as $item): ?>
                <?php if ($item['perm'] === null || can_any($item['perm'])): ?>
                    <a class="nav-link <?= is_active_path($item['href']) ?>" href="<?= e(url($item['href'])) ?>">
                        <i class="bi <?= e($item['icon']) ?>"></i>
                        <span><?= e($item['label']) ?></span>
                    </a>
                <?php endif; ?>
            <?php endforeach; ?>

            <?php
            $visibleAdmin = array_filter($adminNav, static fn (array $item): bool => can_any($item['perm']));
            ?>
            <?php if ($visibleAdmin !== []): ?>
                <div class="nav-section-label">Administración</div>
                <?php foreach ($visibleAdmin as $item): ?>
                    <a class="nav-link <?= is_active_path($item['href']) ?>" href="<?= e(url($item['href'])) ?>">
                        <i class="bi <?= e($item['icon']) ?>"></i>
                        <span><?= e($item['label']) ?></span>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </nav>
        <div class="sidebar-footer">
            <div><i class="bi bi-building me-1"></i> DDE Cochabamba</div>
            <div class="mt-1">SIGA-DDE · v2.0 PHP/MySQL</div>
        </div>
    </aside>

    <div class="main-wrapper">
        <!-- Encabezado principal de la pantalla con accesos y datos del usuario. -->
        <header class="topbar">
            <div class="d-flex align-items-center gap-3">
                <button class="btn-menu" id="menuToggle" type="button" aria-label="Abrir menú">
                    <i class="bi bi-list fs-5"></i>
                </button>
                <div>
                    <h1 class="topbar-title"><?= e($title) ?></h1>
                    <p class="topbar-sub"><?= e(date('d/m/Y')) ?> · Gestión física y valorada de inventarios</p>
                </div>
            </div>

            <?php if ($user !== null): ?>
                <div class="dropdown">
                    <button class="user-pill dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <span class="user-avatar"><?= e($initials) ?></span>
                        <span class="text-start">
                            <span class="user-name d-block"><?= e($user['full_name']) ?></span>
                            <span class="user-role d-block"><?= e($user['role_name']) ?></span>
                        </span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                        <li class="px-3 py-2">
                            <div class="fw-semibold"><?= e($user['username']) ?></div>
                            <div class="small text-muted"><?= e($user['area_name'] ?? 'Sin área asignada') ?></div>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item" href="<?= e(url('/perfil')) ?>">
                                <i class="bi bi-person-circle me-2"></i>Mi perfil
                            </a>
                        </li>
                        <li>
                            <!-- El formulario recibe los datos que procesará el controlador. -->
                            <form method="post" action="<?= e(url('/logout')) ?>" class="px-0">
                                <?= csrf_field() ?>
                                <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                                <button class="dropdown-item text-danger" type="submit">
                                    <i class="bi bi-box-arrow-right me-2"></i>Cerrar sesión
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>
            <?php endif; ?>
        </header>

        <main class="content">
            <?php foreach ($flashes as $flash): ?>
                <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
                <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show js-auto-dismiss" role="alert">
                    <i class="bi bi-info-circle me-1"></i><?= e($flash['message']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
                </div>
            <?php endforeach; ?>

            <?= $content ?>
        </main>

        <footer class="px-4 py-3 border-top bg-white text-muted small d-flex justify-content-between flex-wrap gap-2">
            <span>© <?= e(date('Y')) ?> Dirección Departamental de Educación Cochabamba · SIGA-DDE</span>
            <span>Sistema Integrado de Gestión de Almacenes · PHP <?= e(PHP_VERSION) ?></span>
        </footer>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>
