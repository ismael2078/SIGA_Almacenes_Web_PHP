<?php
// Vista de plantillas y menú general: presenta la pantalla de encabezado y navegación y sus controles.
use App\Core\Auth;
use App\Core\Database;
use App\Core\ApprovalFlow;
use App\Models\Request as RequestModel;

$currentUser = Auth::user();
$dbDriver = Database::getDriver();

// Conteo de solicitudes pendientes para el badge
$pendingCount = 0;
if ($currentUser && Auth::can('aprobaciones.ver')) {
    try {
        $db = Database::getConnection();
        $pendingCount = count(ApprovalFlow::pendingFor($db, $currentUser));
    } catch (\Throwable $e) {}
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'SIGA-DDE - Sistema Integrado de Gestión de Almacenes') ?></title>
    
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/css/custom.css">
</head>
<body class="bg-light d-flex flex-column min-vh-100">

<!-- Barra de Navegación Principal -->
<nav class="navbar navbar-expand-lg navbar-dark bg-navy shadow-sm sticky-top">
    <div class="container-fluid px-3 px-lg-4">
        <a class="navbar-brand d-flex align-items-center gap-2" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/dashboard">
            <span class="badge bg-gold text-dark p-2 rounded-3"><i class="bi bi-boxes fs-5"></i></span>
            <div>
                <span class="fw-bold tracking-tight text-white d-block lh-1">SIGA-DDE</span>
                <small class="text-white-50 fs-8">Almacenes Cochabamba</small>
            </div>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarMain">
            <?php if ($currentUser): ?>
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= (str_starts_with(current_path(), '/dashboard')) ? 'active fw-semibold' : '' ?>" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/dashboard">
                        <i class="bi bi-speedometer2 me-1"></i> Dashboard
                    </a>
                </li>

                <?php if (Auth::can('solicitudes.ver_propias') || Auth::can('solicitudes.crear')): ?>
                <li class="nav-item">
                    <a class="nav-link <?= (str_starts_with(current_path(), '/solicitudes')) ? 'active fw-semibold' : '' ?>" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/solicitudes">
                        <i class="bi bi-file-earmark-text me-1"></i> Solicitudes
                    </a>
                </li>
                <?php endif; ?>

                <?php if (Auth::can('aprobaciones.ver')): ?>
                <li class="nav-item">
                    <a class="nav-link position-relative <?= (str_starts_with(current_path(), '/aprobaciones')) ? 'active fw-semibold' : '' ?>" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/aprobaciones">
                        <i class="bi bi-check2-circle me-1"></i> Aprobaciones
                        <?php if ($pendingCount > 0): ?>
                        <span class="badge rounded-pill bg-danger ms-1"><?= $pendingCount ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (Auth::can('inventario.ver_stock') || Auth::can('ingresos.ver') || Auth::can('salidas.ver')): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?= (preg_match('#^/(inventario|ingresos|salidas|kardex|ajustes|arqueo)#', current_path())) ? 'active fw-semibold' : '' ?>" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-box-seam me-1"></i> Almacén & PEPS
                    </a>
                    <ul class="dropdown-menu shadow-sm">
                        <?php if (Auth::can('inventario.ver_stock')): ?>
                        <li><a class="dropdown-item" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/inventario"><i class="bi bi-grid me-2 text-primary"></i>Catálogo & Existencias</a></li>
                        <?php endif; ?>

                        <?php if (Auth::can('ingresos.ver')): ?>
                        <li><a class="dropdown-item" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/ingresos"><i class="bi bi-arrow-down-left-square me-2 text-success"></i>Comprobantes de Ingreso</a></li>
                        <?php endif; ?>

                        <?php if (Auth::can('salidas.ver')): ?>
                        <li><a class="dropdown-item" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/salidas"><i class="bi bi-arrow-up-right-square me-2 text-warning"></i>Despachos / Salidas</a></li>
                        <?php endif; ?>

                        <li><hr class="dropdown-divider"></li>

                        <?php if (Auth::can('inventario.ver_stock')): ?>
                        <li><a class="dropdown-item" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/kardex/resumen"><i class="bi bi-journal-text me-2 text-info"></i>Kardex Físico-Valorado</a></li>
                        <?php endif; ?>

                        <?php if (Auth::can('ajustes.ver')): ?>
                        <li><a class="dropdown-item" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/ajustes"><i class="bi bi-sliders me-2 text-secondary"></i>Ajustes de Inventario</a></li>
                        <?php endif; ?>

                        <?php if (Auth::can('arqueo.ver')): ?>
                        <li><a class="dropdown-item" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/arqueo"><i class="bi bi-clipboard-check me-2 text-dark"></i>Toma Física / Arqueo</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if (Auth::can('reportes.ver')): ?>
                <li class="nav-item">
                    <a class="nav-link <?= (str_starts_with(current_path(), '/reportes')) ? 'active fw-semibold' : '' ?>" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/reportes">
                        <i class="bi bi-bar-chart-line me-1"></i> Reportes
                    </a>
                </li>
                <?php endif; ?>

                <?php if (Auth::can('catalogos.ver')): ?>
                <li class="nav-item">
                    <a class="nav-link <?= (str_starts_with(current_path(), '/catalogos')) ? 'active fw-semibold' : '' ?>" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/catalogos">
                        <i class="bi bi-collection me-1"></i> Catálogos
                    </a>
                </li>
                <?php endif; ?>

                <?php if (Auth::can('usuarios.ver') || Auth::can('auditoria.ver') || Auth::can('config.ver')): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?= (preg_match('#^/(usuarios|auditoria|configuracion)#', current_path())) ? 'active fw-semibold' : '' ?>" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-gear me-1"></i> Administración
                    </a>
                    <ul class="dropdown-menu shadow-sm">
                        <?php if (Auth::can('usuarios.ver')): ?>
                        <li><a class="dropdown-item" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/usuarios"><i class="bi bi-people me-2 text-primary"></i>Usuarios & Roles</a></li>
                        <?php endif; ?>

                        <?php if (Auth::can('auditoria.ver')): ?>
                        <li><a class="dropdown-item" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/auditoria"><i class="bi bi-shield-check me-2 text-success"></i>Bitácora de Auditoría</a></li>
                        <?php endif; ?>

                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/configuracion"><i class="bi bi-sliders2 me-2 text-secondary"></i>Configuración del Sistema</a></li>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>

            <!-- Indicador DB Driver + Usuario + Logout -->
            <div class="d-flex align-items-center gap-2">
                <span class="badge <?= ($dbDriver === 'mysql') ? 'bg-primary' : 'bg-success' ?> d-none d-md-inline-flex align-items-center gap-1 py-2 px-2 text-uppercase">
                    <i class="bi bi-database"></i> <?= strtoupper($dbDriver) ?> <?= ($dbDriver === 'mysql') ? 'Workbench' : 'Demo' ?>
                </span>

                <div class="dropdown">
                    <button class="btn btn-dark-subtle btn-sm dropdown-toggle d-flex align-items-center gap-2 text-white border-0 bg-transparent" type="button" data-bs-toggle="dropdown">
                        <span class="avatar-circle"><?= strtoupper(substr($currentUser['full_name'], 0, 1)) ?></span>
                        <div class="text-start d-none d-sm-block">
                            <span class="d-block fw-semibold lh-1 fs-7"><?= htmlspecialchars($currentUser['full_name']) ?></span>
                            <small class="text-gold fs-8"><?= htmlspecialchars($currentUser['role_name']) ?></small>
                        </div>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                        <li class="px-3 py-2 border-bottom">
                            <div class="fw-bold"><?= htmlspecialchars($currentUser['full_name']) ?></div>
                            <small class="text-muted"><?= htmlspecialchars($currentUser['position'] ?? 'Funcionario') ?></small><br>
                            <span class="badge bg-secondary fs-8 mt-1"><?= htmlspecialchars($currentUser['role_name']) ?></span>
                        </li>
                        <li><a class="dropdown-item mt-1" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/configuracion"><i class="bi bi-key me-2"></i>Cambiar Contraseña</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form action="<?= e(url('/logout')) ?>" method="POST" class="m-0">
                                <?= csrf_field() ?>
                                <button type="submit" class="dropdown-item text-danger"><i class="bi bi-box-arrow-right me-2"></i>Cerrar Sesión</button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
            <?php else: ?>
            <div class="ms-auto">
                <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/login" class="btn btn-outline-light btn-sm"><i class="bi bi-person me-1"></i> Iniciar Sesión</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- Mensajes Flash / Notificaciones -->
<div class="container-fluid px-3 px-lg-4 pt-3">
    <?php if (!empty($flashes)): ?>
        <?php foreach ($flashes as $flash): ?>
            <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
            <div class="alert alert-<?= htmlspecialchars($flash['type']) ?> alert-dismissible fade show shadow-sm" role="alert">
                <?= htmlspecialchars($flash['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- Contenedor Principal de la Vista -->
<main class="flex-grow-1 container-fluid px-3 px-lg-4 pb-4">
