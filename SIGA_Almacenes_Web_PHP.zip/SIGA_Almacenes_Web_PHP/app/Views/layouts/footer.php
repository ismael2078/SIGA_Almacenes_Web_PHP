<!-- Vista de plantillas y menú general: presenta la pantalla de pie de página y sus controles. -->
</main>

<footer class="bg-white border-top py-3 mt-auto">
    <div class="container-fluid px-3 px-lg-4 d-flex flex-column flex-md-row justify-content-between align-items-center gap-2">
        <div class="text-muted fs-7">
            <span class="fw-semibold text-navy">SIGA-DDE</span> &bull; Dirección Departamental de Educación Cochabamba &bull; Gestión 2026
        </div>
        <div class="text-muted fs-8">
            Arquitectura MVC en PHP POO &bull; MySQL Workbench &bull; Integración API Divisas en Vivo
        </div>
    </div>
</footer>

<!-- Bootstrap 5.3 Bundle JS CDN -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Chart.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.2/dist/chart.umd.min.js"></script>
<!-- App Custom JS -->
<script src="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/js/app.js"></script>

</body>
</html>
