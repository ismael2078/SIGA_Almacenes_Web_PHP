<!DOCTYPE html>
<!-- Vista de plantillas y menú general: presenta la pantalla de plantilla de impresión y sus controles. -->

<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'Impresión Oficial - SIGA DDE') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        @page {
            size: letter;
            margin: 10mm;
        }
        body {
            background-color: #525659;
            color: #212529;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            font-size: 11pt;
            margin: 0;
            padding: 0;
        }
        .print-toolbar {
            position: sticky;
            top: 0;
            z-index: 1000;
            background: #ffffff;
            border-bottom: 2px solid #dee2e6;
            padding: 10px 20px;
        }
        .print-canvas {
            width: 215.9mm;
            max-width: 100%;
            margin: 20px auto;
            padding: 0;
            background: transparent;
        }
        @media print {
            body {
                background: #ffffff !important;
                margin: 0 !important;
                padding: 0 !important;
            }
            .print-toolbar, .print-ignore {
                display: none !important;
            }
            .print-canvas {
                width: 100% !important;
                max-width: none !important;
                margin: 0 !important;
                padding: 0 !important;
            }
        }
    </style>
</head>
<body>

<div class="print-toolbar d-flex justify-content-between align-items-center shadow-sm">
    <div class="d-flex align-items-center gap-2">
        <a href="javascript:history.back()" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Volver al Sistema
        </a>
        <span class="fw-semibold text-muted fs-7">Vista previa de impresión oficial</span>
    </div>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-primary btn-sm px-3">
            <i class="bi bi-printer me-1"></i> Imprimir Documento
        </button>
    </div>
</div>

<div class="print-canvas">
    <?= $content ?>
</div>

</body>
</html>
