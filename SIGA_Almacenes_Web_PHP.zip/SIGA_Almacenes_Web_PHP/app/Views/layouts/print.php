<?php
// Vista de plantillas y menú general: presenta la pantalla de diseño para impresión y sus controles.
/** @var string $content */
/** @var string $title */
$title = $title ?? 'Impresión';
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title) ?> · SIGA-DDE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= e(asset('css/app.css')) ?>" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="print-toolbar no-print">
        <div class="d-flex align-items-center gap-2">
            <i class="bi bi-printer fs-5"></i>
            <span class="fw-semibold">Vista de impresión</span>
        </div>
        <div class="d-flex gap-2">
            <button type="button" class="btn btn-gold btn-sm" data-print>
                <i class="bi bi-printer me-1"></i>Imprimir
            </button>
            <button type="button" class="btn btn-outline-light btn-sm" onclick="window.close()">
                <i class="bi bi-x-lg me-1"></i>Cerrar
            </button>
        </div>
    </div>
    <div class="print-page">
        <?= $content ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>
