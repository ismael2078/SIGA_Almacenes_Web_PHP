<!-- Vista de despachos de materiales: presenta la pantalla de listado y búsqueda y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Despachos y Salidas</h3>
        <p class="text-muted mb-0 fs-7">Comprobantes de egreso de materiales, consumo de capas PEPS y actas de entrega</p>
    </div>
    <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/salidas/nueva" class="btn btn-warning shadow-sm fw-semibold">
        <i class="bi bi-box-arrow-up-right me-2"></i>Registrar Despacho
    </a>
</div>

<div class="card shadow-sm">
    <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <span><i class="bi bi-arrow-up-right-square me-2 text-warning"></i>Historial de Despachos Realizados</span>
        <span class="badge bg-light text-dark border"><?= count($dispatches) ?> despachos</span>
    </div>
    <div class="card-body p-0">
        <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
        <div class="table-responsive">
            <!-- La tabla presenta los registros obtenidos por el controlador. -->
            <table class="table table-hover align-middle mb-0 fs-7">
                <thead class="table-light">
                    <tr>
                        <th>Número</th>
                        <th>Solicitud Origen</th>
                        <th>N° Correspondencia</th>
                        <th>Fecha Despacho</th>
                        <th>Despachado por</th>
                        <th>Recibido por (CI)</th>
                        <th class="text-end">Valor PEPS (Bs)</th>
                        <th class="text-center">Estado</th>
                        <th class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($dispatches)): ?>
                        <tr><td colspan="9" class="text-center text-muted py-5">No se registran salidas en el sistema.</td></tr>
                    <?php else: ?>
                        <?php foreach ($dispatches as $d): ?>
                            <tr>
                                <td class="fw-bold text-navy"><?= htmlspecialchars($d['number']) ?></td>
                                <td>
                                    <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/solicitudes/<?= $d['request_id'] ?>" class="text-decoration-none fw-semibold">
                                        <?= htmlspecialchars($d['request_code']) ?>
                                    </a>
                                </td>
                                <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($d['correspondence_number']) ?></span></td>
                                <td><?= date('d/m/Y H:i', strtotime($d['dispatch_date'])) ?></td>
                                <td><?= htmlspecialchars($d['dispatcher_name']) ?></td>
                                <td>
                                    <strong><?= htmlspecialchars($d['received_by']) ?></strong>
                                    <small class="text-muted d-block">CI: <?= htmlspecialchars($d['received_ci'] ?? '-') ?></small>
                                </td>
                                <td class="text-end fw-bold text-navy" data-bob-amount="<?= $d['total_value'] ?>">
                                    Bs <?= number_format((float)$d['total_value'], 2) ?>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-success-subtle text-success border border-success-subtle"><?= htmlspecialchars($d['status']) ?></span>
                                </td>
                                <td class="text-end">
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/salidas/<?= $d['id'] ?>" class="btn btn-outline-primary" title="Ver detalle">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/imprimir/salida/<?= $d['id'] ?>" class="btn btn-outline-secondary" target="_blank" title="Imprimir comprobante oficial">
                                            <i class="bi bi-printer"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
