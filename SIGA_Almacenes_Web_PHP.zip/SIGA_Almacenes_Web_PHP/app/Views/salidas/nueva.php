<!-- Vista de despachos de materiales: presenta la pantalla de registro nuevo y sus controles. -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Registrar Despacho de Material</h3>
        <p class="text-muted mb-0 fs-7">Entrega física, consumo de capas PEPS (FIFO) y generación del comprobante de salida</p>
    </div>
    <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/salidas" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left me-1"></i> Volver
    </a>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-body p-3">
        <label class="form-label fw-semibold text-secondary mb-2">Seleccione una Solicitud Aprobada para Despachar:</label>
        <div class="row g-2 align-items-center">
            <div class="col-12 col-md-9">
                <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                <select class="form-select" id="selectApprovedRequest" onchange="if(this.value) window.location.href='<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/salidas/nueva?request_id=' + this.value">
                    <option value="">-- Seleccionar solicitud aprobada --</option>
                    <?php foreach ($approvedRequests as $ar): ?>
                        <option value="<?= $ar['id'] ?>" <?= ($selectedRequest && $selectedRequest['id'] == $ar['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($ar['code']) ?> - <?= htmlspecialchars($ar['applicant_name']) ?> (<?= htmlspecialchars($ar['area_name'] ?? 'General') ?>) - Hoja: <?= htmlspecialchars($ar['correspondence_number']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-3">
                <span class="badge bg-light text-dark border p-2 w-100 text-center">
                    <?= count($approvedRequests) ?> aprobadas disponibles
                </span>
            </div>
        </div>
    </div>
</div>

<?php if ($selectedRequest): ?>
<!-- El formulario recibe los datos que procesará el controlador. -->
<form action="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/salidas/guardar" method="POST">
            <?= csrf_field() ?>
    <input type="hidden" name="request_id" value="<?= $selectedRequest['id'] ?>">

    <div class="row g-4">
        <!-- Datos de Entrega y Receptor -->
        <div class="col-12 col-lg-4">
            <div class="card shadow-sm mb-4">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header bg-navy text-white">
                    <i class="bi bi-person-check me-2"></i>Datos de Entrega / Receptor
                </div>
                <div class="card-body fs-7 p-3">
                    <div class="mb-3">
                        <label class="form-label text-muted fw-semibold mb-1">Solicitante Titular</label>
                        <input type="text" class="form-control form-control-sm bg-light" readonly value="<?= htmlspecialchars($selectedRequest['applicant_name']) ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-muted fw-semibold mb-1">Área / Oficina</label>
                        <input type="text" class="form-control form-control-sm bg-light" readonly value="<?= htmlspecialchars($selectedRequest['area_name'] ?? '') ?> - <?= htmlspecialchars($selectedRequest['office'] ?? '') ?>">
                    </div>

                    <hr class="my-2">

                    <div class="mb-3">
                        <label class="form-label fw-semibold text-danger mb-1">Nombre de Quien Recibe Físicamente *</label>
                        <input type="text" name="received_by" class="form-control form-control-sm" required value="<?= htmlspecialchars($selectedRequest['applicant_name']) ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold text-danger mb-1">Cédula de Identidad (CI) *</label>
                        <input type="text" name="received_ci" class="form-control form-control-sm" required value="<?= htmlspecialchars($selectedRequest['applicant_ci'] ?? '') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold text-secondary mb-1">Notas de Entrega</label>
                        <textarea name="notes" class="form-control form-control-sm" rows="2" placeholder="Observaciones de entrega..."></textarea>
                    </div>
                </div>
            </div>
        </div>

        <!-- Ítems a Entregar y Consumir PEPS -->
        <div class="col-12 col-lg-8">
            <div class="card shadow-sm">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-box-arrow-right me-2 text-warning"></i>Artículos Autorizados para Entrega</span>
                    <span class="badge bg-primary"><?= count($requestItems) ?> artículos</span>
                </div>
                <div class="card-body p-0">
                    <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                    <div class="table-responsive">
                        <!-- La tabla presenta los registros obtenidos por el controlador. -->
                        <table class="table table-bordered align-middle mb-0 fs-7">
                            <thead class="table-light">
                                <tr>
                                    <th>Producto / SKU</th>
                                    <th class="text-center">Stock Actual</th>
                                    <th class="text-center">Autorizado</th>
                                    <th style="width: 130px;" class="text-center">Cantidad a Entregar *</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($requestItems as $it): ?>
                                <?php if ((float)$it['qty_authorized'] <= 0) continue; ?>
                                    <input type="hidden" name="items[<?= $it['id'] ?>][product_id]" value="<?= $it['product_id'] ?>">
                                    <tr>
                                        <td>
                                            <span class="fw-semibold text-navy d-block"><?= htmlspecialchars($it['product_name']) ?></span>
                                            <small class="text-muted"><?= htmlspecialchars($it['product_code']) ?> &bull; Unidad: <?= htmlspecialchars($it['unit_name'] ?? 'UND') ?></small>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-light text-dark border"><?= number_format((float)$it['current_stock'], 1) ?></span>
                                        </td>
                                        <td class="text-center fw-bold text-primary">
                                            <?= number_format((float)$it['qty_authorized'], 0) ?>
                                        </td>
                                        <td>
                                            <input type="number" step="1" min="1" max="<?= (float)$it['qty_authorized'] ?>" name="items[<?= $it['id'] ?>][qty]" class="form-control form-control-sm text-end fw-bold" required value="<?= (float)$it['qty_authorized'] ?>">
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer bg-white d-flex justify-content-between align-items-center p-3">
                    <span class="text-muted fs-8">Al confirmar, el sistema consumirá automáticamente las capas PEPS más antiguas.</span>
                    <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                    <button type="submit" class="btn btn-warning px-4 fw-bold shadow-sm">
                        <i class="bi bi-check2-circle me-1"></i>Confirmar Despacho y Consumir PEPS
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>
<?php else: ?>
    <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
    <div class="alert alert-info py-4 text-center">
        <i class="bi bi-hand-index-thumb fs-2 d-block mb-2"></i>
        Por favor, seleccione una solicitud aprobada en el selector superior para proceder al despacho.
    </div>
<?php endif; ?>
