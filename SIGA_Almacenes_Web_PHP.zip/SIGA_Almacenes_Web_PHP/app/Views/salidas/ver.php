<!-- Vista de despachos de materiales: presenta la pantalla de consulta de detalle y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div class="d-flex align-items-center gap-3">
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/salidas" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left"></i>
        </a>
        <div>
            <div class="d-flex align-items-center gap-2">
                <h3 class="fw-bold text-navy mb-0"><?= htmlspecialchars($dispatch['number']) ?></h3>
                <span class="badge bg-success px-3 py-1"><?= htmlspecialchars($dispatch['status']) ?></span>
            </div>
            <p class="text-muted mb-0 fs-7">Solicitud: <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/solicitudes/<?= $dispatch['request_id'] ?>" class="fw-semibold text-decoration-none"><?= htmlspecialchars($dispatch['request_code']) ?></a> &bull; Hoja: <?= htmlspecialchars($dispatch['correspondence_number']) ?></p>
        </div>
    </div>
    <div>
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/imprimir/salida/<?= $dispatch['id'] ?>" target="_blank" class="btn btn-outline-primary btn-sm">
            <i class="bi bi-printer me-1"></i>Imprimir Comprobante Oficial
        </a>
    </div>
</div>

<div class="row g-4">
    <div class="col-12 col-lg-4">
        <div class="card shadow-sm mb-4">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header bg-navy text-white">
                <i class="bi bi-info-circle me-2"></i>Datos del Despacho
            </div>
            <div class="card-body fs-7 p-3">
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Fecha y Hora:</span>
                    <strong><?= date('d/m/Y H:i', strtotime($dispatch['dispatch_date'])) ?></strong>
                </div>
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Despachado por (Almacén):</span>
                    <span><?= htmlspecialchars($dispatch['dispatcher_name']) ?></span>
                </div>
                <hr class="my-2">
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Recibido Físicamente por:</span>
                    <strong><?= htmlspecialchars($dispatch['received_by']) ?></strong>
                    <div class="text-muted fs-8">CI: <?= htmlspecialchars($dispatch['received_ci'] ?? '-') ?></div>
                </div>
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Área / Destino:</span>
                    <span><?= htmlspecialchars($dispatch['area_name'] ?? 'General') ?> - <?= htmlspecialchars($dispatch['office'] ?? '') ?></span>
                </div>
                <hr class="my-2">
                <div>
                    <span class="text-muted d-block fs-8">Valor Total Despachado (PEPS):</span>
                    <h4 class="fw-bold text-navy mb-0" data-bob-amount="<?= $dispatch['total_value'] ?>">
                        Bs <?= number_format((float)$dispatch['total_value'], 2) ?>
                    </h4>
                </div>
            </div>
        </div>
    </div>

    <div class="col-12 col-lg-8">
        <div class="card shadow-sm">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-boxes me-2 text-warning"></i>Artículos Despachados</span>
                <span class="badge bg-light text-dark border"><?= count($items) ?> artículos</span>
            </div>
            <div class="card-body p-0">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- La tabla presenta los registros obtenidos por el controlador. -->
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light">
                            <tr>
                                <th>Producto / SKU</th>
                                <th class="text-center">Unidad</th>
                                <th class="text-center">Cantidad Entregada</th>
                                <th class="text-end">Costo Unit. PEPS (Bs)</th>
                                <th class="text-end">Total Valorado (Bs)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $it): ?>
                                <tr>
                                    <td>
                                        <span class="fw-semibold text-navy d-block"><?= htmlspecialchars($it['product_name']) ?></span>
                                        <small class="text-muted"><?= htmlspecialchars($it['product_code']) ?></small>
                                    </td>
                                    <td class="text-center"><?= htmlspecialchars($it['unit_name'] ?? 'UND') ?></td>
                                    <td class="text-center fw-bold"><?= number_format((float)$it['qty'], 0) ?></td>
                                    <td class="text-end">Bs <?= number_format((float)$it['unit_cost'], 4) ?></td>
                                    <td class="text-end fw-bold text-navy">Bs <?= number_format((float)$it['total_value'], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
