<!-- Vista de configuración del sistema: presenta la pantalla de listado y búsqueda y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Configuración del Sistema</h3>
        <p class="text-muted mb-0 fs-7">Parámetros institucionales, calibración de impresión y seguridad de la cuenta</p>
    </div>
</div>

<div class="row g-4">
    <!-- Configuración Institucional y Calibración -->
    <div class="col-12 col-lg-7">
        <div class="card shadow-sm mb-4">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header bg-navy text-white">
                <i class="bi bi-building me-2"></i>Parámetros Institucionales & Impresión
            </div>
            <div class="card-body p-4 fs-7">
                <?php if (\App\Core\Auth::can('config.editar')): ?>
                <!-- El formulario recibe los datos que procesará el controlador. -->
                <form action="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/configuracion/guardar" method="POST">
            <?= csrf_field() ?>
                    <div class="mb-3">
                        <label class="form-label fw-semibold text-secondary mb-1">Nombre Institucional</label>
                        <input type="text" name="institucion_nombre" class="form-control form-control-sm" value="<?= htmlspecialchars($settings['institucion_nombre']) ?>" required>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label class="form-label fw-semibold text-secondary mb-1">Sigla</label>
                            <input type="text" name="institucion_sigla" class="form-control form-control-sm" value="<?= htmlspecialchars($settings['institucion_sigla']) ?>" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-semibold text-secondary mb-1">Tipo de Hoja</label>
                            <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                            <select name="hoja" class="form-select form-select-sm">
                                <option value="carta" <?= ($settings['hoja'] === 'carta') ? 'selected' : '' ?>>Carta (Letter)</option>
                                <option value="oficio" <?= ($settings['hoja'] === 'oficio') ? 'selected' : '' ?>>Oficio (Legal)</option>
                                <option value="A4" <?= ($settings['hoja'] === 'A4') ? 'selected' : '' ?>>A4</option>
                            </select>
                        </div>
                    </div>

                    <hr class="my-3">
                    <h6 class="fw-bold text-navy mb-3"><i class="bi bi-rulers me-2"></i>Calibración de Impresión (Offsets de Hoja Membretada)</h6>

                    <div class="row g-3 mb-3">
                        <div class="col-4">
                            <label class="form-label text-muted fs-8 mb-1">Desplazamiento X (mm)</label>
                            <input type="number" step="0.5" name="offsetX_mm" class="form-control form-control-sm" value="<?= (float)$settings['offsetX_mm'] ?>">
                        </div>
                        <div class="col-4">
                            <label class="form-label text-muted fs-8 mb-1">Desplazamiento Y (mm)</label>
                            <input type="number" step="0.5" name="offsetY_mm" class="form-control form-control-sm" value="<?= (float)$settings['offsetY_mm'] ?>">
                        </div>
                        <div class="col-4">
                            <label class="form-label text-muted fs-8 mb-1">Escala (%)</label>
                            <input type="number" step="1" name="escala" class="form-control form-control-sm" value="<?= (float)$settings['escala'] ?>">
                        </div>
                    </div>

                    <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                    <button type="submit" class="btn btn-primary btn-sm px-4 fw-semibold shadow-sm">
                        <i class="bi bi-save me-1"></i>Guardar Parámetros
                    </button>
                </form>
                <?php else: ?>
                    <p class="text-muted mb-0">La edición de estos parámetros está reservada a administración. Puede cambiar su propia contraseña en el panel de seguridad.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Estado de la Base de Datos -->
        <div class="card shadow-sm border-info-subtle">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <span><i class="bi bi-database-check me-2 text-info"></i>Motor de Base de Datos Activo</span>
                <span class="badge bg-primary text-uppercase"><?= htmlspecialchars($driver) ?></span>
            </div>
            <div class="card-body p-3 fs-7">
                <p class="mb-2">El sistema está ejecutándose actualmente con el controlador: <strong><?= strtoupper($driver) ?></strong>.</p>
                <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
                <div class="alert alert-light border p-2 mb-0 fs-8">
                    <i class="bi bi-info-circle me-1 text-primary"></i>
                    El archivo SQL oficial para MySQL Workbench se encuentra generado en <code>database/SIGA_DDE_MYSQL_TODOS_LOS_REGISTROS.sql</code>, listo para ser importado con 1 clic en cualquier servidor MySQL.
                </div>
            </div>
        </div>
    </div>

    <!-- Seguridad y Cambio de Contraseña -->
    <div class="col-12 col-lg-5">
        <div class="card shadow-sm">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header bg-navy text-white">
                <i class="bi bi-shield-lock me-2"></i>Seguridad de la Cuenta
            </div>
            <div class="card-body p-4 fs-7">
                <!-- Formulario de configuración; se enviará por POST al controlador encargado. -->
                <form action="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/auth/cambiar-password" method="POST">
            <?= csrf_field() ?>
                    <div class="mb-3">
                        <label class="form-label fw-semibold text-secondary mb-1">Contraseña Actual *</label>
                        <input type="password" name="current_password" class="form-control form-control-sm" required placeholder="••••••••">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold text-secondary mb-1">Nueva Contraseña *</label>
                        <input type="password" name="new_password" class="form-control form-control-sm" required placeholder="••••••••">
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold text-secondary mb-1">Confirmar Nueva Contraseña *</label>
                        <input type="password" name="confirm_password" class="form-control form-control-sm" required placeholder="••••••••">
                    </div>

                    <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                    <button type="submit" class="btn btn-warning btn-sm w-100 fw-bold shadow-sm">
                        <i class="bi bi-key me-1"></i>Actualizar Contraseña
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
