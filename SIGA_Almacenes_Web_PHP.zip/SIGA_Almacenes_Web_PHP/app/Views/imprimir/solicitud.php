<?php
// Vista de impresión de documentos: presenta la pantalla de comprobante de solicitud y sus controles.
$ROWS_PER_PAGE = 14;
$pages = array_chunk($items, $ROWS_PER_PAGE);
if (empty($pages)) $pages = [[]];

$dx = $settings['offsetX_mm'] ?? 0;
$dy = $settings['offsetY_mm'] ?? 0;
?>
<style>
    .page-solicitud {
        position: relative;
        width: 215.9mm;
        height: 279.4mm;
        margin: 0 auto 20px;
        background: #ffffff;
        box-shadow: 0 4px 18px rgba(0,0,0,.15);
        overflow: hidden;
    }
    .bg-guide {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        object-fit: fill;
        opacity: .35;
        pointer-events: none;
    }
    .content-layer {
        position: absolute;
        inset: 0;
        transform: translate(<?= (float)$dx ?>mm, <?= (float)$dy ?>mm);
    }
    .field {
        position: absolute;
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        height: 5.5mm;
        padding-bottom: 0.6mm;
        font-size: 9pt;
        line-height: 1.1;
        color: #000;
        font-weight: 500;
    }
    .f-dep    { left: 45.3mm;  top: 60.8mm; width: 67mm; }
    .f-office { left: 147.0mm; top: 60.8mm; width: 48.6mm; }
    .f-dest   { left: 59.3mm;  top: 70.5mm; width: 136.3mm; }
    .f-date   { left: 56.3mm;  top: 80.0mm; width: 47mm; }

    .rows-container {
        position: absolute;
        left: 19.50mm;
        top: 95.8mm;
        width: 176.07mm;
    }
    .row-item {
        display: grid;
        grid-template-columns: 11.95mm 91.33mm 16.89mm 21.70mm 34.20mm;
        height: 7.95mm;
        align-items: center;
        font-size: 9pt;
        line-height: 1.1;
    }
    .row-item > div { padding: 0 1.5mm; overflow: hidden; }
    .c-num, .c-unit, .c-qty { text-align: center; }
    .c-detail { text-align: left; }

    @media print {
        body { background: white !important; }
        .page-solicitud { box-shadow: none !important; margin: 0 !important; page-break-after: always; }
        .page-solicitud:last-of-type { page-break-after: auto; }
        .bg-guide { display: none !important; }
    }
</style>

<div class="mb-3 bg-white p-3 rounded-3 shadow-sm border print-ignore">
    <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
        <div>
            <h5 class="fw-bold mb-0 text-navy">Impresión Oficial de Pedido de Materiales</h5>
            <small class="text-muted">Hoja Carta oficial DDE-CBBA &bull; <?= htmlspecialchars($request['code']) ?></small>
        </div>
        <div class="d-flex align-items-center gap-2">
            <label class="form-check-label fs-7 me-2">
                <input type="checkbox" class="form-check-input" id="toggleBg" checked onchange="document.querySelectorAll('.bg-guide').forEach(el => el.style.display = this.checked ? 'block' : 'none');">
                Ver fondo membretado de guía
            </label>
            <button onclick="window.print()" class="btn btn-primary btn-sm px-3">
                <i class="bi bi-printer me-1"></i>Imprimir Ahora
            </button>
        </div>
    </div>
    
    <!-- Calibrador visual en vivo para ajustar milimétricamente en pantalla -->
    <div class="d-flex align-items-center gap-3 pt-2 border-top flex-wrap bg-light p-2 rounded">
        <span class="fs-8 fw-bold text-secondary"><i class="bi bi-arrows-move me-1"></i>Calibrar Posición en Vivo:</span>
        <div class="d-inline-flex align-items-center gap-1">
            <span class="fs-8 text-muted">Horizontal (X):</span>
            <button type="button" class="btn btn-outline-secondary btn-sm py-0 px-2" onclick="adjustOffset(-0.5, 0)">◀ -0.5</button>
            <span id="lblOffsetX" class="badge bg-white text-dark border px-2 py-1 fs-8"><?= number_format((float)$dx, 1) ?> mm</span>
            <button type="button" class="btn btn-outline-secondary btn-sm py-0 px-2" onclick="adjustOffset(0.5, 0)">+0.5 ▶</button>
        </div>
        <div class="d-inline-flex align-items-center gap-1">
            <span class="fs-8 text-muted">Vertical (Y):</span>
            <button type="button" class="btn btn-outline-secondary btn-sm py-0 px-2" onclick="adjustOffset(0, -0.5)">▲ -0.5</button>
            <span id="lblOffsetY" class="badge bg-white text-dark border px-2 py-1 fs-8"><?= number_format((float)$dy, 1) ?> mm</span>
            <button type="button" class="btn btn-outline-secondary btn-sm py-0 px-2" onclick="adjustOffset(0, 0.5)">+0.5 ▼</button>
        </div>
        <button type="button" class="btn btn-success btn-sm py-0 px-3 fw-semibold ms-auto" id="btnGuardarCalib" onclick="saveCalibration()">
            <i class="bi bi-check2-circle me-1"></i>Guardar Ajuste
        </button>
        <span id="calibMsg" class="fs-8 text-success fw-bold d-none">¡Guardado!</span>
    </div>
</div>

<script>
let curDx = <?= (float)$dx ?>;
let curDy = <?= (float)$dy ?>;
const csrfToken = '<?= csrf_token() ?>';

function applyTransform() {
    document.querySelectorAll('.content-layer').forEach(el => {
        el.style.transform = `translate(${curDx}mm, ${curDy}mm)`;
    });
    document.getElementById('lblOffsetX').textContent = curDx.toFixed(1) + ' mm';
    document.getElementById('lblOffsetY').textContent = curDy.toFixed(1) + ' mm';
}

function adjustOffset(deltaX, deltaY) {
    curDx = Math.round((curDx + deltaX) * 10) / 10;
    curDy = Math.round((curDy + deltaY) * 10) / 10;
    applyTransform();
}

function saveCalibration() {
    const btn = document.getElementById('btnGuardarCalib');
    const msg = document.getElementById('calibMsg');
    btn.disabled = true;
    btn.textContent = 'Guardando...';

    fetch('<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/imprimir/calibrar', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken
        },
        body: JSON.stringify({
            offsetX_mm: curDx,
            offsetY_mm: curDy
        })
    })
    .then(r => r.json())
    .then(data => {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-check2-circle me-1"></i>Guardar Ajuste';
        msg.classList.remove('d-none');
        setTimeout(() => msg.classList.add('d-none'), 3000);
    })
    .catch(err => {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-check2-circle me-1"></i>Guardar Ajuste';
        alert('Error al guardar calibración');
    });
}
</script>

<?php foreach ($pages as $pIndex => $pItems): ?>
<section class="page-solicitud">
    <img class="bg-guide" src="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/plantillas/hoja-membretada/fondo-pedido.jpg" alt="Fondo Oficial">

    <div class="content-layer">
        <div class="field f-dep"><?= htmlspecialchars($request['area_name'] ?? '') ?></div>
        <div class="field f-office"><?= htmlspecialchars($request['office'] ?? '') ?></div>
        <div class="field f-dest"><?= htmlspecialchars($request['justification'] ?? '') ?></div>
        <div class="field f-date"><?= date('d/m/Y', strtotime($request['created_at'])) ?></div>

        <div class="rows-container">
            <?php foreach ($pItems as $i => $it): ?>
                <div class="row-item">
                    <div class="c-num"><?= ($pIndex * $ROWS_PER_PAGE + $i + 1) ?></div>
                    <div class="c-detail"><?= htmlspecialchars($it['product_name']) ?></div>
                    <div class="c-unit"><?= htmlspecialchars($it['unit_code'] ?? 'UND') ?></div>
                    <div class="c-qty"><?= (int)$it['qty_requested'] ?></div>
                    <div></div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endforeach; ?>
