<?php
// Vista de impresión de documentos: presenta la pantalla de comprobante de salida y sus controles.
$dDate = !empty($dispatch['dispatch_date']) ? strtotime($dispatch['dispatch_date']) : time();
?>
<style>
    .salida-sheet {
        position: relative;
        width: 215.9mm;
        min-height: 279.4mm;
        margin: 0 auto 20px;
        background: #ffffff;
        padding: 18mm 20mm 50mm 20mm;
        box-shadow: 0 4px 18px rgba(0,0,0,.15);
        font-family: Arial, sans-serif;
        color: #1a2a40;
        box-sizing: border-box;
    }
    .salida-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        border-bottom: 2px solid #1a2a40;
        padding-bottom: 8px;
        margin-bottom: 15px;
    }
    .logo-img {
        max-height: 55px;
        object-fit: contain;
    }
    .meta-box {
        text-align: right;
        font-size: 8.5pt;
        line-height: 1.4;
    }
    .salida-title {
        text-align: center;
        font-weight: bold;
        font-size: 13pt;
        letter-spacing: 0.5px;
        margin: 12px 0 15px;
        text-transform: uppercase;
        color: #1a2a40;
    }
    .info-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 8px 15px;
        background: #f8fafc;
        border: 1px solid #cbd5e1;
        border-radius: 4px;
        padding: 10px 14px;
        font-size: 8.5pt;
        margin-bottom: 16px;
    }
    .table-salida {
        width: 100%;
        border-collapse: collapse;
        font-size: 8.5pt;
        margin-bottom: 25px;
    }
    .table-salida th, .table-salida td {
        border: 1px solid #cbd5e1;
        padding: 6px 8px;
    }
    .table-salida th {
        background-color: #f1f5f9;
        font-weight: bold;
        text-align: center;
    }
    .firmas-container {
        position: absolute;
        bottom: 16mm;
        left: 20mm;
        right: 20mm;
        display: grid;
        grid-template-columns: 1fr 1fr 1fr;
        gap: 25px;
        font-size: 8pt;
        text-align: center;
    }
    .linea-firma {
        border-top: 1px solid #1a2a40;
        margin-top: 40px;
        padding-top: 6px;
    }
    @media print {
        body { background: white !important; }
        .salida-sheet {
            box-shadow: none !important;
            margin: 0 !important;
            padding: 12mm 15mm 45mm 15mm !important;
            min-height: 279.4mm !important;
            position: relative !important;
        }
        .firmas-container {
            position: absolute;
            bottom: 12mm;
            left: 15mm;
            right: 15mm;
        }
    }
</style>

<div class="salida-sheet">
    <div class="salida-header">
        <div>
            <img src="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/plantillas/solicitud-almacen/logo_izquierda.png" alt="Logo DDE" class="logo-img" onerror="this.style.display='none'">
            <div class="fw-bold fs-7 mt-1"><?= htmlspecialchars($settings['institucion_nombre'] ?? 'Dirección Departamental de Educación Cochabamba') ?></div>
            <div class="text-muted fs-8">Unidad de Almacenes y Suministros</div>
        </div>
        <div class="meta-box">
            <div><strong>N° SALIDA:</strong> <span class="text-danger fw-bold fs-7"><?= htmlspecialchars($dispatch['number']) ?></span></div>
            <div><strong>N° SOLICITUD:</strong> <?= htmlspecialchars($dispatch['request_code']) ?></div>
            <div><strong>CORRESPONDENCIA:</strong> <?= htmlspecialchars($dispatch['correspondence_number']) ?></div>
            <div><strong>FECHA:</strong> <?= date('d/m/Y', $dDate) ?> &bull; <strong>HORA:</strong> <?= date('H:i', $dDate) ?></div>
        </div>
    </div>

    <div class="salida-title">
        Comprobante Oficial de Salida de Almacén
    </div>

    <div class="info-grid">
        <div><strong>Unidad Solicitante:</strong> <?= htmlspecialchars($dispatch['area_name'] ?? 'General') ?></div>
        <div><strong>Oficina / Dependencia:</strong> <?= htmlspecialchars($dispatch['office'] ?? 'Oficina') ?></div>
        <div><strong>Funcionario Solicitante:</strong> <?= htmlspecialchars($dispatch['applicant_name'] ?? '') ?></div>
        <div><strong>Cargo:</strong> <?= htmlspecialchars($dispatch['applicant_position'] ?? 'Funcionario') ?></div>
        <div style="grid-column: span 2;"><strong>Destino / Justificación:</strong> <?= htmlspecialchars($dispatch['justification'] ?? 'Uso institucional') ?></div>
    </div>

    <!-- La tabla presenta los registros obtenidos por el controlador. -->
    <table class="table-salida">
        <thead>
            <tr>
                <th style="width: 30px;">#</th>
                <th style="width: 100px;">Código SKU</th>
                <th>Descripción del Material Entregado</th>
                <th style="width: 70px;">Unidad</th>
                <th style="width: 80px;">Cantidad</th>
                <th style="width: 100px;">C/U PEPS (Bs)</th>
                <th style="width: 100px;">Total (Bs)</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $idx => $it): ?>
                <tr>
                    <td style="text-align: center;"><?= $idx + 1 ?></td>
                    <td style="text-align: center; font-weight: bold;"><?= htmlspecialchars($it['product_code']) ?></td>
                    <td><?= htmlspecialchars($it['product_name']) ?></td>
                    <td style="text-align: center;"><?= htmlspecialchars($it['unit_name'] ?? 'UND') ?></td>
                    <td style="text-align: center; font-weight: bold;"><?= number_format((float)$it['qty'], 0) ?></td>
                    <td style="text-align: right;"><?= number_format((float)$it['unit_cost'], 4) ?></td>
                    <td style="text-align: right; font-weight: bold;"><?= number_format((float)$it['total_value'], 2) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr>
                <th colspan="6" style="text-align: right;">VALOR TOTAL ENTREGADO (PEPS):</th>
                <th style="text-align: right; font-size: 9.5pt; color: #1a2a40;">Bs <?= number_format((float)$dispatch['total_value'], 2) ?></th>
            </tr>
        </tfoot>
    </table>

    <div class="firmas-container">
        <div>
            <div class="linea-firma">
                <div class="fw-bold mb-1"><?= htmlspecialchars($dispatch['dispatcher_name']) ?></div>
                <div class="fs-8 text-secondary">TÉCNICO DE ALMACENES Y ACTIVOS FIJOS</div>
                <div class="fs-8 text-muted">UNIDAD DE ASUNTOS ADMINISTRATIVOS</div>
                <div class="fw-bold text-navy mt-2 pt-1 border-top border-secondary-subtle">Entregue Conforme</div>
            </div>
        </div>
        <div>
            <div class="linea-firma">
                <div class="fw-bold mb-1"><?= htmlspecialchars($dispatch['received_by']) ?></div>
                <div class="fs-8 text-secondary">C.I.: <?= htmlspecialchars($dispatch['received_ci'] ?? '-') ?></div>
                <div class="fs-8 text-muted"><?= htmlspecialchars($dispatch['applicant_position'] ?? 'Funcionario Solicitante') ?></div>
                <div class="fw-bold text-navy mt-2 pt-1 border-top border-secondary-subtle">Recibí Conforme</div>
            </div>
        </div>
        <div>
            <div class="linea-firma">
                <div class="fw-bold mb-1">Responsable de Contabilidad</div>
                <div class="fs-8 text-secondary">UNIDAD ADMINISTRATIVA Y FINANCIERA</div>
                <div class="fs-8 text-muted">DIRECCIÓN DEPARTAMENTAL DE EDUCACIÓN</div>
                <div class="fw-bold text-navy mt-2 pt-1 border-top border-secondary-subtle">Contabilidad</div>
            </div>
        </div>
    </div>
</div>
