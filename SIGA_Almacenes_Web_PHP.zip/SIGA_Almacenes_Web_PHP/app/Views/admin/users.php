<?php
// Vista de administración y seguridad: presenta la pantalla de cuentas de usuario y sus controles.
/** @var array<int,array<string,mixed>> $users */
/** @var array<int,array<string,mixed>> $roles */
/** @var array<int,array<string,mixed>> $areas */
/** @var bool $canManage */
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Gestión de usuarios</h1>
        <p class="page-sub"><?= e(count($users)) ?> usuarios registrados en el sistema</p>
    </div>
    <?php if ($canManage): ?>
        <button class="btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#createUserModal">
            <i class="bi bi-person-plus me-1"></i>Nuevo usuario
        </button>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-body p-0">
        <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
        <div class="table-responsive">
            <!-- La tabla presenta los registros obtenidos por el controlador. -->
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Usuario</th>
                        <th>Nombre completo</th>
                        <th>Rol</th>
                        <th>Área</th>
                        <th>Cargo / oficina</th>
                        <th>Último acceso</th>
                        <th>Estado</th>
                        <?php if ($canManage): ?><th></th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $row): ?>
                        <?php
                        $userData = [
                            'username' => $row['username'],
                            'full_name' => $row['full_name'],
                            'email' => $row['email'],
                            'ci' => $row['ci'],
                            'position' => $row['position'],
                            'office' => $row['office'],
                            'area_id' => $row['area_id'],
                            'jefe_inmediato_id' => $row['jefe_inmediato_id'],
                            'role_id' => $row['role_id'],
                        ];
                        ?>
                        <tr>
                            <td>
                                <div class="fw-semibold mono"><?= e($row['username']) ?></div>
                                <div class="small text-muted"><?= e($row['email'] ?? '—') ?></div>
                            </td>
                            <td>
                                <div class="fw-semibold"><?= e($row['full_name']) ?></div>
                                <div class="small text-muted mono">CI: <?= e($row['ci'] ?? '—') ?></div>
                            </td>
                            <td><span class="badge badge-soft"><?= e($row['role_name'] ?? '—') ?></span></td>
                            <td class="small"><?= e($row['area_name'] ?? 'Sin área') ?></td>
                            <td class="small">
                                <div><?= e($row['position'] ?? '—') ?></div>
                                <div class="text-muted"><?= e($row['office'] ?? '') ?></div>
                            </td>
                            <td class="small text-muted"><?= e(fecha($row['last_login_at'] ?? null)) ?></td>
                            <td><?= status_badge((int) $row['is_active'] === 1 ? 'ACTIVO' : 'INACTIVO') ?></td>
                            <?php if ($canManage): ?>
                                <td class="text-end text-nowrap">
                                    <button type="button" class="btn btn-sm btn-outline-secondary" title="Editar"
                                            data-bs-toggle="modal" data-bs-target="#editUserModal"
                                            data-action="<?= e(url('/admin/usuarios/' . $row['id'])) ?>"
                                            data-user="<?= e(json_encode($userData, JSON_UNESCAPED_UNICODE)) ?>">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <?php if ((int) $row['id'] !== (int) ($user['id'] ?? 0)): ?>
                                        <!-- El formulario recibe los datos que procesará el controlador. -->
                                        <form method="post" action="<?= e(url('/admin/usuarios/' . $row['id'] . '/estado')) ?>" class="d-inline"
                                              data-confirm="¿Cambiar el estado de este usuario?">
                                            <?= csrf_field() ?>
                                            <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                                            <button type="submit" class="btn btn-sm <?= (int) $row['is_active'] === 1 ? 'btn-outline-danger' : 'btn-outline-success' ?>"
                                                    title="<?= (int) $row['is_active'] === 1 ? 'Desactivar' : 'Activar' ?>">
                                                <i class="bi <?= (int) $row['is_active'] === 1 ? 'bi-person-x' : 'bi-person-check' ?>"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if ($canManage): ?>
<!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
<div class="modal fade" id="createUserModal" tabindex="-1" aria-hidden="true">
    <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
        <div class="modal-content">
            <!-- Formulario de administración de usuarios y roles; se enviará por POST al controlador encargado. -->
            <form method="post" action="<?= e(url('/admin/usuarios')) ?>">
                <?= csrf_field() ?>
                <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
                <div class="modal-header">
                    <h5 class="modal-title">Nuevo usuario</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Usuario *</label>
                            <input type="text" class="form-control" name="username" maxlength="40" required autocomplete="off">
                        </div>
                        <div class="col-md-8">
                            <label class="form-label">Nombre completo *</label>
                            <input type="text" class="form-control" name="full_name" maxlength="200" required>
                        </div>
                        <div class="col-md-4"><label class="form-label">CI</label><input type="text" class="form-control" name="ci" maxlength="30"></div>
                        <div class="col-md-4"><label class="form-label">Correo</label><input type="email" class="form-control" name="email" maxlength="120"></div>
                        <div class="col-md-4"><label class="form-label">Cargo</label><input type="text" class="form-control" name="position" maxlength="120"></div>
                        <div class="col-md-4"><label class="form-label">Oficina</label><input type="text" class="form-control" name="office" maxlength="120"></div>
                        <div class="col-md-4">
                            <label class="form-label">Área</label>
                            <!-- Selector de áreas: vincula la operación con una dependencia institucional. -->
                            <select class="form-select" name="area_id">
                                <option value="">Sin área</option>
                                <?php foreach ($areas as $area): ?><option value="<?= e($area['id']) ?>"><?= e($area['name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Jefe inmediato</label>
                            <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                            <select class="form-select" name="jefe_inmediato_id">
                                <option value="">Sin jefe</option>
                                <?php foreach ($users as $candidate): ?><option value="<?= e($candidate['id']) ?>"><?= e($candidate['full_name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Rol *</label>
                            <!-- Selector de roles: define el perfil que recibirá la cuenta. -->
                            <select class="form-select" name="role_id" required>
                                <option value="">Seleccione...</option>
                                <?php foreach ($roles as $role): ?><option value="<?= e($role['id']) ?>"><?= e($role['name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Contraseña *</label>
                            <input type="password" class="form-control" name="password" minlength="8" required autocomplete="new-password">
                            <div class="form-text">Mínimo 8 caracteres.</div>
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="must_change_password" value="1" id="mustChange" checked>
                                <label class="form-check-label small" for="mustChange">Exigir cambio de contraseña</label>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                    <button type="submit" class="btn btn-primary"><i class="bi bi-person-plus me-1"></i>Crear usuario</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
<div class="modal fade" id="editUserModal" tabindex="-1" aria-hidden="true">
    <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
        <div class="modal-content">
            <!-- Formulario de administración de usuarios y roles; se enviará por POST al controlador encargado. -->
            <form method="post" action="#" id="editUserForm">
                <?= csrf_field() ?>
                <div class="modal-header">
                    <h5 class="modal-title">Editar usuario</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-4"><label class="form-label">Usuario *</label><input type="text" class="form-control" name="username" maxlength="40" required></div>
                        <div class="col-md-8"><label class="form-label">Nombre completo *</label><input type="text" class="form-control" name="full_name" maxlength="200" required></div>
                        <div class="col-md-4"><label class="form-label">CI</label><input type="text" class="form-control" name="ci" maxlength="30"></div>
                        <div class="col-md-4"><label class="form-label">Correo</label><input type="email" class="form-control" name="email" maxlength="120"></div>
                        <div class="col-md-4"><label class="form-label">Cargo</label><input type="text" class="form-control" name="position" maxlength="120"></div>
                        <div class="col-md-4"><label class="form-label">Oficina</label><input type="text" class="form-control" name="office" maxlength="120"></div>
                        <div class="col-md-4">
                            <label class="form-label">Área</label>
                            <!-- Selector de áreas: vincula la operación con una dependencia institucional. -->
                            <select class="form-select" name="area_id">
                                <option value="">Sin área</option>
                                <?php foreach ($areas as $area): ?><option value="<?= e($area['id']) ?>"><?= e($area['name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Jefe inmediato</label>
                            <select class="form-select" name="jefe_inmediato_id">
                                <option value="">Sin jefe</option>
                                <?php foreach ($users as $candidate): ?><option value="<?= e($candidate['id']) ?>"><?= e($candidate['full_name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Rol *</label>
                            <select class="form-select" name="role_id" required>
                                <option value="">Seleccione...</option>
                                <?php foreach ($roles as $role): ?><option value="<?= e($role['id']) ?>"><?= e($role['name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Nueva contraseña</label>
                            <input type="password" class="form-control" name="password" minlength="8" autocomplete="new-password" placeholder="Dejar vacío para no cambiar">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Guardar cambios</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
