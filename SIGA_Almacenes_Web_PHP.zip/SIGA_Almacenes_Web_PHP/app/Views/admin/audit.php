<?php
// Vista de administración y seguridad: presenta la pantalla de auditoría y sus controles.
/** @var array<int,array<string,mixed>> $logs */
/** @var array<int,string> $actions */
/** @var string $action */
/** @var string $search */
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Auditoría del sistema</h1>
        <p class="page-sub"><?= e(count($logs)) ?> registros de trazabilidad · últimas 500 acciones</p>
    </div>
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form class="filter-bar row g-2 align-items-end" method="get" action="<?= e(url('/admin/auditoria')) ?>">
    <div class="col-md-5">
        <label class="form-label">Buscar</label>
        <input type="text" class="form-control" name="search" value="<?= e($search) ?>" placeholder="Usuario, nombre o entidad">
    </div>
    <div class="col-md-5">
        <label class="form-label">Acción</label>
        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
        <select class="form-select" name="action">
            <option value="">Todas las acciones</option>
            <?php foreach ($actions as $option): ?>
                <option value="<?= e($option) ?>" <?= selected($action, $option) ?>><?= e($option) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-2 d-grid">
        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
        <button class="btn btn-primary" type="submit"><i class="bi bi-search me-1"></i>Filtrar</button>
    </div>
</form>

<div class="card">
    <div class="card-body p-0">
        <?php if ($logs === []): ?>
            <div class="empty-state"><i class="bi bi-shield-check"></i>No se encontraron registros de auditoría.</div>
        <?php else: ?>
            <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
            <div class="table-responsive">
                <!-- La tabla presenta los registros obtenidos por el controlador. -->
                <table class="table table-sm table-hover mb-0">
                    <thead><tr><th>Fecha</th><th>Usuario</th><th>Acción</th><th>Entidad</th><th>ID</th><th>IP</th><th>Detalle</th></tr></thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                            <tr>
                                <td class="small text-muted text-nowrap"><?= e(fecha($log['created_at'])) ?></td>
                                <td class="small">
                                    <div class="fw-semibold"><?= e($log['full_name'] ?? 'Sistema') ?></div>
                                    <div class="text-muted mono"><?= e($log['username'] ?? '—') ?></div>
                                </td>
                                <td><span class="badge badge-soft"><?= e($log['action']) ?></span></td>
                                <td class="small mono"><?= e($log['entity'] ?? '—') ?></td>
                                <td class="small"><?= e($log['entity_id'] ?? '—') ?></td>
                                <td class="small mono"><?= e($log['ip'] ?? '—') ?></td>
                                <td class="small">
                                    <?php if (!empty($log['before']) || !empty($log['after'])): ?>
                                        <button class="btn btn-sm btn-outline-secondary py-0 px-1" type="button" data-bs-toggle="collapse" data-bs-target="#logDetail<?= e($log['id']) ?>">
                                            <i class="bi bi-code-square"></i>
                                        </button>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php if (!empty($log['before']) || !empty($log['after'])): ?>
                                <tr class="collapse" id="logDetail<?= e($log['id']) ?>">
                                    <td colspan="7" class="bg-light">
                                        <div class="row g-2">
                                            <div class="col-md-6">
                                                <div class="small fw-bold text-muted">ANTES</div>
                                                <pre class="small mb-0 text-wrap"><?= e((string) ($log['before'] ?? '—')) ?></pre>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="small fw-bold text-muted">DESPUÉS</div>
                                                <pre class="small mb-0 text-wrap"><?= e((string) ($log['after'] ?? '—')) ?></pre>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
