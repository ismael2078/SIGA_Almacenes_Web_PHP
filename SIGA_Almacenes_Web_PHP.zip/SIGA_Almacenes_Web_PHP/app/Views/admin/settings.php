<?php
// Vista de administración y seguridad: presenta la pantalla de parámetros de configuración y sus controles.
/** @var array<string,mixed> $settings */
/** @var bool $canEdit */
$value = static fn (string $key, mixed $default = ''): mixed => $settings[$key] ?? $default;
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Configuración del sistema</h1>
        <p class="page-sub">Parámetros institucionales, impresión, alertas y seguridad</p>
    </div>
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form method="post" action="<?= e(url('/admin/configuracion')) ?>">
    <?= csrf_field() ?>
    <div class="row g-3">
        <div class="col-lg-6">
            <div class="card h-100">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header"><i class="bi bi-building me-1"></i>Institución</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label" for="institucion_nombre">Nombre de la institución</label>
                        <input type="text" class="form-control" id="institucion_nombre" name="institucion.nombre"
                               value="<?= e($value('institucion.nombre', 'Dirección Departamental de Educación Cochabamba')) ?>" <?= $canEdit ? '' : 'disabled' ?>>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="institucion_sigla">Sigla</label>
                        <input type="text" class="form-control" id="institucion_sigla" name="institucion.sigla"
                               value="<?= e($value('institucion.sigla', 'DDE')) ?>" <?= $canEdit ? '' : 'disabled' ?>>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label" for="general_moneda">Moneda</label>
                            <input type="text" class="form-control" id="general_moneda" name="general.moneda"
                                   value="<?= e($value('general.moneda', 'BOB')) ?>" <?= $canEdit ? '' : 'disabled' ?>>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="general_zona">Zona horaria</label>
                            <input type="text" class="form-control" id="general_zona" name="general.zona_horaria"
                                   value="<?= e($value('general.zona_horaria', 'America/La_Paz')) ?>" <?= $canEdit ? '' : 'disabled' ?>>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card h-100">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header"><i class="bi bi-printer me-1"></i>Impresión</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label" for="impresion_hoja">Tamaño de hoja</label>
                        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                        <select class="form-select" id="impresion_hoja" name="impresion.hoja" <?= $canEdit ? '' : 'disabled' ?>>
                            <?php foreach (['letter' => 'Carta (letter)', 'a4' => 'A4', 'legal' => 'Oficio (legal)'] as $key => $label): ?>
                                <option value="<?= e($key) ?>" <?= selected($value('impresion.hoja', 'letter'), $key) ?>><?= e($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label" for="offset_x">Desplazamiento X (mm)</label>
                            <input type="number" step="0.1" class="form-control" id="offset_x" name="impresion.offsetX_mm"
                                   value="<?= e($value('impresion.offsetX_mm', 0)) ?>" <?= $canEdit ? '' : 'disabled' ?>>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="offset_y">Desplazamiento Y (mm)</label>
                            <input type="number" step="0.1" class="form-control" id="offset_y" name="impresion.offsetY_mm"
                                   value="<?= e($value('impresion.offsetY_mm', 0)) ?>" <?= $canEdit ? '' : 'disabled' ?>>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="escala">Escala</label>
                            <input type="number" step="0.01" min="0.5" max="2" class="form-control" id="escala" name="impresion.escala"
                                   value="<?= e($value('impresion.escala', 1)) ?>" <?= $canEdit ? '' : 'disabled' ?>>
                        </div>
                    </div>
                    <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
                    <div class="alert alert-info small mt-3 mb-0">
                        <i class="bi bi-info-circle me-1"></i>
                        Los ajustes de impresión permiten calibrar los formatos institucionales en impresoras matriciales o láser.
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header"><i class="bi bi-bell me-1"></i>Alertas y seguridad</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label" for="alertas_stock">Alertas de stock bajo</label>
                        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                        <select class="form-select" id="alertas_stock" name="alertas.stock_bajo" <?= $canEdit ? '' : 'disabled' ?>>
                            <option value="1" <?= selected($value('alertas.stock_bajo', 1), 1) ?>>Activadas</option>
                            <option value="0" <?= selected($value('alertas.stock_bajo', 1), 0) ?>>Desactivadas</option>
                        </select>
                    </div>
                    <div class="mb-0">
                        <label class="form-label" for="sesion_horas">Duración de sesión (horas)</label>
                        <input type="number" min="1" max="72" class="form-control" id="sesion_horas" name="seguridad.sesion_horas"
                               value="<?= e($value('seguridad.sesion_horas', 8)) ?>" <?= $canEdit ? '' : 'disabled' ?>>
                        <div class="form-text">Valor referencial. La sesión del servidor está configurada en 8 horas.</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header"><i class="bi bi-info-circle me-1"></i>Información del sistema</div>
                <div class="card-body">
                    <div class="d-flex justify-content-between small border-bottom py-2">
                        <span class="text-muted">Aplicación</span><span class="fw-semibold">SIGA-DDE PHP/MySQL</span>
                    </div>
                    <div class="d-flex justify-content-between small border-bottom py-2">
                        <span class="text-muted">Versión</span><span class="fw-semibold">2.0</span>
                    </div>
                    <div class="d-flex justify-content-between small border-bottom py-2">
                        <span class="text-muted">Motor de base de datos</span><span class="fw-semibold">MySQL 8 / InnoDB</span>
                    </div>
                    <div class="d-flex justify-content-between small py-2">
                        <span class="text-muted">Valuación</span><span class="fw-semibold">PEPS / FIFO</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if ($canEdit): ?>
        <div class="d-flex justify-content-end mt-3">
            <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
            <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Guardar configuración</button>
        </div>
    <?php endif; ?>
</form>
