<?php
// Vista de ingresos de materiales: presenta la pantalla de listado y búsqueda y sus controles.
/** @var array<int,array<string,mixed>> $entries */
/** @var string $search */
/** @var string $status */
/** @var string $type */
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Ingresos al almacén</h1>
        <p class="page-sub">Registro de compras, donaciones, aperturas y reclasificaciones</p>
    </div>
    <?php if (can('ingresos.crear')): ?>
        <a href="<?= e(url('/ingresos/nuevo')) ?>" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Nuevo ingreso</a>
    <?php endif; ?>
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form class="filter-bar row g-2 align-items-end" method="get" action="<?= e(url('/ingresos')) ?>">
    <div class="col-md-4">
        <label class="form-label">Buscar</label>
        <input type="text" class="form-control" name="search" value="<?= e($search) ?>" placeholder="Número, documento o proveedor">
    </div>
    <div class="col-md-3">
        <label class="form-label">Tipo</label>
        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
        <select class="form-select" name="type">
            <option value="">Todos</option>
            <?php foreach (['APERTURA', 'COMPRA', 'DONACION', 'DEVOLUCION', 'AJUSTE_SOBRANTE', 'RECLASIFICACION'] as $option): ?>
                <option value="<?= e($option) ?>" <?= selected($type, $option) ?>><?= e(doc_type_label($option)) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-3">
        <label class="form-label">Estado</label>
        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
        <select class="form-select" name="status">
            <option value="">Todos</option>
            <?php foreach (['BORRADOR', 'CONFIRMADO', 'ANULADO'] as $option): ?>
                <option value="<?= e($option) ?>" <?= selected($status, $option) ?>><?= e(status_label($option)) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-2 d-grid">
        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
        <button class="btn btn-primary" type="submit"><i class="bi bi-search me-1"></i>Filtrar</button>
    </div>
</form>

<div class="card">
    <div class="card-body p-0">
        <?php if ($entries === []): ?>
            <div class="empty-state"><i class="bi bi-box-arrow-in-down"></i>No se encontraron ingresos.</div>
        <?php else: ?>
            <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
            <div class="table-responsive">
                <!-- La tabla presenta los registros obtenidos por el controlador. -->
                <table class="table table-hover mb-0">
                    <thead>
                        <tr><th>Número</th><th>Tipo</th><th>Fecha</th><th>Proveedor</th><th>Documento</th><th class="num">Total</th><th>Estado</th><th>Registrado por</th><th></th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($entries as $entry): ?>
                            <tr>
                                <td><a href="<?= e(url('/ingresos/' . $entry['id'])) ?>" class="fw-semibold mono"><?= e($entry['number']) ?></a></td>
                                <td><span class="badge badge-soft"><?= e(doc_type_label((string) $entry['type'])) ?></span></td>
                                <td class="small"><?= e(fecha($entry['entry_date'], false)) ?></td>
                                <td class="small"><?= e($entry['supplier_name'] ?? '—') ?></td>
                                <td class="small">
                                    <div><?= e($entry['doc_type'] ?? '—') ?></div>
                                    <div class="text-muted mono"><?= e($entry['doc_number'] ?? '') ?></div>
                                </td>
                                <td class="num fw-semibold">Bs <?= e(money($entry['total_amount'])) ?></td>
                                <td><?= status_badge((string) $entry['status']) ?></td>
                                <td class="small text-muted"><?= e($entry['created_by_name'] ?? '—') ?></td>
                                <td class="text-end">
                                    <a class="btn btn-sm btn-outline-primary" href="<?= e(url('/ingresos/' . $entry['id'])) ?>"><i class="bi bi-eye"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
