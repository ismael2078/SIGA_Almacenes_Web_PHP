<?php
// Vista de ingresos de materiales: presenta la pantalla de registro nuevo y sus controles.
/** @var array<int,array<string,mixed>> $suppliers */
/** @var array<int,array<string,mixed>> $locations */
/** @var array<int,array<string,mixed>> $products */
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Nuevo ingreso</h1>
        <p class="page-sub">El ingreso se crea en borrador; al confirmarlo se generan capas PEPS y kardex</p>
    </div>
    <a href="<?= e(url('/ingresos')) ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form method="post" action="<?= e(url('/ingresos')) ?>" id="entryForm">
    <?= csrf_field() ?>
    <div class="card">
        <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
        <div class="card-header"><i class="bi bi-box-arrow-in-down me-1"></i>Datos del ingreso</div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label" for="type">Tipo de ingreso *</label>
                    <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                    <select class="form-select" id="type" name="type" required>
                        <option value="COMPRA">Compra</option>
                        <option value="DONACION">Donación</option>
                        <option value="APERTURA">Apertura</option>
                        <option value="DEVOLUCION">Devolución</option>
                        <option value="AJUSTE_SOBRANTE">Ajuste por sobrante</option>
                        <option value="RECLASIFICACION">Reclasificación</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label" for="supplier_id">Proveedor</label>
                    <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                    <select class="form-select" id="supplier_id" name="supplier_id">
                        <option value="">Sin proveedor</option>
                        <?php foreach ($suppliers as $supplier): ?>
                            <option value="<?= e($supplier['id']) ?>"><?= e($supplier['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label" for="doc_type">Tipo de documento</label>
                    <input type="text" class="form-control" id="doc_type" name="doc_type" placeholder="FACTURA, ACTA...">
                </div>
                <div class="col-md-2">
                    <label class="form-label" for="doc_number">Número de documento</label>
                    <input type="text" class="form-control" id="doc_number" name="doc_number" placeholder="000123">
                </div>
                <div class="col-md-2">
                    <label class="form-label" for="doc_date">Fecha del documento</label>
                    <input type="date" class="form-control" id="doc_date" name="doc_date" value="<?= e(date('Y-m-d')) ?>">
                </div>
                <div class="col-12">
                    <label class="form-label" for="notes">Notas / justificación</label>
                    <textarea class="form-control" id="notes" name="notes" rows="2" placeholder="Detalle del ingreso, acta o referencia"></textarea>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-3" data-rows="#entryItems" data-template="#entryRowTemplate" data-add-row="#addEntryRow">
        <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
        <div class="card-header d-flex justify-content-between align-items-center">
            <span><i class="bi bi-list-ul me-1"></i>Detalle de productos</span>
            <button type="button" class="btn btn-sm btn-outline-primary" id="addEntryRow"><i class="bi bi-plus-lg me-1"></i>Agregar fila</button>
        </div>
        <div class="card-body p-0">
            <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
            <div class="table-responsive">
                <!-- La tabla presenta los registros obtenidos por el controlador. -->
                <table class="table table-sm mb-0" id="entryItemsTable">
                    <thead>
                        <tr>
                            <th style="min-width: 280px;">Producto</th>
                            <th>Unidad</th>
                            <th class="num">Stock</th>
                            <th style="width: 110px;">Cantidad</th>
                            <th style="width: 130px;">Costo unit. (Bs)</th>
                            <th class="num">Total</th>
                            <th style="min-width: 170px;">Ubicación</th>
                            <th style="min-width: 160px;">Notas</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="entryItems">
                        <tr data-item-row>
                            <td>
                                <!-- Selector de productos: permite asociar artículos con el formulario. -->
                                <select class="form-select form-select-sm product-select" name="product_id[]" required>
                                    <option value="" data-cost="0" data-unit="" data-stock="0">Seleccione un producto...</option>
                                    <?php foreach ($products as $product): ?>
                                        <option value="<?= e($product['id']) ?>" data-cost="<?= e($product['reference_cost']) ?>" data-unit="<?= e($product['unit_code']) ?>" data-stock="<?= e($product['stock_qty']) ?>">
                                            <?= e($product['code'] . ' · ' . $product['name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td><span class="badge badge-soft" data-unit-label>—</span></td>
                            <td class="num"><span data-stock-label>0</span></td>
                            <td><input type="number" step="1" min="0" class="form-control form-control-sm qty-input" name="quantity[]" required></td>
                            <td><input type="number" step="0.0001" min="0" class="form-control form-control-sm cost-input" name="unit_cost[]" required></td>
                            <td class="num"><span data-line-total>0,00</span></td>
                            <td>
                                <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                                <select class="form-select form-select-sm" name="item_location_id[]">
                                    <option value="">Sin ubicación</option>
                                    <?php foreach ($locations as $location): ?>
                                        <option value="<?= e($location['id']) ?>"><?= e($location['code']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td><input type="text" class="form-control form-control-sm" name="item_notes[]" placeholder="Opcional"></td>
                            <td class="text-end"><button type="button" class="btn btn-sm btn-outline-danger" data-remove-row><i class="bi bi-x-lg"></i></button></td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="5" class="text-end fw-semibold">Total del ingreso</td>
                            <td class="num fw-bold" data-grand-total>0,00</td>
                            <td colspan="3"></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-end gap-2 mt-3">
        <a href="<?= e(url('/ingresos')) ?>" class="btn btn-outline-secondary">Cancelar</a>
        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Guardar ingreso</button>
    </div>
</form>

<template id="entryRowTemplate">
    <tr data-item-row>
        <td>
            <select class="form-select form-select-sm product-select" name="product_id[]" required>
                <option value="" data-cost="0" data-unit="" data-stock="0">Seleccione un producto...</option>
                <?php foreach ($products as $product): ?>
                    <option value="<?= e($product['id']) ?>" data-cost="<?= e($product['reference_cost']) ?>" data-unit="<?= e($product['unit_code']) ?>" data-stock="<?= e($product['stock_qty']) ?>">
                        <?= e($product['code'] . ' · ' . $product['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </td>
        <td><span class="badge badge-soft" data-unit-label>—</span></td>
        <td class="num"><span data-stock-label>0</span></td>
        <td><input type="number" step="1" min="0" class="form-control form-control-sm qty-input" name="quantity[]" required></td>
        <td><input type="number" step="0.0001" min="0" class="form-control form-control-sm cost-input" name="unit_cost[]" required></td>
        <td class="num"><span data-line-total>0,00</span></td>
        <td>
            <select class="form-select form-select-sm" name="item_location_id[]">
                <option value="">Sin ubicación</option>
                <?php foreach ($locations as $location): ?>
                    <option value="<?= e($location['id']) ?>"><?= e($location['code']) ?></option>
                <?php endforeach; ?>
            </select>
        </td>
        <td><input type="text" class="form-control form-control-sm" name="item_notes[]" placeholder="Opcional"></td>
        <td class="text-end"><button type="button" class="btn btn-sm btn-outline-danger" data-remove-row><i class="bi bi-x-lg"></i></button></td>
    </tr>
</template>
