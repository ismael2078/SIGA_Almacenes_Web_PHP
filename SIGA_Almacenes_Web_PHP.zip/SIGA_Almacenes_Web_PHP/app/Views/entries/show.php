<?php
// Vista de ingresos de materiales: presenta la pantalla de detalle del registro y sus controles.
/** @var array<string,mixed> $entry */
/** @var array<int,array<string,mixed>> $items */
?>
<div class="page-head">
    <div>
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <h1 class="page-title mb-0">Ingreso <?= e($entry['number']) ?></h1>
            <?= status_badge((string) $entry['status']) ?>
        </div>
        <p class="page-sub"><?= e(doc_type_label((string) $entry['type'])) ?> · registrado el <?= e(fecha($entry['entry_date'])) ?></p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <a href="<?= e(url('/ingresos')) ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
        <?php if ($entry['status'] === 'BORRADOR' && can('ingresos.confirmar')): ?>
            <!-- El formulario recibe los datos que procesará el controlador. -->
            <form method="post" action="<?= e(url('/ingresos/' . $entry['id'] . '/confirmar')) ?>" data-confirm="¿Confirma este ingreso? Se generarán capas PEPS y movimientos de kardex.">
                <?= csrf_field() ?>
                <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                <button class="btn btn-primary" type="submit"><i class="bi bi-check2-circle me-1"></i>Confirmar ingreso</button>
            </form>
        <?php endif; ?>
        <?php if ($entry['status'] !== 'ANULADO' && can('ingresos.anular')): ?>
            <button class="btn btn-outline-danger" type="button" data-bs-toggle="modal" data-bs-target="#voidEntryModal">
                <i class="bi bi-x-octagon me-1"></i>Anular
            </button>
        <?php endif; ?>
    </div>
</div>

<?php if ($entry['status'] === 'ANULADO'): ?>
    <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
    <div class="alert alert-danger">
        <strong>Ingreso anulado.</strong>
        <?= e($entry['void_reason'] ?? '') ?>
        <div class="small mt-1">
            Por <?= e($entry['voided_by_name'] ?? '—') ?> · <?= e(fecha($entry['voided_at'] ?? null)) ?>
        </div>
    </div>
<?php endif; ?>

<div class="row g-3">
    <div class="col-lg-8">
        <div class="card">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-info-circle me-1"></i>Datos del ingreso</div>
            <div class="card-body">
                <div class="detail-grid">
                    <div class="detail-item"><div class="label">Número</div><div class="value mono"><?= e($entry['number']) ?></div></div>
                    <div class="detail-item"><div class="label">Tipo</div><div class="value"><?= e(doc_type_label((string) $entry['type'])) ?></div></div>
                    <div class="detail-item"><div class="label">Proveedor</div><div class="value"><?= e($entry['supplier_name'] ?? 'Sin proveedor') ?></div></div>
                    <div class="detail-item"><div class="label">NIT</div><div class="value mono"><?= e($entry['supplier_nit'] ?? '—') ?></div></div>
                    <div class="detail-item"><div class="label">Documento</div><div class="value"><?= e($entry['doc_type'] ?? '—') ?> <?= e($entry['doc_number'] ?? '') ?></div></div>
                    <div class="detail-item"><div class="label">Fecha documento</div><div class="value"><?= e(fecha($entry['doc_date'] ?? null, false)) ?></div></div>
                    <div class="detail-item"><div class="label">Fecha de ingreso</div><div class="value"><?= e(fecha($entry['entry_date'])) ?></div></div>
                    <div class="detail-item"><div class="label">Confirmado</div><div class="value"><?= e(fecha($entry['posted_at'] ?? null)) ?></div></div>
                    <div class="detail-item"><div class="label">Registrado por</div><div class="value"><?= e($entry['created_by_name'] ?? '—') ?></div></div>
                    <div class="detail-item"><div class="label">Total</div><div class="value">Bs <?= e(money($entry['total_amount'])) ?></div></div>
                </div>
                <?php if (!empty($entry['notes'])): ?>
                    <hr>
                    <div class="small text-muted"><?= nl2br(e($entry['notes'])) ?></div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mt-3">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-list-ul me-1"></i>Detalle de productos</span>
                <span class="badge badge-soft"><?= count($items) ?> ítems</span>
            </div>
            <div class="card-body p-0">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- La tabla presenta los registros obtenidos por el controlador. -->
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Producto</th>
                                <th>Ubicación</th>
                                <th class="num">Cantidad</th>
                                <th class="num">Costo unit.</th>
                                <th class="num">Total</th>
                                <th>Notas</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                                <tr>
                                    <td>
                                        <div class="fw-semibold mono"><?= e($item['product_code']) ?></div>
                                        <div class="small text-muted"><?= e($item['product_name']) ?></div>
                                    </td>
                                    <td class="small"><?= e($item['location_code'] ?? '—') ?></td>
                                    <td class="num"><?= e(qty($item['quantity'])) ?> <?= e($item['unit_code'] ?? '') ?></td>
                                    <td class="num"><?= e(money($item['unit_cost'], 4)) ?></td>
                                    <td class="num fw-semibold"><?= e(money($item['total'])) ?></td>
                                    <td class="small text-muted"><?= e($item['notes'] ?? '—') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" class="text-end fw-semibold">Total del ingreso</td>
                                <td class="num fw-bold">Bs <?= e(money($entry['total_amount'])) ?></td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-diagram-3 me-1"></i>Flujo del documento</div>
            <div class="card-body">
                <div class="timeline">
                    <div class="timeline-item done">
                        <p class="timeline-title">Registro del ingreso</p>
                        <div class="timeline-meta"><?= e(fecha($entry['created_at'])) ?> · <?= e($entry['created_by_name'] ?? '') ?></div>
                    </div>
                    <div class="timeline-item <?= $entry['status'] === 'CONFIRMADO' ? 'done' : ($entry['status'] === 'ANULADO' ? 'rejected' : 'pending') ?>">
                        <p class="timeline-title">Confirmación contable</p>
                        <div class="timeline-meta">
                            <?= $entry['status'] === 'CONFIRMADO'
                                ? 'Confirmado el ' . e(fecha($entry['posted_at'] ?? null))
                                : ($entry['status'] === 'ANULADO' ? 'Documento anulado' : 'Pendiente de confirmación') ?>
                        </div>
                    </div>
                </div>
                <?php if ($entry['status'] === 'BORRADOR'): ?>
                    <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
                    <div class="alert alert-warning small mb-0 mt-2">
                        <i class="bi bi-exclamation-triangle me-1"></i>
                        Al confirmar se crearán las capas PEPS y el kardex. El stock actual no se modifica hasta ese momento.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mt-3">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-shield-check me-1"></i>Control interno</div>
            <div class="card-body small text-muted">
                <p class="mb-2">Los ingresos confirmados no pueden editarse. Para corregir un documento utilice la anulación con motivo o registre un ajuste autorizado.</p>
                <p class="mb-0">La anulación está bloqueada cuando las capas PEPS ya fueron consumidas por despachos o ajustes.</p>
            </div>
        </div>
    </div>
</div>

<?php if ($entry['status'] !== 'ANULADO' && can('ingresos.anular')): ?>
<!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
<div class="modal fade" id="voidEntryModal" tabindex="-1" aria-hidden="true">
    <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
    <div class="modal-dialog modal-dialog-centered">
        <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
        <div class="modal-content">
            <!-- Formulario de entradas de materiales; se enviará por POST al controlador encargado. -->
            <form method="post" action="<?= e(url('/ingresos/' . $entry['id'] . '/anular')) ?>">
                <?= csrf_field() ?>
                <div class="modal-header">
                    <h5 class="modal-title">Anular ingreso <?= e($entry['number']) ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning small">
                        La anulación revierte el stock y el valor del ingreso. Indique un motivo de al menos 15 caracteres.
                    </div>
                    <label class="form-label" for="voidReason">Motivo de anulación *</label>
                    <textarea class="form-control" id="voidReason" name="reason" rows="3" minlength="15" required></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                    <button type="submit" class="btn btn-danger"><i class="bi bi-x-octagon me-1"></i>Anular ingreso</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
