<!-- Vista de arqueo de inventario: presenta la pantalla de listado y búsqueda y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Toma Física de Inventario / Arqueo</h3>
        <p class="text-muted mb-0 fs-7">Verificación y contraste entre saldo del sistema y conteo físico en estantes</p>
    </div>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-printer me-1"></i>Imprimir Planilla de Conteo
        </button>
    </div>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-body p-3">
        <div class="input-group input-group-sm">
            <span class="input-group-text bg-light text-muted"><i class="bi bi-search"></i></span>
            <input type="text" data-table-search="tablaArqueo" class="form-control" placeholder="Buscar por código, estante o descripción...">
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <span><i class="bi bi-clipboard-check me-2 text-dark"></i>Planilla Oficial de Arqueo Físico</span>
        <span class="badge bg-light text-dark border"><?= count($products) ?> artículos</span>
    </div>
    <div class="card-body p-0">
        <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
        <div class="table-responsive">
            <!-- La tabla presenta los registros obtenidos por el controlador. -->
            <table class="table table-bordered table-hover align-middle mb-0 fs-8" id="tablaArqueo">
                <thead class="table-light">
                    <tr>
                        <th style="width: 120px;">Código SKU</th>
                        <th>Descripción del Producto</th>
                        <th style="width: 110px;">Ubicación</th>
                        <th style="width: 100px;" class="text-center">Saldo Sistema</th>
                        <th style="width: 120px;" class="text-center">Conteo Físico</th>
                        <th style="width: 100px;" class="text-center">Diferencia</th>
                        <th>Observaciones de Inspección</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $idx => $p): ?>
                        <tr>
                            <td class="fw-bold text-navy"><?= htmlspecialchars($p['code']) ?></td>
                            <td>
                                <span class="fw-semibold d-block"><?= htmlspecialchars($p['name']) ?></span>
                                <small class="text-muted"><?= htmlspecialchars($p['category_name']) ?></small>
                            </td>
                            <td><?= htmlspecialchars($p['location_code'] ?? 'A1') ?></td>
                            <td class="text-center fw-bold text-primary" id="sys_<?= $idx ?>">
                                <?= number_format((float)$p['stock_qty'], 1) ?> <?= htmlspecialchars($p['unit_code']) ?>
                            </td>
                            <td>
                                <input type="number" step="1" class="form-control form-control-sm text-end" placeholder="0" oninput="calcDiff(this, <?= (float)$p['stock_qty'] ?>, 'diff_<?= $idx ?>')">
                            </td>
                            <td class="text-center fw-bold" id="diff_<?= $idx ?>">-</td>
                            <td>
                                <input type="text" class="form-control form-control-sm" placeholder="Conforme / Diferencia / Rotura...">
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function calcDiff(input, sysQty, diffId) {
    const el = document.getElementById(diffId);
    if (!input.value) {
        el.textContent = '-';
        el.className = 'text-center fw-bold';
        return;
    }
    const counted = parseFloat(input.value) || 0;
    const diff = counted - sysQty;
    if (Math.abs(diff) < 0.0001) {
        el.textContent = '0.000';
        el.className = 'text-center fw-bold text-success';
    } else if (diff > 0) {
        el.textContent = '+' + diff.toFixed(3);
        el.className = 'text-center fw-bold text-primary';
    } else {
        el.textContent = diff.toFixed(3);
        el.className = 'text-center fw-bold text-danger';
    }
}
</script>
