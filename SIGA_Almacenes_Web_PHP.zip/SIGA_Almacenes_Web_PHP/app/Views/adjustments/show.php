<?php
// Vista de ajustes de inventario: presenta la pantalla de detalle del registro y sus controles.
/** @var array<string,mixed> $adjustment */
/** @var array<int,array<string,mixed>> $items */
/** @var array<string,mixed> $user */
$signatures = [
    'ALMACENES' => [
        'label' => 'Técnica de Almacenes',
        'field' => 'approved_almacenes_by',
        'at' => 'approved_almacenes_at',
        'name' => 'approved_almacenes_name',
        'permission' => 'ajustes.aprobar_almacenes',
        'roles' => ['TECNICO_ALMACEN', 'ADMIN'],
    ],
    'CONTRATACIONES' => [
        'label' => 'Contrataciones / UAA',
        'field' => 'approved_contrataciones_by',
        'at' => 'approved_contrataciones_at',
        'name' => 'approved_contrataciones_name',
        'permission' => 'ajustes.aprobar_contrataciones',
        'roles' => ['JEFE_UAA', 'ADMIN'],
    ],
    'JEFATURA' => [
        'label' => 'Jefatura Administrativa',
        'field' => 'approved_admin_by',
        'at' => 'approved_admin_at',
        'name' => 'approved_admin_name',
        'permission' => 'ajustes.aprobar_jefatura',
        'roles' => ['JEFE_UAA', 'ADMIN'],
    ],
];
$total = array_sum(array_map(static fn (array $item): float => (float) $item['total_value'], $items));
?>
<div class="page-head">
    <div>
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <h1 class="page-title mb-0">Ajuste <?= e($adjustment['number']) ?></h1>
            <?= status_badge((string) $adjustment['status']) ?>
            <span class="badge <?= $adjustment['type'] === 'SOBRANTE' ? 'text-bg-success' : 'text-bg-danger' ?>"><?= e(status_label((string) $adjustment['type'])) ?></span>
        </div>
        <p class="page-sub">Acta <?= e($adjustment['act_number'] ?? 'sin número') ?> · <?= e(fecha($adjustment['adjustment_date'])) ?></p>
    </div>
    <a href="<?= e(url('/ajustes')) ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
</div>

<div class="row g-3">
    <div class="col-lg-8">
        <div class="card">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-info-circle me-1"></i>Datos del ajuste</div>
            <div class="card-body">
                <div class="detail-grid">
                    <div class="detail-item"><div class="label">Número</div><div class="value mono"><?= e($adjustment['number']) ?></div></div>
                    <div class="detail-item"><div class="label">Tipo</div><div class="value"><?= e(status_label((string) $adjustment['type'])) ?></div></div>
                    <div class="detail-item"><div class="label">Acta</div><div class="value mono"><?= e($adjustment['act_number'] ?? '—') ?></div></div>
                    <div class="detail-item"><div class="label">Fecha</div><div class="value"><?= e(fecha($adjustment['adjustment_date'])) ?></div></div>
                    <div class="detail-item"><div class="label">Registrado por</div><div class="value"><?= e($adjustment['created_by_name'] ?? '—') ?></div></div>
                    <div class="detail-item"><div class="label">Total</div><div class="value">Bs <?= e(money($total)) ?></div></div>
                </div>
                <hr>
                <div class="label small text-muted text-uppercase fw-bold">Motivo</div>
                <p class="mb-0 small"><?= nl2br(e($adjustment['reason'])) ?></p>
            </div>
        </div>

        <div class="card mt-3">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-list-ul me-1"></i>Detalle del ajuste</span>
                <span class="badge badge-soft"><?= count($items) ?> ítems</span>
            </div>
            <div class="card-body p-0">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- La tabla presenta los registros obtenidos por el controlador. -->
                    <table class="table table-hover mb-0">
                        <thead><tr><th>Producto</th><th class="num">Cantidad</th><th class="num">Costo unit.</th><th class="num">Total</th><th>Notas</th></tr></thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                                <tr>
                                    <td>
                                        <div class="fw-semibold mono"><?= e($item['product_code']) ?></div>
                                        <div class="small text-muted"><?= e($item['product_name']) ?></div>
                                    </td>
                                    <td class="num"><?= e(qty($item['qty'])) ?> <?= e($item['unit_code'] ?? '') ?></td>
                                    <td class="num"><?= e(money($item['unit_cost'], 4)) ?></td>
                                    <td class="num fw-semibold"><?= e(money($item['total_value'])) ?></td>
                                    <td class="small text-muted"><?= e($item['notes'] ?? '—') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr><td colspan="3" class="text-end fw-semibold">Total</td><td class="num fw-bold">Bs <?= e(money($total)) ?></td><td></td></tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>

        <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
        <div class="alert alert-info mt-3 mb-0 small">
            <i class="bi bi-info-circle me-1"></i>
            El efecto sobre existencias y kardex se aplicó al momento del registro. Las firmas completan la aprobación documental del ajuste.
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-pen me-1"></i>Firmas de aprobación</div>
            <div class="card-body">
                <?php foreach ($signatures as $key => $signature): ?>
                    <?php
                    $signedBy = $adjustment[$signature['field']] ?? null;
                    $canSign = !$signedBy && $adjustment['status'] !== 'APROBADO' && $adjustment['status'] !== 'ANULADO'
                        && in_array($user['role_code'], $signature['roles'], true)
                        && can($signature['permission']);
                    ?>
                    <div class="border rounded p-3 mb-2 <?= $signedBy ? 'bg-success-subtle' : '' ?>">
                        <div class="d-flex justify-content-between align-items-start gap-2">
                            <div>
                                <div class="fw-semibold small"><?= e($signature['label']) ?></div>
                                <div class="small text-muted">
                                    <?= $signedBy ? e($adjustment[$signature['name']] ?? 'Firmado') . ' · ' . e(fecha($adjustment[$signature['at']] ?? null)) : 'Pendiente de firma' ?>
                                </div>
                            </div>
                            <?php if ($signedBy): ?>
                                <i class="bi bi-check-circle-fill text-success"></i>
                            <?php endif; ?>
                        </div>
                        <?php if ($canSign): ?>
                            <!-- El formulario recibe los datos que procesará el controlador. -->
                            <form method="post" action="<?= e(url('/ajustes/' . $adjustment['id'] . '/aprobar')) ?>" class="mt-2">
                                <?= csrf_field() ?>
                                <input type="hidden" name="signature" value="<?= e($key) ?>">
                                <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                                <button type="submit" class="btn btn-sm btn-primary w-100"><i class="bi bi-pen me-1"></i>Firmar como <?= e($signature['label']) ?></button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
                <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
                <div class="alert alert-warning small mb-0 mt-2">
                    <i class="bi bi-shield-check me-1"></i>
                    Se requieren las tres firmas para que el ajuste quede APROBADO.
                </div>
            </div>
        </div>

        <div class="card mt-3">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-shield-exclamation me-1"></i>Control interno</div>
            <div class="card-body small text-muted">
                <p class="mb-0">Los ajustes no pueden anularse desde la interfaz. Si detecta un error, registre un ajuste compensatorio con su acta y firma correspondiente.</p>
            </div>
        </div>
    </div>
</div>
