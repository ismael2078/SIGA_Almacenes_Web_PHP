<?php
// Vista de ajustes de inventario: presenta la pantalla de registro nuevo y sus controles.
/** @var array<int,array<string,mixed>> $products */
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Nuevo ajuste de inventario</h1>
        <p class="page-sub">El ajuste afecta el stock de inmediato y queda pendiente de las tres firmas</p>
    </div>
    <a href="<?= e(url('/ajustes')) ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
</div>

<!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
<div class="alert alert-warning">
    <i class="bi bi-exclamation-triangle me-1"></i>
    Los sobrantes crean una nueva capa PEPS. Los faltantes consumen capas PEPS por orden de antigüedad. Verifique el acta de respaldo antes de guardar.
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form method="post" action="<?= e(url('/ajustes')) ?>" id="adjustmentForm">
    <?= csrf_field() ?>
    <div class="card">
        <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
        <div class="card-header"><i class="bi bi-sliders me-1"></i>Datos del ajuste</div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label" for="type">Tipo de ajuste *</label>
                    <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                    <select class="form-select" id="type" name="type" required>
                        <option value="FALTANTE">Faltante</option>
                        <option value="SOBRANTE">Sobrante</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label" for="act_number">Número de acta</label>
                    <input type="text" class="form-control mono" id="act_number" name="act_number" maxlength="60" placeholder="ACTA-2026-001">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="reason">Motivo del ajuste *</label>
                    <input type="text" class="form-control" id="reason" name="reason" minlength="15" maxlength="500" required
                           placeholder="Describa la causa del faltante o sobrante (mínimo 15 caracteres)">
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-3" data-rows="#adjustmentItems" data-template="#adjustmentRowTemplate" data-add-row="#addAdjustmentRow">
        <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
        <div class="card-header d-flex justify-content-between align-items-center">
            <span><i class="bi bi-list-ul me-1"></i>Productos ajustados</span>
            <button type="button" class="btn btn-sm btn-outline-primary" id="addAdjustmentRow"><i class="bi bi-plus-lg me-1"></i>Agregar fila</button>
        </div>
        <div class="card-body p-0">
            <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
            <div class="table-responsive">
                <!-- La tabla presenta los registros obtenidos por el controlador. -->
                <table class="table table-sm mb-0">
                    <thead>
                        <tr>
                            <th style="min-width: 300px;">Producto</th>
                            <th>Unidad</th>
                            <th class="num">Stock actual</th>
                            <th style="width: 120px;">Cantidad</th>
                            <th style="width: 140px;">Costo unit. (Bs)</th>
                            <th class="num">Total</th>
                            <th style="min-width: 180px;">Notas</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="adjustmentItems">
                        <tr data-item-row>
                            <td>
                                <!-- Selector de productos: permite asociar artículos con el formulario. -->
                                <select class="form-select form-select-sm product-select" name="product_id[]" required>
                                    <option value="" data-cost="0" data-unit="" data-stock="0">Seleccione un producto...</option>
                                    <?php foreach ($products as $product): ?>
                                        <option value="<?= e($product['id']) ?>"
                                                data-cost="<?= e($product['reference_cost']) ?>"
                                                data-unit="<?= e($product['unit_code']) ?>"
                                                data-stock="<?= e($product['stock_qty']) ?>">
                                            <?= e($product['code'] . ' · ' . $product['name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td><span class="badge badge-soft" data-unit-label>—</span></td>
                            <td class="num"><span data-stock-label>0</span></td>
                            <td><input type="number" step="1" min="0" class="form-control form-control-sm qty-input" name="qty[]" required></td>
                            <td><input type="number" step="0.0001" min="0" class="form-control form-control-sm cost-input" name="unit_cost[]" required></td>
                            <td class="num"><span data-line-total>0,00</span></td>
                            <td><input type="text" class="form-control form-control-sm" name="item_notes[]" placeholder="Opcional"></td>
                            <td class="text-end"><button type="button" class="btn btn-sm btn-outline-danger" data-remove-row><i class="bi bi-x-lg"></i></button></td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="5" class="text-end fw-semibold">Total del ajuste</td>
                            <td class="num fw-bold" data-grand-total>0,00</td>
                            <td colspan="2"></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-end gap-2 mt-3">
        <a href="<?= e(url('/ajustes')) ?>" class="btn btn-outline-secondary">Cancelar</a>
        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
        <button type="submit" class="btn btn-primary" data-confirm="¿Registrar el ajuste? El stock se modificará de inmediato.">
            <i class="bi bi-save me-1"></i>Registrar ajuste
        </button>
    </div>
</form>

<template id="adjustmentRowTemplate">
    <tr data-item-row>
        <td>
            <!-- Selector de productos: permite asociar artículos con el formulario. -->
            <select class="form-select form-select-sm product-select" name="product_id[]" required>
                <option value="" data-cost="0" data-unit="" data-stock="0">Seleccione un producto...</option>
                <?php foreach ($products as $product): ?>
                    <option value="<?= e($product['id']) ?>"
                            data-cost="<?= e($product['reference_cost']) ?>"
                            data-unit="<?= e($product['unit_code']) ?>"
                            data-stock="<?= e($product['stock_qty']) ?>">
                        <?= e($product['code'] . ' · ' . $product['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </td>
        <td><span class="badge badge-soft" data-unit-label>—</span></td>
        <td class="num"><span data-stock-label>0</span></td>
        <td><input type="number" step="1" min="0" class="form-control form-control-sm qty-input" name="qty[]" required></td>
        <td><input type="number" step="0.0001" min="0" class="form-control form-control-sm cost-input" name="unit_cost[]" required></td>
        <td class="num"><span data-line-total>0,00</span></td>
        <td><input type="text" class="form-control form-control-sm" name="item_notes[]" placeholder="Opcional"></td>
        <td class="text-end"><button type="button" class="btn btn-sm btn-outline-danger" data-remove-row><i class="bi bi-x-lg"></i></button></td>
    </tr>
</template>
