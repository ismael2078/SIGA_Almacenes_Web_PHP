<?php
// Vista de ajustes de inventario: presenta la pantalla de listado y búsqueda y sus controles.
/** @var array<int,array<string,mixed>> $adjustments */
/** @var string $status */
/** @var string $search */
/** @var bool $canCreate */
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Ajustes de inventario</h1>
        <p class="page-sub">Sobrantes y faltantes con respaldo de acta y tres firmas institucionales</p>
    </div>
    <?php if ($canCreate): ?>
        <a href="<?= e(url('/ajustes/nuevo')) ?>" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Nuevo ajuste</a>
    <?php endif; ?>
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form class="filter-bar row g-2 align-items-end" method="get" action="<?= e(url('/ajustes')) ?>">
    <div class="col-md-6">
        <label class="form-label">Buscar</label>
        <input type="text" class="form-control" name="search" value="<?= e($search) ?>" placeholder="Número, motivo o acta">
    </div>
    <div class="col-md-4">
        <label class="form-label">Estado</label>
        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
        <select class="form-select" name="status">
            <option value="">Todos</option>
            <?php foreach (['EN_REVISION', 'APROBADO', 'ANULADO'] as $option): ?>
                <option value="<?= e($option) ?>" <?= selected($status, $option) ?>><?= e(status_label($option)) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-2 d-grid">
        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
        <button class="btn btn-primary" type="submit"><i class="bi bi-search me-1"></i>Filtrar</button>
    </div>
</form>

<div class="card">
    <div class="card-body p-0">
        <?php if ($adjustments === []): ?>
            <div class="empty-state"><i class="bi bi-sliders"></i>No se encontraron ajustes.</div>
        <?php else: ?>
            <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
            <div class="table-responsive">
                <!-- La tabla presenta los registros obtenidos por el controlador. -->
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Número</th>
                            <th>Tipo</th>
                            <th>Motivo</th>
                            <th>Acta</th>
                            <th>Fecha</th>
                            <th>Firmas</th>
                            <th>Estado</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($adjustments as $adjustment): ?>
                            <?php
                            $signatures = 0;
                            foreach (['approved_almacenes_by', 'approved_contrataciones_by', 'approved_admin_by'] as $field) {
                                if (!empty($adjustment[$field])) {
                                    $signatures++;
                                }
                            }
                            ?>
                            <tr>
                                <td><a href="<?= e(url('/ajustes/' . $adjustment['id'])) ?>" class="fw-semibold mono"><?= e($adjustment['number']) ?></a></td>
                                <td><span class="badge <?= $adjustment['type'] === 'SOBRANTE' ? 'text-bg-success' : 'text-bg-danger' ?>"><?= e(status_label((string) $adjustment['type'])) ?></span></td>
                                <td class="small text-muted" style="max-width: 320px;"><?= e(mb_strimwidth((string) $adjustment['reason'], 0, 100, '…')) ?></td>
                                <td class="small mono"><?= e($adjustment['act_number'] ?? '—') ?></td>
                                <td class="small"><?= e(fecha($adjustment['adjustment_date'], false)) ?></td>
                                <td>
                                    <span class="badge badge-soft"><?= $signatures ?>/3</span>
                                </td>
                                <td><?= status_badge((string) $adjustment['status']) ?></td>
                                <td class="text-end">
                                    <a class="btn btn-sm btn-outline-primary" href="<?= e(url('/ajustes/' . $adjustment['id'])) ?>"><i class="bi bi-eye"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
