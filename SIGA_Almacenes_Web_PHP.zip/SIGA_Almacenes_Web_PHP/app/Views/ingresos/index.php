<!-- Vista de ingresos de inventario: presenta la pantalla de listado y búsqueda y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Comprobantes de Ingreso</h3>
        <p class="text-muted mb-0 fs-7">Entradas de almacén, compras, donaciones y apertura de capas PEPS</p>
    </div>
    <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
    <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/ingresos/nuevo" class="btn btn-success shadow-sm">
        <i class="bi bi-plus-circle me-2"></i>Registrar Ingreso
    </a>
</div>

<div class="card shadow-sm">
    <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <span><i class="bi bi-arrow-down-left-square me-2 text-success"></i>Registro Histórico de Ingresos</span>
        <span class="badge bg-light text-dark border"><?= count($entries) ?> ingresos</span>
    </div>
    <div class="card-body p-0">
        <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
        <div class="table-responsive">
            <!-- La tabla presenta los registros obtenidos por el controlador. -->
            <table class="table table-hover align-middle mb-0 fs-7">
                <thead class="table-light">
                    <tr>
                        <th>Número</th>
                        <th>Tipo</th>
                        <th>Proveedor</th>
                        <th>Doc. Respaldo</th>
                        <th>Fecha Ingreso</th>
                        <th class="text-center">Ítems</th>
                        <th class="text-end">Monto Total</th>
                        <th class="text-center">Estado</th>
                        <th class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($entries)): ?>
                        <tr><td colspan="9" class="text-center text-muted py-5">No hay comprobantes de ingreso registrados.</td></tr>
                    <?php else: ?>
                        <?php foreach ($entries as $e): ?>
                            <tr>
                                <td class="fw-bold text-navy"><?= htmlspecialchars($e['number']) ?></td>
                                <td>
                                    <?php
                                    $tBadge = match($e['type']) {
                                        'APERTURA' => 'bg-info text-dark',
                                        'COMPRA' => 'bg-success',
                                        'DONACION' => 'bg-primary',
                                        default => 'bg-secondary'
                                    };
                                    ?>
                                    <span class="badge <?= $tBadge ?>"><?= htmlspecialchars($e['type']) ?></span>
                                </td>
                                <td><?= htmlspecialchars($e['supplier_name'] ?? 'Institucional / Apertura') ?></td>
                                <td>
                                    <span class="badge bg-light text-dark border">
                                        <?= htmlspecialchars($e['doc_type'] ?? '') ?>: <?= htmlspecialchars($e['doc_number'] ?? '-') ?>
                                    </span>
                                </td>
                                <td><?= date('d/m/Y', strtotime($e['entry_date'])) ?></td>
                                <td class="text-center">
                                    <span class="badge bg-secondary-subtle text-dark border"><?= $e['items_count'] ?></span>
                                </td>
                                <td class="text-end fw-bold text-success" data-bob-amount="<?= $e['total_amount'] ?>">
                                    Bs <?= number_format((float)$e['total_amount'], 2) ?>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-success-subtle text-success border border-success-subtle"><?= htmlspecialchars($e['status']) ?></span>
                                </td>
                                <td class="text-end">
                                    <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/ingresos/<?= $e['id'] ?>" class="btn btn-outline-primary btn-sm py-0 px-2 fs-8">
                                        <i class="bi bi-eye me-1"></i>Ver Detalle
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
