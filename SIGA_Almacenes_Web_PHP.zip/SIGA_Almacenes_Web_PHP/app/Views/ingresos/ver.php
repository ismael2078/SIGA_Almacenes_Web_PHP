<!-- Vista de ingresos de inventario: presenta la pantalla de consulta de detalle y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div class="d-flex align-items-center gap-3">
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/ingresos" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left"></i>
        </a>
        <div>
            <div class="d-flex align-items-center gap-2">
                <h3 class="fw-bold text-navy mb-0"><?= htmlspecialchars($entry['number']) ?></h3>
                <span class="badge bg-success-subtle text-success border border-success-subtle px-3 py-1"><?= htmlspecialchars($entry['status']) ?></span>
            </div>
            <p class="text-muted mb-0 fs-7">Tipo: <strong><?= htmlspecialchars($entry['type']) ?></strong> &bull; Fecha: <?= date('d/m/Y', strtotime($entry['entry_date'])) ?></p>
        </div>
    </div>
    <div>
        <button onclick="window.print()" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-printer me-1"></i>Imprimir Comprobante
        </button>
    </div>
</div>

<div class="row g-4">
    <div class="col-12 col-lg-4">
        <div class="card shadow-sm mb-4">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header bg-navy text-white">
                <i class="bi bi-info-circle me-2"></i>Datos del Documento
            </div>
            <div class="card-body fs-7 p-3">
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Proveedor:</span>
                    <strong><?= htmlspecialchars($entry['supplier_name'] ?? 'Institucional / Apertura') ?></strong>
                    <?php if (!empty($entry['supplier_nit'])): ?>
                        <div class="text-muted fs-8">NIT: <?= htmlspecialchars($entry['supplier_nit']) ?></div>
                    <?php endif; ?>
                </div>
                <hr class="my-2">
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Documento de Respaldo:</span>
                    <span><?= htmlspecialchars($entry['doc_type'] ?? '') ?>: <strong><?= htmlspecialchars($entry['doc_number'] ?? '-') ?></strong></span>
                </div>
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Fecha de Confirmación:</span>
                    <span><?= !empty($entry['posted_at']) ? date('d/m/Y H:i', strtotime($entry['posted_at'])) : date('d/m/Y', strtotime($entry['entry_date'])) ?></span>
                </div>
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Registrado por:</span>
                    <span><?= htmlspecialchars($entry['creator_name'] ?? 'Administrador') ?></span>
                </div>
                <hr class="my-2">
                <div>
                    <span class="text-muted d-block fs-8">Monto Total Valorado:</span>
                    <h4 class="fw-bold text-success mb-0" data-bob-amount="<?= $entry['total_amount'] ?>">
                        Bs <?= number_format((float)$entry['total_amount'], 2) ?>
                    </h4>
                </div>
            </div>
        </div>
    </div>

    <div class="col-12 col-lg-8">
        <div class="card shadow-sm">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-boxes me-2 text-primary"></i>Artículos Ingresados y Capas Contables</span>
                <span class="badge bg-light text-dark border"><?= count($items) ?> artículos</span>
            </div>
            <div class="card-body p-0">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- La tabla presenta los registros obtenidos por el controlador. -->
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light">
                            <tr>
                                <th>Producto / SKU</th>
                                <th>Ubicación</th>
                                <th class="text-center">Cantidad</th>
                                <th class="text-end">Costo Unit. (Bs)</th>
                                <th class="text-end">Total (Bs)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $it): ?>
                                <tr>
                                    <td>
                                        <span class="fw-semibold text-navy d-block"><?= htmlspecialchars($it['product_name']) ?></span>
                                        <small class="text-muted"><?= htmlspecialchars($it['product_code']) ?></small>
                                    </td>
                                    <td><?= htmlspecialchars($it['location_name'] ?? 'Almacén Central') ?></td>
                                    <td class="text-center fw-semibold"><?= number_format((float)$it['quantity'], 0) ?> <?= htmlspecialchars($it['unit_name'] ?? '') ?></td>
                                    <td class="text-end">Bs <?= number_format((float)$it['unit_cost'], 4) ?></td>
                                    <td class="text-end fw-bold text-success">Bs <?= number_format((float)$it['total'], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
