<!-- Vista de ingresos de inventario: presenta la pantalla de registro nuevo y sus controles. -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Registrar Comprobante de Ingreso</h3>
        <p class="text-muted mb-0 fs-7">Entrada de suministros, creación de capas contables PEPS y actualización de Kardex</p>
    </div>
    <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/ingresos" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left me-1"></i> Volver
    </a>
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form action="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/ingresos/guardar" method="POST" id="formNuevoIngreso">
            <?= csrf_field() ?>
    <div class="row g-4">
        <!-- Cabecera del Documento de Ingreso -->
        <div class="col-12 col-lg-4">
            <div class="card shadow-sm mb-4">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header bg-navy text-white">
                    <i class="bi bi-receipt me-2"></i>Datos del Ingreso
                </div>
                <div class="card-body fs-7 p-3">
                    <div class="mb-3">
                        <label class="form-label fw-semibold text-secondary mb-1">Tipo de Ingreso *</label>
                        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                        <select name="type" class="form-select form-select-sm" required>
                            <option value="COMPRA">Compra / Adquisición</option>
                            <option value="DONACION">Donación Institucional</option>
                            <option value="AJUSTE_SOBRANTE">Ajuste por Sobrante</option>
                            <option value="RECLASIFICACION">Reclasificación de Material</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold text-secondary mb-1">Proveedor</label>
                        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                        <select name="supplier_id" class="form-select form-select-sm">
                            <option value="">-- Seleccione proveedor --</option>
                            <?php foreach ($suppliers as $s): ?>
                                <option value="<?= $s['id'] ?>">
                                    <?= htmlspecialchars($s['name']) ?> (NIT: <?= htmlspecialchars($s['nit'] ?? '-') ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold text-secondary mb-1">Tipo de Documento de Respaldo</label>
                        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                        <select name="doc_type" class="form-select form-select-sm">
                            <option value="FACTURA">Factura Comercial</option>
                            <option value="NOTA_REMISION">Nota de Remisión</option>
                            <option value="ORDEN_COMPRA">Orden de Compra</option>
                            <option value="ACTA">Acta de Entrega / Recepción</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold text-secondary mb-1">N° de Documento</label>
                        <input type="text" name="doc_number" class="form-control form-control-sm" placeholder="Ej: F-12345">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold text-secondary mb-1">Fecha de Recepción Física</label>
                        <input type="date" name="entry_date" class="form-control form-control-sm" value="<?= date('Y-m-d') ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold text-secondary mb-1">Notas / Observaciones</label>
                        <textarea name="notes" class="form-control form-control-sm" rows="2" placeholder="Observaciones de la entrega..."></textarea>
                    </div>
                </div>
            </div>
        </div>

        <!-- Detalle de Artículos y Costos Unitarios -->
        <div class="col-12 col-lg-8">
            <div class="card shadow-sm">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-boxes me-2 text-primary"></i>Artículos a Ingresar</span>
                    <button type="button" class="btn btn-primary btn-sm" id="btnAgregarItemIngreso">
                        <i class="bi bi-plus-lg me-1"></i>Agregar Artículo
                    </button>
                </div>
                <div class="card-body p-0">
                    <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                    <div class="table-responsive">
                        <!-- La tabla presenta los registros obtenidos por el controlador. -->
                        <table class="table table-bordered align-middle mb-0 fs-7" id="tablaItemsIngreso">
                            <thead class="table-light">
                                <tr>
                                    <th style="min-width: 220px;">Producto / SKU</th>
                                    <th style="min-width: 140px;">Ubicación</th>
                                    <th style="width: 100px;" class="text-center">Cantidad *</th>
                                    <th style="width: 110px;" class="text-center">Costo Unit. (Bs) *</th>
                                    <th style="width: 110px;" class="text-end">Subtotal (Bs)</th>
                                    <th style="width: 45px;" class="text-center"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Filas dinámicas -->
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer bg-white d-flex justify-content-between align-items-center p-3">
                    <div>
                        <span class="text-muted fs-8">Total General Valorado:</span>
                        <h4 class="fw-bold text-success mb-0" id="totalIngresoVal">Bs 0.00</h4>
                    </div>
                    <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                    <button type="submit" class="btn btn-success btn-sm px-4 fw-semibold shadow-sm">
                        <i class="bi bi-check2-circle me-1"></i>Confirmar y Crear Capas PEPS
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const products = <?= json_encode($products) ?>;
    const locations = <?= json_encode($locations) ?>;

    function addIngresoRow() {
        const tbody = document.querySelector('#tablaItemsIngreso tbody');
        const idx = tbody.children.length;
        const tr = document.createElement('tr');

        let prodOptions = '<option value="">-- Seleccionar producto --</option>';
        products.forEach(p => {
            prodOptions += `<option value="${p.id}" data-cost="${p.reference_cost}">${p.code} - ${p.name}</option>`;
        });

        let locOptions = '<option value="">-- Ubicación --</option>';
        locations.forEach(l => {
            locOptions += `<option value="${l.id}">${l.code} - ${l.name}</option>`;
        });

        tr.innerHTML = `
            <td>
                <select name="items[${idx}][product_id]" class="form-select form-select-sm" required onchange="onProdSelect(this, ${idx})">
                    ${prodOptions}
                </select>
            </td>
            <td>
                <select name="items[${idx}][location_id]" class="form-select form-select-sm">
                    ${locOptions}
                </select>
            </td>
            <td>
                <input type="number" step="1" min="1" name="items[${idx}][quantity]" class="form-control form-control-sm text-end qty-input" required value="1" oninput="recalcRow(${idx})">
            </td>
            <td>
                <input type="number" step="0.0001" min="0.0001" name="items[${idx}][unit_cost]" id="cost_${idx}" class="form-control form-control-sm text-end cost-input" required value="0.0000" oninput="recalcRow(${idx})">
            </td>
            <td class="text-end fw-semibold" id="subtotal_${idx}">0.00</td>
            <td class="text-center">
                <button type="button" class="btn btn-outline-danger btn-sm" onclick="this.closest('tr').remove(); recalcTotal();"><i class="bi bi-trash"></i></button>
            </td>
        `;
        tbody.appendChild(tr);
    }

    window.onProdSelect = function (sel, idx) {
        const opt = sel.options[sel.selectedIndex];
        const cost = opt.getAttribute('data-cost') || '0.0000';
        const costInput = document.getElementById(`cost_${idx}`);
        if (costInput) {
            costInput.value = parseFloat(cost).toFixed(4);
            recalcRow(idx);
        }
    };

    window.recalcRow = function (idx) {
        const row = document.querySelector(`#tablaItemsIngreso tbody tr:nth-child(${idx + 1})`);
        if (!row) return;
        const qty = parseFloat(row.querySelector('.qty-input').value) || 0;
        const cost = parseFloat(row.querySelector('.cost-input').value) || 0;
        const sub = (qty * cost).toFixed(2);
        const subEl = document.getElementById(`subtotal_${idx}`);
        if (subEl) subEl.textContent = sub;
        recalcTotal();
    };

    window.recalcTotal = function () {
        let total = 0;
        document.querySelectorAll('#tablaItemsIngreso tbody tr').forEach(row => {
            const qty = parseFloat(row.querySelector('.qty-input')?.value) || 0;
            const cost = parseFloat(row.querySelector('.cost-input')?.value) || 0;
            total += (qty * cost);
        });
        document.getElementById('totalIngresoVal').textContent = 'Bs ' + total.toLocaleString('es-BO', { minimumFractionDigits: 2 });
    };

    // Agregar primera fila automáticamente
    addIngresoRow();

    document.getElementById('btnAgregarItemIngreso').addEventListener('click', addIngresoRow);
});
</script>
