<!-- Vista de gestión de usuarios: presenta la pantalla de listado y búsqueda y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Gestión de Usuarios y Roles (RBAC)</h3>
        <p class="text-muted mb-0 fs-7">Control de cuentas de funcionarios y perfiles de acceso al sistema</p>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-12 col-lg-8">
        <div class="card shadow-sm">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <span><i class="bi bi-people me-2 text-primary"></i>Usuarios Registrados</span>
                <span class="badge bg-light text-dark border"><?= count($users) ?> usuarios</span>
            </div>
            <div class="card-body p-0">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- La tabla presenta los registros obtenidos por el controlador. -->
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light">
                            <tr>
                                <th>Usuario</th>
                                <th>Nombre Completo</th>
                                <th>Cargo / Oficina</th>
                                <th>Rol Asignado</th>
                                <th class="text-center">Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $u): ?>
                                <tr>
                                    <td>
                                        <span class="fw-bold text-navy d-block"><?= htmlspecialchars($u['username']) ?></span>
                                        <small class="text-muted"><?= htmlspecialchars($u['email'] ?? '') ?></small>
                                    </td>
                                    <td>
                                        <div class="fw-semibold"><?= htmlspecialchars($u['full_name']) ?></div>
                                        <small class="text-muted">CI: <?= htmlspecialchars($u['ci'] ?? '-') ?></small>
                                    </td>
                                    <td>
                                        <div><?= htmlspecialchars($u['position'] ?? '-') ?></div>
                                        <small class="text-muted"><?= htmlspecialchars($u['area_name'] ?? 'General') ?></small>
                                    </td>
                                    <td>
                                        <span class="badge bg-primary"><?= htmlspecialchars($u['role_name'] ?? 'Consulta') ?></span>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge <?= $u['is_active'] ? 'bg-success' : 'bg-danger' ?>">
                                            <?= $u['is_active'] ? 'Activo' : 'Inactivo' ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Roles Definidos -->
    <div class="col-12 col-lg-4">
        <div class="card shadow-sm">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header bg-navy text-white">
                <i class="bi bi-shield-lock me-2"></i>Matriz de Roles del Sistema
            </div>
            <div class="card-body p-0">
                <ul class="list-group list-group-flush fs-7">
                    <?php foreach ($roles as $r): ?>
                        <li class="list-group-item p-3">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <span class="fw-bold text-navy"><?= htmlspecialchars($r['name']) ?></span>
                                <span class="badge bg-light text-dark border"><?= htmlspecialchars($r['code']) ?></span>
                            </div>
                            <small class="text-muted d-block"><?= htmlspecialchars($r['description'] ?? '') ?></small>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
</div>
