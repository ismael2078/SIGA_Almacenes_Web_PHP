<!-- Vista de solicitudes de materiales: presenta la pantalla de registro nuevo y sus controles. -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Nueva Solicitud de Materiales</h3>
        <p class="text-muted mb-0 fs-7">Formulario oficial de requerimiento de insumos de escritorio y almacén</p>
    </div>
    <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/solicitudes" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left me-1"></i> Volver
    </a>
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form action="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/solicitudes/guardar" method="POST" id="formNuevaSolicitud">
            <?= csrf_field() ?>
    <div class="row g-4">
        <!-- Datos Generales -->
        <div class="col-12 col-lg-4">
            <div class="card shadow-sm mb-3">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header bg-navy text-white">
                    <i class="bi bi-person-badge me-2"></i>Datos del Solicitante
                </div>
                <div class="card-body fs-7">
                    <div class="mb-3">
                        <label class="form-label text-muted fw-semibold mb-1">Funcionario Solicitante</label>
                        <input type="text" class="form-control form-control-sm bg-light" readonly value="<?= htmlspecialchars($user['full_name']) ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-muted fw-semibold mb-1">Cargo</label>
                        <input type="text" class="form-control form-control-sm bg-light" readonly value="<?= htmlspecialchars($user['position'] ?? 'Funcionario') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-muted fw-semibold mb-1">Área / Unidad Solicitante</label>
                        <!-- Selector de roles: define el perfil que recibirá la cuenta. -->
                        <select name="area_id" class="form-select form-select-sm" required <?= ($user['role_code'] === 'ADMIN') ? '' : 'disabled' ?>>
                            <?php foreach ($areas as $a): ?>
                                <option value="<?= $a['id'] ?>" <?= ($a['id'] == ($user['area_id'] ?? 1)) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($a['name']) ?> (<?= htmlspecialchars($a['code']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if ($user['role_code'] !== 'ADMIN'): ?>
                            <input type="hidden" name="area_id" value="<?= (int)($user['area_id'] ?? 0) ?>">
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-muted fw-semibold mb-1">Oficina / Dependencia</label>
                        <input type="text" name="office" class="form-control form-control-sm" value="<?= htmlspecialchars($user['office'] ?? '') ?>" placeholder="Ej: Recursos Humanos, Dirección...">
                    </div>
                </div>
            </div>

            <div class="card shadow-sm">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header bg-navy text-white">
                    <i class="bi bi-file-earmark-check me-2"></i>Respaldo Institucional
                </div>
                <div class="card-body fs-7">
                    <div class="mb-3">
                        <label class="form-label fw-semibold text-danger mb-1">N° Hoja de Correspondencia *</label>
                        <input type="text" name="correspondence_number" id="corrNumber" class="form-control form-control-sm" required placeholder="Ej: DDE-2026-000456">
                        <small class="text-muted d-block mt-1">Identificador único de correspondencia DDE.</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold text-secondary mb-1">Justificación del Pedido</label>
                        <textarea name="justification" class="form-control form-control-sm" rows="3" placeholder="Indique el destino y necesidad del material solicitado..."></textarea>
                    </div>
                </div>
            </div>
        </div>

        <!-- Ítems Solicitados -->
        <div class="col-12 col-lg-8">
            <div class="card shadow-sm">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-list-check me-2 text-primary"></i>Artículos Solicitados</span>
                    <button type="button" class="btn btn-primary btn-sm" id="btnAgregarItem">
                        <i class="bi bi-plus-lg me-1"></i>Agregar Ítem
                    </button>
                </div>
                <div class="card-body p-0">
                    <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                    <div class="table-responsive">
                        <!-- La tabla presenta los registros obtenidos por el controlador. -->
                        <table class="table table-bordered align-middle mb-0 fs-7" id="itemsTable">
                            <thead class="table-light">
                                <tr>
                                    <th style="min-width: 250px;">Producto / SKU</th>
                                    <th style="width: 80px;" class="text-center">Unidad</th>
                                    <th style="width: 100px;" class="text-center">Stock Disp.</th>
                                    <th style="width: 100px;" class="text-center">Cantidad *</th>
                                    <th>Observación</th>
                                    <th style="width: 50px;" class="text-center">Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Fila inicial generada dinámicamente -->
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer bg-white d-flex justify-content-between align-items-center p-3">
                    <span class="text-muted fs-8">* Las cantidades están sujetas a validación por Inmediato Superior y existencia en Almacén.</span>
                    <div class="d-flex gap-2">
                        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                        <button type="submit" name="submit_action" value="BORRADOR" class="btn btn-outline-secondary btn-sm">
                            <i class="bi bi-save me-1"></i>Guardar Borrador
                        </button>
                        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                        <button type="submit" name="submit_action" value="ENVIAR" class="btn btn-success btn-sm px-4 fw-semibold shadow-sm">
                            <i class="bi bi-send-check me-1"></i>Enviar a Aprobación
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const productsData = <?= json_encode($products) ?>;
    
    // Agregar primera fila automáticamente
    window.addRequestItemRow(productsData);

    // Event listener del botón
    document.getElementById('btnAgregarItem').addEventListener('click', function () {
        window.addRequestItemRow(productsData);
    });
});
</script>
