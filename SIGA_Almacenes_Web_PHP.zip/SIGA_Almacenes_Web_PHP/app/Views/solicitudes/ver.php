<?php
// Vista de solicitudes de materiales: presenta la pantalla de consulta de detalle y sus controles.
use App\Core\Auth;
?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div class="d-flex align-items-center gap-3">
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/solicitudes" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left"></i>
        </a>
        <div>
            <div class="d-flex align-items-center gap-2">
                <h3 class="fw-bold text-navy mb-0"><?= htmlspecialchars($request['code']) ?></h3>
                <?php
                $badgeClass = match($request['status']) {
                    'BORRADOR' => 'bg-secondary',
                    'EN_APROBACION' => 'bg-warning text-dark',
                    'APROBADA' => 'bg-primary',
                    'OBSERVADA' => 'bg-info text-dark',
                    'ATENDIDA' => 'bg-success',
                    'RECHAZADA' => 'bg-danger',
                    'ANULADA' => 'bg-dark',
                    default => 'bg-secondary'
                };
                ?>
                <span class="badge <?= $badgeClass ?> px-3 py-1"><?= htmlspecialchars($request['status']) ?></span>
            </div>
            <p class="text-muted mb-0 fs-7">N° de Correspondencia: <strong><?= htmlspecialchars($request['correspondence_number']) ?></strong></p>
        </div>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/imprimir/<?= $request['id'] ?>" target="_blank" class="btn btn-outline-primary btn-sm">
            <i class="bi bi-printer me-1"></i>Imprimir Pedido Oficial
        </a>
        <?php if ($request['status'] === 'APROBADA' && (can('salidas.preparar') || can('salidas.confirmar') || in_array($user['role_code'] ?? '', ['ADMIN', 'TECNICO_ALMACEN'], true))): ?>
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/salidas/nueva?request_id=<?= $request['id'] ?>" class="btn btn-success btn-sm fw-bold shadow-sm">
            <i class="bi bi-box-seam me-1"></i>Entregar / Despachar Material
        </a>
        <?php endif; ?>
        <?php if ($request['status'] === 'ATENDIDA' && !empty($dispatch)): ?>
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/salidas/<?= $dispatch['id'] ?>" class="btn btn-outline-success btn-sm fw-semibold">
            <i class="bi bi-file-earmark-check me-1"></i>Ver Despacho <?= htmlspecialchars($dispatch['number']) ?>
        </a>
        <?php endif; ?>
        <?php if ((int)$request['applicant_id'] === (int)$user['id'] && in_array($request['status'], ['BORRADOR','OBSERVADA'], true)): ?>
        <!-- El formulario recibe los datos que procesará el controlador. -->
        <form action="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/solicitudes/<?= $request['id'] ?>/enviar" method="POST">
            <?= csrf_field() ?>
            <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
            <button class="btn btn-success btn-sm" type="submit"><i class="bi bi-send me-1"></i>Enviar a aprobación</button>
        </form>
        <?php endif; ?>
        <?php if (((int)$request['applicant_id'] === (int)$user['id'] || $user['role_code'] === 'ADMIN') && in_array($request['status'], ['BORRADOR', 'OBSERVADA', 'EN_APROBACION'], true)): ?>
        <button type="button" class="btn btn-outline-danger btn-sm" data-bs-toggle="modal" data-bs-target="#modalAnular">
            <i class="bi bi-slash-circle me-1"></i>Anular
        </button>
        <?php endif; ?>
    </div>
</div>

<?php if ($request['status'] === 'APROBADA'): ?>
<div class="alert alert-success d-flex justify-content-between align-items-center shadow-sm mb-4">
    <div class="d-flex align-items-center gap-3">
        <i class="bi bi-check-circle-fill fs-3 text-success"></i>
        <div>
            <h6 class="fw-bold mb-1">¡Solicitud Totalmente Aprobada y Lista para Entrega Física!</h6>
            <p class="mb-0 fs-7 text-secondary">
                El Inmediato Superior dio el visto bueno, Almacén verificó stock y la Jefatura UAA autorizó la salida. 
                <?= (can('salidas.preparar') || in_array($user['role_code'] ?? '', ['ADMIN', 'TECNICO_ALMACEN'], true)) ? 'Proceda con el registro del despacho y entrega física al solicitante para marcar la solicitud como <strong>ATENDIDA</strong>.' : 'La Técnica de Almacenes registrará la entrega física del material para completar el ciclo a <strong>ATENDIDA</strong>.' ?>
            </p>
        </div>
    </div>
    <?php if (can('salidas.preparar') || can('salidas.confirmar') || in_array($user['role_code'] ?? '', ['ADMIN', 'TECNICO_ALMACEN'], true)): ?>
    <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/salidas/nueva?request_id=<?= $request['id'] ?>" class="btn btn-success btn-sm px-3 fw-bold text-nowrap">
        <i class="bi bi-box-seam me-1"></i>Entregar Material
    </a>
    <?php endif; ?>
</div>
<?php elseif ($request['status'] === 'ATENDIDA' && !empty($dispatch)): ?>
<div class="alert alert-info d-flex justify-content-between align-items-center shadow-sm mb-4">
    <div class="d-flex align-items-center gap-3">
        <i class="bi bi-bag-check-fill fs-3 text-info"></i>
        <div>
            <h6 class="fw-bold mb-1">Solicitud ATENDIDA - Material Entregado con Éxito</h6>
            <p class="mb-0 fs-7 text-secondary">
                El despacho físico fue completado y registrado bajo el comprobante oficial <strong><?= htmlspecialchars($dispatch['number']) ?></strong>.
            </p>
        </div>
    </div>
    <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/salidas/<?= $dispatch['id'] ?>" class="btn btn-info btn-sm px-3 fw-semibold text-white text-nowrap">
        <i class="bi bi-eye me-1"></i>Ver Comprobante de Entrega
    </a>
</div>
<?php endif; ?>

<div class="row g-4">
    <!-- Información de Cabecera -->
    <div class="col-12 col-lg-4">
        <div class="card shadow-sm mb-4">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header bg-navy text-white">
                <i class="bi bi-info-circle me-2"></i>Detalle de la Solicitud
            </div>
            <div class="card-body fs-7 p-3">
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Solicitante:</span>
                    <strong><?= htmlspecialchars($request['applicant_name']) ?></strong>
                    <div class="text-muted fs-8"><?= htmlspecialchars($request['applicant_position'] ?? '') ?></div>
                </div>
                <hr class="my-2">
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Área / Unidad:</span>
                    <span><?= htmlspecialchars($request['area_name'] ?? 'General') ?> (<?= htmlspecialchars($request['area_code'] ?? '') ?>)</span>
                </div>
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Oficina:</span>
                    <span><?= htmlspecialchars($request['office'] ?? 'No especificada') ?></span>
                </div>
                <hr class="my-2">
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Fecha de Registro:</span>
                    <span><?= date('d/m/Y H:i', strtotime($request['created_at'])) ?></span>
                </div>
                <?php if (!empty($request['approved_at'])): ?>
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Fecha de Aprobación:</span>
                    <span class="text-success"><?= date('d/m/Y H:i', strtotime($request['approved_at'])) ?></span>
                </div>
                <?php endif; ?>
                <?php if (!empty($request['closed_at'])): ?>
                <div class="mb-2">
                    <span class="text-muted d-block fs-8">Fecha de Cierre / Despacho:</span>
                    <span class="text-primary"><?= date('d/m/Y H:i', strtotime($request['closed_at'])) ?></span>
                </div>
                <?php endif; ?>
                <hr class="my-2">
                <div>
                    <span class="text-muted d-block fs-8">Justificación:</span>
                    <p class="mb-0 italic"><?= nl2br(htmlspecialchars($request['justification'] ?? 'Sin justificación registrada.')) ?></p>
                </div>
            </div>
        </div>

        <!-- Historial de Auditoría / Transiciones -->
        <div class="card shadow-sm">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header bg-white">
                <i class="bi bi-clock-history me-2 text-primary"></i>Historial de Transiciones
            </div>
            <div class="card-body p-3 fs-8">
                <?php if (empty($history)): ?>
                    <span class="text-muted">Sin historial de eventos.</span>
                <?php else: ?>
                    <div class="timeline">
                        <?php foreach ($history as $h): ?>
                            <div class="mb-3 border-start border-2 border-primary ps-3 position-relative">
                                <div class="fw-bold text-navy"><?= htmlspecialchars($h['from_state']) ?> &rarr; <?= htmlspecialchars($h['to_state']) ?></div>
                                <div class="text-muted"><?= htmlspecialchars($h['actor_name']) ?> (<?= htmlspecialchars($h['role_name'] ?? 'Rol') ?>)</div>
                                <div class="fst-italic text-secondary"><?= htmlspecialchars($h['comments'] ?? '') ?></div>
                                <small class="text-muted d-block"><?= date('d/m/Y H:i', strtotime($h['created_at'])) ?></small>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Tabla de Ítems Solicitados -->
    <div class="col-12 col-lg-8">
        <div class="card shadow-sm mb-4">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-boxes me-2 text-primary"></i>Artículos Solicitados</span>
                <span class="badge bg-light text-dark border"><?= count($items) ?> ítems</span>
            </div>
            <div class="card-body p-0">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- La tabla presenta los registros obtenidos por el controlador. -->
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light">
                            <tr>
                                <th>SKU / Producto</th>
                                <th class="text-center">Unidad</th>
                                <th class="text-center">Solicitada</th>
                                <th class="text-center">Aprobada</th>
                                <th class="text-center">Autorizada</th>
                                <th class="text-center">Entregada</th>
                                <th class="text-center">Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $it): ?>
                                <tr>
                                    <td>
                                        <span class="fw-semibold text-navy d-block"><?= htmlspecialchars($it['product_name']) ?></span>
                                        <small class="text-muted"><?= htmlspecialchars($it['product_code']) ?></small>
                                    </td>
                                    <td class="text-center"><?= htmlspecialchars($it['unit_code'] ?? 'UND') ?></td>
                                    <td class="text-center fw-semibold"><?= number_format((float)$it['qty_requested'], 0) ?></td>
                                    <td class="text-center"><?= number_format((float)$it['qty_approved'], 0) ?></td>
                                    <td class="text-center text-primary fw-semibold"><?= number_format((float)$it['qty_authorized'], 0) ?></td>
                                    <td class="text-center text-success fw-bold"><?= number_format((float)$it['qty_delivered'], 0) ?></td>
                                    <td class="text-center">
                                        <span class="badge bg-light text-dark border"><?= htmlspecialchars($it['status']) ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php
            $atendida = $request['status'] === 'ATENDIDA';
            $aprobada = in_array($request['status'], ['APROBADA', 'ATENDIDA'], true);
            $enRevision = $request['status'] === 'EN_APROBACION';
            $paso1Ok = $aprobada || ($enRevision && (int)$request['current_step'] > 1);
            $paso2Ok = $aprobada || ($enRevision && (int)$request['current_step'] > 2);
            $paso3Ok = $aprobada;
            $paso4Ok = $atendida;
            $paso4Listo = $request['status'] === 'APROBADA';
        ?>
        <!-- Pasos del Ciclo de Aprobación Jerárquica y Entrega Física -->
        <div class="card shadow-sm">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <span><i class="bi bi-diagram-3 me-2 text-success"></i>Ciclo de Aprobación Jerárquica y Entrega Física</span>
                <span class="fs-8 text-muted fw-semibold">4 Fases Oficiales</span>
            </div>
            <div class="card-body p-3">
                <div class="row g-3">
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="p-3 rounded-3 border h-100 <?= $paso1Ok ? 'border-success bg-success-subtle' : 'bg-light' ?>">
                            <div class="fw-bold fs-7">Paso 1: Inmediato Superior</div>
                            <small class="text-muted d-block">Validación de necesidad</small>
                            <span class="badge <?= $paso1Ok ? 'bg-success' : 'bg-secondary' ?> mt-2">
                                <i class="bi <?= $paso1Ok ? 'bi-check2' : 'bi-clock' ?> me-1"></i><?= $paso1Ok ? 'Aprobado' : 'Pendiente' ?>
                            </span>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="p-3 rounded-3 border h-100 <?= $paso2Ok ? 'border-success bg-success-subtle' : 'bg-light' ?>">
                            <div class="fw-bold fs-7">Paso 2: Almacén DDE</div>
                            <small class="text-muted d-block">Existencia y preparación</small>
                            <span class="badge <?= $paso2Ok ? 'bg-success' : 'bg-secondary' ?> mt-2">
                                <i class="bi <?= $paso2Ok ? 'bi-check2' : 'bi-clock' ?> me-1"></i><?= $paso2Ok ? 'Verificado' : 'Pendiente' ?>
                            </span>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="p-3 rounded-3 border h-100 <?= $paso3Ok ? 'border-success bg-success-subtle' : 'bg-light' ?>">
                            <div class="fw-bold fs-7">Paso 3: Jefatura UAA</div>
                            <small class="text-muted d-block">Autorización final de salida</small>
                            <span class="badge <?= $paso3Ok ? 'bg-success' : 'bg-secondary' ?> mt-2">
                                <i class="bi <?= $paso3Ok ? 'bi-check2' : 'bi-clock' ?> me-1"></i><?= $paso3Ok ? 'Autorizado' : 'Pendiente' ?>
                            </span>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="p-3 rounded-3 border h-100 <?= $paso4Ok ? 'border-success bg-success-subtle' : ($paso4Listo ? 'border-primary bg-primary-subtle' : 'bg-light') ?>">
                            <div class="fw-bold fs-7">Paso 4: Entrega en Almacén</div>
                            <small class="text-muted d-block">Despacho físico y acta</small>
                            <?php if ($paso4Ok): ?>
                                <span class="badge bg-success mt-2">
                                    <i class="bi bi-check2-all me-1"></i>Atendida <?= !empty($dispatch['number']) ? '(' . htmlspecialchars($dispatch['number']) . ')' : '' ?>
                                </span>
                            <?php elseif ($paso4Listo): ?>
                                <span class="badge bg-primary text-white mt-2">
                                    <i class="bi bi-box-seam me-1"></i>Listo p/ Entrega
                                </span>
                            <?php else: ?>
                                <span class="badge bg-secondary mt-2">
                                    <i class="bi bi-clock me-1"></i>Pendiente
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Anular Solicitud -->
<div class="modal fade" id="modalAnular" tabindex="-1">
    <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
    <div class="modal-dialog">
        <!-- Formulario de solicitudes de materiales; se enviará por POST al controlador encargado. -->
        <form action="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/solicitudes/<?= $request['id'] ?>/anular" method="POST" class="modal-content">
            <?= csrf_field() ?>
            <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
            <div class="modal-header">
                <h5 class="modal-title text-danger"><i class="bi bi-exclamation-triangle me-2"></i>Anular Solicitud</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
            <div class="modal-body fs-7">
                <p>¿Está seguro de anular la solicitud <strong><?= htmlspecialchars($request['code']) ?></strong>?</p>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Motivo de anulación *</label>
                    <textarea name="reason" class="form-control" rows="3" required placeholder="Especifique el motivo de anulación..."></textarea>
                </div>
            </div>
            <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                <button type="submit" class="btn btn-danger btn-sm">Confirmar Anulación</button>
            </div>
        </form>
    </div>
</div>
