<?php
// Vista de solicitudes de materiales: presenta la pantalla de listado y búsqueda y sus controles.
use App\Core\Auth;
?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Solicitudes de Materiales</h3>
        <p class="text-muted mb-0 fs-7">Gestión y seguimiento de requerimientos de insumos institucionales</p>
    </div>
    <?php if (Auth::can('solicitudes.crear')): ?>
    <div>
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/solicitudes/nueva" class="btn btn-primary shadow-sm">
            <i class="bi bi-plus-circle me-2"></i>Nueva Solicitud
        </a>
    </div>
    <?php endif; ?>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-body p-3">
        <!-- El formulario recibe los datos que procesará el controlador. -->
        <form method="GET" action="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/solicitudes" class="row g-2 align-items-center">
            <div class="col-12 col-md-5">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-light text-muted"><i class="bi bi-search"></i></span>
                    <input type="text" name="search" class="form-control" placeholder="Buscar por código, N° correspondencia o solicitante..." value="<?= htmlspecialchars($filters['search'] ?? '') ?>">
                </div>
            </div>
            <div class="col-12 col-md-4">
                <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">-- Todos los estados --</option>
                    <option value="BORRADOR" <?= (($filters['status'] ?? '') === 'BORRADOR') ? 'selected' : '' ?>>Borrador</option>
                    <option value="EN_APROBACION" <?= (($filters['status'] ?? '') === 'EN_APROBACION') ? 'selected' : '' ?>>En Aprobación</option>
                    <option value="APROBADA" <?= (($filters['status'] ?? '') === 'APROBADA') ? 'selected' : '' ?>>Aprobada (Lista p/ entrega)</option>
                    <option value="OBSERVADA" <?= (($filters['status'] ?? '') === 'OBSERVADA') ? 'selected' : '' ?>>Observada / Devuelta</option>
                    <option value="ATENDIDA" <?= (($filters['status'] ?? '') === 'ATENDIDA') ? 'selected' : '' ?>>Atendida / Entregada</option>
                    <option value="RECHAZADA" <?= (($filters['status'] ?? '') === 'RECHAZADA') ? 'selected' : '' ?>>Rechazada</option>
                    <option value="ANULADA" <?= (($filters['status'] ?? '') === 'ANULADA') ? 'selected' : '' ?>>Anulada</option>
                </select>
            </div>
            <div class="col-12 col-md-3 d-flex gap-2">
                <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                <button type="submit" class="btn btn-secondary btn-sm flex-grow-1">Filtrar</button>
                <?php if (!empty($filters['search']) || !empty($filters['status'])): ?>
                <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/solicitudes" class="btn btn-outline-secondary btn-sm"><i class="bi bi-x-circle"></i></a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
        <div class="table-responsive">
            <!-- La tabla presenta los registros obtenidos por el controlador. -->
            <table class="table table-hover align-middle mb-0 fs-7">
                <thead class="table-light">
                    <tr>
                        <th>Código</th>
                        <th>N° Correspondencia</th>
                        <th>Fecha</th>
                        <th>Solicitante</th>
                        <th>Área / Unidad</th>
                        <th class="text-center">Ítems</th>
                        <th class="text-center">Estado</th>
                        <th class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($requests)): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted py-5">
                                <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                No se encontraron solicitudes registradas con los criterios seleccionados.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($requests as $r): ?>
                            <tr>
                                <td class="fw-bold text-navy"><?= htmlspecialchars($r['code']) ?></td>
                                <td>
                                    <span class="badge bg-light text-dark border"><?= htmlspecialchars($r['correspondence_number']) ?></span>
                                </td>
                                <td><?= date('d/m/Y H:i', strtotime($r['created_at'])) ?></td>
                                <td>
                                    <div class="fw-semibold"><?= htmlspecialchars($r['applicant_name']) ?></div>
                                    <small class="text-muted"><?= htmlspecialchars($r['applicant_position'] ?? '') ?></small>
                                </td>
                                <td><?= htmlspecialchars($r['area_name'] ?? 'General') ?></td>
                                <td class="text-center">
                                    <span class="badge bg-secondary-subtle text-dark border"><?= $r['items_count'] ?></span>
                                </td>
                                <td class="text-center">
                                    <?php
                                    $badgeClass = match($r['status']) {
                                        'BORRADOR' => 'bg-secondary',
                                        'EN_APROBACION' => 'bg-warning text-dark',
                                        'APROBADA' => 'bg-primary',
                                        'OBSERVADA' => 'bg-info text-dark',
                                        'ATENDIDA' => 'bg-success',
                                        'RECHAZADA' => 'bg-danger',
                                        'ANULADA' => 'bg-dark',
                                        default => 'bg-secondary'
                                    };
                                    ?>
                                    <span class="badge <?= $badgeClass ?>"><?= htmlspecialchars($r['status']) ?></span>
                                </td>
                                <td class="text-end">
                                    <div class="btn-group btn-group-sm">
                                        <?php if ($r['status'] === 'APROBADA' && (can('salidas.preparar') || in_array($user['role_code'] ?? '', ['ADMIN', 'TECNICO_ALMACEN'], true))): ?>
                                        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/salidas/nueva?request_id=<?= $r['id'] ?>" class="btn btn-success" title="Entregar / Despachar Material">
                                            <i class="bi bi-box-seam"></i>
                                        </a>
                                        <?php endif; ?>
                                        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/solicitudes/<?= $r['id'] ?>" class="btn btn-outline-primary" title="Ver detalle">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/imprimir/<?= $r['id'] ?>" class="btn btn-outline-secondary" title="Imprimir hoja membretada" target="_blank">
                                            <i class="bi bi-printer"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
