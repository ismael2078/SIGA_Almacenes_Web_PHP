<?php
// Vista de catálogos de productos: presenta la pantalla de listado y búsqueda y sus controles.
/** @var array<int,array<string,mixed>> $categories */
/** @var array<int,array<string,mixed>> $subcategories */
/** @var array<int,array<string,mixed>> $units */
/** @var array<int,array<string,mixed>> $locations */
/** @var array<int,array<string,mixed>> $suppliers */
/** @var array<int,array<string,mixed>> $areas */
/** @var bool $canEdit */
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Catálogos generales</h1>
        <p class="page-sub">Categorías, unidades, ubicaciones, proveedores y áreas institucionales</p>
    </div>
</div>

<ul class="nav nav-tabs mb-3" role="tablist">
    <li class="nav-item" role="presentation"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tabCategories" type="button" role="tab">Categorías</button></li>
    <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabSubcategories" type="button" role="tab">Subcategorías</button></li>
    <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabUnits" type="button" role="tab">Unidades</button></li>
    <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabLocations" type="button" role="tab">Ubicaciones</button></li>
    <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabSuppliers" type="button" role="tab">Proveedores</button></li>
    <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabAreas" type="button" role="tab">Áreas</button></li>
</ul>

<div class="tab-content">
    <!-- Categorías -->
    <div class="tab-pane fade show active" id="tabCategories" role="tabpanel">
        <?php if ($canEdit): ?>
            <div class="card mb-3">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header"><i class="bi bi-plus-circle me-1"></i>Nueva categoría</div>
                <div class="card-body">
                    <!-- El formulario recibe los datos que procesará el controlador. -->
                    <form method="post" action="<?= e(url('/catalogos/categorias')) ?>" class="row g-2 align-items-end">
                        <?= csrf_field() ?>
                        <div class="col-md-2"><label class="form-label">Código *</label><input type="text" class="form-control" name="code" maxlength="20" required placeholder="PAP"></div>
                        <div class="col-md-4"><label class="form-label">Nombre *</label><input type="text" class="form-control" name="name" maxlength="100" required></div>
                        <div class="col-md-4"><label class="form-label">Descripción</label><input type="text" class="form-control" name="description"></div>
                        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                        <div class="col-md-2 d-grid"><button class="btn btn-primary" type="submit">Agregar</button></div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body p-0">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- La tabla presenta los registros obtenidos por el controlador. -->
                    <table class="table table-hover mb-0">
                        <thead><tr><th>Código</th><th>Nombre</th><th>Descripción</th><th class="num">Subcategorías</th><th>Estado</th></tr></thead>
                        <tbody>
                            <?php foreach ($categories as $category): ?>
                                <tr>
                                    <td class="mono fw-semibold"><?= e($category['code']) ?></td>
                                    <td><?= e($category['name']) ?></td>
                                    <td class="small text-muted"><?= e($category['description'] ?? '—') ?></td>
                                    <td class="num"><?= e((int) $category['subcategory_count']) ?></td>
                                    <td><?= status_badge((int) $category['is_active'] === 1 ? 'ACTIVO' : 'INACTIVO') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Subcategorías -->
    <div class="tab-pane fade" id="tabSubcategories" role="tabpanel">
        <?php if ($canEdit): ?>
            <div class="card mb-3">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header"><i class="bi bi-plus-circle me-1"></i>Nueva subcategoría</div>
                <div class="card-body">
                    <!-- Formulario de catálogos; se enviará por POST al controlador encargado. -->
                    <form method="post" action="<?= e(url('/catalogos/subcategorias')) ?>" class="row g-2 align-items-end">
                        <?= csrf_field() ?>
                        <div class="col-md-3">
                            <label class="form-label">Categoría *</label>
                            <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                            <select class="form-select" name="category_id" required>
                                <option value="">Seleccione...</option>
                                <?php foreach ($categories as $category): ?><option value="<?= e($category['id']) ?>"><?= e($category['name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2"><label class="form-label">Código *</label><input type="text" class="form-control" name="code" maxlength="20" required></div>
                        <div class="col-md-4"><label class="form-label">Nombre *</label><input type="text" class="form-control" name="name" maxlength="100" required></div>
                        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                        <div class="col-md-3 d-grid"><button class="btn btn-primary" type="submit">Agregar</button></div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body p-0">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- Tabla de catálogos: organiza los registros y sus acciones visibles. -->
                    <table class="table table-hover mb-0">
                        <thead><tr><th>Categoría</th><th>Código</th><th>Nombre</th><th>Estado</th></tr></thead>
                        <tbody>
                            <?php foreach ($subcategories as $subcategory): ?>
                                <tr>
                                    <td class="small"><?= e($subcategory['category_name']) ?></td>
                                    <td class="mono fw-semibold"><?= e($subcategory['code']) ?></td>
                                    <td><?= e($subcategory['name']) ?></td>
                                    <td><?= status_badge((int) $subcategory['is_active'] === 1 ? 'ACTIVO' : 'INACTIVO') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Unidades -->
    <div class="tab-pane fade" id="tabUnits" role="tabpanel">
        <?php if ($canEdit): ?>
            <div class="card mb-3">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header"><i class="bi bi-plus-circle me-1"></i>Nueva unidad de medida</div>
                <div class="card-body">
                    <!-- Formulario de catálogos; se enviará por POST al controlador encargado. -->
                    <form method="post" action="<?= e(url('/catalogos/unidades')) ?>" class="row g-2 align-items-end">
                        <?= csrf_field() ?>
                        <div class="col-md-3"><label class="form-label">Código *</label><input type="text" class="form-control" name="code" maxlength="10" required placeholder="UND"></div>
                        <div class="col-md-5"><label class="form-label">Nombre *</label><input type="text" class="form-control" name="name" maxlength="60" required></div>
                        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                        <div class="col-md-4 d-grid"><button class="btn btn-primary" type="submit">Agregar</button></div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body p-0">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- Tabla de catálogos: organiza los registros y sus acciones visibles. -->
                    <table class="table table-hover mb-0">
                        <thead><tr><th>Código</th><th>Nombre</th><th>Estado</th></tr></thead>
                        <tbody>
                            <?php foreach ($units as $unit): ?>
                                <tr>
                                    <td class="mono fw-semibold"><?= e($unit['code']) ?></td>
                                    <td><?= e($unit['name']) ?></td>
                                    <td><?= status_badge((int) $unit['is_active'] === 1 ? 'ACTIVO' : 'INACTIVO') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Ubicaciones -->
    <div class="tab-pane fade" id="tabLocations" role="tabpanel">
        <?php if ($canEdit): ?>
            <div class="card mb-3">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header"><i class="bi bi-plus-circle me-1"></i>Nueva ubicación</div>
                <div class="card-body">
                    <!-- Formulario de catálogos; se enviará por POST al controlador encargado. -->
                    <form method="post" action="<?= e(url('/catalogos/ubicaciones')) ?>" class="row g-2 align-items-end">
                        <?= csrf_field() ?>
                        <div class="col-md-2"><label class="form-label">Código *</label><input type="text" class="form-control" name="code" maxlength="30" required></div>
                        <div class="col-md-4"><label class="form-label">Nombre *</label><input type="text" class="form-control" name="name" maxlength="100" required></div>
                        <div class="col-md-2"><label class="form-label">Almacén</label><input type="text" class="form-control" name="warehouse" maxlength="80"></div>
                        <div class="col-md-1"><label class="form-label">Pasillo</label><input type="text" class="form-control" name="aisle" maxlength="20"></div>
                        <div class="col-md-1"><label class="form-label">Estante</label><input type="text" class="form-control" name="shelf" maxlength="20"></div>
                        <div class="col-md-1"><label class="form-label">Nivel</label><input type="text" class="form-control" name="level" maxlength="20"></div>
                        <div class="col-md-1 d-grid"><button class="btn btn-primary" type="submit">Agregar</button></div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <!-- Tabla de catálogos: organiza los registros y sus acciones visibles. -->
                    <table class="table table-hover mb-0">
                        <thead><tr><th>Código</th><th>Nombre</th><th>Almacén</th><th>Pasillo / estante / nivel</th><th>Estado</th></tr></thead>
                        <tbody>
                            <?php foreach ($locations as $location): ?>
                                <tr>
                                    <td class="mono fw-semibold"><?= e($location['code']) ?></td>
                                    <td><?= e($location['name']) ?></td>
                                    <td class="small"><?= e($location['warehouse'] ?? '—') ?></td>
                                    <td class="small text-muted"><?= e(trim(($location['aisle'] ?? '') . ' / ' . ($location['shelf'] ?? '') . ' / ' . ($location['level'] ?? ''), ' /')) ?></td>
                                    <td><?= status_badge((int) $location['is_active'] === 1 ? 'ACTIVO' : 'INACTIVO') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Proveedores -->
    <div class="tab-pane fade" id="tabSuppliers" role="tabpanel">
        <?php if ($canEdit): ?>
            <div class="card mb-3">
                <div class="card-header"><i class="bi bi-plus-circle me-1"></i>Nuevo proveedor</div>
                <div class="card-body">
                    <!-- Formulario de catálogos; se enviará por POST al controlador encargado. -->
                    <form method="post" action="<?= e(url('/catalogos/proveedores')) ?>" class="row g-2 align-items-end">
                        <?= csrf_field() ?>
                        <div class="col-md-2"><label class="form-label">NIT</label><input type="text" class="form-control" name="nit" maxlength="30"></div>
                        <div class="col-md-4"><label class="form-label">Nombre *</label><input type="text" class="form-control" name="name" maxlength="200" required></div>
                        <div class="col-md-3"><label class="form-label">Contacto</label><input type="text" class="form-control" name="contact_name" maxlength="120"></div>
                        <div class="col-md-3"><label class="form-label">Teléfono</label><input type="text" class="form-control" name="phone" maxlength="50"></div>
                        <div class="col-md-4"><label class="form-label">Correo</label><input type="email" class="form-control" name="email" maxlength="120"></div>
                        <div class="col-md-5"><label class="form-label">Dirección</label><input type="text" class="form-control" name="address"></div>
                        <div class="col-md-3 d-grid"><button class="btn btn-primary" type="submit">Agregar</button></div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead><tr><th>NIT</th><th>Nombre</th><th>Contacto</th><th>Teléfono</th><th>Correo</th><th>Estado</th></tr></thead>
                        <tbody>
                            <?php foreach ($suppliers as $supplier): ?>
                                <tr>
                                    <td class="mono"><?= e($supplier['nit'] ?? '—') ?></td>
                                    <td class="fw-semibold"><?= e($supplier['name']) ?></td>
                                    <td class="small"><?= e($supplier['contact_name'] ?? '—') ?></td>
                                    <td class="small"><?= e($supplier['phone'] ?? '—') ?></td>
                                    <td class="small"><?= e($supplier['email'] ?? '—') ?></td>
                                    <td><?= status_badge((int) $supplier['is_active'] === 1 ? 'ACTIVO' : 'INACTIVO') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Áreas -->
    <div class="tab-pane fade" id="tabAreas" role="tabpanel">
        <?php if ($canEdit): ?>
            <div class="card mb-3">
                <div class="card-header"><i class="bi bi-plus-circle me-1"></i>Nueva área</div>
                <div class="card-body">
                    <form method="post" action="<?= e(url('/catalogos/areas')) ?>" class="row g-2 align-items-end">
                        <?= csrf_field() ?>
                        <div class="col-md-2"><label class="form-label">Código *</label><input type="text" class="form-control" name="code" maxlength="30" required></div>
                        <div class="col-md-4"><label class="form-label">Nombre *</label><input type="text" class="form-control" name="name" maxlength="150" required></div>
                        <div class="col-md-2">
                            <label class="form-label">Tipo</label>
                            <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                            <select class="form-select" name="type">
                                <option value="UNIDAD">Unidad</option>
                                <option value="DIRECCION">Dirección</option>
                                <option value="JEFATURA">Jefatura</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Área padre</label>
                            <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                            <select class="form-select" name="parent_id">
                                <option value="">Sin padre</option>
                                <?php foreach ($areas as $area): ?><option value="<?= e($area['id']) ?>"><?= e($area['name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2 d-grid"><button class="btn btn-primary" type="submit">Agregar</button></div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead><tr><th>Código</th><th>Nombre</th><th>Tipo</th><th>Área padre</th><th>Estado</th></tr></thead>
                        <tbody>
                            <?php foreach ($areas as $area): ?>
                                <tr>
                                    <td class="mono fw-semibold"><?= e($area['code']) ?></td>
                                    <td><?= e($area['name']) ?></td>
                                    <td><span class="badge badge-soft"><?= e($area['type']) ?></span></td>
                                    <td class="small"><?= e($area['parent_name'] ?? '—') ?></td>
                                    <td><?= status_badge((int) $area['is_active'] === 1 ? 'ACTIVO' : 'INACTIVO') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
