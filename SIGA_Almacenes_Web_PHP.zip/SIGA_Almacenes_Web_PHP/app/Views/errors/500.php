<?php
// Vista de mensajes de error: presenta la pantalla de 500 y sus controles.
/** @var string $title */
/** @var string|null $message */
/** @var string|null $trace */
$message = $message ?? null;
$trace = $trace ?? null;
?>
<div class="card mx-auto" style="max-width: 760px;">
    <div class="card-body text-center py-5">
        <div class="display-3 fw-bold" style="color: var(--siga-danger, #b42318);">500</div>
        <h1 class="h4 fw-bold mt-2">Error del sistema</h1>
        <p class="text-muted mb-4">Ocurrió un error inesperado al procesar la solicitud. El incidente quedó registrado en los archivos de auditoría del servidor.</p>
        <?php if ($message !== null): ?>
            <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
            <div class="alert alert-danger text-start small">
                <div class="fw-semibold mb-1">Detalle técnico</div>
                <div class="mono text-break"><?= e($message) ?></div>
            </div>
        <?php endif; ?>
        <?php if ($trace !== null): ?>
            <details class="text-start small mb-4">
                <summary class="text-muted">Ver traza de ejecución</summary>
                <pre class="bg-light border rounded p-2 mt-2 text-wrap" style="max-height: 260px; overflow: auto;"><?= e($trace) ?></pre>
            </details>
        <?php endif; ?>
        <div class="d-flex justify-content-center gap-2 flex-wrap">
            <a href="<?= e(url('/dashboard')) ?>" class="btn btn-primary"><i class="bi bi-grid-1x2 me-1"></i>Ir al panel</a>
            <a href="javascript:location.reload()" class="btn btn-outline-secondary"><i class="bi bi-arrow-clockwise me-1"></i>Reintentar</a>
        </div>
    </div>
</div>
