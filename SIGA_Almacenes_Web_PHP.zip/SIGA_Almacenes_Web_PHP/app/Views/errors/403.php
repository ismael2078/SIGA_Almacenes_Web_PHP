<?php /* Vista de mensajes de error: presenta la pantalla de 403 y sus controles. */ /** @var string $title */ ?>
<div class="card mx-auto" style="max-width: 640px;">
    <div class="card-body text-center py-5">
        <div class="display-3 fw-bold" style="color: var(--siga-danger, #b42318);">403</div>
        <h1 class="h4 fw-bold mt-2">Acceso denegado</h1>
        <p class="text-muted mb-4">Su usuario no cuenta con los permisos necesarios para acceder a este recurso. Si considera que se trata de un error, contacte al administrador del sistema.</p>
        <div class="d-flex justify-content-center gap-2 flex-wrap">
            <a href="<?= e(url('/dashboard')) ?>" class="btn btn-primary"><i class="bi bi-grid-1x2 me-1"></i>Ir al panel</a>
            <a href="<?= e(url('/login')) ?>" class="btn btn-outline-secondary"><i class="bi bi-box-arrow-in-right me-1"></i>Iniciar sesión</a>
        </div>
    </div>
</div>
