<?php /* Vista de mensajes de error: presenta la pantalla de 404 y sus controles. */ /** @var string $title */ ?>
<div class="card mx-auto" style="max-width: 640px;">
    <div class="card-body text-center py-5">
        <div class="display-3 fw-bold" style="color: var(--siga-primary, #0b3a6f);">404</div>
        <h1 class="h4 fw-bold mt-2">Recurso no encontrado</h1>
        <p class="text-muted mb-4">La página, documento o registro solicitado no existe o fue removido del sistema. Verifique la dirección o regrese al panel de control.</p>
        <div class="d-flex justify-content-center gap-2 flex-wrap">
            <a href="<?= e(url('/dashboard')) ?>" class="btn btn-primary"><i class="bi bi-grid-1x2 me-1"></i>Ir al panel</a>
            <a href="javascript:history.back()" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
        </div>
    </div>
</div>
