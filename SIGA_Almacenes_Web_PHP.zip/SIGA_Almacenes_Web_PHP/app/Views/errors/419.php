<?php /* Vista de mensajes de error: presenta la pantalla de 419 y sus controles. */ /** @var string $title */ ?>
<div class="card mx-auto" style="max-width: 640px;">
    <div class="card-body text-center py-5">
        <div class="display-3 fw-bold" style="color: var(--siga-gold, #b7791f);">419</div>
        <h1 class="h4 fw-bold mt-2">Sesión expirada</h1>
        <p class="text-muted mb-4">El formulario perdió vigencia o el token de seguridad no es válido. Recargue la página e intente nuevamente; si el problema persiste, cierre sesión y vuelva a ingresar.</p>
        <div class="d-flex justify-content-center gap-2 flex-wrap">
            <a href="<?= e(url('/login')) ?>" class="btn btn-primary"><i class="bi bi-box-arrow-in-right me-1"></i>Iniciar sesión</a>
            <a href="javascript:history.back()" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
        </div>
    </div>
</div>
