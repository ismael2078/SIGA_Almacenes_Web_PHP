<?php
// Vista de salidas de inventario: presenta la pantalla de selección de una solicitud aprobada y sus controles.
/** @var array<int,array<string,mixed>> $requests */
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Nueva salida</h1>
        <p class="page-sub">Seleccione una solicitud aprobada para preparar el despacho</p>
    </div>
    <a href="<?= e(url('/salidas')) ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
</div>

<!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
<div class="alert alert-info">
    <i class="bi bi-info-circle me-1"></i>
    Solo se muestran solicitudes en estado <strong>APROBADA</strong>. Si una solicitud ya fue atendida, no aparecerá en esta lista.
</div>

<div class="card">
    <div class="card-body p-0">
        <?php if ($requests === []): ?>
            <div class="empty-state"><i class="bi bi-inbox"></i>No hay solicitudes aprobadas pendientes de despacho.</div>
        <?php else: ?>
            <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
            <div class="table-responsive">
                <!-- La tabla presenta los registros obtenidos por el controlador. -->
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Solicitud</th>
                            <th>Correspondencia</th>
                            <th>Solicitante</th>
                            <th>Área</th>
                            <th>Aprobada</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($requests as $request): ?>
                            <tr>
                                <td class="fw-semibold mono"><?= e($request['code']) ?></td>
                                <td class="small mono"><?= e($request['correspondence_number']) ?></td>
                                <td class="small"><?= e($request['applicant_name'] ?? '—') ?></td>
                                <td class="small"><?= e($request['area_name'] ?? '—') ?></td>
                                <td class="small"><?= e(fecha($request['approved_at'] ?? null)) ?></td>
                                <td class="text-end">
                                    <a class="btn btn-sm btn-primary" href="<?= e(url('/salidas/nueva/' . $request['id'])) ?>">
                                        <i class="bi bi-box-arrow-up me-1"></i>Preparar despacho
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
