<?php
// Vista de salidas de inventario: presenta la pantalla de listado y búsqueda y sus controles.
/** @var array<int,array<string,mixed>> $dispatches */
/** @var string $search */
/** @var string $status */
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Salidas y despachos</h1>
        <p class="page-sub">Despachos valorados con consumo PEPS de capas de inventario</p>
    </div>
    <?php if (can('salidas.preparar') || can('salidas.confirmar')): ?>
        <a href="<?= e(url('/salidas/nueva')) ?>" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Nueva salida</a>
    <?php endif; ?>
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form class="filter-bar row g-2 align-items-end" method="get" action="<?= e(url('/salidas')) ?>">
    <div class="col-md-6">
        <label class="form-label">Buscar</label>
        <input type="text" class="form-control" name="search" value="<?= e($search) ?>" placeholder="Número, solicitud o persona que recibe">
    </div>
    <div class="col-md-4">
        <label class="form-label">Estado</label>
        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
        <select class="form-select" name="status">
            <option value="">Todos</option>
            <?php foreach (['BORRADOR', 'CONFIRMADO', 'ANULADO'] as $option): ?>
                <option value="<?= e($option) ?>" <?= selected($status, $option) ?>><?= e(status_label($option)) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-2 d-grid">
        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
        <button class="btn btn-primary" type="submit"><i class="bi bi-search me-1"></i>Filtrar</button>
    </div>
</form>

<div class="card">
    <div class="card-body p-0">
        <?php if ($dispatches === []): ?>
            <div class="empty-state"><i class="bi bi-truck"></i>No se encontraron despachos.</div>
        <?php else: ?>
            <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
            <div class="table-responsive">
                <!-- La tabla presenta los registros obtenidos por el controlador. -->
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Número</th>
                            <th>Solicitud</th>
                            <th>Solicitante / área</th>
                            <th>Recibe</th>
                            <th>Fecha</th>
                            <th class="num">Valor</th>
                            <th>Estado</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dispatches as $dispatch): ?>
                            <tr>
                                <td><a href="<?= e(url('/salidas/' . $dispatch['id'])) ?>" class="fw-semibold mono"><?= e($dispatch['number']) ?></a></td>
                                <td class="small">
                                    <div class="mono"><?= e($dispatch['request_code'] ?? '—') ?></div>
                                    <div class="text-muted"><?= e($dispatch['correspondence_number'] ?? '') ?></div>
                                </td>
                                <td class="small">
                                    <div><?= e($dispatch['applicant_name'] ?? '—') ?></div>
                                    <div class="text-muted"><?= e($dispatch['area_name'] ?? '—') ?></div>
                                </td>
                                <td class="small">
                                    <div><?= e($dispatch['received_by'] ?? '—') ?></div>
                                    <div class="text-muted mono"><?= e($dispatch['received_ci'] ?? '') ?></div>
                                </td>
                                <td class="small"><?= e(fecha($dispatch['dispatch_date'], false)) ?></td>
                                <td class="num fw-semibold">Bs <?= e(money($dispatch['total_value'])) ?></td>
                                <td><?= status_badge((string) $dispatch['status']) ?></td>
                                <td class="text-end">
                                    <a class="btn btn-sm btn-outline-primary" href="<?= e(url('/salidas/' . $dispatch['id'])) ?>"><i class="bi bi-eye"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
