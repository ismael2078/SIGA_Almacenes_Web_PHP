<?php
// Vista de salidas de inventario: presenta la pantalla de registro nuevo y sus controles.
/** @var array<string,mixed> $request */
/** @var array<int,array<string,mixed>> $items */
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Despachar solicitud <?= e($request['code']) ?></h1>
        <p class="page-sub"><?= e($request['correspondence_number']) ?> · <?= e($request['applicant_name'] ?? '') ?> · <?= e($request['area_name'] ?? '') ?></p>
    </div>
    <a href="<?= e(url('/salidas/nueva')) ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
</div>

<!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
<div class="alert alert-warning">
    <i class="bi bi-exclamation-triangle me-1"></i>
    Al confirmar el despacho se consumirán las capas PEPS más antiguas y se afectará el kardex de forma definitiva.
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form method="post" action="<?= e(url('/salidas')) ?>" id="dispatchForm">
    <?= csrf_field() ?>
    <input type="hidden" name="request_id" value="<?= e($request['id']) ?>">

    <div class="row g-3">
        <div class="col-lg-8">
            <div class="card">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header"><i class="bi bi-list-ul me-1"></i>Ítems a despachar</div>
                <div class="card-body p-0">
                    <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                    <div class="table-responsive">
                        <!-- La tabla presenta los registros obtenidos por el controlador. -->
                        <table class="table table-sm mb-0">
                            <thead>
                                <tr>
                                    <th>Producto</th>
                                    <th class="num">Autorizado</th>
                                    <th class="num">Entregado</th>
                                    <th class="num">Stock actual</th>
                                    <th style="width: 140px;">Cantidad a despachar</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($items as $item): ?>
                                    <?php
                                    $authorized = (float) $item['qty_authorized'] > 0
                                        ? (float) $item['qty_authorized']
                                        : ((float) $item['qty_approved'] > 0 ? (float) $item['qty_approved'] : (float) $item['qty_requested']);
                                    $pending = max(0, $authorized - (float) $item['qty_delivered']);
                                    $stock = (float) $item['stock_qty'];
                                    ?>
                                    <tr>
                                        <td>
                                            <div class="fw-semibold mono"><?= e($item['product_code']) ?></div>
                                            <div class="small text-muted"><?= e($item['product_name']) ?></div>
                                        </td>
                                        <td class="num"><?= e(qty($authorized)) ?> <?= e($item['unit_code'] ?? '') ?></td>
                                        <td class="num"><?= e(qty($item['qty_delivered'])) ?></td>
                                        <td class="num <?= $stock < $pending ? 'text-danger fw-semibold' : '' ?>"><?= e(qty($stock)) ?></td>
                                        <td>
                                            <input type="hidden" name="request_item_id[]" value="<?= e($item['id']) ?>">
                                            <input type="number" step="1" min="0" max="<?= e(number_format($authorized, 3, '.', '')) ?>"
                                                   class="form-control form-control-sm" name="qty[]"
                                                   value="<?= e(number_format($pending, 3, '.', '')) ?>"
                                                   <?= $pending <= 0 ? 'disabled' : '' ?>>
                                            <?php if ($stock + 0.0001 < $pending): ?>
                                                <div class="form-text text-danger">Stock insuficiente</div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card">
                <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
                <div class="card-header"><i class="bi bi-person-check me-1"></i>Recepción del material</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label" for="received_by">Nombre de quien recibe *</label>
                        <input type="text" class="form-control" id="received_by" name="received_by" maxlength="200" required
                               value="<?= e($request['applicant_name'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="received_ci">Cédula de identidad *</label>
                        <input type="text" class="form-control mono" id="received_ci" name="received_ci" maxlength="30" required
                               value="<?= e($request['applicant_ci'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="notes">Observaciones</label>
                        <textarea class="form-control" id="notes" name="notes" rows="3" placeholder="Observaciones del despacho"></textarea>
                    </div>
                    <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
                    <div class="alert alert-info small mb-0">
                        <i class="bi bi-info-circle me-1"></i>
                        El despacho quedará registrado con la fecha y hora actual, junto con la firma de recepción.
                    </div>
                </div>
            </div>

            <div class="d-grid gap-2 mt-3">
                <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                <button type="submit" class="btn btn-primary" data-confirm="¿Confirmar el despacho? Se afectará el inventario de forma definitiva.">
                    <i class="bi bi-check2-circle me-1"></i>Confirmar despacho
                </button>
                <a href="<?= e(url('/solicitudes/' . $request['id'])) ?>" class="btn btn-outline-secondary">Ver solicitud</a>
            </div>
        </div>
    </div>
</form>
