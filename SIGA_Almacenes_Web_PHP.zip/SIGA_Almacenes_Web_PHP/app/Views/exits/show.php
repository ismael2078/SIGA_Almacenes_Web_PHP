<?php
// Vista de salidas de inventario: presenta la pantalla de detalle del registro y sus controles.
/** @var array<string,mixed> $dispatch */
/** @var array<int,array<string,mixed>> $items */
/** @var array<int,array<string,mixed>> $consumptions */
?>
<div class="page-head">
    <div>
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <h1 class="page-title mb-0">Despacho <?= e($dispatch['number']) ?></h1>
            <?= status_badge((string) $dispatch['status']) ?>
        </div>
        <p class="page-sub">Solicitud <?= e($dispatch['request_code'] ?? '—') ?> · <?= e(fecha($dispatch['dispatch_date'])) ?></p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <a href="<?= e(url('/salidas')) ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
        <a href="<?= e(url('/imprimir/salida/' . $dispatch['id'])) ?>" target="_blank" class="btn btn-outline-primary"><i class="bi bi-printer me-1"></i>Imprimir</a>
        <?php if ($dispatch['status'] === 'CONFIRMADO' && can('salidas.anular')): ?>
            <button class="btn btn-outline-danger" type="button" data-bs-toggle="modal" data-bs-target="#voidDispatchModal"><i class="bi bi-x-octagon me-1"></i>Anular</button>
        <?php endif; ?>
    </div>
</div>

<?php if ($dispatch['status'] === 'ANULADO'): ?>
    <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
    <div class="alert alert-danger">
        <strong>Despacho anulado.</strong> <?= e($dispatch['void_reason'] ?? '') ?>
        <div class="small mt-1">Por <?= e($dispatch['voided_by_name'] ?? '—') ?> · <?= e(fecha($dispatch['voided_at'] ?? null)) ?></div>
    </div>
<?php endif; ?>

<div class="row g-3">
    <div class="col-lg-8">
        <div class="card">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-info-circle me-1"></i>Datos del despacho</div>
            <div class="card-body">
                <div class="detail-grid">
                    <div class="detail-item"><div class="label">Número</div><div class="value mono"><?= e($dispatch['number']) ?></div></div>
                    <div class="detail-item"><div class="label">Solicitud</div><div class="value mono"><?= e($dispatch['request_code'] ?? '—') ?></div></div>
                    <div class="detail-item"><div class="label">Correspondencia</div><div class="value mono"><?= e($dispatch['correspondence_number'] ?? '—') ?></div></div>
                    <div class="detail-item"><div class="label">Solicitante</div><div class="value"><?= e($dispatch['applicant_name'] ?? '—') ?></div></div>
                    <div class="detail-item"><div class="label">Área</div><div class="value"><?= e($dispatch['area_name'] ?? '—') ?></div></div>
                    <div class="detail-item"><div class="label">Recibido por</div><div class="value"><?= e($dispatch['received_by'] ?? '—') ?></div></div>
                    <div class="detail-item"><div class="label">CI de quien recibe</div><div class="value mono"><?= e($dispatch['received_ci'] ?? '—') ?></div></div>
                    <div class="detail-item"><div class="label">Despachado por</div><div class="value"><?= e($dispatch['dispatched_by_name'] ?? '—') ?></div></div>
                    <div class="detail-item"><div class="label">Valor total</div><div class="value">Bs <?= e(money($dispatch['total_value'])) ?></div></div>
                    <div class="detail-item"><div class="label">Firma de recepción</div><div class="value"><?= e(fecha($dispatch['received_signature_at'] ?? null)) ?></div></div>
                </div>
                <?php if (!empty($dispatch['notes'])): ?>
                    <hr>
                    <p class="small mb-0 text-muted"><?= nl2br(e($dispatch['notes'])) ?></p>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mt-3">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-list-ul me-1"></i>Ítems despachados</div>
            <div class="card-body p-0">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- La tabla presenta los registros obtenidos por el controlador. -->
                    <table class="table table-hover mb-0">
                        <thead><tr><th>Producto</th><th class="num">Cantidad</th><th class="num">Costo unit. PEPS</th><th class="num">Valor</th></tr></thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                                <tr>
                                    <td>
                                        <div class="fw-semibold mono"><?= e($item['product_code']) ?></div>
                                        <div class="small text-muted"><?= e($item['product_name']) ?></div>
                                    </td>
                                    <td class="num"><?= e(qty($item['qty'])) ?> <?= e($item['unit_code'] ?? '') ?></td>
                                    <td class="num"><?= e(money($item['unit_cost'], 4)) ?></td>
                                    <td class="num fw-semibold"><?= e(money($item['total_value'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr><td colspan="3" class="text-end fw-semibold">Valor total del despacho</td><td class="num fw-bold">Bs <?= e(money($dispatch['total_value'])) ?></td></tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>

        <div class="card mt-3">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-layers me-1"></i>Consumo de capas PEPS</div>
            <div class="card-body p-0">
                <?php if ($consumptions === []): ?>
                    <div class="empty-state"><i class="bi bi-layers"></i>No hay consumos PEPS registrados.</div>
                <?php else: ?>
                    <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                    <div class="table-responsive">
                        <!-- Tabla de salidas y despachos: organiza los registros y sus acciones visibles. -->
                        <table class="table table-sm mb-0">
                            <thead><tr><th>Producto</th><th>Fecha de capa</th><th class="num">Cantidad consumida</th><th class="num">Costo unit. capa</th><th class="num">Valor consumido</th></tr></thead>
                            <tbody>
                                <?php foreach ($consumptions as $consumption): ?>
                                    <tr>
                                        <td class="small"><span class="mono"><?= e($consumption['product_code']) ?></span> · <?= e($consumption['product_name']) ?></td>
                                        <td class="small"><?= e(fecha($consumption['layer_date'])) ?></td>
                                        <td class="num"><?= e(qty($consumption['qty'])) ?></td>
                                        <td class="num"><?= e(money($consumption['unit_cost'], 4)) ?></td>
                                        <td class="num"><?= e(money($consumption['total_value'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-diagram-3 me-1"></i>Trazabilidad</div>
            <div class="card-body">
                <div class="timeline">
                    <div class="timeline-item done">
                        <p class="timeline-title">Solicitud aprobada</p>
                        <div class="timeline-meta"><?= e(fecha($dispatch['submitted_at'] ?? null)) ?></div>
                    </div>
                    <div class="timeline-item done">
                        <p class="timeline-title">Despacho confirmado</p>
                        <div class="timeline-meta"><?= e(fecha($dispatch['dispatch_date'])) ?> · <?= e($dispatch['dispatched_by_name'] ?? '') ?></div>
                    </div>
                    <div class="timeline-item <?= $dispatch['status'] === 'ANULADO' ? 'rejected' : 'pending' ?>">
                        <p class="timeline-title">Anulación</p>
                        <div class="timeline-meta"><?= $dispatch['status'] === 'ANULADO' ? e(fecha($dispatch['voided_at'] ?? null)) : 'No anulado' ?></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mt-3">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-shield-check me-1"></i>Nota de control</div>
            <div class="card-body small text-muted">
                <p class="mb-2">La anulación de un despacho restituye las capas PEPS consumidas y devuelve la solicitud al estado APROBADA si no existen otros despachos confirmados.</p>
                <p class="mb-0">El movimiento de anulación queda registrado en el kardex.</p>
            </div>
        </div>
    </div>
</div>

<?php if ($dispatch['status'] === 'CONFIRMADO' && can('salidas.anular')): ?>
<!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
<div class="modal fade" id="voidDispatchModal" tabindex="-1" aria-hidden="true">
    <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <!-- El formulario recibe los datos que procesará el controlador. -->
            <form method="post" action="<?= e(url('/salidas/' . $dispatch['id'] . '/anular')) ?>">
                <?= csrf_field() ?>
                <div class="modal-header">
                    <h5 class="modal-title">Anular despacho <?= e($dispatch['number']) ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning small">Se restituirán las capas PEPS consumidas. Indique un motivo de al menos 15 caracteres.</div>
                    <label class="form-label" for="voidDispatchReason">Motivo *</label>
                    <textarea class="form-control" id="voidDispatchReason" name="reason" rows="3" minlength="15" required></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                    <button type="submit" class="btn btn-danger">Anular despacho</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
