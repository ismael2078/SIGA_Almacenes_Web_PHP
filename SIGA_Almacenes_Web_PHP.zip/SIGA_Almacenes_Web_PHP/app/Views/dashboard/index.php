<!-- Vista de tablero principal: presenta la pantalla de listado y búsqueda y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Tablero de Control</h3>
        <p class="text-muted mb-0 fs-7">Resumen ejecutivo y monitoreo en tiempo real del almacén</p>
    </div>
    
    <!-- Banner de API Externa: Cotización en Vivo -->
    <div class="d-flex align-items-center gap-2 bg-white px-3 py-2 rounded-3 shadow-sm border">
        <div class="d-flex align-items-center gap-2">
            <span class="badge bg-success-subtle text-success border border-success-subtle p-2 rounded-circle">
                <i class="bi bi-globe-americas fs-6"></i>
            </span>
            <div>
                <small class="text-muted d-block fs-8">Tipo de Cambio Oficial (API en vivo):</small>
                <span class="fw-bold fs-7">1 USD = <?= number_format($exchangeRates['usd_to_bob'], 2) ?> BOB</span>
            </div>
        </div>
        <button id="currencyToggleBtn" class="btn btn-outline-primary btn-sm ms-2 py-1 px-2 fs-8" data-active="BOB" data-rate="<?= $exchangeRates['usd_to_bob'] ?>">
            <i class="bi bi-currency-dollar me-1"></i>Ver en USD
        </button>
    </div>
</div>

<!-- Tarjetas KPI -->
<div class="row g-3 mb-4">
    <div class="col-12 col-sm-6 col-xl-3">
        <!-- Indicador resumido: presenta una métrica calculada en el tablero. -->
        <div class="card kpi-card h-100 p-3">
            <div class="d-flex align-items-center gap-3">
                <div class="kpi-icon bg-primary-subtle text-primary">
                    <i class="bi bi-box-seam"></i>
                </div>
                <div>
                    <span class="text-muted fs-7 d-block">Catálogo Total</span>
                    <h4 class="fw-bold mb-0"><?= number_format($invStats['total_products'] ?? 0) ?></h4>
                    <small class="text-muted fs-8"><?= number_format($invStats['total_qty'] ?? 0, 1) ?> unidades físicas</small>
                </div>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
        <!-- Indicador resumido: presenta una métrica calculada en el tablero. -->
        <div class="card kpi-card h-100 p-3">
            <div class="d-flex align-items-center gap-3">
                <div class="kpi-icon bg-success-subtle text-success">
                    <i class="bi bi-cash-stack"></i>
                </div>
                <div>
                    <span class="text-muted fs-7 d-block">Saldo Valorado Total</span>
                    <h4 class="fw-bold mb-0 text-success" data-bob-amount="<?= $invStats['total_value'] ?? 0 ?>">
                        Bs <?= number_format($invStats['total_value'] ?? 0, 2) ?>
                    </h4>
                    <small class="text-muted fs-8">&asymp; $ <?= number_format($totalValueUsd, 2) ?> USD</small>
                </div>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
        <!-- Indicador resumido: presenta una métrica calculada en el tablero. -->
        <div class="card kpi-card h-100 p-3">
            <div class="d-flex align-items-center gap-3">
                <div class="kpi-icon bg-warning-subtle text-warning">
                    <i class="bi bi-clock-history"></i>
                </div>
                <div>
                    <span class="text-muted fs-7 d-block">En Aprobación</span>
                    <h4 class="fw-bold mb-0"><?= number_format($reqStats['pending_approvals'] ?? 0) ?></h4>
                    <small class="text-muted fs-8">
                        <?php if ((int)($reqStats['approved_pending_dispatch'] ?? 0) > 0 && (can('salidas.preparar') || in_array($user['role_code'] ?? '', ['ADMIN', 'TECNICO_ALMACEN'], true))): ?>
                            <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/salidas/nueva" class="text-decoration-none fw-semibold text-primary">
                                <?= number_format($reqStats['approved_pending_dispatch'] ?? 0) ?> listas para despacho &rarr;
                            </a>
                        <?php else: ?>
                            <?= number_format($reqStats['approved_pending_dispatch'] ?? 0) ?> listas para despacho
                        <?php endif; ?>
                    </small>
                </div>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
        <!-- Indicador resumido: presenta una métrica calculada en el tablero. -->
        <div class="card kpi-card h-100 p-3">
            <div class="d-flex align-items-center gap-3">
                <div class="kpi-icon bg-danger-subtle text-danger">
                    <i class="bi bi-exclamation-triangle"></i>
                </div>
                <div>
                    <span class="text-muted fs-7 d-block">Stock Crítico (&le; Mín)</span>
                    <h4 class="fw-bold mb-0 text-danger"><?= number_format($invStats['low_stock_count'] ?? 0) ?></h4>
                    <small class="text-muted fs-8">Artículos para reposición</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Fila de Gráficos -->
<div class="row g-4 mb-4">
    <div class="col-12 col-lg-7">
        <div class="card shadow-sm h-100">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-pie-chart me-2 text-primary"></i>Distribución de Valor por Categoría</span>
                <span class="badge bg-light text-dark fs-8 border">PEPS Valorado</span>
            </div>
            <div class="card-body d-flex align-items-center justify-content-center" style="min-height: 280px;">
                <!-- Gráfico: representa los valores preparados por el controlador de esta vista. -->
                <canvas id="categoryChart" style="max-height: 260px;"></canvas>
            </div>
        </div>
    </div>

    <div class="col-12 col-lg-5">
        <div class="card shadow-sm h-100">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-bell me-2 text-danger"></i>Alertas de Stock Mínimo</span>
                <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/inventario" class="btn btn-outline-secondary btn-sm py-0 px-2 fs-8">Ver todo</a>
            </div>
            <div class="card-body p-0">
                <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
                <div class="table-responsive">
                    <!-- La tabla presenta los registros obtenidos por el controlador. -->
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light">
                            <tr>
                                <th>Código / Producto</th>
                                <th class="text-center">Existencia</th>
                                <th class="text-center">Mínimo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($lowStockProducts)): ?>
                                <tr><td colspan="3" class="text-center text-muted py-3">No hay productos en nivel crítico.</td></tr>
                            <?php else: ?>
                                <?php foreach ($lowStockProducts as $lp): ?>
                                    <tr>
                                        <td>
                                            <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/inventario/<?= $lp['id'] ?>" class="fw-semibold text-decoration-none text-navy d-block">
                                                <?= htmlspecialchars($lp['name']) ?>
                                            </a>
                                            <small class="text-muted"><?= htmlspecialchars($lp['code']) ?></small>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-danger"><?= number_format($lp['stock_qty'], 1) ?> <?= htmlspecialchars($lp['unit_name']) ?></span>
                                        </td>
                                        <td class="text-center text-muted">
                                            <?= number_format($lp['min_stock'], 1) ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Últimas Solicitudes Registradas -->
<div class="card shadow-sm mb-4">
    <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
    <div class="card-header d-flex justify-content-between align-items-center">
        <span><i class="bi bi-file-earmark-text me-2 text-primary"></i>Últimas Solicitudes Registradas</span>
        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/solicitudes" class="btn btn-primary btn-sm fs-8"><i class="bi bi-plus-circle me-1"></i>Ver todas las solicitudes</a>
    </div>
    <div class="card-body p-0">
        <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
        <div class="table-responsive">
            <!-- Tabla de tablero de indicadores: organiza los registros y sus acciones visibles. -->
            <table class="table table-hover align-middle mb-0 fs-7">
                <thead class="table-light">
                    <tr>
                        <th>Código</th>
                        <th>N° Correspondencia</th>
                        <th>Solicitante</th>
                        <th>Área / Unidad</th>
                        <th class="text-center">Ítems</th>
                        <th class="text-center">Estado</th>
                        <th class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($recentRequests)): ?>
                        <tr><td colspan="7" class="text-center text-muted py-4">No se registran solicitudes en el sistema.</td></tr>
                    <?php else: ?>
                        <?php foreach ($recentRequests as $r): ?>
                            <tr>
                                <td class="fw-semibold text-navy"><?= htmlspecialchars($r['code']) ?></td>
                                <td><?= htmlspecialchars($r['correspondence_number']) ?></td>
                                <td><?= htmlspecialchars($r['applicant_name']) ?></td>
                                <td><?= htmlspecialchars($r['area_name'] ?? 'General') ?></td>
                                <td class="text-center"><span class="badge bg-light text-dark border"><?= $r['items_count'] ?></span></td>
                                <td class="text-center">
                                    <?php
                                    $badgeClass = match($r['status']) {
                                        'BORRADOR' => 'bg-secondary',
                                        'EN_APROBACION' => 'bg-warning text-dark',
                                        'APROBADA' => 'bg-primary',
                                        'OBSERVADA' => 'bg-info text-dark',
                                        'ATENDIDA' => 'bg-success',
                                        'RECHAZADA' => 'bg-danger',
                                        'ANULADA' => 'bg-dark',
                                        default => 'bg-secondary'
                                    };
                                    ?>
                                    <span class="badge <?= $badgeClass ?>"><?= htmlspecialchars($r['status']) ?></span>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/solicitudes/<?= $r['id'] ?>" class="btn btn-outline-primary btn-sm py-0 px-2 fs-8">
                                            <i class="bi bi-eye me-1"></i>Ver
                                        </a>
                                        <?php if ($r['status'] === 'APROBADA' && (can('salidas.preparar') || in_array($user['role_code'] ?? '', ['ADMIN', 'TECNICO_ALMACEN'], true))): ?>
                                        <a href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/salidas/nueva?request_id=<?= $r['id'] ?>" class="btn btn-success btn-sm py-0 px-2 fs-8 fw-semibold" title="Entregar y despachar material">
                                            <i class="bi bi-box-seam me-1"></i>Despachar
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const chartData = <?= json_encode($categoryChartData) ?>;
    const labels = chartData.map(d => d.name);
    const dataValues = chartData.map(d => parseFloat(d.total_val));

    const ctx = document.getElementById('categoryChart');
    if (ctx) {
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: dataValues,
                    backgroundColor: [
                        '#1a2a40', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#64748b'
                    ],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { boxWidth: 12, font: { size: 11 } }
                    },
                    tooltip: {
                        callbacks: {
                            label: function (context) {
                                return context.label + ': Bs ' + Number(context.raw).toLocaleString('es-BO', { minimumFractionDigits: 2 });
                            }
                        }
                    }
                }
            }
        });
    }
});
</script>
