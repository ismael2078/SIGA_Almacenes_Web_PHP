<!-- Vista de bandeja de aprobaciones: presenta la pantalla de listado y búsqueda y sus controles. -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-navy mb-0">Bandeja de Aprobaciones</h3>
        <p class="text-muted mb-0 fs-7">Revisión jerárquica y validación de solicitudes de materiales</p>
    </div>
    <span class="badge bg-primary px-3 py-2 fs-7">
        <i class="bi bi-person-badge me-1"></i>Rol actual: <?= htmlspecialchars($user['role_name']) ?>
    </span>
</div>

<div class="card shadow-sm">
    <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <span><i class="bi bi-inbox me-2 text-warning"></i>Solicitudes Pendientes de Decisión</span>
        <span class="badge bg-warning text-dark"><?= count($pendingRequests) ?> pendientes</span>
    </div>
    <div class="card-body p-0">
        <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
        <div class="table-responsive">
            <!-- La tabla presenta los registros obtenidos por el controlador. -->
            <table class="table table-hover align-middle mb-0 fs-7">
                <thead class="table-light">
                    <tr>
                        <th>Código</th>
                        <th>N° Correspondencia</th>
                        <th>Fecha de Envío</th>
                        <th>Solicitante</th>
                        <th>Área / Unidad</th>
                        <th class="text-center">Paso Actual</th>
                        <th class="text-center">Ítems</th>
                        <th class="text-end">Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($pendingRequests)): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted py-5">
                                <i class="bi bi-check2-all text-success fs-1 d-block mb-2"></i>
                                No hay solicitudes pendientes de aprobación para su nivel en este momento.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($pendingRequests as $pr): ?>
                            <tr>
                                <td class="fw-bold text-navy"><?= htmlspecialchars($pr['code']) ?></td>
                                <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($pr['correspondence_number']) ?></span></td>
                                <td><?= date('d/m/Y H:i', strtotime($pr['submitted_at'] ?? $pr['created_at'])) ?></td>
                                <td>
                                    <div class="fw-semibold"><?= htmlspecialchars($pr['applicant_name']) ?></div>
                                    <small class="text-muted"><?= htmlspecialchars($pr['applicant_position'] ?? '') ?></small>
                                </td>
                                <td><?= htmlspecialchars($pr['area_name'] ?? 'General') ?></td>
                                <td class="text-center">
                                    <span class="badge bg-info text-dark">Paso <?= $pr['current_step'] ?> / 3</span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-secondary-subtle text-dark border"><?= $pr['items_count'] ?></span>
                                </td>
                                <td class="text-end">
                                    <button type="button" class="btn btn-primary btn-sm" onclick="openDecisionModal(<?= $pr['id'] ?>, '<?= htmlspecialchars($pr['code']) ?>')">
                                        <i class="bi bi-pencil-square me-1"></i>Decidir
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal para Tomar Decisión -->
<div class="modal fade" id="modalDecision" tabindex="-1">
    <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
    <div class="modal-dialog">
        <!-- El formulario recibe los datos que procesará el controlador. -->
        <form action="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/aprobaciones/decidir" method="POST" class="modal-content">
            <?= csrf_field() ?>
            <input type="hidden" name="request_id" id="decisionRequestId">
            <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
            <div class="modal-header bg-navy text-white">
                <h5 class="modal-title fs-6"><i class="bi bi-shield-check me-2"></i>Decisión de Solicitud: <span id="decisionReqCode"></span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
            <div class="modal-body fs-7">
                <div class="mb-3">
                    <label class="form-label fw-semibold text-secondary">Acción a Tomar *</label>
                    <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
                    <select name="decision" class="form-select form-select-sm" required id="selectDecision">
                        <option value="APROBAR">Aprobar (Dar Visto Bueno / Autorizar)</option>
                        <option value="OBSERVAR">Observar / Devolver con observaciones</option>
                        <option value="RECHAZAR">Rechazar Solicitud</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold text-secondary">Comentarios / Observaciones</label>
                    <textarea name="comments" class="form-control form-control-sm" rows="3" placeholder="Indique las justificaciones de su decisión..."></textarea>
                </div>
            </div>
            <!-- Ventana modal: muestra un formulario o confirmación sin salir de la página. -->
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                <button type="submit" class="btn btn-primary btn-sm px-3">Confirmar Decisión</button>
            </div>
        </form>
    </div>
</div>

<script>
function openDecisionModal(id, code) {
    document.getElementById('decisionRequestId').value = id;
    document.getElementById('decisionReqCode').textContent = code;
    const modal = new bootstrap.Modal(document.getElementById('modalDecision'));
    modal.show();
}
</script>
