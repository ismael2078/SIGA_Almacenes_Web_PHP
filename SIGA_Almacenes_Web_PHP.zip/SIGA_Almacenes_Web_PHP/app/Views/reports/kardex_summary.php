<?php
// Vista de reportes de inventario: presenta la pantalla de resumen del Kardex y sus controles.
/** @var array<int,array<string,mixed>> $rows */
/** @var string $from */
/** @var string $to */
/** @var string $search */
/** @var int $categoryId */
/** @var array<int,array<string,mixed>> $categories */
$totals = ['initial_qty' => 0.0, 'in_qty' => 0.0, 'out_qty' => 0.0, 'final_qty' => 0.0, 'initial_val' => 0.0, 'in_val' => 0.0, 'out_val' => 0.0, 'final_val' => 0.0];
foreach ($rows as $row) {
    foreach ($totals as $key => $value) {
        $totals[$key] += (float) $row[$key];
    }
}
$exportUrl = '/reportes/kardex-resumen?' . http_build_query(['from' => $from, 'to' => $to, 'search' => $search, 'categoryId' => $categoryId, 'export' => 'csv']);
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Resumen Kardex físico-valorado</h1>
        <p class="page-sub">Saldos por producto entre <?= e(fecha($from, false)) ?> y <?= e(fecha($to, false)) ?></p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <a href="<?= e(url('/reportes')) ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Reportes</a>
        <a href="<?= e(url($exportUrl)) ?>" class="btn btn-outline-primary"><i class="bi bi-file-earmark-arrow-down me-1"></i>Exportar CSV</a>
    </div>
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form class="filter-bar row g-2 align-items-end" method="get" action="<?= e(url('/reportes/kardex-resumen')) ?>">
    <div class="col-md-2">
        <label class="form-label">Desde</label>
        <input type="date" class="form-control" name="from" value="<?= e($from) ?>" required>
    </div>
    <div class="col-md-2">
        <label class="form-label">Hasta</label>
        <input type="date" class="form-control" name="to" value="<?= e($to) ?>" required>
    </div>
    <div class="col-md-3">
        <label class="form-label">Producto</label>
        <input type="text" class="form-control" name="search" value="<?= e($search) ?>" placeholder="Código o nombre">
    </div>
    <div class="col-md-3">
        <label class="form-label">Categoría</label>
        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
        <select class="form-select" name="categoryId">
            <option value="">Todas</option>
            <?php foreach ($categories as $category): ?>
                <option value="<?= e($category['id']) ?>" <?= selected($categoryId, $category['id']) ?>><?= e($category['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-2 d-grid">
        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
        <button class="btn btn-primary" type="submit"><i class="bi bi-search me-1"></i>Consultar</button>
    </div>
</form>

<div class="card">
    <div class="card-body p-0">
        <?php if ($rows === []): ?>
            <div class="empty-state"><i class="bi bi-bar-chart"></i>No hay datos para los criterios seleccionados.</div>
        <?php else: ?>
            <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
            <div class="table-responsive">
                <!-- La tabla presenta los registros obtenidos por el controlador. -->
                <table class="table table-sm table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Categoría</th>
                            <th>Unidad</th>
                            <th class="num">Saldo inicial cant.</th>
                            <th class="num">Saldo inicial valor</th>
                            <th class="num">Entradas cant.</th>
                            <th class="num">Entradas valor</th>
                            <th class="num">Salidas cant.</th>
                            <th class="num">Salidas valor</th>
                            <th class="num">Saldo final cant.</th>
                            <th class="num">Saldo final valor</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as $row): ?>
                            <tr>
                                <td>
                                    <div class="fw-semibold mono"><?= e($row['code']) ?></div>
                                    <div class="small text-muted"><?= e($row['name']) ?></div>
                                </td>
                                <td class="small"><?= e($row['category_name']) ?></td>
                                <td class="small"><?= e($row['unit_code']) ?></td>
                                <td class="num"><?= e(qty($row['initial_qty'])) ?></td>
                                <td class="num"><?= e(money($row['initial_val'])) ?></td>
                                <td class="num text-success"><?= e(qty($row['in_qty'])) ?></td>
                                <td class="num text-success"><?= e(money($row['in_val'])) ?></td>
                                <td class="num text-danger"><?= e(qty($row['out_qty'])) ?></td>
                                <td class="num text-danger"><?= e(money($row['out_val'])) ?></td>
                                <td class="num fw-semibold"><?= e(qty($row['final_qty'])) ?></td>
                                <td class="num fw-semibold"><?= e(money($row['final_val'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-end fw-semibold">Totales</td>
                            <td class="num fw-bold"><?= e(qty($totals['initial_qty'])) ?></td>
                            <td class="num fw-bold"><?= e(money($totals['initial_val'])) ?></td>
                            <td class="num fw-bold"><?= e(qty($totals['in_qty'])) ?></td>
                            <td class="num fw-bold"><?= e(money($totals['in_val'])) ?></td>
                            <td class="num fw-bold"><?= e(qty($totals['out_qty'])) ?></td>
                            <td class="num fw-bold"><?= e(money($totals['out_val'])) ?></td>
                            <td class="num fw-bold"><?= e(qty($totals['final_qty'])) ?></td>
                            <td class="num fw-bold"><?= e(money($totals['final_val'])) ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
