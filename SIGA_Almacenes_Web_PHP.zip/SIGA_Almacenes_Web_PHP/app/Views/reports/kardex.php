<?php
// Vista de reportes de inventario: presenta la pantalla de reporte Kardex y sus controles.
/** @var array<int,array<string,mixed>> $rows */
/** @var string $from */
/** @var string $to */
/** @var string $search */
/** @var string $docType */
$totals = ['in_qty' => 0.0, 'out_qty' => 0.0, 'in_val' => 0.0, 'out_val' => 0.0];
foreach ($rows as $row) {
    $totals['in_qty'] += (float) $row['qty_in'];
    $totals['out_qty'] += (float) $row['qty_out'];
    $totals['in_val'] += (float) $row['total_in'];
    $totals['out_val'] += (float) $row['total_out'];
}
$exportUrl = '/reportes/kardex?' . http_build_query(['from' => $from, 'to' => $to, 'search' => $search, 'docType' => $docType, 'export' => 'csv']);
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Kardex de movimientos</h1>
        <p class="page-sub"><?= e(count($rows)) ?> movimientos entre <?= e(fecha($from, false)) ?> y <?= e(fecha($to, false)) ?></p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <a href="<?= e(url('/reportes')) ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Reportes</a>
        <a href="<?= e(url($exportUrl)) ?>" class="btn btn-outline-primary"><i class="bi bi-file-earmark-arrow-down me-1"></i>Exportar CSV</a>
    </div>
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form class="filter-bar row g-2 align-items-end" method="get" action="<?= e(url('/reportes/kardex')) ?>">
    <div class="col-md-2">
        <label class="form-label">Desde</label>
        <input type="date" class="form-control" name="from" value="<?= e($from) ?>" required>
    </div>
    <div class="col-md-2">
        <label class="form-label">Hasta</label>
        <input type="date" class="form-control" name="to" value="<?= e($to) ?>" required>
    </div>
    <div class="col-md-3">
        <label class="form-label">Producto</label>
        <input type="text" class="form-control" name="search" value="<?= e($search) ?>" placeholder="Código o nombre">
    </div>
    <div class="col-md-3">
        <label class="form-label">Tipo de documento</label>
        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
        <select class="form-select" name="docType">
            <option value="">Todos</option>
            <?php foreach (['INGRESO', 'SALIDA', 'AJUSTE', 'ANULACION', 'INGRESO_ANULADO'] as $option): ?>
                <option value="<?= e($option) ?>" <?= selected($docType, $option) ?>><?= e(doc_type_label($option)) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-2 d-grid">
        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
        <button class="btn btn-primary" type="submit"><i class="bi bi-search me-1"></i>Consultar</button>
    </div>
</form>

<div class="row g-3 mb-3">
    <div class="col-6 col-lg-3"><div class="stat-card"><div class="stat-icon"><i class="bi bi-box-arrow-in-down"></i></div><div class="stat-value"><?= e(qty($totals['in_qty'])) ?></div><div class="stat-label">Cantidad ingresada</div><div class="stat-hint">Bs <?= e(money($totals['in_val'])) ?></div></div></div>
    <div class="col-6 col-lg-3"><div class="stat-card danger"><div class="stat-icon"><i class="bi bi-box-arrow-up"></i></div><div class="stat-value"><?= e(qty($totals['out_qty'])) ?></div><div class="stat-label">Cantidad salida</div><div class="stat-hint">Bs <?= e(money($totals['out_val'])) ?></div></div></div>
    <div class="col-6 col-lg-3"><div class="stat-card gold"><div class="stat-icon"><i class="bi bi-arrow-left-right"></i></div><div class="stat-value"><?= e(qty($totals['in_qty'] - $totals['out_qty'])) ?></div><div class="stat-label">Movimiento neto</div><div class="stat-hint">Cantidad</div></div></div>
    <div class="col-6 col-lg-3"><div class="stat-card success"><div class="stat-icon"><i class="bi bi-cash-stack"></i></div><div class="stat-value">Bs <?= e(money($totals['in_val'] - $totals['out_val'])) ?></div><div class="stat-label">Valor neto</div><div class="stat-hint">Diferencia del periodo</div></div></div>
</div>

<div class="card">
    <div class="card-body p-0">
        <?php if ($rows === []): ?>
            <div class="empty-state"><i class="bi bi-journal-x"></i>No hay movimientos para los criterios seleccionados.</div>
        <?php else: ?>
            <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
            <div class="table-responsive">
                <!-- La tabla presenta los registros obtenidos por el controlador. -->
                <table class="table table-sm table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Producto</th>
                            <th>Documento</th>
                            <th>Referencia</th>
                            <th class="num">Entrada</th>
                            <th class="num">Salida</th>
                            <th class="num">Costo unit.</th>
                            <th class="num">Saldo cant.</th>
                            <th class="num">Saldo valor</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as $row): ?>
                            <tr>
                                <td class="small"><?= e(fecha($row['movement_date'])) ?></td>
                                <td class="small">
                                    <div class="fw-semibold mono"><?= e($row['product_code']) ?></div>
                                    <div class="text-muted"><?= e($row['product_name']) ?></div>
                                </td>
                                <td><span class="badge badge-soft"><?= e(doc_type_label((string) $row['doc_type'])) ?></span></td>
                                <td class="small mono"><?= e($row['reference'] ?? '—') ?></td>
                                <td class="num text-success"><?= (float) $row['qty_in'] > 0 ? e(qty($row['qty_in'])) : '—' ?></td>
                                <td class="num text-danger"><?= (float) $row['qty_out'] > 0 ? e(qty($row['qty_out'])) : '—' ?></td>
                                <td class="num"><?= e(money((float) $row['unit_cost_in'] > 0 ? $row['unit_cost_in'] : $row['unit_cost_out'], 4)) ?></td>
                                <td class="num"><?= e(qty($row['balance_qty'])) ?></td>
                                <td class="num"><?= e(money($row['balance_value'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
