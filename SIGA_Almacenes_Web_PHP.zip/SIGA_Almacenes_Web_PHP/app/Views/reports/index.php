<?php
// Vista de reportes de inventario: presenta la pantalla de listado y búsqueda y sus controles.
/** @var array<int,array<string,mixed>> $categories */
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Reportes e informes</h1>
        <p class="page-sub">Consultas físicas y valoradas del inventario institucional</p>
    </div>
</div>

<div class="row g-3">
    <div class="col-md-6 col-xl-4">
        <div class="card h-100">
            <div class="card-body">
                <div class="stat-icon mb-2"><i class="bi bi-journal-text"></i></div>
                <h2 class="h6 fw-bold">Kardex de movimientos</h2>
                <p class="small text-muted">Detalle cronológico de entradas, salidas, ajustes y anulaciones por producto, con saldos físicos y valorados.</p>
                <a href="<?= e(url('/reportes/kardex')) ?>" class="btn btn-sm btn-primary"><i class="bi bi-arrow-right me-1"></i>Abrir reporte</a>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-4">
        <div class="card h-100">
            <div class="card-body">
                <div class="stat-icon mb-2"><i class="bi bi-box-seam"></i></div>
                <h2 class="h6 fw-bold">Inventario valorado</h2>
                <p class="small text-muted">Existencias, costo de referencia, valor total y alertas de stock bajo por producto y categoría.</p>
                <a href="<?= e(url('/reportes/inventario')) ?>" class="btn btn-sm btn-primary"><i class="bi bi-arrow-right me-1"></i>Abrir reporte</a>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-4">
        <div class="card h-100">
            <div class="card-body">
                <div class="stat-icon mb-2"><i class="bi bi-bar-chart-line"></i></div>
                <h2 class="h6 fw-bold">Resumen Kardex físico-valorado</h2>
                <p class="small text-muted">Saldos iniciales, entradas, salidas y saldos finales por producto en un rango de fechas.</p>
                <a href="<?= e(url('/reportes/kardex-resumen')) ?>" class="btn btn-sm btn-primary"><i class="bi bi-arrow-right me-1"></i>Abrir reporte</a>
            </div>
        </div>
    </div>
</div>

<div class="card mt-3">
    <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
    <div class="card-header"><i class="bi bi-tags me-1"></i>Categorías registradas</div>
    <div class="card-body">
        <div class="d-flex flex-wrap gap-2">
            <?php foreach ($categories as $category): ?>
                <a class="badge badge-soft text-decoration-none" href="<?= e(url('/reportes/inventario?category=' . $category['id'])) ?>">
                    <?= e($category['code'] . ' · ' . $category['name']) ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<div class="card mt-3">
    <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
    <div class="card-header"><i class="bi bi-info-circle me-1"></i>Criterios de valuación</div>
    <div class="card-body small text-muted">
        <p class="mb-2">El sistema utiliza el método PEPS (primeros en entrar, primeros en salir). Cada ingreso genera una capa con su costo unitario; cada salida consume las capas más antiguas.</p>
        <p class="mb-0">El kardex conserva el saldo físico y valorado posterior a cada movimiento, permitiendo conciliar existencias con contabilidad.</p>
    </div>
</div>
