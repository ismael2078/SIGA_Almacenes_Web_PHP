<?php
// Vista de reportes de inventario: presenta la pantalla de reporte de inventario y sus controles.
/** @var array<int,array<string,mixed>> $rows */
/** @var string $search */
/** @var int $category */
/** @var int $lowStock */
/** @var array<int,array<string,mixed>> $categories */
/** @var float $totalValue */
$exportUrl = '/reportes/inventario?' . http_build_query(['search' => $search, 'category' => $category, 'low_stock' => $lowStock, 'export' => 'csv']);
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Inventario valorado</h1>
        <p class="page-sub"><?= e(count($rows)) ?> productos · valor total Bs <?= e(money($totalValue)) ?></p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <a href="<?= e(url('/reportes')) ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Reportes</a>
        <a href="<?= e(url($exportUrl)) ?>" class="btn btn-outline-primary"><i class="bi bi-file-earmark-arrow-down me-1"></i>Exportar CSV</a>
    </div>
</div>

<!-- El formulario recibe los datos que procesará el controlador. -->
<form class="filter-bar row g-2 align-items-end" method="get" action="<?= e(url('/reportes/inventario')) ?>">
    <div class="col-md-5">
        <label class="form-label">Producto</label>
        <input type="text" class="form-control" name="search" value="<?= e($search) ?>" placeholder="Código o nombre">
    </div>
    <div class="col-md-4">
        <label class="form-label">Categoría</label>
        <!-- Selector: ofrece opciones permitidas para registrar o filtrar datos. -->
        <select class="form-select" name="category">
            <option value="">Todas</option>
            <?php foreach ($categories as $item): ?>
                <option value="<?= e($item['id']) ?>" <?= selected($category, $item['id']) ?>><?= e($item['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-2">
        <div class="form-check mt-4">
            <input class="form-check-input" type="checkbox" name="low_stock" value="1" id="lowStock" <?= checked($lowStock) ?>>
            <label class="form-check-label small" for="lowStock">Solo stock bajo</label>
        </div>
    </div>
    <div class="col-md-1 d-grid">
        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
        <button class="btn btn-primary" type="submit"><i class="bi bi-search"></i></button>
    </div>
</form>

<div class="card">
    <div class="card-body p-0">
        <?php if ($rows === []): ?>
            <div class="empty-state"><i class="bi bi-box"></i>No hay productos para los criterios seleccionados.</div>
        <?php else: ?>
            <!-- Contenedor adaptable: permite desplazar la tabla en pantallas pequeñas. -->
            <div class="table-responsive">
                <!-- La tabla presenta los registros obtenidos por el controlador. -->
                <table class="table table-sm table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Producto</th>
                            <th>Categoría</th>
                            <th>Unidad</th>
                            <th class="num">Stock</th>
                            <th class="num">Mínimo</th>
                            <th class="num">Costo ref.</th>
                            <th class="num">Valor stock</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as $row): ?>
                            <tr>
                                <td class="mono fw-semibold"><?= e($row['code']) ?></td>
                                <td>
                                    <a href="<?= e(url('/inventario/' . $row['id'])) ?>" class="text-dark fw-semibold"><?= e($row['name']) ?></a>
                                    <div class="small text-muted"><?= e($row['subcategory_name']) ?></div>
                                </td>
                                <td class="small"><?= e($row['category_name']) ?></td>
                                <td class="small"><?= e($row['unit_code']) ?></td>
                                <td class="num <?= (float) $row['stock_qty'] <= (float) $row['min_stock'] ? 'text-danger fw-semibold' : '' ?>"><?= e(qty($row['stock_qty'])) ?></td>
                                <td class="num text-muted"><?= e(qty($row['min_stock'])) ?></td>
                                <td class="num"><?= e(money($row['reference_cost'], 4)) ?></td>
                                <td class="num fw-semibold"><?= e(money($row['stock_value'])) ?></td>
                                <td><?= status_badge((string) $row['status']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr><td colspan="7" class="text-end fw-semibold">Valor total del inventario</td><td class="num fw-bold">Bs <?= e(money($totalValue)) ?></td><td></td></tr>
                    </tfoot>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
