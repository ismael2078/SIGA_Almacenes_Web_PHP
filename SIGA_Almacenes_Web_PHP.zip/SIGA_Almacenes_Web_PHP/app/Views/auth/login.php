<!DOCTYPE html>
<!-- Vista de autenticación o perfil: presenta la pantalla de inicio de sesión y sus controles. -->

<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - SIGA DDE Almacenes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/css/custom.css">
</head>
<body class="bg-navy min-vh-100 d-flex align-items-center justify-content-center p-3">

<div class="card login-card bg-white p-4 p-sm-5">
    <div class="text-center mb-4">
        <div class="d-inline-flex p-3 bg-navy text-white rounded-circle shadow-sm mb-3">
            <i class="bi bi-boxes fs-1"></i>
        </div>
        <h4 class="fw-bold text-navy mb-1">SIGA-DDE</h4>
        <div class="text-muted fs-7">Sistema Integrado de Gestión de Almacenes</div>
        <div class="badge bg-gold text-dark mt-1 px-3 py-1">Dirección Departamental de Educación</div>
    </div>

    <!-- Alertas Flash -->
    <?php
    use App\Core\Auth;
    Auth::init();
    $flashes = $_SESSION['siga_flashes'] ?? [];
    unset($_SESSION['siga_flashes']);
    ?>
    <?php if (!empty($flashes)): ?>
        <?php foreach ($flashes as $f): ?>
            <!-- Mensaje informativo: comunica avisos o resultados de una operación. -->
            <div class="alert alert-<?= htmlspecialchars($f['type']) ?> py-2 fs-7 alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($f['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- El formulario recibe los datos que procesará el controlador. -->
    <form action="<?= htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8') ?>/login" method="POST">
            <?= csrf_field() ?>
        <div class="mb-3">
            <label for="username" class="form-label fs-7 fw-semibold text-secondary">Usuario</label>
            <div class="input-group">
                <span class="input-group-text bg-light text-muted"><i class="bi bi-person"></i></span>
                <input type="text" class="form-control" id="username" name="username" placeholder="admin, almacen, solicitante..." required autofocus>
            </div>
        </div>

        <div class="mb-4">
            <label for="password" class="form-label fs-7 fw-semibold text-secondary">Contraseña</label>
            <div class="input-group">
                <span class="input-group-text bg-light text-muted"><i class="bi bi-lock"></i></span>
                <input type="password" class="form-control" id="password" name="password" placeholder="••••••••" required>
            </div>
        </div>

        <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
        <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold shadow-sm">
            <i class="bi bi-box-arrow-in-right me-2"></i> Ingresar al Sistema
        </button>
    </form>

    <!-- Acceso Rápido para Demostración -->
    <div class="mt-4 pt-3 border-top text-center">
        <small class="text-muted fw-bold d-block mb-2"><i class="bi bi-lightning-charge-fill text-warning me-1"></i>Acceso rápido para demostración:</small>
        <div class="d-flex flex-wrap gap-1 justify-content-center">
            <button type="button" class="btn btn-outline-secondary btn-sm fs-8 py-1 px-2" onclick="fillUser('admin', 'admin123')">Admin</button>
            <button type="button" class="btn btn-outline-secondary btn-sm fs-8 py-1 px-2" onclick="fillUser('almacen', 'almacen123')">Almacén</button>
            <button type="button" class="btn btn-outline-secondary btn-sm fs-8 py-1 px-2" onclick="fillUser('solicitante', 'sol123')">Solicitante</button>
            <button type="button" class="btn btn-outline-secondary btn-sm fs-8 py-1 px-2" onclick="fillUser('jefe_inmediato', 'jefe123')">Jefe Inmediato</button>
            <button type="button" class="btn btn-outline-secondary btn-sm fs-8 py-1 px-2" onclick="fillUser('jefe_uaa', 'uaa123')">Jefe UAA</button>
            <button type="button" class="btn btn-outline-secondary btn-sm fs-8 py-1 px-2" onclick="fillUser('auditor', 'auditor123')">Auditor</button>
        </div>
    </div>
</div>

<script>
function fillUser(u, p) {
    document.getElementById('username').value = u;
    document.getElementById('password').value = p;
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
