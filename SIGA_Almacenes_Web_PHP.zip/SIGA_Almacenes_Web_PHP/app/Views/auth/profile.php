<?php
// Vista de autenticación o perfil: presenta la pantalla de perfil del usuario y sus controles.
/** @var array<string,mixed>|null $profile */
/** @var array<string,mixed> $user */
?>
<div class="page-head">
    <div>
        <h1 class="page-title">Mi perfil</h1>
        <p class="page-sub">Datos de la cuenta y seguridad de acceso</p>
    </div>
    <a href="<?= e(url('/dashboard')) ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i>Volver al panel
    </a>
</div>

<div class="row g-3">
    <div class="col-lg-7">
        <div class="card">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-person-vcard me-1"></i>Información del usuario</div>
            <div class="card-body">
                <?php if ($profile !== null): ?>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <div class="label">Nombre completo</div>
                            <div class="value"><?= e($profile['full_name']) ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="label">Usuario</div>
                            <div class="value mono"><?= e($profile['username']) ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="label">Cédula de identidad</div>
                            <div class="value"><?= e($profile['ci'] ?? '—') ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="label">Rol</div>
                            <div class="value"><?= e($profile['role_name'] ?? '—') ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="label">Área / unidad</div>
                            <div class="value"><?= e($profile['area_name'] ?? 'Sin asignar') ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="label">Cargo</div>
                            <div class="value"><?= e($profile['position'] ?? '—') ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="label">Oficina</div>
                            <div class="value"><?= e($profile['office'] ?? '—') ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="label">Correo electrónico</div>
                            <div class="value"><?= e($profile['email'] ?? '—') ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="label">Último acceso</div>
                            <div class="value"><?= e(fecha($profile['last_login_at'] ?? null)) ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="label">Estado</div>
                            <div class="value"><?= status_badge((int) $profile['is_active'] === 1 ? 'ACTIVO' : 'INACTIVO') ?></div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mt-3">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-shield-lock me-1"></i>Permisos efectivos</div>
            <div class="card-body">
                <div class="d-flex flex-wrap gap-1">
                    <?php foreach (($user['permissions'] ?? []) as $permission): ?>
                        <span class="badge badge-soft"><?= e($permission) ?></span>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="card">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-key me-1"></i>Cambiar contraseña</div>
            <div class="card-body">
                <!-- El formulario recibe los datos que procesará el controlador. -->
                <form method="post" action="<?= e(url('/perfil/password')) ?>">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label class="form-label" for="current_password">Contraseña actual</label>
                        <input type="password" class="form-control" id="current_password" name="current_password" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="new_password">Nueva contraseña</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" minlength="8" required>
                        <div class="form-text">Mínimo 8 caracteres. Use mayúsculas, minúsculas y números.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="confirm_password">Confirmar nueva contraseña</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" minlength="8" required>
                    </div>
                    <!-- Acción del formulario: permite confirmar o enviar la información ingresada. -->
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-check2-circle me-1"></i>Actualizar contraseña
                    </button>
                </form>
            </div>
        </div>
        <div class="card mt-3">
            <!-- Cabecera de bloque: identifica la información presentada en esta tarjeta. -->
            <div class="card-header"><i class="bi bi-info-circle me-1"></i>Seguridad</div>
            <div class="card-body small text-muted">
                <p class="mb-2">La sesión se mantiene activa durante 8 horas o hasta que cierre sesión.</p>
                <p class="mb-0">Después de 5 intentos fallidos, la cuenta se bloquea temporalmente por 15 minutos.</p>
            </div>
        </div>
    </div>
</div>
