<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de la aprobación de solicitudes.

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\AuditLog;
use App\Models\Request;
use RuntimeException;

final class ApprovalController extends Controller
{
    // Consulta los datos y prepara la pantalla principal de la aprobación de solicitudes.
    public function index(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('aprobaciones.ver');
        $pending = Request::pendingForApprover($user);
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($pending as &$request) {
            $request['items'] = Request::items((int) $request['id']);
        }
        unset($request);

        $this->view('approvals/index', [
            'title' => 'Aprobaciones pendientes',
            'pending' => $pending,
        ]);
    }

    // Valida y registra la decisión sobre un trámite pendiente.
    public function decide(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('aprobaciones.decidir');
        $action = (string) $this->input('action', '');
        $comments = trim((string) $this->input('comments', ''));
        $quantityItems = [];
        // Recupera los valores enviados por el formulario para validarlos en el servidor.
        foreach ((array) ($_POST['qty'] ?? []) as $itemId => $qty) {
            $quantityItems[] = ['id' => (int) $itemId, 'qty' => (float) str_replace(',', '.', (string) $qty)];
        }

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            Request::decide((int) $id, $user, $action, $comments, $quantityItems);
            AuditLog::record((int) $user['id'], 'SOLICITUD_DECIDIDA', 'requests', (int) $id, null, [
                'action' => $action,
                'comments' => $comments,
            ]);
            Session::flash('success', 'Decisión registrada correctamente.');
        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (RuntimeException $exception) {
            Session::flash('danger', $exception->getMessage());
        }

        // Redirige a la pantalla correspondiente e informa el resultado de la acción.
        $this->redirect('/aprobaciones');
    }
}
