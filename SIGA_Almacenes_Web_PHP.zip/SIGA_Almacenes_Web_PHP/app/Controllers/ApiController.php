<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de las consultas de la API.
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\Product;
use App\Services\ExternalApiService;
use PDO;

class ApiController extends Controller {

    // Devuelve información básica del estado del servicio.
    public function health(): void {
        $driver = Database::getDriver();
        $this->json([
            'status' => 'OK',
            'timestamp' => date('Y-m-d H:i:s'),
            'database' => [
                'driver' => $driver,
                'status' => 'connected'
            ],
            'version' => '2.0.0-php-mvc'
        ]);
    }

    // Consulta y entrega los tipos de cambio utilizados en el sistema.
    public function getRates(): void {
        $rates = ExternalApiService::getExchangeRates();
        $this->json($rates);
    }

    // Busca productos para formularios con autocompletado.
    public function searchProducts(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('productos.ver');
        $term = trim($_GET['q'] ?? '');
        $prodModel = new Product();
        $filters = [];
        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (!empty($term)) {
            $filters['search'] = $term;
        }
        $products = $prodModel->getDetailedList($filters);
        $this->json($products);
    }

    // Devuelve la información de un producto específico.
    public function getProduct(string $id): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('productos.ver');
        $prodModel = new Product();
        $product = $prodModel->getWithDetails((int)$id);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if (!$product) {
            $this->json(['error' => 'Producto no encontrado'], 404);
        }
        $this->json($product);
    }

    // Comprueba si un número de correspondencia ya está registrado.
    public function checkCorrespondence(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('solicitudes.crear');
        $num = trim($_GET['number'] ?? '');
        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (empty($num)) {
            $this->json(['available' => false, 'error' => 'Número vacío']);
        }

        $db = Database::getConnection();
        // Prepara una consulta parametrizada para recuperar información sin concatenar datos del usuario.
        $stmt = $db->prepare("SELECT id FROM requests WHERE correspondence_number = ? LIMIT 1");
        $stmt->execute([$num]);
        $exists = (bool)$stmt->fetch();

        $this->json(['available' => !$exists]);
    }
}
