<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de los comprobantes impresos.

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Models\AuditLog;
use App\Models\Dispatch;
use App\Models\Request;

final class PrintController extends Controller
{
    // Genera la vista imprimible de una solicitud autorizada.
    public function request(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requireAuth();
        $request = Request::findDetailed((int) $id);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($request === null) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Solicitud no encontrada'], 'print');
            return;
        }
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if (!$this->canViewRequest($request, $user)) {
            http_response_code(403);
            $this->view('errors/403', ['title' => 'Acceso denegado'], 'print');
            return;
        }

        Request::update((int) $id, [
            'printed_at' => date('Y-m-d H:i:s'),
            'print_count' => (int) ($request['print_count'] ?? 0) + 1,
        ]);
        AuditLog::record((int) $user['id'], 'SOLICITUD_IMPRESA', 'requests', (int) $id);

        $this->view('print/request', [
            'title' => 'Solicitud ' . $request['code'],
            'request' => $request,
            'items' => Request::items((int) $id),
            'approvals' => Request::approvals((int) $id),
        ], 'print');
    }

    // Genera el comprobante imprimible de una salida.
    public function dispatch(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requireAuth();
        if (!can('salidas.ver') && !can('salidas.preparar') && !can('salidas.confirmar')) {
            http_response_code(403);
            $this->view('errors/403', ['title' => 'Acceso denegado'], 'print');
            return;
        }
        $dispatch = Dispatch::findDetailed((int) $id);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($dispatch === null) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Despacho no encontrado'], 'print');
            return;
        }

        $this->view('print/dispatch', [
            'title' => 'Despacho ' . $dispatch['number'],
            'dispatch' => $dispatch,
            'items' => Dispatch::items((int) $id),
        ], 'print');
    }

    /** @param array<string,mixed> $request */
    private function canViewRequest(array $request, array $user): bool
    {
        if ((int) $request['applicant_id'] === (int) $user['id']) {
            return true;
        }
        // Aplica una restricción de seguridad de acuerdo con el rol o permiso del usuario.
        if (in_array('solicitudes.ver_todas', $user['permissions'], true)) {
            return true;
        }
        // Aplica una restricción de seguridad de acuerdo con el rol o permiso del usuario.
        if (in_array('solicitudes.ver_area', $user['permissions'], true) && (int) $request['area_id'] === (int) ($user['area_id'] ?? -1)) {
            return true;
        }
        // Aplica una restricción de seguridad de acuerdo con el rol o permiso del usuario.
        if (in_array('aprobaciones.ver', $user['permissions'], true)) {
            return $user['role_code'] !== 'JEFE_INMEDIATO' || (int) $request['area_id'] === (int) ($user['area_id'] ?? -1);
        }
        return false;
    }
}
