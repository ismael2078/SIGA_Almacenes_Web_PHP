<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de las solicitudes de materiales.
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Core\Database;
use App\Core\PepsEngine;
use App\Core\ApprovalFlow;
use App\Models\Request as RequestModel;
use App\Models\Product;
use App\Models\Area;
use PDO;

class SolicitudesController extends Controller {

    // Filtra la lista para mostrar a cada usuario solo las solicitudes que puede consultar.
    public function index(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requireAuth();
        $reqModel = new RequestModel();

        $filters = [];
        // Verifica el estado actual para impedir cambios fuera del flujo permitido.
        if (!empty($_GET['status'])) $filters['status'] = (string)$_GET['status'];
        if (!empty($_GET['search'])) $filters['search'] = (string)$_GET['search'];
        $db = Database::getConnection();
        $requests = array_values(array_filter(
            $reqModel->getDetailedList($filters),
            // Restringe la consulta de solicitudes según el usuario y su participación.
            static fn(array $r): bool => ApprovalFlow::canView($db, $r, $user)
        ));

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('solicitudes/index', [
            'pageTitle' => 'Solicitudes de Material - SIGA DDE',
            'requests' => $requests,
            'filters' => $filters
        ]);
    }

    // Carga los productos y las áreas necesarias para el formulario de solicitud.
    public function nueva(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('solicitudes.crear');
        $user = Auth::user();

        $prodModel = new Product();
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $products = $prodModel->fetchAll("
            SELECT p.id, p.code, p.name, p.stock_qty, p.reference_cost, u.name AS unit_name
            FROM products p
            LEFT JOIN units u ON u.id = p.unit_id
            WHERE p.is_active = 1
            ORDER BY p.name ASC
        ");

        $areaModel = new Area();
        $areas = $areaModel->all();

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('solicitudes/nueva', [
            'pageTitle' => 'Nueva Solicitud de Materiales - SIGA DDE',
            'user' => $user,
            'products' => $products,
            'areas' => $areas,
        ]);
    }

    // Valida, crea y registra una solicitud con sus productos y el paso inicial.
    public function store(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('solicitudes.crear');
        $data = $this->getPostData();

        $corrNumber = trim($data['correspondence_number'] ?? '');
        $justification = trim($data['justification'] ?? '');
        $office = trim($data['office'] ?? $user['office'] ?? '');
        // No permitir cambiar de área para dirigir pedidos a jefaturas ajenas.
        $areaId = ($user['role_code'] === 'ADMIN')
            ? (int)($data['area_id'] ?? $user['area_id'] ?? 0)
            : (int)($user['area_id'] ?? 0);
        $items = $data['items'] ?? [];
        $action = strtoupper((string)($data['submit_action'] ?? 'ENVIAR'));

        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (empty($corrNumber)) {
            $this->redirect('/solicitudes/nueva', 'El número de hoja de correspondencia es obligatorio.', 'danger');
        }

        if ($areaId <= 0) $this->redirect('/solicitudes/nueva', 'Su usuario no tiene área asignada.', 'danger');
        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (empty($items) || !is_array($items)) {
            $this->redirect('/solicitudes/nueva', 'Debe seleccionar al menos un ítem para solicitar.', 'danger');
        }

        $db = Database::getConnection();
        $validItems = array_filter($items, static fn($i) => is_array($i) && (int)($i['product_id'] ?? 0) > 0 && (float)($i['qty'] ?? 0) > 0);
        // Controla los valores de cantidad o costo antes de continuar con el inventario.
        if (!$validItems) $this->redirect('/solicitudes/nueva', 'Agregue al menos un producto con cantidad válida.', 'danger');
        // Evita que se guarden filas vacías o con cantidades no finitas.
        $items = array_values(array_filter($validItems, static fn($i) => is_finite((float)$i['qty'])));
        if (!$items) $this->redirect('/solicitudes/nueva', 'Las cantidades ingresadas no son válidas.', 'danger');

        // Verificar correspondencia única
        $stmt = $db->prepare("SELECT id FROM requests WHERE correspondence_number = ?");
        $stmt->execute([$corrNumber]);
        if ($stmt->fetch()) {
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/solicitudes/nueva', "El número de correspondencia {$corrNumber} ya fue registrado previamente.", 'danger');
        }

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            Database::beginTransaction();

            // Código correlativo anual
            $code = PepsEngine::nextSequence('SOL', (int)date('Y'));
            // Distingue entre guardar sin enviar y activar inmediatamente la ruta de aprobación.
            $status = ($action === 'BORRADOR') ? 'BORRADOR' : 'EN_APROBACION';

            // La solicitud queda asociada a una ruta del área, no a todos los jefes del sistema.
            $routeId = ApprovalFlow::routeForArea($db, $areaId);
            if ($status === 'EN_APROBACION') {
                // Comprueba que todos los pasos tengan un responsable definido antes de enviar.
                ApprovalFlow::assertSendable($db, [
                    'route_id' => $routeId, 'area_id' => $areaId,
                    'applicant_id' => $user['id'], 'current_step' => 1
                ]);
            }
            // Crear solicitud
            $ins = $db->prepare("
                INSERT INTO requests (
                    code, correspondence_number, applicant_id, area_id, office,
                    justification, route_id, current_step, status, submitted_at, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, CURRENT_TIMESTAMP)
            ");
            $ins->execute([
                $code,
                $corrNumber,
                $user['id'],
                $areaId,
                $office,
                $justification,
                $routeId,
                $status,
                $status === 'BORRADOR' ? null : date('Y-m-d H:i:s')
            ]);
            // Recupera el identificador de la cabecera para relacionar cada producto solicitado.
            $requestId = (int)$db->lastInsertId();

            // Insertar ítems
            $itemIns = $db->prepare("
                INSERT INTO request_items (
                    request_id, product_id, qty_requested, qty_approved,
                    qty_proposed, qty_authorized, stock_at_request, status, notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 'PENDIENTE', ?)
            ");

            // Procesa cada producto por separado para registrar o calcular su movimiento.
            foreach ($items as $item) {
                $pId = (int)($item['product_id'] ?? 0);
                $qty = (float)($item['qty'] ?? 0);
                $notes = trim($item['notes'] ?? '');

                // Controla los valores de cantidad o costo antes de continuar con el inventario.
                if ($pId <= 0 || $qty <= 0) continue;

                // Obtener stock al momento de la solicitud
                $pStmt = $db->prepare("SELECT stock_qty FROM products WHERE id = ? AND is_active = 1");
                $pStmt->execute([$pId]);
                // Un producto inexistente no debe quedar asociado a una solicitud.
                $productStock = $pStmt->fetchColumn();
                if ($productStock === false) {
                    throw new \RuntimeException('Se seleccionó un producto inexistente. Actualice el formulario.');
                }
                // Guarda una fotografía de las existencias que había al momento de solicitar.
                $pStock = (float)$productStock;

                $itemIns->execute([
                    $requestId,
                    $pId,
                    $qty,
                    0, // solo el aprobador de cada paso valida cantidades
                    0,
                    0,
                    $pStock,
                    $notes
                ]);
            }

            // Historial
            $histIns = $db->prepare("
                INSERT INTO request_history (
                    request_id, from_state, to_state, actor_id, role_id, comments, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ");
            $histIns->execute([
                $requestId,
                'INICIO',
                $status,
                $user['id'],
                $user['role_id'],
                ($status === 'BORRADOR') ? 'Guardado como borrador' : 'Enviado para aprobación jerárquica'
            ]);

            // Auditoría
            Auth::audit('solicitudes.crear', 'requests', $requestId, null, ['code' => $code, 'items_count' => count($items)]);

            Database::commit();

            $this->redirect("/solicitudes/{$requestId}", "Solicitud {$code} creada exitosamente.", 'success');

        } catch (\Throwable $e) {
            if ($db->inTransaction()) Database::rollBack();
            $this->redirect('/solicitudes/nueva', 'Error al crear la solicitud: ' . $e->getMessage(), 'danger');
        }
    }

    // Muestra el detalle, historial y aprobaciones solo a usuarios autorizados.
    public function ver(string $id): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requireAuth();
        $reqModel = new RequestModel();
        $request = $reqModel->getWithDetails((int)$id);

        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if (!$request) {
            $this->redirect('/solicitudes', 'La solicitud no existe.', 'danger');
        }

        // Restringe la consulta de solicitudes según el usuario y su participación.
        if (!ApprovalFlow::canView(Database::getConnection(), $request, $user)) {
            http_response_code(403);
            echo 'Acceso denegado a esta solicitud.';
            return;
        }

        $items = $reqModel->getItems((int)$id);
        $history = $reqModel->getHistory((int)$id);
        $approvals = $reqModel->getApprovals((int)$id);

        // Si la solicitud ya fue atendida, obtener el comprobante de despacho generado
        $db = Database::getConnection();
        $dispStmt = $db->prepare("SELECT id, number, total_value, created_at FROM stock_dispatches WHERE request_id = ? LIMIT 1");
        $dispStmt->execute([(int)$id]);
        $dispatchInfo = $dispStmt->fetch(PDO::FETCH_ASSOC) ?: null;

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('solicitudes/ver', [
            'pageTitle' => "Solicitud {$request['code']} - SIGA DDE",
            'request' => $request,
            'items' => $items,
            'history' => $history,
            'approvals' => $approvals,
            'dispatch' => $dispatchInfo,
            'user' => $user
        ]);
    }

    /** Enviar borrador u observada al inicio de su ruta de aprobación. */
    public function enviar(string $id): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('solicitudes.crear');
        $db = Database::getConnection();
        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            Database::beginTransaction();
            // Construye la consulta de lectura con los campos y relaciones necesarios.
            $sql = 'SELECT * FROM requests WHERE id = ?';
            if (Database::getDriver() === 'mysql') $sql .= ' FOR UPDATE';
            // Prepara una sentencia SQL parametrizada para ejecutar esta operación de forma segura.
            $q = $db->prepare($sql);
            $q->execute([(int)$id]);
            // Lee el resultado obtenido de la consulta SQL ejecutada.
            $req = $q->fetch(PDO::FETCH_ASSOC);
            if (!$req || (int)$req['applicant_id'] !== (int)$user['id'] || !in_array($req['status'], ['BORRADOR','OBSERVADA'], true)) {
                throw new \RuntimeException('Solo el solicitante puede enviar su borrador u observación.');
            }
            // Prepara una consulta parametrizada para recuperar información sin concatenar datos del usuario.
            $q = $db->prepare('SELECT COUNT(*) FROM request_items WHERE request_id = ?');
            $q->execute([(int)$id]);
            if ((int)$q->fetchColumn() < 1) throw new \RuntimeException('La solicitud no tiene productos.');
            // Selecciona la ruta de aprobación configurada para el área del solicitante.
            $req['route_id'] = ApprovalFlow::routeForArea($db, (int)$req['area_id']);
            $req['current_step'] = 1;
            // Comprueba que todos los pasos tengan un responsable definido antes de enviar.
            ApprovalFlow::assertSendable($db, $req);
            $db->prepare('UPDATE requests SET route_id = ?, current_step = 1, status = ?, submitted_at = CURRENT_TIMESTAMP, observation = NULL WHERE id = ?')
                ->execute([$req['route_id'], 'EN_APROBACION', (int)$id]);
            $db->prepare('UPDATE request_items SET qty_approved = 0, qty_proposed = 0, qty_authorized = 0 WHERE request_id = ?')
                ->execute([(int)$id]);
            $db->prepare('INSERT INTO request_history (request_id, from_state, to_state, actor_id, role_id, comments, created_at)
                VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)')
                ->execute([(int)$id, $req['status'], 'EN_APROBACION', $user['id'], $user['role_id'], 'Reenviado a jefe inmediato']);
            // Confirma los cambios después de completar las validaciones y registros.
            Database::commit();
            $this->redirect('/solicitudes/' . $id, 'Solicitud enviada a su responsable correspondiente.', 'success');
        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (\Throwable $e) {
            if ($db->inTransaction()) Database::rollBack();
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/solicitudes/' . $id, 'No se pudo enviar: ' . $e->getMessage(), 'danger');
        }
    }

    // Comprueba las condiciones para anular una solicitud y registra el cambio.
    public function anular(string $id): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requireAuth();
        $data = $this->getPostData();
        $reason = trim($data['reason'] ?? 'Anulación por el usuario');

        $reqModel = new RequestModel();
        $req = $reqModel->find((int)$id);

        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if (!$req) {
            $this->redirect('/solicitudes', 'Solicitud no encontrada.', 'danger');
        }

        // Aplica una restricción de seguridad de acuerdo con el rol o permiso del usuario.
        if ((int)$req['applicant_id'] !== (int)$user['id'] && $user['role_code'] !== 'ADMIN') {
            $this->redirect('/solicitudes', 'Solo el solicitante o administrador puede anular el pedido.', 'danger');
        }
        // Verifica el estado actual para impedir cambios fuera del flujo permitido.
        if (!in_array($req['status'], ['BORRADOR', 'OBSERVADA', 'EN_APROBACION'], true)) {
            $this->redirect("/solicitudes/{$id}", 'No se puede anular una solicitud que ya está atendida o previamente anulada.', 'warning');
        }

        $db = Database::getConnection();
        // Prepara una actualización controlada de los campos que deben modificarse.
        $upd = $db->prepare("UPDATE requests SET status = 'ANULADA', rejection_reason = ? WHERE id = ?");
        $upd->execute([$reason, (int)$id]);

        // Prepara una sentencia SQL parametrizada para ejecutar esta operación de forma segura.
        $histIns = $db->prepare("
            INSERT INTO request_history (request_id, from_state, to_state, actor_id, role_id, comments, created_at)
            VALUES (?, ?, 'ANULADA', ?, ?, ?, CURRENT_TIMESTAMP)
        ");
        $histIns->execute([(int)$id, $req['status'], $user['id'], $user['role_id'], "Anulada: {$reason}"]);

        // Guarda el evento en auditoría para identificar qué usuario realizó la acción.
        Auth::audit('solicitudes.anular', 'requests', (int)$id, ['status' => $req['status']], ['status' => 'ANULADA', 'reason' => $reason]);

        // Redirige a la pantalla correspondiente e informa el resultado de la acción.
        $this->redirect("/solicitudes/{$id}", 'La solicitud ha sido anulada.', 'info');
    }
}
