<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de el inicio de sesión y la cuenta.
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Models\User;

class AuthController extends Controller {

    // Muestra el formulario de acceso si todavía no hay una sesión activa.
    public function showLogin(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        if (Auth::check()) {
            $this->redirect('/dashboard');
        }
        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('auth/login', [
            'pageTitle' => 'Iniciar Sesión - SIGA DDE'
        ], 'none');
    }

    // Valida usuario y contraseña antes de permitir el ingreso al sistema.
    public function login(): void {
        // Recupera los valores enviados por el formulario para validarlos en el servidor.
        $data = $this->getPostData();
        $username = trim($data['username'] ?? '');
        $password = $data['password'] ?? '';

        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (empty($username) || empty($password)) {
            $this->redirect('/login', 'Debe ingresar usuario y contraseña.', 'danger');
        }

        $userModel = new User();
        $user = $userModel->findByUsername($username);

        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if (!$user) {
            $this->redirect('/login', 'Credenciales incorrectas.', 'danger');
        }

        // Validar contraseña con password_verify
        if (!password_verify($password, $user['password_hash'])) {
            // Incrementar intentos fallidos
            $userModel->query("UPDATE users SET failed_attempts = failed_attempts + 1 WHERE id = ?", [$user['id']]);
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/login', 'Credenciales incorrectas.', 'danger');
        }

        // Login exitoso: reiniciar intentos fallidos y registrar fecha
        $userModel->query("UPDATE users SET failed_attempts = 0, last_login_at = CURRENT_TIMESTAMP WHERE id = ?", [$user['id']]);

        Auth::login($user);

        // Redirige a la pantalla correspondiente e informa el resultado de la acción.
        $this->redirect('/dashboard', "Bienvenido(a) {$user['full_name']} ({$user['role_name']})", 'success');
    }

    // Finaliza la sesión y regresa a la pantalla de acceso.
    public function logout(): void {
        Auth::logout();
        // Redirige a la pantalla correspondiente e informa el resultado de la acción.
        $this->redirect('/login', 'Ha cerrado sesión exitosamente.', 'info');
    }

    // Valida y actualiza la contraseña del usuario que inició sesión.
    public function changePassword(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requireAuth();
        $data = $this->getPostData();

        $current = $data['current_password'] ?? '';
        $new = $data['new_password'] ?? '';
        $confirm = $data['confirm_password'] ?? '';

        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (empty($current) || empty($new) || empty($confirm)) {
            $this->redirect('/configuracion', 'Todos los campos de contraseña son requeridos.', 'danger');
        }

        if ($new !== $confirm) {
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/configuracion', 'La nueva contraseña y su confirmación no coinciden.', 'danger');
        }

        $userModel = new User();
        $dbUser = $userModel->find($user['id']);

        if (!password_verify($current, $dbUser['password_hash'])) {
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/configuracion', 'La contraseña actual no es correcta.', 'danger');
        }

        $newHash = password_hash($new, PASSWORD_BCRYPT);
        $userModel->update($user['id'], [
            'password_hash' => $newHash,
            'must_change_password' => 0,
            'password_changed_at' => date('Y-m-d H:i:s')
        ]);

        // Guarda el evento en auditoría para identificar qué usuario realizó la acción.
        Auth::audit('auth.change_password', 'users', $user['id']);
        $this->redirect('/configuracion', 'Contraseña actualizada correctamente.', 'success');
    }
}
