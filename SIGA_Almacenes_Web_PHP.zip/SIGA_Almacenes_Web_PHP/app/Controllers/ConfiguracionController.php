<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de la configuración del sistema.
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Core\Database;
use App\Models\Setting;

class ConfiguracionController extends Controller {

    // Consulta los datos y prepara la pantalla principal de la configuración del sistema.
    public function index(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requireAuth(); // La pantalla también permite cambiar la contraseña propia.
        $setModel = new Setting();

        $settings = [
            'institucion_nombre' => $setModel->get('institucion.nombre', 'Dirección Departamental de Educación - Cochabamba'),
            'institucion_sigla'  => $setModel->get('institucion.sigla', 'DDE-CBBA'),
            'offsetX_mm'         => $setModel->get('impresion.offsetX_mm', 0),
            'offsetY_mm'         => $setModel->get('impresion.offsetY_mm', 0),
            'escala'             => $setModel->get('impresion.escala', 100),
            'hoja'               => $setModel->get('impresion.hoja', 'carta'),
            'zona_horaria'       => $setModel->get('general.zona_horaria', 'America/La_Paz'),
            'moneda'             => $setModel->get('general.moneda', 'BOB'),
        ];

        $driver = Database::getDriver();

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('configuracion/index', [
            'pageTitle' => 'Configuración Institucional del Sistema - SIGA DDE',
            'settings' => $settings,
            'driver' => $driver,
            'user' => $user
        ]);
    }

    // Comprueba los cambios permitidos y actualiza la información de la configuración del sistema.
    public function update(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('config.editar');
        $data = $this->getPostData();

        $setModel = new Setting();
        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (isset($data['institucion_nombre'])) $setModel->set('institucion.nombre', trim($data['institucion_nombre']));
        if (isset($data['institucion_sigla'])) $setModel->set('institucion.sigla', trim($data['institucion_sigla']));
        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (isset($data['offsetX_mm'])) $setModel->set('impresion.offsetX_mm', (float)$data['offsetX_mm']);
        if (isset($data['offsetY_mm'])) $setModel->set('impresion.offsetY_mm', (float)$data['offsetY_mm']);
        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (isset($data['escala'])) $setModel->set('impresion.escala', (float)$data['escala']);
        if (isset($data['hoja'])) $setModel->set('impresion.hoja', trim($data['hoja']));

        // Guarda el evento en auditoría para identificar qué usuario realizó la acción.
        Auth::audit('config.editar', 'settings', null, null, $data);

        // Redirige a la pantalla correspondiente e informa el resultado de la acción.
        $this->redirect('/configuracion', 'Configuraciones actualizadas exitosamente.', 'success');
    }
}
