<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de los reportes.

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Category;
use App\Models\Kardex;
use App\Models\Product;

final class ReportController extends Controller
{
    // Consulta los datos y prepara la pantalla principal de los reportes.
    public function index(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('reportes.ver');
        $this->view('reports/index', [
            'title' => 'Reportes e informes',
            'categories' => Category::allOrdered(),
        ]);
    }

    // Prepara el reporte de entradas y salidas de Kardex.
    public function kardex(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('reportes.ver');
        $from = (string) $this->input('from', date('Y-01-01'));
        $to = (string) $this->input('to', date('Y-m-d'));
        $search = trim((string) $this->input('search', ''));
        $docType = (string) $this->input('docType', '');

        $rows = Kardex::report($from, $to, $search, $docType);

        if ((string) $this->input('export', '') === 'csv') {
            $headers = ['Código', 'Producto', 'Fecha', 'Tipo documento', 'Referencia', 'Entrada', 'Salida', 'Costo unitario', 'Saldo cantidad', 'Saldo valor'];
            $data = [];
            // Recorre los registros consultados para preparar el resultado.
            foreach ($rows as $row) {
                $data[] = [
                    $row['product_code'],
                    $row['product_name'],
                    fecha($row['movement_date']),
                    doc_type_label((string) $row['doc_type']),
                    $row['reference'],
                    qty($row['qty_in']),
                    qty($row['qty_out']),
                    money($row['unit_cost_in'] > 0 ? $row['unit_cost_in'] : $row['unit_cost_out'], 4),
                    qty($row['balance_qty']),
                    money($row['balance_value']),
                ];
            }
            csv_download('kardex_' . $from . '_' . $to . '.csv', $headers, $data);
        }

        $this->view('reports/kardex', [
            'title' => 'Kardex de movimientos',
            'rows' => $rows,
            'from' => $from,
            'to' => $to,
            'search' => $search,
            'docType' => $docType,
        ]);
    }

    // Prepara el reporte de existencias de almacén.
    public function inventory(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('reportes.ver');
        $search = trim((string) $this->input('search', ''));
        $category = $this->intInput('category');
        $lowStock = $this->intInput('low_stock');
        $filters = [
            'search' => $search,
            'category' => $category,
            'low_stock' => $lowStock,
            'status' => 'ACTIVO',
        ];
        $result = Product::paginate($filters, 1, 5000);
        $rows = $result['items'];

        if ((string) $this->input('export', '') === 'csv') {
            $headers = ['Código', 'Producto', 'Categoría', 'Subcategoría', 'Unidad', 'Stock', 'Costo referencia', 'Valor stock', 'Stock mínimo', 'Estado'];
            $data = [];
            // Recorre los registros consultados para preparar el resultado.
            foreach ($rows as $row) {
                $data[] = [
                    $row['code'],
                    $row['name'],
                    $row['category_name'],
                    $row['subcategory_name'],
                    $row['unit_code'],
                    qty($row['stock_qty']),
                    money($row['reference_cost'], 4),
                    money($row['stock_value']),
                    qty($row['min_stock']),
                    status_label((string) $row['status']),
                ];
            }
            csv_download('inventario_' . date('Ymd_His') . '.csv', $headers, $data);
        }

        $this->view('reports/inventory', [
            'title' => 'Reporte de inventario',
            'rows' => $rows,
            'search' => $search,
            'category' => $category,
            'lowStock' => $lowStock,
            'categories' => Category::allOrdered(),
            'totalValue' => array_sum(array_map(static fn (array $row): float => (float) $row['stock_value'], $rows)),
        ]);
    }

    // Resume movimientos de inventario por producto y periodo.
    public function kardexSummary(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('reportes.ver');
        $from = (string) $this->input('from', date('Y-01-01'));
        $to = (string) $this->input('to', date('Y-m-d'));
        $search = trim((string) $this->input('search', ''));
        $categoryId = $this->intInput('categoryId');
        $rows = Kardex::summary($from, $to, $search, $categoryId);

        if ((string) $this->input('export', '') === 'csv') {
            $headers = [
                'Código', 'Producto', 'Categoría', 'Unidad',
                'Saldo inicial cantidad', 'Saldo inicial valor',
                'Entradas cantidad', 'Entradas valor',
                'Salidas cantidad', 'Salidas valor',
                'Saldo final cantidad', 'Saldo final valor',
            ];
            $data = [];
            // Recorre los registros consultados para preparar el resultado.
            foreach ($rows as $row) {
                $data[] = [
                    $row['code'],
                    $row['name'],
                    $row['category_name'],
                    $row['unit_code'],
                    qty($row['initial_qty']),
                    money($row['initial_val']),
                    qty($row['in_qty']),
                    money($row['in_val']),
                    qty($row['out_qty']),
                    money($row['out_val']),
                    qty($row['final_qty']),
                    money($row['final_val']),
                ];
            }
            csv_download('kardex_resumen_' . $from . '_' . $to . '.csv', $headers, $data);
        }

        $this->view('reports/kardex_summary', [
            'title' => 'Resumen Kardex físico-valorado',
            'rows' => $rows,
            'from' => $from,
            'to' => $to,
            'search' => $search,
            'categoryId' => $categoryId,
            'categories' => Category::allOrdered(),
        ]);
    }
}
