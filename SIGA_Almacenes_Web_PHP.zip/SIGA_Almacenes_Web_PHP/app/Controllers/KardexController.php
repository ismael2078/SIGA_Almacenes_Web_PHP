<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de el Kardex.
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Product;
use App\Models\KardexMovement;

class KardexController extends Controller {

    // Realiza la operación «producto» relacionada con el Kardex.
    public function producto(string $id): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('inventario.ver_stock');
        $prodModel = new Product();
        $product = $prodModel->getWithDetails((int)$id);

        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if (!$product) {
            $this->redirect('/inventario', 'Producto no encontrado para consulta de Kardex.', 'danger');
        }

        $kardexModel = new KardexMovement();
        $movements = $kardexModel->getProductMovements((int)$id);

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('kardex/producto', [
            'pageTitle' => "Kardex Físico-Valorado: {$product['name']} - SIGA DDE",
            'product' => $product,
            'movements' => $movements,
        ]);
    }

    // Realiza la operación «resumen» relacionada con el Kardex.
    public function resumen(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('inventario.ver_stock');
        $kardexModel = new KardexMovement();
        $summary = $kardexModel->getSummaryList();

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('kardex/resumen', [
            'pageTitle' => 'Resumen General de Kardex - SIGA DDE',
            'summary' => $summary,
        ]);
    }
}
