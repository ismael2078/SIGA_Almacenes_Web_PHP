<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de las aprobaciones jerárquicas.
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Core\Database;
use App\Core\ApprovalFlow;
use App\Models\Request as RequestModel;
use PDO;
use RuntimeException;

class AprobacionesController extends Controller {

    // Construye la bandeja con solicitudes asignadas al responsable autenticado.
    public function index(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('aprobaciones.ver');
        $pendingRequests = ApprovalFlow::pendingFor(Database::getConnection(), $user);
        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('aprobaciones/index', [
            'pageTitle' => 'Bandeja de Aprobaciones - SIGA DDE',
            'pendingRequests' => $pendingRequests,
            'user' => $user
        ]);
    }

    // Comprueba al responsable del paso y registra la aprobación u observación.
    public function decidir(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('aprobaciones.decidir');
        $data = $this->getPostData();
        $requestId = (int)($data['request_id'] ?? 0);
        $decision = strtoupper(trim((string)($data['decision'] ?? '')));
        $comments = trim((string)($data['comments'] ?? ''));
        if ($requestId <= 0 || !in_array($decision, ['APROBAR','OBSERVAR','RECHAZAR','DEVOLVER'], true)) {
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/aprobaciones', 'Datos de decisión inválidos.', 'danger');
        }
        if ($decision !== 'APROBAR' && $comments === '') {
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/aprobaciones', 'Debe indicar el motivo de observación o rechazo.', 'danger');
        }
        $db = Database::getConnection();
        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            Database::beginTransaction();
            // Bloqueo de fila MySQL: dos funcionarios no pueden decidir el mismo paso.
            $sql = 'SELECT * FROM requests WHERE id = ?';
            // Adapta la instrucción al motor de base de datos utilizado.
            if (Database::getDriver() === 'mysql') $sql .= ' FOR UPDATE';
            $q = $db->prepare($sql);
            $q->execute([$requestId]);
            // Lee el resultado obtenido de la consulta SQL ejecutada.
            $req = $q->fetch(PDO::FETCH_ASSOC);
            if (!$req || !ApprovalFlow::canDecide($db, $req, $user)) {
                throw new RuntimeException('Esta solicitud no está asignada a usted en el paso actual. No se registró la decisión.');
            }
            $step = (int)$req['current_step'];
            $status = $req['status'];
            $newStatus = $status;
            if ($decision === 'RECHAZAR') {
                $newStatus = 'RECHAZADA';
                $db->prepare('UPDATE requests SET status = ?, rejection_reason = ?, closed_at = CURRENT_TIMESTAMP WHERE id = ?')
                    ->execute([$newStatus, $comments, $requestId]);
            } elseif ($decision === 'OBSERVAR' || $decision === 'DEVOLVER') {
                $newStatus = 'OBSERVADA';
                $db->prepare('UPDATE requests SET status = ?, observation = ? WHERE id = ?')
                    ->execute([$newStatus, $comments, $requestId]);
            } else {
                // Aprobar cantidades del paso correcto sin saltar la jerarquía.
                $field = $step === 1 ? 'qty_approved' : ($step === 2 ? 'qty_proposed' : 'qty_authorized');
                $source = $step === 1 ? 'qty_requested' : ($step === 2 ? 'qty_approved' : 'qty_proposed');
                // La interfaz actual no permite reducir cantidades; se propagan las del paso previo.
                $db->prepare("UPDATE request_items SET {$field} = {$source} WHERE request_id = ?")
                    ->execute([$requestId]);
                $next = ApprovalFlow::nextStep($db, $req);
                // Comprueba el resultado recibido y evita continuar con datos inexistentes.
                if ($next === null) {
                    $newStatus = 'APROBADA';
                    $db->prepare('UPDATE requests SET status = ?, approved_at = CURRENT_TIMESTAMP WHERE id = ?')
                        ->execute([$newStatus, $requestId]);
                } else {
                    $candidate = $req;
                    $candidate['current_step'] = $next;
                    // Identifica a una sola persona responsable del paso para evitar envíos masivos.
                    if (ApprovalFlow::assigneeId($db, $candidate) === null) {
                        throw new RuntimeException('No hay un único responsable activo para el siguiente paso. La decisión no se aplicó.');
                    }
                    $db->prepare('UPDATE requests SET current_step = ? WHERE id = ?')
                        ->execute([$next, $requestId]);
                }
            }
            $db->prepare('INSERT INTO request_approvals
                (request_id, step_order, approver_user_id, role_id, action, action_at, comments)
                VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?)')
                ->execute([$requestId, $step, $user['id'], $user['role_id'], $decision, $comments]);
            $db->prepare('INSERT INTO request_history
                (request_id, from_state, to_state, actor_id, role_id, comments, created_at)
                VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)')
                ->execute([$requestId, $status, $newStatus, $user['id'], $user['role_id'], "Paso {$step}: {$decision}. {$comments}"]);
            // Guarda el evento en auditoría para identificar qué usuario realizó la acción.
            Auth::audit('solicitudes.decidir.' . $decision, 'requests', $requestId,
                ['step' => $step], ['decision' => $decision, 'to_state' => $newStatus]);
            // Confirma los cambios después de completar las validaciones y registros.
            Database::commit();
            $this->redirect('/aprobaciones', "Decisión registrada en el paso {$step} para {$req['code']}.", 'success');
        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (\Throwable $e) {
            if ($db->inTransaction()) Database::rollBack();
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/aprobaciones', 'No se pudo registrar la decisión: ' . $e->getMessage(), 'danger');
        }
    }
}
