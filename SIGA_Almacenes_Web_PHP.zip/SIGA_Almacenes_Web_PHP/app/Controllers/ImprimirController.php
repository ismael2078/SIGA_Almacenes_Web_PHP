<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de los documentos de impresión.
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Core\ApprovalFlow;
use App\Core\Database;
use App\Models\Request as RequestModel;
use App\Models\StockDispatch;
use App\Models\Setting;

class ImprimirController extends Controller {

    // Realiza la operación «solicitud» relacionada con los documentos de impresión.
    public function solicitud(string $id): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requireAuth();
        $reqModel = new RequestModel();
        $request = $reqModel->getWithDetails((int)$id);

        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if (!$request) {
            $this->redirect('/solicitudes', 'Solicitud no encontrada para impresión.', 'danger');
        }

        // Restringe la consulta de solicitudes según el usuario y su participación.
        if (!ApprovalFlow::canView(Database::getConnection(), $request, $user)) {
            http_response_code(403);
            echo 'Acceso denegado a la impresión de esta solicitud.';
            return;
        }
        $items = $reqModel->getItems((int)$id);
        $setModel = new Setting();

        $settings = [
            'institucion_nombre' => $setModel->get('institucion.nombre', 'Dirección Departamental de Educación - Cochabamba'),
            'institucion_sigla'  => $setModel->get('institucion.sigla', 'DDE-CBBA'),
            'offsetX_mm'         => (float)$setModel->get('impresion.offsetX_mm', 0),
            'offsetY_mm'         => (float)$setModel->get('impresion.offsetY_mm', 0),
            'escala'             => (float)$setModel->get('impresion.escala', 100),
            'hoja'               => $setModel->get('impresion.hoja', 'carta'),
        ];

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('imprimir/solicitud', [
            'pageTitle' => "Imprimir Pedido de Materiales - {$request['code']}",
            'request' => $request,
            'items' => $items,
            'settings' => $settings,
        ], 'print_layout');
    }

    // Realiza la operación «salida» relacionada con los documentos de impresión.
    public function salida(string $id): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('salidas.ver');
        $dispModel = new StockDispatch();
        $dispatch = $dispModel->getWithDetails((int)$id);

        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if (!$dispatch) {
            $this->redirect('/salidas', 'Comprobante de salida no encontrado para impresión.', 'danger');
        }

        $items = $dispModel->getItems((int)$id);
        $setModel = new Setting();

        $settings = [
            'institucion_nombre' => $setModel->get('institucion.nombre', 'Dirección Departamental de Educación - Cochabamba'),
            'institucion_sigla'  => $setModel->get('institucion.sigla', 'DDE-CBBA'),
        ];

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('imprimir/salida', [
            'pageTitle' => "Comprobante de Salida - {$dispatch['number']}",
            'dispatch' => $dispatch,
            'items' => $items,
            'settings' => $settings,
        ], 'print_layout');
    }

    // Guarda la calibración de impresión en milímetros
    public function calibrar(): void {
        $this->requireAuth();
        $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
        $setModel = new Setting();
        if (isset($input['offsetX_mm'])) {
            $setModel->set('impresion.offsetX_mm', (float)$input['offsetX_mm']);
        }
        if (isset($input['offsetY_mm'])) {
            $setModel->set('impresion.offsetY_mm', (float)$input['offsetY_mm']);
        }
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'success' => true,
            'offsetX_mm' => (float)$setModel->get('impresion.offsetX_mm', 0),
            'offsetY_mm' => (float)$setModel->get('impresion.offsetY_mm', 0),
        ]);
        exit;
    }
}
