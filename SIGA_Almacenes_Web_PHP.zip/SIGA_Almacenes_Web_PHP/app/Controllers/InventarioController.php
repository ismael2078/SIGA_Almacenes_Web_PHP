<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de el inventario.
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Product;
use App\Models\Category;
use App\Models\KardexMovement;

class InventarioController extends Controller {

    // Consulta los datos y prepara la pantalla principal de el inventario.
    public function index(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('inventario.ver_stock');
        $prodModel = new Product();
        $catModel = new Category();

        $filters = [];
        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (!empty($_GET['search'])) $filters['search'] = $_GET['search'];
        if (!empty($_GET['category_id'])) $filters['category_id'] = (int)$_GET['category_id'];
        // Verifica el estado actual para impedir cambios fuera del flujo permitido.
        if (!empty($_GET['status'])) $filters['status'] = $_GET['status'];

        $products = $prodModel->getDetailedList($filters);
        $categories = $catModel->all();

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('inventario/index', [
            'pageTitle' => 'Inventario y Existencias - SIGA DDE',
            'products' => $products,
            'categories' => $categories,
            'filters' => $filters,
        ]);
    }

    // Busca el registro solicitado y presenta su información de el inventario.
    public function ver(string $id): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('inventario.ver_stock');
        $prodModel = new Product();
        $product = $prodModel->getWithDetails((int)$id);

        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if (!$product) {
            $this->redirect('/inventario', 'Producto no encontrado.', 'danger');
        }

        $layers = $prodModel->getOpenLayers((int)$id);
        $kardexModel = new KardexMovement();
        $movements = $kardexModel->getProductMovements((int)$id);

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('inventario/ver', [
            'pageTitle' => "Detalle de Producto {$product['code']} - SIGA DDE",
            'product' => $product,
            'layers' => $layers,
            'movements' => $movements,
        ]);
    }
}
