<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de los informes del almacén.
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Product;
use App\Models\Category;
use App\Services\ExternalApiService;

class ReportesController extends Controller {

    // Consulta los datos y prepara la pantalla principal de los informes del almacén.
    public function index(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('reportes.ver');
        $prodModel = new Product();
        $catModel = new Category();

        $categories = $catModel->all();
        // Lee los criterios recibidos por la URL para limitar o buscar resultados.
        $selectedCatId = !empty($_GET['category_id']) ? (int)$_GET['category_id'] : 0;

        $filters = [];
        if ($selectedCatId > 0) {
            $filters['category_id'] = $selectedCatId;
        }

        $products = $prodModel->getDetailedList($filters);

        $totalQty = 0.0;
        $totalValBob = 0.0;
        // Procesa cada producto por separado para registrar o calcular su movimiento.
        foreach ($products as $p) {
            $totalQty += (float)$p['stock_qty'];
            $totalValBob += (float)$p['stock_value'];
        }

        // Integración de API externa para cotización en USD en el reporte oficial
        $exchangeRates = ExternalApiService::getExchangeRates();
        $totalValUsd = ExternalApiService::convertBobToUsd($totalValBob);

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('reportes/index', [
            'pageTitle' => 'Reportes Contables y de Inventario - SIGA DDE',
            'products' => $products,
            'categories' => $categories,
            'selectedCatId' => $selectedCatId,
            'totalQty' => $totalQty,
            'totalValBob' => $totalValBob,
            'totalValUsd' => $totalValUsd,
            'exchangeRates' => $exchangeRates,
        ]);
    }

    // Genera un archivo CSV a partir de los resultados consultados.
    public function exportarCsv(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('reportes.exportar');
        $prodModel = new Product();
        $products = $prodModel->getDetailedList();

        // Configura la respuesta HTTP que recibirá el navegador.
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="Inventario_Oficial_SIGA_DDE_' . date('Ymd_His') . '.csv"');

        $output = fopen('php://output', 'w');
        // UTF-8 BOM para apertura perfecta en Excel
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

        fputcsv($output, [
            'ID',
            'Código SKU',
            'Nombre del Producto',
            'Categoría',
            'Subcategoría',
            'Unidad',
            'Ubicación',
            'Stock Actual',
            'Stock Mínimo',
            'Costo Referencial (BOB)',
            'Valor Total (BOB)',
            'Estado'
        ]);

        // Procesa cada producto por separado para registrar o calcular su movimiento.
        foreach ($products as $p) {
            fputcsv($output, [
                $p['id'],
                $p['code'],
                $p['name'],
                $p['category_name'] ?? '',
                $p['subcategory_name'] ?? '',
                $p['unit_code'] ?? '',
                $p['location_code'] ?? '',
                number_format((float)$p['stock_qty'], 3, '.', ''),
                number_format((float)$p['min_stock'], 3, '.', ''),
                number_format((float)$p['reference_cost'], 4, '.', ''),
                number_format((float)$p['stock_value'], 2, '.', ''),
                $p['status']
            ]);
        }

        fclose($output);
        exit;
    }
}
