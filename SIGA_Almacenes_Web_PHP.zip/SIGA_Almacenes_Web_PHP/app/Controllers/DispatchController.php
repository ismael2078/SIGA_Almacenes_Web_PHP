<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de los despachos de materiales.

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\AuditLog;
use App\Models\Dispatch;
use App\Models\Request;
use RuntimeException;

final class DispatchController extends Controller
{
    // Consulta los datos y prepara la pantalla principal de los despachos de materiales.
    public function index(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('salidas.ver');
        $search = trim((string) $this->input('search', ''));
        $status = (string) $this->input('status', '');

        $this->view('exits/index', [
            'title' => 'Salidas y despachos',
            'dispatches' => Dispatch::paginate($search, $status),
            'search' => $search,
            'status' => $status,
        ]);
    }

    // Carga los datos necesarios para registrar información de los despachos de materiales.
    public function create(?string $requestId = null): void
    {
        $this->requireAnyPermission(['salidas.preparar', 'salidas.confirmar']);

        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($requestId === null || $requestId === '') {
            $this->view('exits/select_request', [
                'title' => 'Nueva salida',
                'requests' => Request::approvedForDispatch(),
            ]);
            return;
        }

        $request = Request::findDetailed((int) $requestId);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($request === null) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Solicitud no encontrada']);
            return;
        }
        // Verifica el estado actual para impedir cambios fuera del flujo permitido.
        if ($request['status'] !== 'APROBADA') {
            Session::flash('warning', 'La solicitud debe estar aprobada para preparar un despacho.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/salidas/nueva');
        }

        $this->view('exits/create', [
            'title' => 'Despachar solicitud ' . $request['code'],
            'request' => $request,
            'items' => Dispatch::pendingItems((int) $requestId),
        ]);
    }

    // Valida los datos recibidos y registra la operación de los despachos de materiales.
    public function store(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('salidas.confirmar');
        $requestId = $this->intInput('request_id');
        $receivedBy = trim((string) $this->input('received_by', ''));
        $receivedCi = trim((string) $this->input('received_ci', ''));
        $notes = trim((string) $this->input('notes', ''));

        // Recupera los valores enviados por el formulario para validarlos en el servidor.
        $itemIds = $_POST['request_item_id'] ?? [];
        $quantities = $_POST['qty'] ?? [];
        $items = [];
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ((array) $itemIds as $index => $itemId) {
            $qty = (float) str_replace(',', '.', (string) ($quantities[$index] ?? 0));
            // Controla los valores de cantidad o costo antes de continuar con el inventario.
            if ((int) $itemId > 0 && $qty > 0) {
                $items[] = ['request_item_id' => (int) $itemId, 'qty' => $qty];
            }
        }

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            $dispatch = Dispatch::createFromRequest($requestId, $user, $items, $receivedBy, $receivedCi, $notes);
            AuditLog::record((int) $user['id'], 'DESPACHO_CONFIRMADO', 'stock_dispatches', (int) $dispatch['id'], null, $dispatch);
            Session::flash('success', 'Despacho ' . $dispatch['number'] . ' confirmado con valuación PEPS.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/salidas/' . (int) $dispatch['id']);
        } catch (RuntimeException $exception) {
            Session::flash('danger', $exception->getMessage());
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/salidas/nueva/' . $requestId);
        }
    }

    // Recupera y muestra el detalle de un registro de los despachos de materiales.
    public function show(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('salidas.ver');
        $dispatch = Dispatch::findDetailed((int) $id);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($dispatch === null) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Despacho no encontrado']);
            return;
        }
        $consumptions = Dispatch::query(
            'SELECT lc.*, sl.layer_date, sl.unit_cost AS layer_unit_cost,
                    di.product_id, p.code AS product_code, p.name AS product_name
             FROM layer_consumptions lc
             INNER JOIN stock_layers sl ON sl.id = lc.layer_id
             INNER JOIN dispatch_items di ON di.id = lc.dispatch_item_id
             INNER JOIN products p ON p.id = di.product_id
             WHERE di.dispatch_id = ?
             ORDER BY lc.id ASC',
            [(int) $id]
        )->fetchAll();

        $this->view('exits/show', [
            'title' => 'Despacho ' . $dispatch['number'],
            'dispatch' => $dispatch,
            'items' => Dispatch::items((int) $id),
            'consumptions' => $consumptions,
        ]);
    }

    // Verifica las condiciones antes de anular un registro de los despachos de materiales.
    public function cancel(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('salidas.anular');
        $reason = trim((string) $this->input('reason', ''));
        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            Dispatch::void((int) $id, $user, $reason);
            AuditLog::record((int) $user['id'], 'DESPACHO_ANULADO', 'stock_dispatches', (int) $id, null, ['reason' => $reason]);
            Session::flash('success', 'Despacho anulado. Las capas PEPS fueron restituidas.');
        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (RuntimeException $exception) {
            Session::flash('danger', $exception->getMessage());
        }
        // Redirige a la pantalla correspondiente e informa el resultado de la acción.
        $this->redirect('/salidas/' . (int) $id);
    }
}
