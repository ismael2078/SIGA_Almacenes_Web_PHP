<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de la administración de usuarios y parámetros.

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\Area;
use App\Models\AuditLog;
use App\Models\Role;
use App\Models\Setting;
use App\Models\User;

final class AdminController extends Controller
{
    // Obtiene la lista de usuarios para su administración.
    public function users(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('usuarios.ver');
        $this->view('admin/users', [
            'title' => 'Gestión de usuarios',
            'users' => User::withRelations(),
            'roles' => Role::allOrdered(),
            'areas' => Area::allOrdered(),
            'canManage' => can('usuarios.gestionar'),
        ]);
    }

    // Registra un usuario con sus datos y rol.
    public function storeUser(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('usuarios.gestionar');
        $username = strtolower(trim((string) $this->input('username', '')));
        $fullName = trim((string) $this->input('full_name', ''));
        $password = (string) $this->input('password', '');
        $roleId = $this->intInput('role_id');

        // Distingue las acciones permitidas según el cargo o rol asignado.
        if ($username === '' || $fullName === '' || strlen($password) < 8 || $roleId <= 0) {
            Session::flash('danger', 'Usuario, nombre completo, rol y contraseña de al menos 8 caracteres son obligatorios.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/admin/usuarios');
        }

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            $id = User::createUser([
                'username' => $username,
                'full_name' => $fullName,
                'email' => trim((string) $this->input('email', '')) ?: null,
                'ci' => trim((string) $this->input('ci', '')) ?: null,
                'position' => trim((string) $this->input('position', '')) ?: null,
                'office' => trim((string) $this->input('office', '')) ?: null,
                'area_id' => $this->intInput('area_id') ?: null,
                'jefe_inmediato_id' => $this->intInput('jefe_inmediato_id') ?: null,
                'role_id' => $roleId,
                'is_active' => 1,
                'must_change_password' => $this->intInput('must_change_password') ? 1 : 0,
            ], $password);
            AuditLog::record((int) $user['id'], 'USUARIO_CREADO', 'users', $id, null, ['username' => $username, 'role_id' => $roleId]);
            Session::flash('success', 'Usuario creado correctamente.');
        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (\PDOException $exception) {
            Session::flash('danger', 'No se pudo crear el usuario. Verifique que el nombre de usuario no esté duplicado.');
        }

        // Redirige a la pantalla correspondiente e informa el resultado de la acción.
        $this->redirect('/admin/usuarios');
    }

    // Actualiza los datos de la cuenta de un usuario.
    public function updateUser(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('usuarios.gestionar');
        $target = User::find((int) $id);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($target === null) {
            Session::flash('danger', 'Usuario no encontrado.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/admin/usuarios');
        }

        $password = (string) $this->input('password', '');
        $data = [
            'username' => strtolower(trim((string) $this->input('username', ''))),
            'full_name' => trim((string) $this->input('full_name', '')),
            'email' => trim((string) $this->input('email', '')) ?: null,
            'ci' => trim((string) $this->input('ci', '')) ?: null,
            'position' => trim((string) $this->input('position', '')) ?: null,
            'office' => trim((string) $this->input('office', '')) ?: null,
            'area_id' => $this->intInput('area_id') ?: null,
            'jefe_inmediato_id' => $this->intInput('jefe_inmediato_id') ?: null,
            'role_id' => $this->intInput('role_id'),
        ];

        // Aplica una restricción de seguridad de acuerdo con el rol o permiso del usuario.
        if ($data['username'] === '' || $data['full_name'] === '' || $data['role_id'] <= 0) {
            Session::flash('danger', 'Usuario, nombre completo y rol son obligatorios.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/admin/usuarios');
        }
        if ($password !== '' && strlen($password) < 8) {
            Session::flash('danger', 'La nueva contraseña debe tener al menos 8 caracteres.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/admin/usuarios');
        }

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            User::updateUser((int) $id, $data, $password !== '' ? $password : null);
            AuditLog::record((int) $user['id'], 'USUARIO_EDITADO', 'users', (int) $id, $target, $data);
            Session::flash('success', 'Usuario actualizado correctamente.');
        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (\PDOException $exception) {
            Session::flash('danger', 'No se pudo actualizar el usuario. Verifique los datos.');
        }

        // Redirige a la pantalla correspondiente e informa el resultado de la acción.
        $this->redirect('/admin/usuarios');
    }

    // Activa o desactiva una cuenta de usuario según la operación.
    public function toggleUser(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('usuarios.gestionar');
        if ((int) $id === (int) $user['id']) {
            Session::flash('warning', 'No puede desactivar su propio usuario.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/admin/usuarios');
        }
        $target = User::find((int) $id);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($target === null) {
            Session::flash('danger', 'Usuario no encontrado.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/admin/usuarios');
        }
        $newState = (int) $target['is_active'] === 1 ? 0 : 1;
        User::update((int) $id, ['is_active' => $newState]);
        AuditLog::record((int) $user['id'], $newState === 1 ? 'USUARIO_ACTIVADO' : 'USUARIO_DESACTIVADO', 'users', (int) $id, $target, ['is_active' => $newState]);
        Session::flash('success', $newState === 1 ? 'Usuario activado.' : 'Usuario desactivado.');
        // Redirige a la pantalla correspondiente e informa el resultado de la acción.
        $this->redirect('/admin/usuarios');
    }

    // Consulta los eventos registrados en el historial de auditoría.
    public function audit(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('auditoria.ver');
        $action = (string) $this->input('action', '');
        $search = trim((string) $this->input('search', ''));

        $this->view('admin/audit', [
            'title' => 'Auditoría del sistema',
            'logs' => AuditLog::recent(500, $action, $search),
            'actions' => AuditLog::actions(),
            'action' => $action,
            'search' => $search,
        ]);
    }

    // Muestra los parámetros de configuración disponibles.
    public function settings(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('config.ver');
        $this->view('admin/settings', [
            'title' => 'Configuración del sistema',
            'settings' => Setting::allKeyed(),
            'canEdit' => can('config.editar'),
        ]);
    }

    // Actualiza los parámetros de configuración administrables.
    public function saveSettings(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('config.editar');
        $keys = [
            'institucion.nombre',
            'institucion.sigla',
            'general.moneda',
            'general.zona_horaria',
            'impresion.hoja',
            'impresion.offsetX_mm',
            'impresion.offsetY_mm',
            'impresion.escala',
            'alertas.stock_bajo',
            'seguridad.sesion_horas',
        ];
        $before = Setting::allKeyed();
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($keys as $key) {
            if (array_key_exists($key, $_POST)) {
                // Recupera los valores enviados por el formulario para validarlos en el servidor.
                $value = $_POST[$key];
                if (is_numeric($value)) {
                    $value = $value + 0;
                }
                Setting::set($key, $value);
            }
        }
        AuditLog::record((int) $user['id'], 'CONFIGURACION_EDITADA', 'settings', null, $before, Setting::allKeyed());
        Session::flash('success', 'Configuración guardada correctamente.');
        // Redirige a la pantalla correspondiente e informa el resultado de la acción.
        $this->redirect('/admin/configuracion');
    }
}
