<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de el tablero principal.
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\ApprovalFlow;
use App\Models\Product;
use App\Models\Request;
use App\Services\ExternalApiService;
use PDO;

class DashboardController extends Controller {

    // Consulta los datos y prepara la pantalla principal de el tablero principal.
    public function index(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requireAuth();
        $db = Database::getConnection();

        // 1. Estadísticas de inventario
        $stmt = $db->query("
            SELECT 
                COUNT(*) AS total_products,
                COALESCE(SUM(stock_qty), 0) AS total_qty,
                COALESCE(SUM(stock_value), 0) AS total_value,
                SUM(CASE WHEN stock_qty <= min_stock THEN 1 ELSE 0 END) AS low_stock_count
            FROM products
            WHERE is_active = 1
        ");
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $invStats = $stmt->fetch(PDO::FETCH_ASSOC);

        // 2. Estadísticas de solicitudes
        $stmt = $db->query("
            SELECT 
                COUNT(*) AS total_requests,
                SUM(CASE WHEN status = 'EN_APROBACION' THEN 1 ELSE 0 END) AS pending_approvals,
                SUM(CASE WHEN status = 'APROBADA' THEN 1 ELSE 0 END) AS approved_pending_dispatch,
                SUM(CASE WHEN status = 'ATENDIDA' THEN 1 ELSE 0 END) AS attended_requests
            FROM requests
        ");
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $reqStats = $stmt->fetch(PDO::FETCH_ASSOC);

        // 3. Alertas de stock crítico
        $stmt = $db->query("
            SELECT p.id, p.code, p.name, p.stock_qty, p.min_stock, p.reference_cost, u.name AS unit_name
            FROM products p
            LEFT JOIN units u ON u.id = p.unit_id
            WHERE p.stock_qty <= p.min_stock AND p.is_active = 1
            ORDER BY (p.stock_qty - p.min_stock) ASC
            LIMIT 6
        ");
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $lowStockProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // 4. Últimas solicitudes
        $reqModel = new Request();
        $recentRequests = array_values(array_filter(
            $reqModel->getDetailedList([]),
            // Restringe la consulta de solicitudes según el usuario y su participación.
            static fn(array $r): bool => ApprovalFlow::canView($db, $r, $user)
        ));
        // Si el usuario es Solicitante, sus estadísticas de pendientes corresponden a SUS solicitudes
        if (($user['role_code'] ?? '') === 'SOLICITANTE') {
            $stmt = $db->prepare("
                SELECT 
                    COUNT(*) AS total_requests,
                    COALESCE(SUM(CASE WHEN status = 'EN_APROBACION' THEN 1 ELSE 0 END), 0) AS pending_approvals,
                    COALESCE(SUM(CASE WHEN status = 'APROBADA' THEN 1 ELSE 0 END), 0) AS approved_pending_dispatch,
                    COALESCE(SUM(CASE WHEN status = 'ATENDIDA' THEN 1 ELSE 0 END), 0) AS attended_requests
                FROM requests
                WHERE applicant_id = :uid
            ");
            $stmt->execute([':uid' => $user['id']]);
            $myStats = $stmt->fetch(PDO::FETCH_ASSOC);
            $reqStats['pending_approvals'] = (int)($myStats['pending_approvals'] ?? 0);
            $reqStats['approved_pending_dispatch'] = (int)($myStats['approved_pending_dispatch'] ?? 0);
        } else {
            // Para jefaturas y almacén: muestra las solicitudes pendientes por su firma
            $myPending = count(ApprovalFlow::pendingFor($db, $user));
            $reqStats['pending_approvals'] = $myPending > 0 ? $myPending : (int)($reqStats['pending_approvals'] ?? 0);
        }

        // 5. Integración API Externa: Tipo de cambio en vivo
        $exchangeRates = ExternalApiService::getExchangeRates();
        $totalValueUsd = ExternalApiService::convertBobToUsd((float)$invStats['total_value']);

        // 6. Distribución de valor por categoría para el gráfico
        $stmt = $db->query("
            SELECT c.name, COALESCE(SUM(p.stock_value), 0) AS total_val
            FROM categories c
            LEFT JOIN products p ON p.category_id = c.id
            GROUP BY c.id, c.name
            ORDER BY total_val DESC
        ");
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $categoryChartData = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('dashboard/index', [
            'pageTitle' => 'Panel de Control - SIGA DDE',
            'invStats' => $invStats,
            'reqStats' => $reqStats,
            'lowStockProducts' => $lowStockProducts,
            'recentRequests' => array_slice($recentRequests, 0, 6),
            'exchangeRates' => $exchangeRates,
            'totalValueUsd' => $totalValueUsd,
            'categoryChartData' => $categoryChartData,
        ]);
    }
}
