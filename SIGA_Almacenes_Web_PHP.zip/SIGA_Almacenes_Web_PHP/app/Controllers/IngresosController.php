<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de los ingresos de almacén.
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Core\Database;
use App\Core\PepsEngine;
use App\Models\StockEntry;
use App\Models\Product;
use App\Models\Supplier;
use App\Models\Location;
use PDO;

class IngresosController extends Controller {

    // Muestra los ingresos disponibles para el usuario autorizado.
    public function index(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('ingresos.ver');
        $entryModel = new StockEntry();
        $entries = $entryModel->getDetailedList();

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('ingresos/index', [
            'pageTitle' => 'Comprobantes de Ingreso - SIGA DDE',
            'entries' => $entries
        ]);
    }

    // Prepara los datos del formulario para un nuevo ingreso.
    public function nuevo(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('ingresos.ver');
        $this->requireEntryWriteRole();
        $suppModel = new Supplier();
        $suppliers = $suppModel->all();

        $prodModel = new Product();
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $products = $prodModel->fetchAll("
            SELECT p.id, p.code, p.name, p.reference_cost, u.name AS unit_name
            FROM products p
            LEFT JOIN units u ON u.id = p.unit_id
            WHERE p.is_active = 1
            ORDER BY p.name ASC
        ");

        $locModel = new Location();
        $locations = $locModel->all();

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('ingresos/nuevo', [
            'pageTitle' => 'Registrar Ingreso de Almacén - SIGA DDE',
            'suppliers' => $suppliers,
            'products' => $products,
            'locations' => $locations
        ]);
    }

    // Valida y registra el ingreso con sus productos y valores.
    public function store(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('ingresos.ver');
        $this->requireEntryWriteRole();
        // Recupera los valores enviados por el formulario para validarlos en el servidor.
        $data = $this->getPostData();

        $type = $data['type'] ?? 'COMPRA';
        $supplierId = !empty($data['supplier_id']) ? (int)$data['supplier_id'] : null;
        $docType = $data['doc_type'] ?? 'FACTURA';
        $docNumber = trim($data['doc_number'] ?? '');
        $docDate = !empty($data['doc_date']) ? $data['doc_date'] : date('Y-m-d');
        $entryDate = !empty($data['entry_date']) ? $data['entry_date'] : date('Y-m-d H:i:s');
        $notes = trim($data['notes'] ?? '');
        $items = $data['items'] ?? [];

        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (empty($items) || !is_array($items)) {
            $this->redirect('/ingresos/nuevo', 'Debe agregar al menos un ítem al comprobante de ingreso.', 'danger');
        }

        // Excluir filas vacías y rechazar cantidades o costos inválidos antes de registrar.
        $validItems = [];
        foreach ($items as $it) {
            if (!is_array($it)) continue;
            $productId = (int)($it['product_id'] ?? 0);
            $quantity = (float)($it['quantity'] ?? 0);
            $unitCost = (float)($it['unit_cost'] ?? -1);
            if ($productId <= 0 && $quantity <= 0) continue; // fila sin completar
            if ($productId <= 0 || $quantity <= 0 || !is_finite($quantity) ||
                $unitCost < 0 || !is_finite($unitCost)) {
                $this->redirect('/ingresos/nuevo', 'Revise los productos, cantidades y costos del ingreso.', 'danger');
            }
            $validItems[] = $it;
        }
        if (!$validItems) {
            $this->redirect('/ingresos/nuevo', 'Debe registrar al menos un producto válido.', 'danger');
        }
        $items = $validItems;

        $db = Database::getConnection();

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            Database::beginTransaction();

            // Solicita el código correlativo del documento para mantener su identificación.
            $number = PepsEngine::nextSequence('ING', (int)date('Y'));
            $totalAmount = 0.0;

            // Procesa cada producto por separado para registrar o calcular su movimiento.
            foreach ($items as $it) {
                $qty = (float)($it['quantity'] ?? 0);
                $cost = (float)($it['unit_cost'] ?? 0);
                $totalAmount += ($qty * $cost);
            }

            // Crear stock_entries
            $ins = $db->prepare("
                INSERT INTO stock_entries (
                    number, type, supplier_id, doc_type, doc_number, doc_date,
                    entry_date, posted_at, total_amount, notes, status, created_by, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?, ?, 'CONFIRMADO', ?, CURRENT_TIMESTAMP)
            ");
            $ins->execute([
                $number,
                $type,
                $supplierId,
                $docType,
                $docNumber,
                $docDate,
                $entryDate,
                $totalAmount,
                $notes,
                $user['id']
            ]);
            $entryId = (int)$db->lastInsertId();

            // Insertar items, capas PEPS y kardex
            $itemIns = $db->prepare("
                INSERT INTO stock_entry_items (entry_id, product_id, location_id, quantity, unit_cost, total, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");

            // Prepara una sentencia SQL parametrizada para ejecutar esta operación de forma segura.
            $layerIns = $db->prepare("
                INSERT INTO stock_layers (product_id, entry_id, entry_item_id, layer_date, sequence, original_qty, remaining_qty, unit_cost, status)
                VALUES (?, ?, ?, ?, 1, ?, ?, ?, 'ABIERTA')
            ");

            // Procesa cada producto por separado para registrar o calcular su movimiento.
            foreach ($items as $it) {
                $pId = (int)($it['product_id'] ?? 0);
                $locId = !empty($it['location_id']) ? (int)$it['location_id'] : null;
                $qty = (float)($it['quantity'] ?? 0);
                $cost = (float)($it['unit_cost'] ?? 0);
                $itNotes = trim($it['notes'] ?? '');

                // Controla los valores de cantidad o costo antes de continuar con el inventario.
                if ($pId <= 0 || $qty <= 0) continue;

                $itemTotal = round($qty * $cost, 2);

                $itemIns->execute([$entryId, $pId, $locId, $qty, $cost, $itemTotal, $itNotes]);
                $entryItemId = (int)$db->lastInsertId();

                // Capa PEPS
                $layerIns->execute([$pId, $entryId, $entryItemId, $entryDate, $qty, $qty, $cost]);

                // Recalcular stock producto
                PepsEngine::recomputeProductStock($pId);

                // Actualizar costo de referencia
                $db->prepare("UPDATE products SET reference_cost = ? WHERE id = ?")->execute([$cost, $pId]);

                // Registrar en Kardex
                PepsEngine::recordKardex(
                    $pId,
                    $entryDate,
                    'INGRESO',
                    $entryId,
                    $number,
                    $qty,
                    0.0,
                    $cost,
                    0.0,
                    $user['id']
                );
            }

            // Guarda el evento en auditoría para identificar qué usuario realizó la acción.
            Auth::audit('ingresos.crear', 'stock_entries', $entryId, null, ['number' => $number, 'total_amount' => $totalAmount]);

            // Confirma los cambios después de completar las validaciones y registros.
            Database::commit();

            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect("/ingresos/{$entryId}", "Comprobante de ingreso {$number} registrado exitosamente.", 'success');

        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (\Throwable $e) {
            if ($db->inTransaction()) Database::rollBack();
            $this->redirect('/ingresos/nuevo', 'Error al registrar el ingreso: ' . $e->getMessage(), 'danger');
        }
    }

    // Muestra el detalle de un ingreso registrado.
    public function ver(string $id): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('ingresos.ver');
        $entryModel = new StockEntry();
        $entry = $entryModel->find((int)$id);

        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if (!$entry) {
            $this->redirect('/ingresos', 'Comprobante de ingreso no encontrado.', 'danger');
        }

        // Cargar datos adicionales
        $db = Database::getConnection();
        // Prepara una sentencia SQL parametrizada para ejecutar esta operación de forma segura.
        $stmt = $db->prepare("
            SELECT e.*, s.name AS supplier_name, s.nit AS supplier_nit, s.phone AS supplier_phone,
                   u.full_name AS creator_name
            FROM stock_entries e
            LEFT JOIN suppliers s ON s.id = e.supplier_id
            LEFT JOIN users u ON u.id = e.created_by
            WHERE e.id = ?
        ");
        $stmt->execute([(int)$id]);
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $entry = $stmt->fetch(PDO::FETCH_ASSOC);

        $items = $entryModel->getItems((int)$id);

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('ingresos/ver', [
            'pageTitle' => "Ingreso {$entry['number']} - SIGA DDE",
            'entry' => $entry,
            'items' => $items
        ]);
    }
    /** El permiso de lectura también pertenece al auditor; no autoriza ingresos. */
    private function requireEntryWriteRole(): void {
        $role = Auth::user()['role_code'] ?? '';
        // Distingue las acciones permitidas según el cargo o rol asignado.
        if (!in_array($role, ['ADMIN', 'TECNICO_ALMACEN'], true)) {
            $this->redirect('/ingresos', 'Su rol puede consultar ingresos, pero no registrar nuevos.', 'danger');
        }
    }

}
