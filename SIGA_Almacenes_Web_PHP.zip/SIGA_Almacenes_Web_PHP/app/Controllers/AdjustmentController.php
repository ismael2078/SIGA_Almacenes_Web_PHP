<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de los ajustes de inventario.

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Session;
use App\Models\Adjustment;
use App\Models\AuditLog;
use App\Models\Product;
use RuntimeException;

final class AdjustmentController extends Controller
{
    // Consulta los datos y prepara la pantalla principal de los ajustes de inventario.
    public function index(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('ajustes.ver');
        $status = (string) $this->input('status', '');
        $search = trim((string) $this->input('search', ''));

        $this->view('adjustments/index', [
            'title' => 'Ajustes de inventario',
            'adjustments' => Adjustment::paginate($status, $search),
            'status' => $status,
            'search' => $search,
            'canCreate' => can('ajustes.crear'),
        ]);
    }

    // Carga los datos necesarios para registrar información de los ajustes de inventario.
    public function create(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('ajustes.crear');
        $this->view('adjustments/create', [
            'title' => 'Nuevo ajuste',
            'products' => Product::allForSelect(),
        ]);
    }

    // Valida los datos recibidos y registra la operación de los ajustes de inventario.
    public function store(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('ajustes.crear');
        $type = (string) $this->input('type', 'FALTANTE');
        $reason = trim((string) $this->input('reason', ''));
        $actNumber = trim((string) $this->input('act_number', ''));

        // Recupera los valores enviados por el formulario para validarlos en el servidor.
        $productIds = $_POST['product_id'] ?? [];
        $quantities = $_POST['qty'] ?? [];
        // Recupera los valores enviados por el formulario para validarlos en el servidor.
        $unitCosts = $_POST['unit_cost'] ?? [];
        $notes = $_POST['item_notes'] ?? [];
        $items = [];
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ((array) $productIds as $index => $productId) {
            $pid = (int) $productId;
            $qty = (float) str_replace(',', '.', (string) ($quantities[$index] ?? 0));
            // Controla los valores de cantidad o costo antes de continuar con el inventario.
            if ($pid <= 0 || $qty <= 0) {
                continue;
            }
            $items[] = [
                'product_id' => $pid,
                'qty' => $qty,
                'unit_cost' => (float) str_replace(',', '.', (string) ($unitCosts[$index] ?? 0)),
                'notes' => trim((string) ($notes[$index] ?? '')) ?: null,
            ];
        }

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            $adjustment = Adjustment::create((int) $user['id'], $type, $reason, $actNumber, $items);
            AuditLog::record((int) $user['id'], 'AJUSTE_CREADO', 'adjustments', (int) $adjustment['id'], null, $adjustment);
            Session::flash('success', 'Ajuste ' . $adjustment['number'] . ' registrado. Requiere las tres firmas para completar su aprobación.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/ajustes/' . (int) $adjustment['id']);
        } catch (RuntimeException $exception) {
            Session::flash('danger', $exception->getMessage());
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/ajustes/nuevo');
        }
    }

    // Recupera y muestra el detalle de un registro de los ajustes de inventario.
    public function show(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('ajustes.ver');
        $adjustment = Adjustment::findDetailed((int) $id);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($adjustment === null) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Ajuste no encontrado']);
            return;
        }
        $this->view('adjustments/show', [
            'title' => 'Ajuste ' . $adjustment['number'],
            'adjustment' => $adjustment,
            'items' => Adjustment::items((int) $id),
        ]);
    }

    // Registra una autorización tras validar los permisos correspondientes.
    public function approve(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('ajustes.aprobar');
        $signature = (string) $this->input('signature', '');
        $signaturePermissions = [
            'ALMACENES' => 'ajustes.aprobar_almacenes',
            'CONTRATACIONES' => 'ajustes.aprobar_contrataciones',
            'JEFATURA' => 'ajustes.aprobar_jefatura',
        ];

        // Aplica una restricción de seguridad de acuerdo con el rol o permiso del usuario.
        if (!isset($signaturePermissions[$signature]) || !Auth::can($signaturePermissions[$signature])) {
            Session::flash('danger', 'No está autorizado para firmar como ' . ($signature !== '' ? $signature : 'esa instancia') . '.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/ajustes/' . (int) $id);
        }

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            Adjustment::approve((int) $id, $user, $signature);
            AuditLog::record((int) $user['id'], 'AJUSTE_FIRMADO', 'adjustments', (int) $id, null, ['signature' => $signature]);
            Session::flash('success', 'Firma registrada correctamente.');
        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (RuntimeException $exception) {
            Session::flash('danger', $exception->getMessage());
        }
        // Redirige a la pantalla correspondiente e informa el resultado de la acción.
        $this->redirect('/ajustes/' . (int) $id);
    }
}
