<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de los catálogos del almacén.
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Category;
use App\Models\Subcategory;
use App\Models\Unit;
use App\Models\Location;
use App\Models\Supplier;
use App\Models\Area;

class CatalogosController extends Controller {

    // Consulta los datos y prepara la pantalla principal de los catálogos del almacén.
    public function index(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('catalogos.ver');

        $catModel = new Category();
        $categories = $catModel->all();

        $subModel = new Subcategory();
        $subcategories = $subModel->getDetailedList();

        $unitModel = new Unit();
        $units = $unitModel->all();

        $locModel = new Location();
        $locations = $locModel->all();

        $suppModel = new Supplier();
        $suppliers = $suppModel->all();

        $areaModel = new Area();
        $areas = $areaModel->getDetailedList();

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('catalogos/index', [
            'pageTitle' => 'Catálogos Generales del Sistema - SIGA DDE',
            'categories' => $categories,
            'subcategories' => $subcategories,
            'units' => $units,
            'locations' => $locations,
            'suppliers' => $suppliers,
            'areas' => $areas,
        ]);
    }
}
