<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de los ajustes de existencias.
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Core\Database;
use App\Core\PepsEngine;
use App\Models\Adjustment;
use App\Models\Product;
use PDO;

class AjustesController extends Controller {

    // Consulta los datos y prepara la pantalla principal de los ajustes de existencias.
    public function index(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('ajustes.ver');
        $adjModel = new Adjustment();
        $adjustments = $adjModel->getDetailedList();

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('ajustes/index', [
            'pageTitle' => 'Ajustes de Inventario - SIGA DDE',
            'adjustments' => $adjustments,
        ]);
    }

    // Prepara el formulario de registro de los ajustes de existencias.
    public function nuevo(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('ajustes.crear');
        $prodModel = new Product();
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $products = $prodModel->fetchAll("
            SELECT p.id, p.code, p.name, p.stock_qty, p.reference_cost, u.name AS unit_name
            FROM products p
            LEFT JOIN units u ON u.id = p.unit_id
            WHERE p.is_active = 1
            ORDER BY p.name ASC
        ");

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('ajustes/nuevo', [
            'pageTitle' => 'Registrar Ajuste Físico de Inventario - SIGA DDE',
            'products' => $products,
        ]);
    }

    // Valida los datos recibidos y registra la operación de los ajustes de existencias.
    public function store(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('ajustes.crear');
        $data = $this->getPostData();

        $type = $data['type'] ?? 'FALTANTE';
        $reason = trim($data['reason'] ?? '');
        $actNumber = trim($data['act_number'] ?? '');
        $adjustmentDate = !empty($data['adjustment_date']) ? $data['adjustment_date'] : date('Y-m-d H:i:s');
        $items = $data['items'] ?? [];

        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (empty($reason) || empty($actNumber)) {
            $this->redirect('/ajustes/nuevo', 'El motivo y número de acta son obligatorios.', 'danger');
        }

        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (empty($items) || !is_array($items)) {
            $this->redirect('/ajustes/nuevo', 'Debe incluir al menos un producto a ajustar.', 'danger');
        }

        $db = Database::getConnection();

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            Database::beginTransaction();

            // Solicita el código correlativo del documento para mantener su identificación.
            $number = PepsEngine::nextSequence('AJ', (int)date('Y'));

            // Prepara una sentencia SQL parametrizada para ejecutar esta operación de forma segura.
            $ins = $db->prepare("
                INSERT INTO adjustments (number, type, reason, act_number, adjustment_date, status, created_by, created_at)
                VALUES (?, ?, ?, ?, ?, 'EN_REVISION', ?, CURRENT_TIMESTAMP)
            ");
            $ins->execute([$number, $type, $reason, $actNumber, $adjustmentDate, $user['id']]);
            $adjId = (int)$db->lastInsertId();

            // Prepara una sentencia SQL parametrizada para ejecutar esta operación de forma segura.
            $itemIns = $db->prepare("
                INSERT INTO adjustment_items (adjustment_id, product_id, qty, unit_cost, total_value, notes)
                VALUES (?, ?, ?, ?, ?, ?)
            ");

            // Procesa cada producto por separado para registrar o calcular su movimiento.
            foreach ($items as $it) {
                $pId = (int)($it['product_id'] ?? 0);
                $qty = (float)($it['qty'] ?? 0);
                $cost = (float)($it['unit_cost'] ?? 0);
                $notes = trim($it['notes'] ?? '');

                // Controla los valores de cantidad o costo antes de continuar con el inventario.
                if ($pId <= 0 || $qty <= 0) continue;

                $tot = round($qty * $cost, 2);
                $itemIns->execute([$adjId, $pId, $qty, $cost, $tot, $notes]);
            }

            // Guarda el evento en auditoría para identificar qué usuario realizó la acción.
            Auth::audit('ajustes.crear', 'adjustments', $adjId, null, ['number' => $number, 'type' => $type]);

            // Confirma los cambios después de completar las validaciones y registros.
            Database::commit();

            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/ajustes', "Ajuste {$number} creado y enviado a revisión tripartita.", 'success');

        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (\Throwable $e) {
            Database::rollBack();
            $this->redirect('/ajustes/nuevo', 'Error al registrar el ajuste: ' . $e->getMessage(), 'danger');
        }
    }

    // Registra una aprobación si se cumplen las condiciones del proceso.
    public function aprobar(string $id): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('ajustes.aprobar');
        $adjModel = new Adjustment();
        $adj = $adjModel->find((int)$id);

        // Verifica el estado actual para impedir cambios fuera del flujo permitido.
        if (!$adj || $adj['status'] !== 'EN_REVISION') {
            $this->redirect('/ajustes', 'El ajuste no se encuentra en estado de revisión.', 'warning');
        }

        $db = Database::getConnection();

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            Database::beginTransaction();

            // Firma según rol del usuario
            $roleCode = $user['role_code'];
            $now = date('Y-m-d H:i:s');

            // Distingue las acciones permitidas según el cargo o rol asignado.
            if ($roleCode === 'TECNICO_ALMACEN') {
                $db->prepare("UPDATE adjustments SET approved_almacenes_by = ?, approved_almacenes_at = ? WHERE id = ?")
                   ->execute([$user['id'], $now, (int)$id]);
            } elseif ($roleCode === 'ADMIN') {
                $db->prepare("UPDATE adjustments SET approved_admin_by = ?, approved_admin_at = ?, approved_almacenes_by = COALESCE(approved_almacenes_by, ?), approved_almacenes_at = COALESCE(approved_almacenes_at, ?) WHERE id = ?")
                   ->execute([$user['id'], $now, $user['id'], $now, (int)$id]);
            }

            // Si está firmado por admin o almacén, aplicar efecto contable
            $adjItems = $adjModel->getItems((int)$id);

            // Recorre los elementos de la colección y procesa cada registro.
            foreach ($adjItems as $ai) {
                $pId = (int)$ai['product_id'];
                $qty = (float)$ai['qty'];
                $cost = (float)$ai['unit_cost'];

                if ($adj['type'] === 'SOBRANTE') {
                    // Crea capa PEPS
                    $db->prepare("
                        INSERT INTO stock_layers (product_id, entry_id, layer_date, sequence, original_qty, remaining_qty, unit_cost, status)
                        VALUES (?, 1, ?, 1, ?, ?, ?, 'ABIERTA')
                    ")->execute([$pId, $adj['adjustment_date'], $qty, $qty, $cost]);

                    // Utiliza el servicio PEPS para conservar la coherencia entre existencias y movimientos.
                    PepsEngine::recomputeProductStock($pId);

                    // Utiliza el servicio PEPS para conservar la coherencia entre existencias y movimientos.
                    PepsEngine::recordKardex(
                        $pId,
                        $adj['adjustment_date'],
                        'AJUSTE',
                        (int)$id,
                        $adj['number'],
                        $qty,
                        0.0,
                        $cost,
                        0.0,
                        $user['id']
                    );
                } else {
                    // FALTANTE: consume PEPS
                    PepsEngine::consume($pId, $qty);
                    // Utiliza el servicio PEPS para conservar la coherencia entre existencias y movimientos.
                    PepsEngine::recomputeProductStock($pId);

                    // Utiliza el servicio PEPS para conservar la coherencia entre existencias y movimientos.
                    PepsEngine::recordKardex(
                        $pId,
                        $adj['adjustment_date'],
                        'AJUSTE',
                        (int)$id,
                        $adj['number'],
                        0.0,
                        $qty,
                        0.0,
                        $cost,
                        $user['id']
                    );
                }
            }

            $db->prepare("UPDATE adjustments SET status = 'APROBADO' WHERE id = ?")->execute([(int)$id]);

            // Guarda el evento en auditoría para identificar qué usuario realizó la acción.
            Auth::audit('ajustes.aprobar', 'adjustments', (int)$id, ['status' => 'EN_REVISION'], ['status' => 'APROBADO']);

            // Confirma los cambios después de completar las validaciones y registros.
            Database::commit();

            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/ajustes', "Ajuste {$adj['number']} aprobado e impactado contablemente en Kardex y PEPS.", 'success');

        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (\Throwable $e) {
            Database::rollBack();
            $this->redirect('/ajustes', 'Error al aprobar el ajuste: ' . $e->getMessage(), 'danger');
        }
    }
}
