<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de los usuarios.
namespace App\Controllers;

use App\Core\Controller;
use App\Models\User;
use App\Models\Area;
use App\Core\Database;
use PDO;

class UsuariosController extends Controller {

    // Consulta los datos y prepara la pantalla principal de los usuarios.
    public function index(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('usuarios.ver');
        $userModel = new User();
        $users = $userModel->getDetailedList();

        $db = Database::getConnection();
        $roles = $db->query("SELECT * FROM roles ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

        $areaModel = new Area();
        $areas = $areaModel->all();

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('usuarios/index', [
            'pageTitle' => 'Gestión de Usuarios y Roles - SIGA DDE',
            'users' => $users,
            'roles' => $roles,
            'areas' => $areas,
        ]);
    }
}
