<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de las solicitudes de materiales.

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\AuditLog;
use App\Models\Product;
use App\Models\Request;
use RuntimeException;

final class RequestController extends Controller
{
    // Lista las solicitudes según el alcance permitido al usuario.
    public function index(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requireAuth();
        $scope = (string) $this->input('scope', 'mine');
        $status = (string) $this->input('status', '');
        $search = trim((string) $this->input('search', ''));

        $canAll = in_array('solicitudes.ver_todas', $user['permissions'], true);
        $canArea = in_array('solicitudes.ver_area', $user['permissions'], true);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($scope === 'all' && !$canAll) {
            $scope = 'mine';
        }
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($scope === 'area' && !$canArea) {
            $scope = 'mine';
        }

        $this->view('requests/index', [
            'title' => 'Solicitudes de materiales',
            'requests' => Request::listForUser($user, $scope, $status, $search),
            'scope' => $scope,
            'status' => $status,
            'search' => $search,
            'canAll' => $canAll,
            'canArea' => $canArea,
            'canCreate' => can('solicitudes.crear'),
        ]);
    }

    // Prepara la pantalla para registrar una nueva solicitud.
    public function create(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('solicitudes.crear');
        $this->view('requests/create', [
            'title' => 'Nueva solicitud',
            'mode' => 'create',
            'request' => null,
            'items' => [],
            'products' => Product::allForSelect(),
            'user' => $user,
        ]);
    }

    // Valida y guarda una solicitud junto con los materiales pedidos.
    public function store(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('solicitudes.crear');
        $items = $this->parseItems();
        $submit = (string) $this->input('submit_action', 'borrador') === 'enviar';
        $data = [
            'correspondence_number' => trim((string) $this->input('correspondence_number', '')),
            'office' => trim((string) $this->input('office', '')),
            'justification' => trim((string) $this->input('justification', '')),
            'area_id' => $this->intInput('area_id') ?: ($user['area_id'] ?? 0),
        ];

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            $request = Request::createRequest($user, $data, $items, $submit);
            AuditLog::record((int) $user['id'], 'SOLICITUD_CREADA', 'requests', (int) $request['id'], null, $request);
            Session::flash('success', 'Solicitud ' . $request['code'] . ' registrada correctamente.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/solicitudes/' . (int) $request['id']);
        } catch (RuntimeException $exception) {
            Session::flash('danger', $exception->getMessage());
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/solicitudes/nueva');
        }
    }

    // Carga un borrador editable, comprobando que pertenezca al solicitante.
    public function edit(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('solicitudes.crear');
        $request = Request::findDetailed((int) $id);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($request === null) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Solicitud no encontrada']);
            return;
        }
        // Verifica el estado actual para impedir cambios fuera del flujo permitido.
        if ((int) $request['applicant_id'] !== (int) $user['id'] || !in_array($request['status'], ['BORRADOR', 'OBSERVADA'], true)) {
            Session::flash('warning', 'Solo puede editar sus propias solicitudes en borrador u observadas.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/solicitudes/' . (int) $id);
        }

        $this->view('requests/create', [
            'title' => 'Editar solicitud ' . $request['code'],
            'mode' => 'edit',
            'request' => $request,
            'items' => Request::items((int) $id),
            'products' => Product::allForSelect(),
            'user' => $user,
        ]);
    }

    // Guarda los cambios permitidos en una solicitud en edición.
    public function update(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('solicitudes.crear');
        $items = $this->parseItems();
        $submit = (string) $this->input('submit_action', 'borrador') === 'enviar';
        $data = [
            'correspondence_number' => trim((string) $this->input('correspondence_number', '')),
            'office' => trim((string) $this->input('office', '')),
            'justification' => trim((string) $this->input('justification', '')),
        ];

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            Request::updateRequest((int) $id, $user, $data, $items, $submit);
            AuditLog::record((int) $user['id'], 'SOLICITUD_ACTUALIZADA', 'requests', (int) $id, null, $data);
            Session::flash('success', 'Solicitud actualizada correctamente.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/solicitudes/' . (int) $id);
        } catch (RuntimeException $exception) {
            Session::flash('danger', $exception->getMessage());
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/solicitudes/' . (int) $id . '/editar');
        }
    }

    // Cambia el borrador al estado de aprobación cuando cumple las condiciones.
    public function submit(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('solicitudes.crear');
        $request = Request::find((int) $id);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($request === null) {
            $this->redirect('/solicitudes');
        }
        // Verifica el estado actual para impedir cambios fuera del flujo permitido.
        if ((int) $request['applicant_id'] !== (int) $user['id'] || !in_array($request['status'], ['BORRADOR', 'OBSERVADA'], true)) {
            Session::flash('warning', 'La solicitud no puede enviarse en su estado actual.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/solicitudes/' . (int) $id);
        }

        $items = [];
        // Procesa cada producto por separado para registrar o calcular su movimiento.
        foreach (Request::items((int) $id) as $item) {
            $items[] = [
                'product_id' => (int) $item['product_id'],
                'qty_requested' => (float) $item['qty_requested'],
            ];
        }
        $data = [
            'correspondence_number' => (string) $request['correspondence_number'],
            'office' => (string) $request['office'],
            'justification' => (string) $request['justification'],
        ];

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            Request::updateRequest((int) $id, $user, $data, $items, true);
            AuditLog::record((int) $user['id'], 'SOLICITUD_ENVIADA', 'requests', (int) $id);
            Session::flash('success', 'Solicitud enviada al flujo de aprobación.');
        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (RuntimeException $exception) {
            Session::flash('danger', $exception->getMessage());
        }
        // Redirige a la pantalla correspondiente e informa el resultado de la acción.
        $this->redirect('/solicitudes/' . (int) $id);
    }

    // Muestra el detalle con las restricciones de visibilidad correspondientes.
    public function show(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requireAuth();
        $request = Request::findDetailed((int) $id);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($request === null) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Solicitud no encontrada']);
            return;
        }
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if (!$this->canView($request, $user)) {
            http_response_code(403);
            $this->view('errors/403', ['title' => 'Acceso denegado']);
            return;
        }

        $items = Request::items((int) $id);
        $canDecide = $this->canDecide($request, $user);

        $this->view('requests/show', [
            'title' => 'Solicitud ' . $request['code'],
            'request' => $request,
            'items' => $items,
            'approvals' => Request::approvals((int) $id),
            'history' => Request::history((int) $id),
            'canDecide' => $canDecide,
            'canEdit' => (int) $request['applicant_id'] === (int) $user['id'] && in_array($request['status'], ['BORRADOR', 'OBSERVADA'], true),
            'canCancel' => (int) $request['applicant_id'] === (int) $user['id'] || can('solicitudes.ver_todas'),
        ]);
    }

    // Registra la decisión del aprobador en el paso que le corresponde.
    public function decide(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('aprobaciones.decidir');
        $action = (string) $this->input('action', '');
        $comments = trim((string) $this->input('comments', ''));
        $quantityItems = [];
        // Recupera los valores enviados por el formulario para validarlos en el servidor.
        foreach ((array) ($_POST['qty'] ?? []) as $itemId => $qty) {
            $quantityItems[] = ['id' => (int) $itemId, 'qty' => (float) str_replace(',', '.', (string) $qty)];
        }

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            Request::decide((int) $id, $user, $action, $comments, $quantityItems);
            AuditLog::record((int) $user['id'], 'SOLICITUD_DECIDIDA', 'requests', (int) $id, null, [
                'action' => $action,
                'comments' => $comments,
            ]);
            Session::flash('success', 'Decisión registrada correctamente.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/solicitudes/' . (int) $id);
        } catch (RuntimeException $exception) {
            Session::flash('danger', $exception->getMessage());
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/solicitudes/' . (int) $id);
        }
    }

    // Anula una solicitud si el usuario y el estado permiten hacerlo.
    public function cancel(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requireAuth();
        $reason = trim((string) $this->input('reason', ''));
        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            Request::cancel((int) $id, $user, $reason);
            AuditLog::record((int) $user['id'], 'SOLICITUD_ANULADA', 'requests', (int) $id, null, ['reason' => $reason]);
            Session::flash('success', 'Solicitud anulada correctamente.');
        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (RuntimeException $exception) {
            Session::flash('danger', $exception->getMessage());
        }
        // Redirige a la pantalla correspondiente e informa el resultado de la acción.
        $this->redirect('/solicitudes/' . (int) $id);
    }

    /** @return array<int,array{product_id:int,qty_requested:float}> */
    private function parseItems(): array
    {
        // Recupera los valores enviados por el formulario para validarlos en el servidor.
        $productIds = $_POST['product_id'] ?? [];
        $quantities = $_POST['qty_requested'] ?? [];
        $items = [];
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ((array) $productIds as $index => $productId) {
            $pid = (int) $productId;
            $qty = (float) str_replace(',', '.', (string) ($quantities[$index] ?? 0));
            // Controla los valores de cantidad o costo antes de continuar con el inventario.
            if ($pid <= 0 || $qty <= 0) {
                continue;
            }
            $items[] = ['product_id' => $pid, 'qty_requested' => $qty];
        }
        return $items;
    }

    /** @param array<string,mixed> $request */
    private function canView(array $request, array $user): bool
    {
        if ((int) $request['applicant_id'] === (int) $user['id']) {
            return true;
        }
        // Aplica una restricción de seguridad de acuerdo con el rol o permiso del usuario.
        if (in_array('solicitudes.ver_todas', $user['permissions'], true)) {
            return true;
        }
        // Aplica una restricción de seguridad de acuerdo con el rol o permiso del usuario.
        if (in_array('solicitudes.ver_area', $user['permissions'], true) && (int) $request['area_id'] === (int) ($user['area_id'] ?? -1)) {
            return true;
        }
        // Aplica una restricción de seguridad de acuerdo con el rol o permiso del usuario.
        if (in_array('aprobaciones.ver', $user['permissions'], true)) {
            if ($user['role_code'] === 'JEFE_INMEDIATO') {
                return (int) $request['area_id'] === (int) ($user['area_id'] ?? -1);
            }
            return true;
        }
        return false;
    }

    /** @param array<string,mixed> $request */
    private function canDecide(array $request, array $user): bool
    {
        // Aplica una restricción de seguridad de acuerdo con el rol o permiso del usuario.
        if (!in_array('aprobaciones.decidir', $user['permissions'], true)) {
            return false;
        }
        // Verifica el estado actual para impedir cambios fuera del flujo permitido.
        if ($request['status'] !== 'EN_APROBACION') {
            return false;
        }
        if ((int) $request['applicant_id'] === (int) $user['id']) {
            return false;
        }
        // Aplica una restricción de seguridad de acuerdo con el rol o permiso del usuario.
        if ($user['role_code'] === 'JEFE_INMEDIATO' && (int) $request['area_id'] !== (int) ($user['area_id'] ?? -1)) {
            return false;
        }
        $step = Request::first(
            'SELECT s.role_id FROM approval_route_steps s WHERE s.route_id = ? AND s.step_order = ? LIMIT 1',
            [(int) $request['route_id'], (int) $request['current_step']]
        );
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($step === null) {
            return false;
        }
        return (int) $step['role_id'] === (int) $user['role_id'] || $user['role_code'] === 'ADMIN';
    }
}
