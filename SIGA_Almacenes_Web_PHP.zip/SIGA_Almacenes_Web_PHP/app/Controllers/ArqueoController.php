<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de el arqueo físico de productos.
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Product;

class ArqueoController extends Controller {

    // Consulta los datos y prepara la pantalla principal de el arqueo físico de productos.
    public function index(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('arqueo.ver');
        $prodModel = new Product();
        $products = $prodModel->getDetailedList();

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('arqueo/index', [
            'pageTitle' => 'Toma Física de Inventario / Arqueo - SIGA DDE',
            'products' => $products
        ]);
    }
}
