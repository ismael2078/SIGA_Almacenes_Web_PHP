<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de las salidas de almacén.
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Core\Database;
use App\Core\PepsEngine;
use App\Models\StockDispatch;
use App\Models\Request as RequestModel;
use PDO;

class SalidasController extends Controller {

    // Presenta el historial de salidas y despachos.
    public function index(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('salidas.ver');
        $dispatchModel = new StockDispatch();
        $dispatches = $dispatchModel->getDetailedList();

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('salidas/index', [
            'pageTitle' => 'Comprobantes de Salida / Despachos - SIGA DDE',
            'dispatches' => $dispatches
        ]);
    }

    // Obtiene solicitudes autorizadas y prepara el despacho.
    public function nueva(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('salidas.preparar');
        $db = Database::getConnection();

        // Obtener solicitudes en estado 'APROBADA' listas para despacho
        $stmt = $db->query("
            SELECT r.*, u.full_name AS applicant_name, a.name AS area_name,
                   (SELECT COUNT(*) FROM request_items ri WHERE ri.request_id = r.id) AS items_count
            FROM requests r
            LEFT JOIN users u ON u.id = r.applicant_id
            LEFT JOIN areas a ON a.id = r.area_id
            WHERE r.status = 'APROBADA'
            ORDER BY r.approved_at ASC, r.id ASC
        ");
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $approvedRequests = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Lee los criterios recibidos por la URL para limitar o buscar resultados.
        $selectedReqId = !empty($_GET['request_id']) ? (int)$_GET['request_id'] : 0;
        $selectedRequest = null;
        $requestItems = [];

        if ($selectedReqId > 0) {
            $reqModel = new RequestModel();
            $selectedRequest = $reqModel->getWithDetails($selectedReqId);
            // Verifica el estado actual para impedir cambios fuera del flujo permitido.
            if ($selectedRequest && $selectedRequest['status'] === 'APROBADA') {
                $requestItems = $reqModel->getItems($selectedReqId);
            }
        }

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('salidas/nueva', [
            'pageTitle' => 'Registrar Despacho de Material - SIGA DDE',
            'approvedRequests' => $approvedRequests,
            'selectedRequest' => $selectedRequest,
            'requestItems' => $requestItems,
        ]);
    }

    // Registra el despacho y actualiza existencias con el método PEPS.
    public function store(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('salidas.confirmar');
        $data = $this->getPostData();

        $requestId = (int)($data['request_id'] ?? 0);
        $receivedBy = trim($data['received_by'] ?? '');
        $receivedCi = trim($data['received_ci'] ?? '');
        $notes = trim($data['notes'] ?? '');
        $items = $data['items'] ?? [];

        if ($requestId <= 0) {
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/salidas/nueva', 'Debe seleccionar una solicitud aprobada.', 'danger');
        }

        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (empty($receivedBy) || empty($receivedCi)) {
            $this->redirect("/salidas/nueva?request_id={$requestId}", 'El nombre y cédula de quien recibe el material son obligatorios.', 'danger');
        }

        $reqModel = new RequestModel();
        $req = $reqModel->find($requestId);
        // Verifica el estado actual para impedir cambios fuera del flujo permitido.
        if (!$req || $req['status'] !== 'APROBADA') {
            $this->redirect('/salidas/nueva', 'La solicitud seleccionada no se encuentra aprobada para entrega.', 'warning');
        }

        $db = Database::getConnection();

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            Database::beginTransaction();

            // Releer y bloquear: una solicitud no puede despacharse dos veces
            // ni recibir artículos/cantidades distintos de lo autorizado.
            $sql = 'SELECT status FROM requests WHERE id = ?';
            // Adapta la instrucción al motor de base de datos utilizado.
            if (Database::getDriver() === 'mysql') $sql .= ' FOR UPDATE';
            $lock = $db->prepare($sql);
            $lock->execute([$requestId]);
            // Verifica el estado actual para impedir cambios fuera del flujo permitido.
            if ($lock->fetchColumn() !== 'APROBADA') {
                throw new \RuntimeException('La solicitud ya no está disponible para despacho.');
            }
            // Prepara una consulta parametrizada para recuperar información sin concatenar datos del usuario.
            $auth = $db->prepare('SELECT id, product_id, qty_authorized FROM request_items WHERE request_id = ?');
            $auth->execute([$requestId]);
            $expected = [];
            // Recorre los elementos de la colección y procesa cada registro.
            foreach ($auth->fetchAll(PDO::FETCH_ASSOC) as $it) {
                if ((float)$it['qty_authorized'] > 0) $expected[(int)$it['id']] = $it;
            }
            // Valida que el dato obligatorio exista y tenga un formato utilizable.
            if (!$expected || !is_array($items)) {
                throw new \RuntimeException('No existen artículos autorizados para despacho.');
            }
            if (count($items) !== count($expected)) {
                throw new \RuntimeException('El despacho debe incluir todos los artículos autorizados.');
            }
            // Procesa cada producto por separado para registrar o calcular su movimiento.
            foreach ($items as $itemId => $it) {
                $itemId = (int)$itemId;
                $qty = (float)($it['qty'] ?? 0);
                // Valida que el dato obligatorio exista y tenga un formato utilizable.
                if (!isset($expected[$itemId]) || (int)($it['product_id'] ?? 0) !== (int)$expected[$itemId]['product_id']
                    || $qty <= 0 || abs($qty - (float)$expected[$itemId]['qty_authorized']) > 0.0005) {
                    throw new \RuntimeException('Los productos o cantidades no coinciden con la autorización de la solicitud.');
                }
            }

            // Solicita el código correlativo del documento para mantener su identificación.
            $salidaNumber = PepsEngine::nextSequence('SAL', (int)date('Y'));
            $dispatchDate = date('Y-m-d H:i:s');

            // 1. Crear stock_dispatches
            $dispIns = $db->prepare("
                INSERT INTO stock_dispatches (
                    number, request_id, dispatch_date, dispatched_by, received_by,
                    received_ci, received_signature_at, total_value, status, notes, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, 0, 'CONFIRMADO', ?, CURRENT_TIMESTAMP)
            ");
            $dispIns->execute([
                $salidaNumber,
                $requestId,
                $dispatchDate,
                $user['id'],
                $receivedBy,
                $receivedCi,
                $notes
            ]);
            $dispatchId = (int)$db->lastInsertId();

            $totalDispatchValue = 0.0;

            $itemIns = $db->prepare("
                INSERT INTO dispatch_items (dispatch_id, request_item_id, product_id, qty, unit_cost, total_value)
                VALUES (?, ?, ?, ?, ?, ?)
            ");

            $consIns = $db->prepare("
                INSERT INTO layer_consumptions (dispatch_item_id, layer_id, qty, unit_cost, total_value)
                VALUES (?, ?, ?, ?, ?)
            ");

            $reqItemUpd = $db->prepare("
                UPDATE request_items 
                SET qty_delivered = ?, status = 'ENTREGADO' 
                WHERE id = ?
            ");

            // 2. Procesar cada ítem con el motor PEPS
            foreach ($items as $reqItemId => $itData) {
                $reqItemId = (int)$reqItemId;
                $pId = (int)($itData['product_id'] ?? 0);
                $qty = (float)($itData['qty'] ?? 0);

                if ($pId <= 0 || $qty <= 0) continue;

                // Consumir capas PEPS (FIFO)
                $pepsResult = PepsEngine::consume($pId, $qty);
                $unitCost = $pepsResult['unit_cost'];
                $itemTotal = $pepsResult['total_cost'];
                $totalDispatchValue += $itemTotal;

                // Registrar dispatch_item
                $itemIns->execute([$dispatchId, $reqItemId, $pId, $qty, $unitCost, $itemTotal]);
                $dispatchItemId = (int)$db->lastInsertId();

                // Registrar layer_consumptions
                foreach ($pepsResult['consumed_layers'] as $cLayer) {
                    $consIns->execute([
                        $dispatchItemId,
                        $cLayer['layer_id'],
                        $cLayer['qty'],
                        $cLayer['unit_cost'],
                        $cLayer['total_cost']
                    ]);
                }

                // Recalcular stock del producto
                PepsEngine::recomputeProductStock($pId);

                // Registrar en Kardex movimiento de salida
                PepsEngine::recordKardex(
                    $pId,
                    $dispatchDate,
                    'SALIDA',
                    $dispatchId,
                    $salidaNumber,
                    0.0,
                    $qty,
                    0.0,
                    $unitCost,
                    $user['id']
                );

                // Actualizar ítem de la solicitud
                $reqItemUpd->execute([$qty, $reqItemId]);
            }

            // 3. Actualizar valor total del despacho
            $db->prepare("UPDATE stock_dispatches SET total_value = ? WHERE id = ?")->execute([$totalDispatchValue, $dispatchId]);

            // 4. Actualizar estado de la solicitud a ATENDIDA
            $db->prepare("UPDATE requests SET status = 'ATENDIDA', closed_at = CURRENT_TIMESTAMP WHERE id = ?")->execute([$requestId]);

            // 5. Historial de solicitud
            $histIns = $db->prepare("
                INSERT INTO request_history (request_id, from_state, to_state, actor_id, role_id, comments, created_at)
                VALUES (?, 'APROBADA', 'ATENDIDA', ?, ?, ?, CURRENT_TIMESTAMP)
            ");
            $histIns->execute([$requestId, $user['id'], $user['role_id'], "Entrega física realizada bajo comprobante {$salidaNumber} a {$receivedBy}"]);

            Auth::audit('salidas.confirmar', 'stock_dispatches', $dispatchId, null, [
                'number' => $salidaNumber,
                'request_id' => $requestId,
                'total_value' => $totalDispatchValue
            ]);

            Database::commit();

            $this->redirect("/salidas/{$dispatchId}", "Despacho {$salidaNumber} confirmado y entregado con éxito.", 'success');

        } catch (\Throwable $e) {
            if ($db->inTransaction()) Database::rollBack();
            $this->redirect("/salidas/nueva?request_id={$requestId}", 'Error al procesar el despacho PEPS: ' . $e->getMessage(), 'danger');
        }
    }

    // Muestra la información y los materiales de una salida.
    public function ver(string $id): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('salidas.ver');
        $dispModel = new StockDispatch();
        $dispatch = $dispModel->getWithDetails((int)$id);

        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if (!$dispatch) {
            $this->redirect('/salidas', 'Comprobante de salida no encontrado.', 'danger');
        }

        $items = $dispModel->getItems((int)$id);

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('salidas/ver', [
            'pageTitle' => "Comprobante de Salida {$dispatch['number']} - SIGA DDE",
            'dispatch' => $dispatch,
            'items' => $items
        ]);
    }
}
