<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de los catálogos del almacén.

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\Area;
use App\Models\AuditLog;
use App\Models\Category;
use App\Models\Location;
use App\Models\Subcategory;
use App\Models\Supplier;
use App\Models\Unit;

final class CatalogController extends Controller
{
    // Consulta categorías, unidades, ubicaciones y demás catálogos para la pantalla.
    public function index(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('catalogos.ver');
        $this->view('catalogs/index', [
            'title' => 'Catálogos generales',
            'categories' => Category::withSubcategories(),
            'subcategories' => Subcategory::allOrdered(),
            'units' => Unit::allOrdered(),
            'locations' => Location::allOrdered(),
            'suppliers' => Supplier::allOrdered(),
            'areas' => Area::allOrdered(),
            'canEdit' => can('catalogos.editar'),
        ]);
    }

    // Valida el tipo de catálogo y deriva el registro al método correspondiente.
    public function store(string $tipo): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('catalogos.editar');

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            switch ($tipo) {
                case 'categorias':
                    $this->insertCategory($user);
                    break;
                case 'subcategorias':
                    $this->insertSubcategory($user);
                    break;
                case 'unidades':
                    $this->insertUnit($user);
                    break;
                case 'ubicaciones':
                    $this->insertLocation($user);
                    break;
                case 'proveedores':
                    $this->insertSupplier($user);
                    break;
                case 'areas':
                    $this->insertArea($user);
                    break;
                default:
                    throw new \RuntimeException('Tipo de catálogo no reconocido.');
            }
            Session::flash('success', 'Registro agregado correctamente.');
        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (\PDOException $exception) {
            Session::flash('danger', 'No se pudo guardar. Verifique que el código o NIT no estén duplicados.');
        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (\RuntimeException $exception) {
            Session::flash('danger', $exception->getMessage());
        }

        // Redirige a la pantalla correspondiente e informa el resultado de la acción.
        $this->redirect('/catalogos');
    }

    // Registra una categoría con su código y nombre.
    private function insertCategory(array $user): void
    {
        $code = strtoupper(trim((string) $this->input('code', '')));
        $name = trim((string) $this->input('name', ''));
        if ($code === '' || $name === '') {
            throw new \RuntimeException('Código y nombre son obligatorios.');
        }
        $id = Category::insert(['code' => $code, 'name' => $name, 'description' => trim((string) $this->input('description', '')) ?: null]);
        AuditLog::record((int) $user['id'], 'CATALOGO_CREADO', 'categories', $id, null, ['code' => $code, 'name' => $name]);
    }

    // Registra una subcategoría asociada a su categoría principal.
    private function insertSubcategory(array $user): void
    {
        $categoryId = $this->intInput('category_id');
        $code = strtoupper(trim((string) $this->input('code', '')));
        $name = trim((string) $this->input('name', ''));
        if ($categoryId <= 0 || $code === '' || $name === '') {
            throw new \RuntimeException('Categoría, código y nombre son obligatorios.');
        }
        $id = Subcategory::insert(['category_id' => $categoryId, 'code' => $code, 'name' => $name]);
        AuditLog::record((int) $user['id'], 'CATALOGO_CREADO', 'subcategories', $id, null, ['category_id' => $categoryId, 'code' => $code, 'name' => $name]);
    }

    // Registra una unidad de medida utilizada por los productos.
    private function insertUnit(array $user): void
    {
        $code = strtoupper(trim((string) $this->input('code', '')));
        $name = trim((string) $this->input('name', ''));
        if ($code === '' || $name === '') {
            throw new \RuntimeException('Código y nombre son obligatorios.');
        }
        $id = Unit::insert(['code' => $code, 'name' => $name]);
        AuditLog::record((int) $user['id'], 'CATALOGO_CREADO', 'units', $id, null, ['code' => $code, 'name' => $name]);
    }

    // Registra una ubicación física dentro del almacén.
    private function insertLocation(array $user): void
    {
        $code = strtoupper(trim((string) $this->input('code', '')));
        $name = trim((string) $this->input('name', ''));
        if ($code === '' || $name === '') {
            throw new \RuntimeException('Código y nombre son obligatorios.');
        }
        $data = [
            'code' => $code,
            'name' => $name,
            'warehouse' => trim((string) $this->input('warehouse', '')) ?: null,
            'aisle' => trim((string) $this->input('aisle', '')) ?: null,
            'shelf' => trim((string) $this->input('shelf', '')) ?: null,
            'level' => trim((string) $this->input('level', '')) ?: null,
        ];
        $id = Location::insert($data);
        AuditLog::record((int) $user['id'], 'CATALOGO_CREADO', 'locations', $id, null, $data);
    }

    // Registra un proveedor en el catálogo.
    private function insertSupplier(array $user): void
    {
        $name = trim((string) $this->input('name', ''));
        if ($name === '') {
            throw new \RuntimeException('El nombre del proveedor es obligatorio.');
        }
        $data = [
            'nit' => trim((string) $this->input('nit', '')) ?: null,
            'name' => $name,
            'contact_name' => trim((string) $this->input('contact_name', '')) ?: null,
            'phone' => trim((string) $this->input('phone', '')) ?: null,
            'email' => trim((string) $this->input('email', '')) ?: null,
            'address' => trim((string) $this->input('address', '')) ?: null,
        ];
        $id = Supplier::insert($data);
        AuditLog::record((int) $user['id'], 'CATALOGO_CREADO', 'suppliers', $id, null, $data);
    }

    // Registra un área institucional para las solicitudes.
    private function insertArea(array $user): void
    {
        $code = strtoupper(trim((string) $this->input('code', '')));
        $name = trim((string) $this->input('name', ''));
        if ($code === '' || $name === '') {
            throw new \RuntimeException('Código y nombre son obligatorios.');
        }
        $data = [
            'code' => $code,
            'name' => $name,
            'type' => (string) $this->input('type', 'UNIDAD'),
            'parent_id' => $this->intInput('parent_id') ?: null,
        ];
        $id = Area::insert($data);
        AuditLog::record((int) $user['id'], 'CATALOGO_CREADO', 'areas', $id, null, $data);
    }
}
