<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de los ingresos de productos.

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\AuditLog;
use App\Models\Location;
use App\Models\Product;
use App\Models\StockEntry;
use App\Models\Supplier;
use RuntimeException;

final class EntryController extends Controller
{
    // Consulta los ingresos registrados y aplica los filtros de búsqueda.
    public function index(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('ingresos.ver');
        $search = trim((string) $this->input('search', ''));
        $status = (string) $this->input('status', '');
        $type = (string) $this->input('type', '');

        $this->view('entries/index', [
            'title' => 'Ingresos al almacén',
            'entries' => StockEntry::paginate($search, $status, $type),
            'search' => $search,
            'status' => $status,
            'type' => $type,
        ]);
    }

    // Prepara el formulario de ingreso de materiales.
    public function create(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('ingresos.crear');
        $this->view('entries/create', [
            'title' => 'Nuevo ingreso',
            'suppliers' => Supplier::allOrdered(),
            'locations' => Location::allOrdered(),
            'products' => Product::allForSelect(),
        ]);
    }

    // Registra un ingreso con sus productos y cantidades.
    public function store(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('ingresos.crear');
        $items = $this->parseItems();

        if ($items === []) {
            Session::flash('danger', 'Debe agregar al menos un producto con cantidad mayor a cero.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/ingresos/nuevo');
        }

        $data = [
            'type' => (string) $this->input('type', 'COMPRA'),
            'supplier_id' => $this->intInput('supplier_id'),
            'doc_type' => trim((string) $this->input('doc_type', '')),
            'doc_number' => trim((string) $this->input('doc_number', '')),
            'doc_date' => (string) $this->input('doc_date', ''),
            'notes' => trim((string) $this->input('notes', '')),
        ];

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            $entry = StockEntry::create((int) $user['id'], $data, $items);
            AuditLog::record((int) $user['id'], 'INGRESO_CREADO', 'stock_entries', (int) $entry['id'], null, $entry);
            Session::flash('success', 'Ingreso ' . $entry['number'] . ' creado en estado BORRADOR. Confirme para afectar el inventario.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/ingresos/' . (int) $entry['id']);
        } catch (RuntimeException $exception) {
            Session::flash('danger', $exception->getMessage());
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/ingresos/nuevo');
        }
    }

    // Carga los datos detallados de un ingreso existente.
    public function show(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('ingresos.ver');
        $entry = StockEntry::findDetailed((int) $id);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($entry === null) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Ingreso no encontrado']);
            return;
        }
        $this->view('entries/show', [
            'title' => 'Ingreso ' . $entry['number'],
            'entry' => $entry,
            'items' => StockEntry::items((int) $id),
        ]);
    }

    // Confirma el ingreso y actualiza las existencias correspondientes.
    public function confirm(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('ingresos.confirmar');
        try {
            StockEntry::confirm((int) $id, (int) $user['id']);
            AuditLog::record((int) $user['id'], 'INGRESO_CONFIRMADO', 'stock_entries', (int) $id);
            Session::flash('success', 'Ingreso confirmado. Se generaron las capas PEPS y movimientos de kardex.');
        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (RuntimeException $exception) {
            Session::flash('danger', $exception->getMessage());
        }
        // Redirige a la pantalla correspondiente e informa el resultado de la acción.
        $this->redirect('/ingresos/' . (int) $id);
    }

    // Anula el ingreso conforme a sus validaciones.
    public function cancel(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('ingresos.anular');
        $reason = trim((string) $this->input('reason', ''));
        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            StockEntry::void((int) $id, (int) $user['id'], $reason);
            AuditLog::record((int) $user['id'], 'INGRESO_ANULADO', 'stock_entries', (int) $id, null, ['reason' => $reason]);
            Session::flash('success', 'Ingreso anulado correctamente.');
        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (RuntimeException $exception) {
            Session::flash('danger', $exception->getMessage());
        }
        // Redirige a la pantalla correspondiente e informa el resultado de la acción.
        $this->redirect('/ingresos/' . (int) $id);
    }

    /** @return array<int,array{product_id:int,quantity:float,unit_cost:float,location_id:?int,notes:?string}> */
    private function parseItems(): array
    {
        // Recupera los valores enviados por el formulario para validarlos en el servidor.
        $productIds = $_POST['product_id'] ?? [];
        $quantities = $_POST['quantity'] ?? [];
        // Recupera los valores enviados por el formulario para validarlos en el servidor.
        $unitCosts = $_POST['unit_cost'] ?? [];
        $locationIds = $_POST['item_location_id'] ?? [];
        // Recupera los valores enviados por el formulario para validarlos en el servidor.
        $notes = $_POST['item_notes'] ?? [];

        $items = [];
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ((array) $productIds as $index => $productId) {
            $pid = (int) $productId;
            $quantity = (float) str_replace(',', '.', (string) ($quantities[$index] ?? 0));
            $unitCost = (float) str_replace(',', '.', (string) ($unitCosts[$index] ?? 0));
            if ($pid <= 0 || $quantity <= 0) {
                continue;
            }
            $items[] = [
                'product_id' => $pid,
                'quantity' => $quantity,
                'unit_cost' => max(0, $unitCost),
                'location_id' => !empty($locationIds[$index]) ? (int) $locationIds[$index] : null,
                'notes' => trim((string) ($notes[$index] ?? '')) ?: null,
            ];
        }
        return $items;
    }
}
