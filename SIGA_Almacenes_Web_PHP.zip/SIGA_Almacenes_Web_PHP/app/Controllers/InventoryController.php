<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de el catálogo de productos.

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\AuditLog;
use App\Models\Category;
use App\Models\Location;
use App\Models\Product;
use App\Models\Subcategory;
use App\Models\Unit;
use RuntimeException;

final class InventoryController extends Controller
{
    // Consulta los datos y prepara la pantalla principal de el catálogo de productos.
    public function index(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requireAuth();

        $filters = [
            'search' => trim((string) $this->input('search', '')),
            'category' => $this->intInput('category'),
            'status' => (string) $this->input('status', ''),
            'low_stock' => $this->intInput('low_stock'),
            'no_stock' => $this->intInput('no_stock'),
        ];
        $page = max(1, $this->intInput('page', 1));
        $result = Product::paginate($filters, $page, 25);

        $this->view('inventory/index', [
            'title' => 'Inventario de productos',
            'filters' => $filters,
            'result' => $result,
            'categories' => Category::allOrdered(),
            'stats' => Product::stats(),
            'canValues' => can('inventario.ver_valores'),
        ]);
    }

    // Recupera y muestra el detalle de un registro de el catálogo de productos.
    public function show(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requireAuth();
        $product = Product::findDetailed((int) $id);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($product === null) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Producto no encontrado']);
            return;
        }

        $this->view('inventory/show', [
            'title' => 'Producto ' . $product['code'],
            'product' => $product,
            'layers' => Product::layers((int) $id),
            'movements' => Product::kardex((int) $id, 300),
            'canValues' => can('inventario.ver_valores'),
        ]);
    }

    // Carga los datos necesarios para registrar información de el catálogo de productos.
    public function create(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('productos.crear');
        $this->view('inventory/form', [
            'title' => 'Nuevo producto',
            'product' => null,
            'categories' => Category::allOrdered(),
            'subcategories' => Subcategory::allOrdered(),
            'units' => Unit::allOrdered(),
            'locations' => Location::allOrdered(),
            'nextCode' => '',
        ]);
    }

    // Valida los datos recibidos y registra la operación de el catálogo de productos.
    public function store(): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('productos.crear');
        $data = $this->validateProduct();

        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            $id = Product::insert($data + [
                'stock_qty' => '0.000',
                'stock_value' => '0.00',
                'is_active' => 1,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            AuditLog::record((int) $user['id'], 'PRODUCTO_CREADO', 'products', $id, null, $data);
            Session::flash('success', 'Producto creado correctamente.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/inventario/' . $id);
        } catch (\PDOException $exception) {
            Session::flash('danger', 'No se pudo crear el producto. Verifique que el código no esté duplicado.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/inventario/nuevo');
        }
    }

    // Prepara los datos que pueden editarse de el catálogo de productos.
    public function edit(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('productos.editar');
        $product = Product::findDetailed((int) $id);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($product === null) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Producto no encontrado']);
            return;
        }
        $this->view('inventory/form', [
            'title' => 'Editar producto',
            'product' => $product,
            'categories' => Category::allOrdered(),
            'subcategories' => Subcategory::allOrdered(),
            'units' => Unit::allOrdered(),
            'locations' => Location::allOrdered(),
            'nextCode' => '',
        ]);
    }

    // Comprueba los cambios permitidos y actualiza la información de el catálogo de productos.
    public function update(string $id): void
    {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requirePermission('productos.editar');
        $product = Product::find((int) $id);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($product === null) {
            http_response_code(404);
            $this->view('errors/404', ['title' => 'Producto no encontrado']);
            return;
        }

        $data = $this->validateProduct();
        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            Product::update((int) $id, $data);
            AuditLog::record((int) $user['id'], 'PRODUCTO_EDITADO', 'products', (int) $id, $product, $data);
            Session::flash('success', 'Producto actualizado correctamente.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/inventario/' . (int) $id);
        } catch (\PDOException $exception) {
            Session::flash('danger', 'No se pudo actualizar el producto. Verifique los datos.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/inventario/' . (int) $id . '/editar');
        }
    }

    /** @return array<string,mixed> */
    private function validateProduct(): array
    {
        $code = strtoupper(trim((string) $this->input('code', '')));
        $name = trim((string) $this->input('name', ''));
        $categoryId = $this->intInput('category_id');
        $subcategoryId = $this->intInput('subcategory_id');
        $unitId = $this->intInput('unit_id');

        if ($code === '' || $name === '' || $categoryId <= 0 || $subcategoryId <= 0 || $unitId <= 0) {
            Session::flash('danger', 'Código, nombre, categoría, subcategoría y unidad son obligatorios.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/inventario');
        }

        $sub = Subcategory::find($subcategoryId);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($sub === null || (int) $sub['category_id'] !== $categoryId) {
            Session::flash('danger', 'La subcategoría seleccionada no pertenece a la categoría indicada.');
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/inventario');
        }

        return [
            'code' => $code,
            'name' => $name,
            'description' => trim((string) $this->input('description', '')) ?: null,
            'brand' => trim((string) $this->input('brand', '')) ?: null,
            'model' => trim((string) $this->input('model', '')) ?: null,
            'barcode' => trim((string) $this->input('barcode', '')) ?: null,
            'category_id' => $categoryId,
            'subcategory_id' => $subcategoryId,
            'unit_id' => $unitId,
            'location_id' => $this->intInput('location_id') ?: null,
            'min_stock' => number_format($this->floatInput('min_stock'), 3, '.', ''),
            'max_stock' => number_format($this->floatInput('max_stock'), 3, '.', ''),
            'reference_cost' => number_format($this->floatInput('reference_cost'), 4, '.', ''),
            'status' => in_array($this->input('status'), ['ACTIVO', 'INACTIVO', 'ARCHIVADO'], true)
                ? (string) $this->input('status')
                : 'ACTIVO',
        ];
    }
}
