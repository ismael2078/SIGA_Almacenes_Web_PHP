<?php
// Conecta las peticiones del navegador con el modelo y la vista. Se ocupa de los registros de auditoría.
namespace App\Controllers;

use App\Core\Controller;
use App\Models\AuditLog;

class AuditoriaController extends Controller {

    // Consulta los datos y prepara la pantalla principal de los registros de auditoría.
    public function index(): void {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $this->requirePermission('auditoria.ver');
        $auditModel = new AuditLog();
        $logs = $auditModel->getDetailedList(150);

        // Entrega los datos preparados a la vista que se mostrará al usuario.
        $this->render('auditoria/index', [
            'pageTitle' => 'Bitácora de Auditoría del Sistema - SIGA DDE',
            'logs' => $logs
        ]);
    }
}
