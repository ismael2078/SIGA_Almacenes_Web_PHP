<?php
// Archivo auxiliar utilizado para la configuración y ejecución del proyecto.
namespace App\Services;

class ExternalApiService {
    private const CACHE_FILE = __DIR__ . '/../../storage/exchange_rates_cache.json';
    private const CACHE_TTL_SECONDS = 3600; // 1 hora de caché

    /**
     * Obtiene el tipo de cambio oficial/referencial en vivo consumiendo una API externa RESTful.
     * Retorna tasas respecto a USD y BOB con fallback resiliente.
     */
    public static function getExchangeRates(): array {
        // Verificar si tenemos caché válido
        if (file_exists(self::CACHE_FILE)) {
            $cacheData = json_decode(file_get_contents(self::CACHE_FILE), true);
            if ($cacheData && (time() - ($cacheData['timestamp'] ?? 0)) < self::CACHE_TTL_SECONDS) {
                return $cacheData['data'];
            }
        }

        $rates = null;
        $source = '';

        // Intentar consumir API de tasas de cambio públicas
        try {
            $ch = curl_init('https://open.er-api.com/v6/latest/USD');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 3);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

            if ($httpCode === 200 && $response) {
                $json = json_decode($response, true);
                // Valida que el dato obligatorio exista y tenga un formato utilizable.
                if (isset($json['rates']['BOB'])) {
                    $rates = [
                        'usd_to_bob' => (float)$json['rates']['BOB'],
                        'usd_to_eur' => (float)($json['rates']['EUR'] ?? 0.92),
                        'last_update' => $json['time_last_update_utc'] ?? date('Y-m-d H:i:s'),
                        'source' => 'Open Exchange Rates API (En vivo)',
                        'is_live' => true
                    ];
                }
            }
        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (\Throwable $e) {
            // Manejado abajo por fallback
        }

        // Si falló la primera, intentar segunda API alternativa
        if (!$rates) {
            // Ejecuta el proceso controlando posibles errores durante la operación.
            try {
                $ch = curl_init('https://api.frankfurter.app/latest?from=USD&to=EUR');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 3);
                $response = curl_exec($ch);
                if ($response) {
                    $json = json_decode($response, true);
                    // Valida que el dato obligatorio exista y tenga un formato utilizable.
                    if (isset($json['rates']['EUR'])) {
                        $rates = [
                            'usd_to_bob' => 6.96, // Tipo de cambio oficial referencial Banco Central
                            'usd_to_eur' => (float)$json['rates']['EUR'],
                            'last_update' => date('Y-m-d H:i:s'),
                            'source' => 'Frankfurter API + BCB Oficial',
                            'is_live' => true
                        ];
                    }
                }
            // Captura el error para informar el problema y mantener los datos consistentes.
            } catch (\Throwable $e) {
                // Fallback
            }
        }

        // Si no hay conexión a internet, fallback institucional oficial (BCB)
        if (!$rates) {
            $rates = [
                'usd_to_bob' => 6.96, // Tipo oficial BOB/USD
                'usd_to_eur' => 0.92,
                'last_update' => date('Y-m-d H:i:s'),
                'source' => 'Banco Central de Bolivia (Oficial referencial)',
                'is_live' => false
            ];
        }

        // Guardar en caché local
        $cacheDir = dirname(self::CACHE_FILE);
        if (!is_dir($cacheDir)) {
            @mkdir($cacheDir, 0777, true);
        }
        @file_put_contents(self::CACHE_FILE, json_encode([
            'timestamp' => time(),
            'data' => $rates
        ]));

        return $rates;
    }

    /**
     * Convierte un monto en Bolivianos (BOB) a Dólares Estadounidenses (USD).
     */
    public static function convertBobToUsd(float $bobAmount): float {
        $rates = self::getExchangeRates();
        $rate = $rates['usd_to_bob'] ?: 6.96;
        return round($bobAmount / $rate, 2);
    }
}
