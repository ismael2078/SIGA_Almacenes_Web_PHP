<?php
// Archivo auxiliar utilizado para la configuración y ejecución del proyecto.

declare(strict_types=1);

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Session;

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

if (!function_exists('app_base_path')) {
    function app_base_path(): string
    {
        static $base = null;
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($base !== null) {
            return $base;
        }
        $configured = (string) App\Core\Env::get('APP_BASE_PATH', '');
        if ($configured !== '') {
            $base = '/' . trim($configured, '/');
            return $base;
        }
        $script = $_SERVER['SCRIPT_NAME'] ?? '';
        $dir = str_replace('\\', '/', dirname($script));
        $base = ($dir === '/' || $dir === '.') ? '' : rtrim($dir, '/');
        return $base;
    }
}

if (!function_exists('url')) {
    function url(string $path = ''): string
    {
        $path = '/' . ltrim($path, '/');
        return app_base_path() . ($path === '/' ? '/' : $path);
    }
}

if (!function_exists('asset')) {
    function asset(string $path): string
    {
        return url('/assets/' . ltrim($path, '/'));
    }
}

if (!function_exists('redirect')) {
    function redirect(string $path): never
    {
        // Configura la respuesta HTTP que recibirá el navegador.
        header('Location: ' . url($path));
        exit;
    }
}

if (!function_exists('current_path')) {
    function current_path(): string
    {
        $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $base = app_base_path();
        if ($base !== '' && str_starts_with($path, $base)) {
            $path = substr($path, strlen($base));
        }
        return '/' . trim($path, '/');
    }
}

if (!function_exists('csrf_field')) {
    function csrf_field(): string
    {
        return Csrf::field();
    }
}

if (!function_exists('csrf_token')) {
    function csrf_token(): string
    {
        return Csrf::token();
    }
}

if (!function_exists('flash')) {
    function flash(string $type, string $message): void
    {
        Session::flash($type, $message);
    }
}

if (!function_exists('can')) {
    function can(string $permission): bool
    {
        return Auth::can($permission);
    }
}

if (!function_exists('user')) {
    function user(): ?array
    {
        return Auth::user();
    }
}

if (!function_exists('can_any')) {
    /**
     * Verifica si el usuario actual tiene al menos uno de los permisos indicados.
     * @param array<int,string> $permissions
     */
    function can_any(array $permissions): bool
    {
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($permissions as $permission) {
            if (Auth::can($permission)) {
                return true;
            }
        }
        return false;
    }
}

if (!function_exists('money')) {
    function money(mixed $value, int $decimals = 2): string
    {
        return number_format((float) $value, $decimals, ',', '.');
    }
}

// Controla los valores de cantidad o costo antes de continuar con el inventario.
if (!function_exists('qty')) {
    function qty(mixed $value, int $decimals = 3): string
    {
        $number = (float) $value;
        $formatted = number_format($number, $decimals, ',', '.');
        $formatted = rtrim(rtrim($formatted, '0'), ',');
        return $formatted === '' ? '0' : $formatted;
    }
}

if (!function_exists('fecha')) {
    function fecha(?string $value, bool $withTime = true): string
    {
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($value === null || $value === '' || $value === '0000-00-00 00:00:00') {
            return '—';
        }
        $ts = strtotime($value);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($ts === false) {
            return '—';
        }
        return date($withTime ? 'd/m/Y H:i' : 'd/m/Y', $ts);
    }
}

if (!function_exists('fecha_larga')) {
    function fecha_larga(?string $value): string
    {
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($value === null || $value === '') {
            return '—';
        }
        $ts = strtotime($value);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($ts === false) {
            return '—';
        }
        $months = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
        return date('j', $ts) . ' de ' . $months[(int) date('n', $ts) - 1] . ' de ' . date('Y', $ts);
    }
}

// Verifica el estado actual para impedir cambios fuera del flujo permitido.
if (!function_exists('status_label')) {
    function status_label(string $status): string
    {
        $labels = [
            'BORRADOR' => 'Borrador',
            'EN_APROBACION' => 'En aprobación',
            'APROBADA' => 'Aprobada',
            'OBSERVADA' => 'Observada',
            'ATENDIDA' => 'Atendida',
            'RECHAZADA' => 'Rechazada',
            'ANULADA' => 'Anulada',
            'CONFIRMADO' => 'Confirmado',
            'ANULADO' => 'Anulado',
            'EN_REVISION' => 'En revisión',
            'APROBADO' => 'Aprobado',
            'ACTIVO' => 'Activo',
            'INACTIVO' => 'Inactivo',
            'ARCHIVADO' => 'Archivado',
            'ABIERTO' => 'Abierto',
            'CERRADO' => 'Cerrado',
            'REABIERTO' => 'Reabierto',
            'REGISTRADO' => 'Registrado',
            'ANULADO_FISICO' => 'Anulado',
            'PENDIENTE' => 'Pendiente',
            'NO_DISPONIBLE' => 'No disponible',
            'ENTREGADO' => 'Entregado',
            'DEVUELTO' => 'Devuelto',
            'APROBADO_FINAL' => 'Aprobado final',
            'ABIERTA' => 'Abierta',
            'AGOTADA' => 'Agotada',
            'SOBRANTE' => 'Sobrante',
            'FALTANTE' => 'Faltante',
        ];
        return $labels[$status] ?? ucfirst(strtolower(str_replace('_', ' ', $status)));
    }
}

// Verifica el estado actual para impedir cambios fuera del flujo permitido.
if (!function_exists('status_badge')) {
    function status_badge(string $status): string
    {
        $map = [
            'BORRADOR' => 'secondary',
            'PENDIENTE' => 'secondary',
            'EN_APROBACION' => 'warning',
            'EN_REVISION' => 'warning',
            'OBSERVADA' => 'warning',
            'APROBADA' => 'success',
            'APROBADO' => 'success',
            'CONFIRMADO' => 'success',
            'ACTIVO' => 'success',
            'ENTREGADO' => 'success',
            'RECHAZADA' => 'danger',
            'RECHAZADO' => 'danger',
            'ANULADO' => 'danger',
            'ANULADA' => 'danger',
            'NO_DISPONIBLE' => 'danger',
            'ATENDIDA' => 'primary',
            'CERRADO' => 'primary',
            'REABIERTO' => 'info',
            'INACTIVO' => 'dark',
            'ARCHIVADO' => 'dark',
            'ABIERTO' => 'info',
            'ABIERTA' => 'info',
            'AGOTADA' => 'dark',
        ];
        $class = $map[$status] ?? 'secondary';
        return '<span class="badge text-bg-' . $class . ' badge-status">' . e(status_label($status)) . '</span>';
    }
}

if (!function_exists('selected')) {
    function selected(mixed $a, mixed $b): string
    {
        return (string) $a === (string) $b ? 'selected' : '';
    }
}

if (!function_exists('checked')) {
    function checked(mixed $a): string
    {
        return $a ? 'checked' : '';
    }
}

if (!function_exists('doc_type_label')) {
    function doc_type_label(string $type): string
    {
        $labels = [
            'APERTURA' => 'Apertura',
            'COMPRA' => 'Compra',
            'DONACION' => 'Donación',
            'AJUSTE_SOBRANTE' => 'Ajuste sobrante',
            'RECLASIFICACION' => 'Reclasificación',
            'INGRESO' => 'Ingreso',
            'SALIDA' => 'Salida',
            'DEVOLUCION' => 'Devolución',
            'AJUSTE' => 'Ajuste',
            'ANULACION' => 'Anulación',
            'INGRESO_ANULADO' => 'Ingreso anulado',
        ];
        return $labels[$type] ?? ucfirst(strtolower(str_replace('_', ' ', $type)));
    }
}

// Verifica el estado actual para impedir cambios fuera del flujo permitido.
if (!function_exists('request_status_class')) {
    function request_status_class(string $status): string
    {
        return match ($status) {
            'APROBADA', 'ATENDIDA', 'CONFIRMADO' => 'success',
            'EN_APROBACION', 'EN_REVISION', 'OBSERVADA' => 'warning',
            'RECHAZADA', 'ANULADA', 'ANULADO' => 'danger',
            default => 'secondary',
        };
    }
}

if (!function_exists('is_active_path')) {
    function is_active_path(string $prefix): string
    {
        $path = current_path();
        return ($path === $prefix || str_starts_with($path, rtrim($prefix, '/') . '/')) ? 'active' : '';
    }
}

if (!function_exists('json_response')) {
    function json_response(array $data, int $status = 200): never
    {
        http_response_code($status);
        // Configura la respuesta HTTP que recibirá el navegador.
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}

if (!function_exists('csv_download')) {
    function csv_download(string $filename, array $headers, array $rows): never
    {
        // Configura la respuesta HTTP que recibirá el navegador.
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        // Configura la respuesta HTTP que recibirá el navegador.
        header('Cache-Control: no-store');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, $headers, ';');
        // Recorre los registros consultados para preparar el resultado.
        foreach ($rows as $row) {
            fputcsv($out, $row, ';');
        }
        fclose($out);
        exit;
    }
}
