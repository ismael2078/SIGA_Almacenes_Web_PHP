<?php
// Contiene servicios reutilizables que apoyan el funcionamiento del sistema. Se ocupa de la carga de configuración del entorno.

declare(strict_types=1);

namespace App\Core;

/**
 * Cargador mínimo de archivos .env (sin dependencias).
 */
final class Env
{
    /** @var array<string,string> */
    private static array $values = [];

    // Realiza la operación «load» relacionada con la carga de configuración del entorno.
    public static function load(string $path): void
    {
        if (!is_file($path)) {
            return;
        }

        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($lines === false) {
            return;
        }

        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }
            if (!str_contains($line, '=')) {
                continue;
            }
            [$key, $value] = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);

            if (strlen($value) >= 2) {
                $first = $value[0];
                $last = $value[strlen($value) - 1];
                if (($first === '"' && $last === '"') || ($first === "'" && $last === "'")) {
                    $value = substr($value, 1, -1);
                }
            }

            self::$values[$key] = $value;
            // Comprueba el resultado recibido y evita continuar con datos inexistentes.
            if (getenv($key) === false) {
                putenv("{$key}={$value}");
                $_ENV[$key] = $value;
            }
        }
    }

    // Recupera un valor de configuración o sesión.
    public static function get(string $key, mixed $default = null): mixed
    {
        if (array_key_exists($key, self::$values)) {
            return self::$values[$key];
        }
        $value = getenv($key);
        return $value === false ? $default : $value;
    }
}
