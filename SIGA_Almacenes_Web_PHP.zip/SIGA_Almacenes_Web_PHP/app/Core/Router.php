<?php
// Contiene servicios reutilizables que apoyan el funcionamiento del sistema. Se ocupa de las rutas HTTP.
namespace App\Core;

class Router {
    private array $routes = [];

    // Registra una ruta que responde a peticiones GET.
    public function get(string $uri, string $action): void {
        $this->addRoute('GET', $uri, $action);
    }

    // Registra una ruta que recibe formularios mediante POST.
    public function post(string $uri, string $action): void {
        $this->addRoute('POST', $uri, $action);
    }

    // Asocia una URL con su controlador y método correspondiente.
    private function addRoute(string $method, string $uri, string $action): void {
        $uri = '/' . trim($uri, '/');
        if ($uri === '/') $uri = '';
        $this->routes[] = [
            'method' => $method,
            'pattern' => $this->convertUriToRegex($uri),
            'action' => $action,
            'uri' => $uri
        ];
    }

    // Convierte los parámetros de una URL en patrones reconocibles.
    private function convertUriToRegex(string $uri): string {
        $pattern = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '(?P<$1>[^/]+)', $uri);
        return '#^' . $pattern . '$#';
    }

    // Determina qué controlador atiende la petición recibida.
    public function dispatch(string $requestUri, string $requestMethod): void {
        if ($requestMethod === 'HEAD') {
            $requestMethod = 'GET';
        }
        // Limpiar query strings y normalizar
        $parsedUri = parse_url($requestUri, PHP_URL_PATH) ?: '/';
        // XAMPP: /SIGA_Almacenes_Web_PHP/login -> /login.
        // En la raíz del servidor el prefijo queda vacío.
        $basePath = function_exists('app_base_path') ? app_base_path() : '';
        if ($basePath !== '' && ($parsedUri === $basePath || str_starts_with($parsedUri, $basePath . '/'))) {
            $parsedUri = substr($parsedUri, strlen($basePath)) ?: '/';
        }
        // Permitir además que el index.php se abra directamente.
        if ($parsedUri === '/index.php') {
            $parsedUri = '/';
        }
        $uri = '/' . trim($parsedUri, '/');
        if ($uri === '/') $uri = '';

        // Recorre los pasos de aprobación conservando su orden y responsable.
        foreach ($this->routes as $route) {
            if ($route['method'] !== $requestMethod) {
                continue;
            }

            if (preg_match($route['pattern'], $uri, $matches)) {
                $params = array_filter($matches, fn($key) => !is_int($key), ARRAY_FILTER_USE_KEY);

                [$controllerName, $method] = explode('@', $route['action']);
                $fullControllerClass = "App\\Controllers\\{$controllerName}";

                if (!class_exists($fullControllerClass)) {
                    http_response_code(500);
                    echo "Error interno: Controlador {$fullControllerClass} no encontrado.";
                    return;
                }

                $controller = new $fullControllerClass();
                if (!method_exists($controller, $method)) {
                    http_response_code(500);
                    echo "Error interno: Método {$method} no encontrado en {$fullControllerClass}.";
                    return;
                }

                call_user_func_array([$controller, $method], $params);
                return;
            }
        }

        // Si no se encuentra la ruta:
        http_response_code(404);
        if (str_starts_with($uri, '/api/')) {
            // Configura la respuesta HTTP que recibirá el navegador.
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Endpoint no encontrado (404)']);
            return;
        }

        require __DIR__ . '/../Views/layouts/header.php';
        echo '<div class="container py-5 text-center">
                <div class="display-1 text-muted fw-bold">404</div>
                <h3 class="mt-3">Página no encontrada</h3>
                <p class="text-muted">La ruta solicitada no existe en el sistema SIGA.</p>
                <a href="' . htmlspecialchars(url('/dashboard'), ENT_QUOTES, 'UTF-8') . '" class="btn btn-primary mt-3"><i class="bi bi-house me-2"></i>Ir al Tablero Principal</a>
              </div>';
        require __DIR__ . '/../Views/layouts/footer.php';
    }
}
