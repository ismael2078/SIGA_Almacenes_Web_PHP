<?php
// Contiene servicios reutilizables que apoyan el funcionamiento del sistema. Se ocupa de el acceso común a los datos.
namespace App\Core;

use PDO;

abstract class Model {
    protected string $table = '';
    protected string $primaryKey = 'id';
    protected PDO $db;

    // Inicializa la conexión utilizada por este modelo.
    public function __construct() {
        $this->db = Database::getConnection();
    }

    // Identifica la tabla de base de datos vinculada al modelo.
    public function getTable(): string {
        return $this->table;
    }

    // Consulta todos los registros de la tabla.
    public function all(): array {
        $stmt = $this->db->query("SELECT * FROM `{$this->table}` ORDER BY `{$this->primaryKey}` ASC");
        return $stmt->fetchAll();
    }

    // Busca un registro por su identificador.
    public function find($id): ?array {
        $stmt = $this->db->prepare("SELECT * FROM `{$this->table}` WHERE `{$this->primaryKey}` = ? LIMIT 1");
        $stmt->execute([$id]);
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $row = $stmt->fetch();
        return $row ?: null;
    }

    // Aplica condiciones para consultar registros de la tabla.
    public function where(string $column, $value, string $operator = '='): array {
        $stmt = $this->db->prepare("SELECT * FROM `{$this->table}` WHERE `{$column}` {$operator} ?");
        $stmt->execute([$value]);
        return $stmt->fetchAll();
    }

    // Encuentra el primer registro que coincide con un campo.
    public function findBy(string $column, $value): ?array {
        $stmt = $this->db->prepare("SELECT * FROM `{$this->table}` WHERE `{$column}` = ? LIMIT 1");
        $stmt->execute([$value]);
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $row = $stmt->fetch();
        return $row ?: null;
    }

    // Inserta un registro nuevo utilizando los datos recibidos.
    public function create(array $data): int {
        $fields = array_keys($data);
        $escapedFields = array_map(fn($f) => "`{$f}`", $fields);
        $placeholders = array_fill(0, count($fields), '?');

        // Define los datos que se almacenarán en el registro nuevo.
        $sql = "INSERT INTO `{$this->table}` (" . implode(', ', $escapedFields) . ") VALUES (" . implode(', ', $placeholders) . ")";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(array_values($data));

        return (int)$this->db->lastInsertId();
    }

    // Actualiza un registro existente de forma controlada.
    public function update($id, array $data): bool {
        $fields = array_keys($data);
        $setClauses = array_map(fn($f) => "`{$f}` = ?", $fields);

        // Define los campos que serán actualizados en la base de datos.
        $sql = "UPDATE `{$this->table}` SET " . implode(', ', $setClauses) . " WHERE `{$this->primaryKey}` = ?";
        $params = array_values($data);
        $params[] = $id;

        $stmt = $this->db->prepare($sql);
        return $stmt->execute($params);
    }

    // Elimina un registro según la clave proporcionada.
    public function delete($id): bool {
        $stmt = $this->db->prepare("DELETE FROM `{$this->table}` WHERE `{$this->primaryKey}` = ?");
        return $stmt->execute([$id]);
    }

    // Ejecuta una consulta parametrizada en la base de datos.
    public function query(string $sql, array $params = []): \PDOStatement {
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    // Devuelve todas las filas obtenidas por una consulta.
    public function fetchAll(string $sql, array $params = []): array {
        // Ejecuta la consulta y devuelve directamente el resultado al controlador.
        return $this->query($sql, $params)->fetchAll();
    }

    // Devuelve la primera fila obtenida por una consulta.
    public function fetchOne(string $sql, array $params = []): ?array {
        // Consulta la base de datos y devuelve los registros necesarios para la operación.
        $row = $this->query($sql, $params)->fetch();
        return $row ?: null;
    }
}
