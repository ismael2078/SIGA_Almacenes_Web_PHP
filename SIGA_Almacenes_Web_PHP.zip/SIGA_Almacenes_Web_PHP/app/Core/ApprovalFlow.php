<?php
// Contiene servicios reutilizables que apoyan el funcionamiento del sistema. Se ocupa de la ruta de aprobación por responsables.
namespace App\Core;

use PDO;
use RuntimeException;

/**
 * Enrutamiento de solicitudes basado en approval_routes / approval_route_steps.
 * No crea notificaciones masivas: la bandeja se calcula para el destinatario actual.
 */
final class ApprovalFlow
{
    // Busca la ruta de aprobación activa asignada al área del solicitante.
    public static function routeForArea(PDO $db, int $areaId): ?int
    {
        // Prepara una consulta parametrizada para recuperar información sin concatenar datos del usuario.
        $s = $db->prepare('SELECT id FROM approval_routes WHERE area_id = ? AND is_active = 1 ORDER BY id LIMIT 1');
        $s->execute([$areaId]);
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $v = $s->fetchColumn();
        return $v === false ? null : (int)$v;
    }

    // Obtiene el paso actual y el rol responsable dentro de la ruta.
    public static function step(PDO $db, array $request): ?array
    {
        // Prepara una consulta parametrizada para recuperar información sin concatenar datos del usuario.
        $s = $db->prepare('SELECT s.step_order, s.role_id, ro.code AS role_code
            FROM approval_route_steps s
            INNER JOIN approval_routes ar ON ar.id = s.route_id AND ar.is_active = 1
            INNER JOIN roles ro ON ro.id = s.role_id
            WHERE s.route_id = ? AND s.step_order = ? AND s.is_required = 1 LIMIT 1');
        $s->execute([(int)($request['route_id'] ?? 0), (int)($request['current_step'] ?? 0)]);
        return $s->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /**
     * Devuelve exactamente una persona activa para el paso, o null si falta
     * asignación o hay varios candidatos. Nunca envía a todos los del mismo rol.
     */
    public static function assigneeId(PDO $db, array $request): ?int
    {
        $step = self::step($db, $request);
        // Si no hay etapa activa, no se asigna un aprobador por aproximación.
        if (!$step) return null;
        $roleId = (int)$step['role_id'];
        $roleCode = $step['role_code'];
        $areaId = (int)($request['area_id'] ?? 0);

        // El primer responsable es el jefe designado del funcionario; solo si falta se busca un único jefe de su área.
        if ($roleCode === 'JEFE_INMEDIATO') {
            $q = $db->prepare('SELECT jefe_inmediato_id FROM users WHERE id = ?');
            $q->execute([(int)$request['applicant_id']]);
            // Lee el resultado obtenido de la consulta SQL ejecutada.
            $explicit = $q->fetchColumn();
            if ($explicit !== false && $explicit !== null && (int)$explicit > 0) {
                return self::verifyUser($db, (int)$explicit, $roleId);
            }
            // Si no hay jefe configurado, permitir un único jefe activo del área.
            return self::uniqueUser($db, $roleId, $areaId);
        }

        // En la etapa UAA, primero se consulta el titular asignado a la propia área.
        if ($roleCode === 'JEFE_UAA') {
            $q = $db->prepare('SELECT jefe_uaa_id FROM areas WHERE id = ?');
            $q->execute([$areaId]);
            // Lee el resultado obtenido de la consulta SQL ejecutada.
            $explicit = $q->fetchColumn();
            if ($explicit !== false && $explicit !== null && (int)$explicit > 0) {
                return self::verifyUser($db, (int)$explicit, $roleId);
            }
        }
        // Para almacén y UAA, se requiere un único titular activo de ese rol
        // o una asignación explícita anterior; múltiples titulares NO reciben
        // automáticamente la misma solicitud.
        return self::uniqueUser($db, $roleId, null);
    }

    // Comprueba que el usuario asignado esté activo y tenga el rol esperado.
    private static function verifyUser(PDO $db, int $userId, int $roleId): ?int
    {
        // Prepara una consulta parametrizada para recuperar información sin concatenar datos del usuario.
        $q = $db->prepare('SELECT id FROM users WHERE id = ? AND role_id = ? AND is_active = 1');
        $q->execute([$userId, $roleId]);
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $v = $q->fetchColumn();
        return $v === false ? null : (int)$v;
    }

    // Evita elegir un destinatario ambiguo cuando hay varios usuarios con el mismo rol.
    private static function uniqueUser(PDO $db, int $roleId, ?int $areaId): ?int
    {
        // Construye la consulta de lectura con los campos y relaciones necesarios.
        $sql = 'SELECT id FROM users WHERE role_id = ? AND is_active = 1';
        $params = [$roleId];
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($areaId !== null) { $sql .= ' AND area_id = ?'; $params[] = $areaId; }
        $sql .= ' ORDER BY id LIMIT 2';
        // Prepara una sentencia SQL parametrizada para ejecutar esta operación de forma segura.
        $q = $db->prepare($sql);
        $q->execute($params);
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $ids = $q->fetchAll(PDO::FETCH_COLUMN);
        return count($ids) === 1 ? (int)$ids[0] : null;
    }

    /** Validar toda la ruta antes de enviar, para no dejar pedidos bloqueados. */
    public static function assertSendable(PDO $db, array $request): void
    {
        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (empty($request['route_id'])) {
            throw new RuntimeException('No hay ruta de aprobación activa configurada para esta área.');
        }
        // Prepara una consulta parametrizada para recuperar información sin concatenar datos del usuario.
        $q = $db->prepare('SELECT s.step_order FROM approval_route_steps s
            JOIN approval_routes r ON r.id = s.route_id AND r.is_active = 1
            WHERE s.route_id = ? AND s.is_required = 1 ORDER BY s.step_order ASC');
        $q->execute([(int)$request['route_id']]);
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $steps = $q->fetchAll(PDO::FETCH_COLUMN);
        if (!$steps || (int)$steps[0] !== 1) {
            throw new RuntimeException('La ruta no contiene un primer paso de aprobación válido.');
        }
        // Antes del envío se comprueba cada etapa, no únicamente el jefe inicial.
        foreach ($steps as $stepOrder) {
            $candidate = $request;
            $candidate['current_step'] = (int)$stepOrder;
            $id = self::assigneeId($db, $candidate);
            // Comprueba el resultado recibido y evita continuar con datos inexistentes.
            if ($id === null) {
                throw new RuntimeException('Falta asignar un único responsable activo para el paso ' . $stepOrder . ' del área. Configure el jefe inmediato, almacén o UAA.');
            }
            if ($id === (int)$request['applicant_id']) {
                throw new RuntimeException('El solicitante no puede ser su propio aprobador en el paso ' . $stepOrder . '.');
            }
        }
    }

    // Autoriza la decisión únicamente al responsable del paso vigente.
    public static function canDecide(PDO $db, array $request, array $user): bool
    {
        // Una decisión solo se admite mientras la solicitud sigue en aprobación.
        if (($request['status'] ?? '') !== 'EN_APROBACION') return false;
        if ((int)$request['applicant_id'] === (int)$user['id']) return false;
        // Aplica una restricción de seguridad de acuerdo con el rol o permiso del usuario.
        if (!in_array('aprobaciones.decidir', $user['permissions'] ?? [], true)) return false;
        $step = self::step($db, $request);
        return $step !== null && (int)$step['role_id'] === (int)$user['role_id']
            && self::assigneeId($db, $request) === (int)$user['id'];
    }

    // Devuelve solo las solicitudes pendientes que corresponden al usuario autenticado.
    public static function pendingFor(PDO $db, array $user): array
    {
        // Aplica una restricción de seguridad de acuerdo con el rol o permiso del usuario.
        if (!in_array('aprobaciones.ver', $user['permissions'] ?? [], true)) return [];
        $stmt = $db->prepare('SELECT r.*, u.full_name AS applicant_name, u.position AS applicant_position,
            a.name AS area_name, a.code AS area_code,
            (SELECT COUNT(*) FROM request_items ri WHERE ri.request_id = r.id) AS items_count
            FROM requests r
            JOIN approval_route_steps s ON s.route_id = r.route_id AND s.step_order = r.current_step AND s.is_required = 1
            LEFT JOIN users u ON u.id = r.applicant_id
            LEFT JOIN areas a ON a.id = r.area_id
            WHERE r.status = ? AND s.role_id = ? ORDER BY r.submitted_at ASC, r.id ASC');
        $stmt->execute(['EN_APROBACION', (int)$user['role_id']]);
        // Depura o reorganiza los resultados para entregar únicamente los registros válidos.
        return array_values(array_filter($stmt->fetchAll(PDO::FETCH_ASSOC),
            static fn(array $r): bool => self::assigneeId($db, $r) === (int)$user['id']
                && (int)$r['applicant_id'] !== (int)$user['id']));
    }

    /** Control de lectura: el detalle no debe quedar accesible cambiando el ID en la URL. */
    public static function canView(PDO $db, array $request, array $user): bool
    {
        if ((int)$request['applicant_id'] === (int)$user['id']) return true;
        $role = $user['role_code'] ?? '';
        // Distingue las acciones permitidas según el cargo o rol asignado.
        if (in_array($role, ['ADMIN', 'AUDITOR', 'CONSULTA'], true)
            && in_array('solicitudes.ver_todas', $user['permissions'] ?? [], true)) return true;
        // Distingue las acciones permitidas según el cargo o rol asignado.
        // La pertenencia a un área no da acceso automático a solicitudes ajenas.
        // El jefe solo consulta pedidos asignados a él o que ya aprobó.
        if ($role === 'TECNICO_ALMACEN' && in_array($request['status'], ['APROBADA', 'ATENDIDA'], true)) return true;
        // Verifica el estado actual para impedir cambios fuera del flujo permitido.
        if (self::assigneeId($db, $request) === (int)$user['id'] && $request['status'] === 'EN_APROBACION') return true;
        $q = $db->prepare('SELECT 1 FROM request_approvals WHERE request_id = ? AND approver_user_id = ? LIMIT 1');
        $q->execute([(int)$request['id'], (int)$user['id']]);
        return (bool)$q->fetchColumn();
    }

    // Busca el siguiente paso obligatorio después de una aprobación.
    public static function nextStep(PDO $db, array $request): ?int
    {
        // Prepara una consulta parametrizada para recuperar información sin concatenar datos del usuario.
        $q = $db->prepare('SELECT step_order FROM approval_route_steps WHERE route_id = ?
           AND is_required = 1 AND step_order > ? ORDER BY step_order ASC LIMIT 1');
        $q->execute([(int)$request['route_id'], (int)$request['current_step']]);
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $v = $q->fetchColumn();
        return $v === false ? null : (int)$v;
    }
}
