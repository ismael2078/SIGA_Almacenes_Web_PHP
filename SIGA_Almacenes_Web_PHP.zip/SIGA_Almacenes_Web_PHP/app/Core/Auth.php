<?php
// Contiene servicios reutilizables que apoyan el funcionamiento del sistema. Se ocupa de la autenticación y los permisos.
namespace App\Core;

class Auth {
    private const SESSION_KEY = 'siga_user';

    // Prepara la sesión de usuario y sus datos de acceso.
    public static function init(): void {
        // Verifica el estado actual para impedir cambios fuera del flujo permitido.
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    // Indica si existe una sesión de usuario válida.
    public static function check(): bool {
        self::init();
        return isset($_SESSION[self::SESSION_KEY]) && !empty($_SESSION[self::SESSION_KEY]['id']);
    }

    // Devuelve la información del usuario que inició sesión.
    public static function user(): ?array {
        self::init();
        return $_SESSION[self::SESSION_KEY] ?? null;
    }

    // Obtiene el identificador del usuario autenticado.
    public static function id(): ?int {
        $u = self::user();
        return $u ? (int)$u['id'] : null;
    }

    // Consulta el rol asignado al usuario actual.
    public static function role(): ?string {
        $u = self::user();
        return $u ? $u['role_code'] : null;
    }

    // Obtiene el nombre legible del rol del usuario.
    public static function roleName(): ?string {
        $u = self::user();
        return $u ? $u['role_name'] : null;
    }

    // Comprueba las credenciales y crea la sesión autenticada.
    public static function login(array $userData): void {
        self::init();
        // Cargar permisos asociados al rol
        $db = Database::getConnection();
        // Prepara una sentencia SQL parametrizada para ejecutar esta operación de forma segura.
        $stmt = $db->prepare("
            SELECT p.code 
            FROM permissions p
            INNER JOIN role_permissions rp ON rp.permission_id = p.id
            WHERE rp.role_id = ?
        ");
        $stmt->execute([$userData['role_id']]);
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $perms = $stmt->fetchAll(\PDO::FETCH_COLUMN);

        $userData['permissions'] = $perms;
        // Verifica el estado actual para impedir cambios fuera del flujo permitido.
        if (session_status() === PHP_SESSION_ACTIVE && PHP_SAPI !== 'cli') {
            session_regenerate_id(true);
        }
        $_SESSION[self::SESSION_KEY] = $userData;

        // Registrar auditoría de inicio de sesión
        self::audit('auth.login', 'users', $userData['id'], null, ['ip' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1']);
    }

    // Cierra la sesión y elimina sus datos de autenticación.
    public static function logout(): void {
        self::init();
        if (self::check()) {
            self::audit('auth.logout', 'users', self::id());
        }
        unset($_SESSION[self::SESSION_KEY]);
        session_destroy();
    }

    // Verifica si el rol tiene autorización para ejecutar una acción.
    public static function can(string $permission): bool {
        $u = self::user();
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if (!$u) return false;
        if (($u['role_code'] ?? '') === 'ADMIN') return true;
        $perms = $u['permissions'] ?? [];
        return in_array($permission, $perms, true);
    }

    // Registra una operación para conservar su trazabilidad en auditoría.
    public static function audit(string $action, ?string $entity = null, ?int $entityId = null, $before = null, $after = null): void {
        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            $db = Database::getConnection();
            $userId = self::id();
            $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
            $beforeJson = $before !== null ? json_encode($before, JSON_UNESCAPED_UNICODE) : null;
            $afterJson = $after !== null ? json_encode($after, JSON_UNESCAPED_UNICODE) : null;

            // MySQL usa NOW(); SQLite usa datetime('now').
            $nowSql = (Database::getDriver() === 'mysql') ? "NOW()" : "datetime('now')";
            // Prepara una sentencia SQL parametrizada para ejecutar esta operación de forma segura.
            $stmt = $db->prepare("
                INSERT INTO audit_log (user_id, action, entity, entity_id, `before`, `after`, ip, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, $nowSql)
            ");
            $stmt->execute([$userId, $action, $entity, $entityId, $beforeJson, $afterJson, $ip]);
        // Captura el error para informar el problema y mantener los datos consistentes.
        } catch (\Throwable $e) {
            // Ignorar silenciosamente fallo de auditoría para no bloquear la operación
        }
    }
}
