<?php
// Contiene servicios reutilizables que apoyan el funcionamiento del sistema. Se ocupa de el cálculo de existencias mediante PEPS.
namespace App\Core;

use PDO;
use Exception;

class PepsEngine {

    /**
     * Consume capas PEPS (FIFO) para un producto, de la más antigua a la más nueva.
     * Devuelve las capas consumidas y el costo promedio ponderado.
     */
    public static function consume(int $productId, float $qty): array {
        $db = Database::getConnection();

        // Obtener capas abiertas ordenadas por fecha contable y secuencia
        $stmt = $db->prepare("
            SELECT id, entry_id, sequence, original_qty, remaining_qty, unit_cost, status, layer_date
            FROM stock_layers
            WHERE product_id = ? AND remaining_qty > 0 AND status = 'ABIERTA'
            ORDER BY layer_date ASC, sequence ASC
        ");
        $stmt->execute([$productId]);
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $layers = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $totalAvailable = 0.0;
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($layers as $l) {
            $totalAvailable += (float)$l['remaining_qty'];
        }

        // Controla los valores de cantidad o costo antes de continuar con el inventario.
        if ($totalAvailable < ($qty - 0.0001)) {
            throw new Exception("STOCK_INSUFICIENTE: Existencia disponible " . number_format($totalAvailable, 3) . ", solicitada " . number_format($qty, 3));
        }

        $remainingToConsume = $qty;
        $totalCost = 0.0;
        $consumedLayers = [];

        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($layers as $l) {
            if ($remainingToConsume <= 0.00001) break;

            $layerRem = (float)$l['remaining_qty'];
            $take = min($layerRem, $remainingToConsume);
            $newRem = $layerRem - $take;
            $newStatus = ($newRem <= 0.0001) ? 'AGOTADA' : 'ABIERTA';

            // Actualizar la capa
            $upd = $db->prepare("UPDATE stock_layers SET remaining_qty = ?, status = ? WHERE id = ?");
            $upd->execute([$newRem, $newStatus, $l['id']]);

            $costThisTake = $take * (float)$l['unit_cost'];
            $totalCost += $costThisTake;
            $remainingToConsume -= $take;

            $consumedLayers[] = [
                'layer_id'   => (int)$l['id'],
                'qty'        => $take,
                'unit_cost'  => (float)$l['unit_cost'],
                'total_cost' => $costThisTake,
            ];
        }

        $weightedUnitCost = $qty > 0 ? ($totalCost / $qty) : 0.0;

        return [
            'unit_cost'       => $weightedUnitCost,
            'total_cost'      => $totalCost,
            'consumed_layers' => $consumedLayers,
        ];
    }

    /**
     * Recalcula el stock y valor de un producto a partir de sus capas abiertas.
     */
    public static function recomputeProductStock(int $productId): array {
        $db = Database::getConnection();

        // Prepara una sentencia SQL parametrizada para ejecutar esta operación de forma segura.
        $stmt = $db->prepare("
            SELECT 
                COALESCE(SUM(remaining_qty), 0) AS qty,
                COALESCE(SUM(remaining_qty * unit_cost), 0) AS val
            FROM stock_layers
            WHERE product_id = ? AND status = 'ABIERTA'
        ");
        $stmt->execute([$productId]);
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        $qty = (float)($row['qty'] ?? 0);
        $val = (float)($row['val'] ?? 0);
        $status = ($qty <= 0.0001) ? 'INACTIVO' : 'ACTIVO';

        // Prepara una actualización controlada de los campos que deben modificarse.
        $upd = $db->prepare("UPDATE products SET stock_qty = ?, stock_value = ?, status = ? WHERE id = ?");
        $upd->execute([$qty, $val, $status, $productId]);

        return [
            'stock_qty'   => $qty,
            'stock_value' => $val,
            'status'      => $status,
        ];
    }

    /**
     * Registra un movimiento en Kardex Físico-Valorado y actualiza el saldo contable.
     */
    public static function recordKardex(
        int $productId,
        string $movementDate,
        string $docType,
        ?int $docId,
        string $reference,
        float $qtyIn,
        float $qtyOut,
        float $unitCostIn,
        float $unitCostOut,
        ?int $userId = null
    ): int {
        $db = Database::getConnection();

        // Obtener último saldo de Kardex
        $stmt = $db->prepare("
            SELECT balance_qty, balance_value 
            FROM kardex_movements 
            WHERE product_id = ? 
            ORDER BY id DESC LIMIT 1
        ");
        $stmt->execute([$productId]);
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $last = $stmt->fetch(PDO::FETCH_ASSOC);

        $prevQty = $last ? (float)$last['balance_qty'] : 0.0;
        $prevVal = $last ? (float)$last['balance_value'] : 0.0;

        $totalIn = $qtyIn * $unitCostIn;
        $totalOut = $qtyOut * $unitCostOut;

        $newQty = $prevQty + $qtyIn - $qtyOut;
        $newVal = $prevVal + $totalIn - $totalOut;
        $newUnitCost = $newQty > 0 ? ($newVal / $newQty) : 0.0;

        // Prepara una sentencia SQL parametrizada para ejecutar esta operación de forma segura.
        $ins = $db->prepare("
            INSERT INTO kardex_movements (
                product_id, movement_date, doc_type, doc_id, reference,
                qty_in, qty_out, unit_cost_in, unit_cost_out, total_in, total_out,
                balance_qty, balance_value, balance_unit_cost, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $now = date('Y-m-d H:i:s');
        $ins->execute([
            $productId,
            $movementDate ?: $now,
            $docType,
            $docId,
            $reference,
            $qtyIn,
            $qtyOut,
            $unitCostIn,
            $unitCostOut,
            $totalIn,
            $totalOut,
            $newQty,
            $newVal,
            $newUnitCost,
            $now
        ]);

        return (int)$db->lastInsertId();
    }

    /**
     * Generador atómico de correlativos sin huecos (ej: SOL-2026-000002).
     */
    public static function nextSequence(string $key, int $year): string {
        $db = Database::getConnection();

        $aliasKey = ($key === 'SAL') ? 'DES' : (($key === 'DES') ? 'SAL' : $key);

        // Prepara una consulta parametrizada para recuperar información sin concatenar datos del usuario.
        $stmt = $db->prepare("SELECT id, `key`, current_value FROM sequences WHERE (`key` = ? OR `key` = ?) AND `year` = ?");
        $stmt->execute([$key, $aliasKey, $year]);
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $nextVal = (int)$row['current_value'] + 1;
            // Prepara una actualización controlada de los campos que deben modificarse.
            $upd = $db->prepare("UPDATE sequences SET current_value = ? WHERE id = ?");
            $upd->execute([$nextVal, $row['id']]);
        } else {
            $maxNum = 0;
            if ($key === 'SAL' || $key === 'DES') {
                $maxNum = (int)$db->query("SELECT COUNT(*) FROM stock_dispatches")->fetchColumn();
            } elseif ($key === 'ING') {
                $maxNum = (int)$db->query("SELECT COUNT(*) FROM stock_entries")->fetchColumn();
            } elseif ($key === 'SOL') {
                $maxNum = (int)$db->query("SELECT COUNT(*) FROM requests")->fetchColumn();
            } elseif ($key === 'AJ') {
                $maxNum = (int)$db->query("SELECT COUNT(*) FROM adjustments")->fetchColumn();
            }
            $nextVal = $maxNum + 1;
            // Prepara el registro de datos usando parámetros en lugar de construir SQL manualmente.
            $ins = $db->prepare("INSERT INTO sequences (`key`, `year`, current_value) VALUES (?, ?, ?)");
            $ins->execute([$key, $year, $nextVal]);
        }

        return sprintf("%s-%d-%06d", $key, $year, $nextVal);
    }
}
