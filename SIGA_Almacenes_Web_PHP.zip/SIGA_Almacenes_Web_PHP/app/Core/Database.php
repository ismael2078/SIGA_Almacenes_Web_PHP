<?php
// Contiene servicios reutilizables que apoyan el funcionamiento del sistema. Se ocupa de la conexión y las transacciones.
namespace App\Core;

use PDO;
use PDOException;

class Database {
    private static ?Database $instance = null;
    private ?PDO $pdo = null;
    private string $activeDriver = 'mysql';

    // Configura la conexión PDO según las variables del entorno.
    private function __construct() {
        $config = require __DIR__ . '/../../config/database.php';
        $default = $config['default'];

        // Adapta la instrucción al motor de base de datos utilizado.
        if ($default === 'mysql') {
            try {
                $mc = $config['connections']['mysql'];
                $dsn = "mysql:host={$mc['host']};port={$mc['port']};dbname={$mc['database']};charset={$mc['charset']}";
                $this->pdo = new PDO($dsn, $mc['username'], $mc['password'], $mc['options']);
                $this->activeDriver = 'mysql';
            // Captura el error para informar el problema y mantener los datos consistentes.
            } catch (PDOException $e) {
                // Fallback inteligente para demostración inmediata
                $sc = $config['connections']['sqlite'];
                if (file_exists($sc['database'])) {
                    $this->pdo = new PDO("sqlite:" . $sc['database'], null, null, $sc['options']);
                    $this->pdo->exec("PRAGMA foreign_keys = ON;");
                    $this->activeDriver = 'sqlite';
                } else {
                    throw new PDOException("Error de conexión MySQL y base SQLite no encontrada: " . $e->getMessage());
                }
            }
        } else {
            $sc = $config['connections']['sqlite'];
            $this->pdo = new PDO("sqlite:" . $sc['database'], null, null, $sc['options']);
            $this->pdo->exec("PRAGMA foreign_keys = ON;");
            $this->activeDriver = 'sqlite';
        }
    }

    // Obtiene la instancia compartida del administrador de base de datos.
    public static function getInstance(): Database {
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    // Entrega la conexión actual para ejecutar consultas y transacciones.
    public static function getConnection(): PDO {
        return self::getInstance()->pdo;
    }

    // Informa si se está utilizando MySQL o SQLite.
    public static function getDriver(): string {
        return self::getInstance()->activeDriver;
    }

    // Inicia una transacción para asegurar operaciones de inventario consistentes.
    public static function beginTransaction(): bool {
        // Inicia una transacción: todas las escrituras de esta operación deben confirmarse juntas.
        return self::getConnection()->beginTransaction();
    }

    // Confirma los cambios realizados dentro de la transacción.
    public static function commit(): bool {
        // Confirma los cambios después de completar las validaciones y registros.
        return self::getConnection()->commit();
    }

    // Revierte los cambios cuando una operación no puede completarse.
    public static function rollBack(): bool {
        // Revierte los cambios pendientes si alguna etapa no se completó correctamente.
        return self::getConnection()->rollBack();
    }
}
