<?php
// Contiene servicios reutilizables que apoyan el funcionamiento del sistema. Se ocupa de la presentación de las vistas.

declare(strict_types=1);

namespace App\Core;

/**
 * Renderizador de vistas PHP con layouts.
 */
final class View
{
    // Realiza la operación «render» relacionada con la presentación de las vistas.
    public static function render(string $view, array $data = [], string $layout = 'app'): void
    {
        $viewFile = BASE_PATH . '/app/Views/' . $view . '.php';
        if (!is_file($viewFile)) {
            http_response_code(500);
            echo 'Vista no encontrada: ' . e($view);
            return;
        }

        $data['user'] = $data['user'] ?? Auth::user();
        $data['currentPath'] = current_path();
        extract($data, EXTR_SKIP);

        ob_start();
        require $viewFile;
        $content = ob_get_clean();

        if ($layout === 'none') {
            echo $content;
            return;
        }

        $layoutFile = BASE_PATH . '/app/Views/layouts/' . $layout . '.php';
        if (!is_file($layoutFile)) {
            echo $content;
            return;
        }
        require $layoutFile;
    }

    // Realiza la operación «partial» relacionada con la presentación de las vistas.
    public static function partial(string $view, array $data = []): void
    {
        $viewFile = BASE_PATH . '/app/Views/' . $view . '.php';
        if (is_file($viewFile)) {
            extract($data, EXTR_SKIP);
            require $viewFile;
        }
    }
}
