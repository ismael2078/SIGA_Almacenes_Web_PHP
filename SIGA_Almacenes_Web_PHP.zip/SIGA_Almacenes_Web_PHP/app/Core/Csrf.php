<?php
// Contiene servicios reutilizables que apoyan el funcionamiento del sistema. Se ocupa de la validación de formularios mediante token CSRF.

declare(strict_types=1);

namespace App\Core;

/**
 * Protección CSRF basada en token de sesión.
 */
final class Csrf
{
    // Genera o recupera el token de protección de formularios.
    public static function token(): string
    {
        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (empty($_SESSION['_csrf_token'])) {
            $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['_csrf_token'];
    }

    // Devuelve el campo oculto con el token para usarlo en el formulario.
    public static function field(): string
    {
        return '<input type="hidden" name="_token" value="' . e(self::token()) . '">';
    }

    // Comprueba que el token enviado coincida con el guardado en sesión.
    public static function verify(string $token): bool
    {
        return $token !== '' && hash_equals($_SESSION['_csrf_token'] ?? '', $token);
    }
}
