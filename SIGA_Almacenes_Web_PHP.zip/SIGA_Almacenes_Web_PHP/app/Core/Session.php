<?php
// Contiene servicios reutilizables que apoyan el funcionamiento del sistema. Se ocupa de los datos de la sesión.

declare(strict_types=1);

namespace App\Core;

/**
 * Manejo de mensajes flash y datos temporales de sesión.
 */
final class Session
{
    // Guarda un mensaje temporal para la siguiente pantalla.
    public static function flash(string $type, string $message): void
    {
        $_SESSION['_flash'][] = ['type' => $type, 'message' => $message];
    }

    /** @return array<int,array{type:string,message:string}> */
    public static function consumeFlash(): array
    {
        $messages = $_SESSION['_flash'] ?? [];
        unset($_SESSION['_flash']);
        return $messages;
    }

    // Almacena un dato en la sesión.
    public static function put(string $key, mixed $value): void
    {
        $_SESSION[$key] = $value;
    }

    // Recupera un dato de sesión o su valor predeterminado.
    public static function get(string $key, mixed $default = null): mixed
    {
        return $_SESSION[$key] ?? $default;
    }

    // Elimina una variable específica de la sesión.
    public static function forget(string $key): void
    {
        unset($_SESSION[$key]);
    }

    // Renueva el identificador de sesión por seguridad.
    public static function regenerate(): void
    {
        // Verifica el estado actual para impedir cambios fuera del flujo permitido.
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }
    }
}
