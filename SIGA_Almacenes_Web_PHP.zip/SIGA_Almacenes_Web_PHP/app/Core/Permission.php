<?php
// Contiene servicios reutilizables que apoyan el funcionamiento del sistema. Se ocupa de los permisos según rol.

declare(strict_types=1);

namespace App\Core;

/**
 * Matriz RBAC centralizada del sistema SIGA-DDE.
 * Cada rol agrupa los permisos que habilitan rutas, acciones y elementos de interfaz.
 */
final class Permission
{
    public const ROLES = [
        'ADMIN' => 'Administrador',
        'SOLICITANTE' => 'Solicitante',
        'JEFE_INMEDIATO' => 'Inmediato Superior',
        'JEFE_UAA' => 'Jefatura de UAA',
        'TECNICO_ALMACEN' => 'Técnica de Almacenes',
        'CONSULTA' => 'Consulta',
        'AUDITOR' => 'Auditor del Sistema',
    ];

    /** @var array<string,array<int,string>> */
    public const MAP = [
        'SOLICITANTE' => [
            'solicitudes.crear', 'solicitudes.ver_propias', 'inventario.ver_basico',
            'productos.ver', 'catalogos.ver', 'dashboard.solicitudes',
        ],
        'JEFE_INMEDIATO' => [
            'solicitudes.crear', 'solicitudes.ver_propias', 'solicitudes.ver_area',
            'solicitudes.aprobar', 'solicitudes.reducir', 'solicitudes.devolver', 'solicitudes.rechazar',
            'aprobaciones.ver', 'aprobaciones.decidir', 'dashboard.solicitudes',
            'inventario.ver_basico', 'productos.ver', 'catalogos.ver',
        ],
        'JEFE_UAA' => [
            'solicitudes.crear', 'solicitudes.ver_propias', 'solicitudes.ver_todas', 'solicitudes.ver_area',
            'solicitudes.reducir', 'solicitudes.devolver', 'solicitudes.rechazar', 'solicitudes.autorizar',
            'aprobaciones.ver', 'aprobaciones.decidir', 'dashboard.solicitudes',
            'reportes.ver', 'inventario.ver_stock', 'inventario.ver_valores',
            'productos.ver', 'catalogos.ver', 'arqueo.ver',
            'ajustes.ver', 'ajustes.aprobar', 'ajustes.aprobar_contrataciones', 'ajustes.aprobar_jefatura',
        ],
        'TECNICO_ALMACEN' => [
            'solicitudes.ver_propias', 'solicitudes.ver_todas', 'solicitudes.ver_area',
            'solicitudes.reducir', 'solicitudes.devolver', 'solicitudes.rechazar',
            'aprobaciones.ver', 'aprobaciones.decidir',
            'solicitudes.preparar', 'solicitudes.entregar',
            'inventario.ver_stock', 'inventario.ver_valores', 'productos.ver', 'productos.crear', 'productos.editar',
            'ingresos.ver', 'ingresos.crear', 'ingresos.confirmar', 'ingresos.anular',
            'salidas.ver', 'salidas.preparar', 'salidas.confirmar', 'salidas.anular',
            'ajustes.ver', 'ajustes.crear', 'ajustes.aprobar', 'ajustes.aprobar_almacenes',
            'catalogos.ver', 'catalogos.editar',
            'dashboard.solicitudes', 'dashboard.despachos', 'dashboard.ajustes',
            'reportes.ver', 'reportes.exportar',
            'arqueo.ver', 'arqueo.registrar', 'arqueo.cerrar', 'arqueo.reabrir',
        ],
        'CONSULTA' => [
            'solicitudes.ver_todas', 'inventario.ver_stock', 'inventario.ver_valores',
            'reportes.ver', 'reportes.exportar', 'productos.ver', 'catalogos.ver', 'arqueo.ver',
        ],
        'AUDITOR' => [
            'solicitudes.ver_todas', 'aprobaciones.ver', 'inventario.ver_stock', 'inventario.ver_valores',
            'productos.ver', 'ingresos.ver', 'salidas.ver', 'catalogos.ver',
            'reportes.ver', 'reportes.exportar', 'auditoria.ver',
            'dashboard.solicitudes', 'dashboard.despachos', 'arqueo.ver',
        ],
        'ADMIN' => [
            'solicitudes.crear', 'solicitudes.ver_propias', 'solicitudes.ver_area', 'solicitudes.ver_todas',
            'aprobaciones.ver', 'aprobaciones.decidir', 'dashboard.solicitudes', 'dashboard.ajustes', 'dashboard.despachos',
            'inventario.ver_stock', 'inventario.ver_valores', 'inventario.ver_basico',
            'productos.ver', 'productos.crear', 'productos.editar', 'productos.archivar',
            'ingresos.ver', 'ingresos.crear', 'ingresos.confirmar', 'ingresos.anular',
            'salidas.ver', 'salidas.preparar', 'salidas.confirmar', 'salidas.anular',
            'ajustes.ver', 'ajustes.crear', 'ajustes.aprobar',
            'ajustes.aprobar_almacenes', 'ajustes.aprobar_contrataciones', 'ajustes.aprobar_jefatura',
            'reportes.ver', 'reportes.exportar',
            'catalogos.ver', 'catalogos.editar',
            'usuarios.ver', 'usuarios.editar', 'usuarios.gestionar',
            'auditoria.ver', 'config.ver', 'config.editar',
            'arqueo.ver', 'arqueo.registrar', 'arqueo.cerrar', 'arqueo.reabrir',
        ],
    ];

    // Realiza la operación «forRole» relacionada con los permisos según rol.
    public static function forRole(?string $roleCode): array
    {
        // Distingue las acciones permitidas según el cargo o rol asignado.
        if ($roleCode === null) {
            return [];
        }
        return self::MAP[$roleCode] ?? [];
    }
}
