<?php
// Contiene servicios reutilizables que apoyan el funcionamiento del sistema. Se ocupa de las utilidades compartidas de los controladores.
namespace App\Core;

abstract class Controller {
    // Carga la vista solicitada y le entrega los datos de pantalla.
    protected function render(string $view, array $data = [], string $layout = 'default'): void {
        extract($data);
        $user = Auth::user();
        $flashes = $this->getFlashes();

        ob_start();
        $viewPath = __DIR__ . '/../Views/' . $view . '.php';
        if (!file_exists($viewPath)) {
            throw new \RuntimeException("La vista no existe: {$viewPath}");
        }
        require $viewPath;
        $content = ob_get_clean();

        if ($layout === 'none') {
            echo $content;
            return;
        }

        $layoutPath = __DIR__ . '/../Views/layouts/' . $layout . '.php';
        if (file_exists($layoutPath)) {
            require $layoutPath;
        } else {
            // Layout por defecto incluido en views/layouts/header.php y footer.php
            require __DIR__ . '/../Views/layouts/header.php';
            echo $content;
            require __DIR__ . '/../Views/layouts/footer.php';
        }
    }

    // Devuelve una respuesta JSON con el código HTTP correspondiente.
    protected function json($data, int $statusCode = 200): void {
        http_response_code($statusCode);
        // Configura la respuesta HTTP que recibirá el navegador.
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Redirige a otra ruta y permite mostrar un mensaje al usuario.
    protected function redirect(string $url, ?string $message = null, string $type = 'success'): void {
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if ($message !== null) {
            $this->setFlash($type, $message);
        }
        // Configura la respuesta HTTP que recibirá el navegador.
        header('Location: ' . (preg_match('~^https?://~i', $url) ? $url : url($url)));
        exit;
    }

    // Recupera los valores enviados desde un formulario.
    protected function getPostData(): array {
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        // Comprueba el resultado recibido y evita continuar con datos inexistentes.
        if (stripos($contentType, 'application/json') !== false) {
            $raw = file_get_contents('php://input');
            $data = json_decode($raw, true);
            return is_array($data) ? $data : [];
        }
        // Recupera los valores enviados por el formulario para validarlos en el servidor.
        return $_POST;
    }

    // Guarda un mensaje breve para mostrarlo después de redirigir.
    protected function setFlash(string $type, string $message): void {
        Auth::init();
        $_SESSION['siga_flashes'][] = [
            'type' => $type,
            'message' => $message
        ];
    }

    // Obtiene los mensajes pendientes de mostrar.
    protected function getFlashes(): array {
        Auth::init();
        $flashes = $_SESSION['siga_flashes'] ?? [];
        unset($_SESSION['siga_flashes']);
        return $flashes;
    }

    // Exige una sesión válida antes de continuar.
    protected function requireAuth(): array {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        if (!Auth::check()) {
            $this->redirect('/login', 'Debe iniciar sesión para continuar.', 'warning');
        }
        return Auth::user();
    }

    // Bloquea el acceso cuando falta el permiso solicitado.
    protected function requirePermission(string $permission): array {
        // Confirma la identidad o el permiso antes de permitir esta operación.
        $user = $this->requireAuth();
        if (!Auth::can($permission)) {
            if ($this->isAjax()) {
                $this->json(['error' => 'Acceso denegado: permiso insuficiente.', 'code' => 'FORBIDDEN'], 403);
            }
            // Redirige a la pantalla correspondiente e informa el resultado de la acción.
            $this->redirect('/dashboard', 'No tiene los permisos requeridos para acceder a este módulo.', 'danger');
        }
        return $user;
    }

    // Comprueba si la solicitud HTTP se envió mediante AJAX.
    protected function isAjax(): bool {
        return (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
            || (isset($_SERVER['CONTENT_TYPE']) && stripos($_SERVER['CONTENT_TYPE'], 'application/json') !== false);
    }
}
