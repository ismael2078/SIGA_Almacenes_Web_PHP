<?php
// Archivo auxiliar utilizado para la configuración y ejecución del proyecto.
/**
 * Acceso directo a SIGA-DDE desde la carpeta del proyecto en XAMPP.
 * El controlador frontal MVC original permanece en public/index.php.
 */
declare(strict_types=1);

require __DIR__ . '/public/index.php';
