<?php
// Define los parámetros PDO para conectar con MySQL o SQLite.
/**
 * SIGA-DDE - Configuración de Base de Datos
 * Compatible con MySQL (Workbench) y SQLite (Demostración Inmediata)
 */

return [
    // Driver predeterminado: 'mysql' (o 'sqlite' para demostración inmediata sin servidor MySQL activo)
    // Si 'mysql' está activo pero el servidor MySQL no responde, el sistema conmuta automáticamente
    // al archivo SQLite local precargado con los 181 productos y datos completos para garantizar
    // que la demostración en navegador funcione al 100% sin configuraciones previas.
    'default' => getenv('DB_CONNECTION') ?: 'mysql',

    'connections' => [
        'mysql' => [
            'driver'    => 'mysql',
            'host'      => getenv('DB_HOST') ?: '127.0.0.1',
            'port'      => getenv('DB_PORT') ?: '3306',
            'database'  => getenv('DB_DATABASE') ?: 'siga_db',
            'username'  => getenv('DB_USERNAME') ?: 'root',
            'password'  => getenv('DB_PASSWORD') ?: '',
            'charset'   => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'options'   => [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ],
        ],

        'sqlite' => [
            'driver'   => 'sqlite',
            'database' => __DIR__ . '/../database/siga.sqlite',
            'options'  => [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ],
        ],
    ],
];
