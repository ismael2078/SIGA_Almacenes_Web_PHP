<?php
// Agrupa la configuración principal de la aplicación.

declare(strict_types=1);

return [
    'name' => App\Core\Env::get('APP_NAME', 'SIGA-DDE'),
    'env' => App\Core\Env::get('APP_ENV', 'production'),
    'debug' => filter_var(App\Core\Env::get('APP_DEBUG', 'false'), FILTER_VALIDATE_BOOLEAN),
    'url' => rtrim((string) App\Core\Env::get('APP_URL', ''), '/'),
    'base_path' => rtrim((string) App\Core\Env::get('APP_BASE_PATH', ''), '/'),
    'timezone' => App\Core\Env::get('APP_TIMEZONE', 'America/La_Paz'),
    'locale' => App\Core\Env::get('APP_LOCALE', 'es_BO'),
    'session_name' => App\Core\Env::get('SESSION_NAME', 'siga_session'),
    'session_lifetime' => (int) App\Core\Env::get('SESSION_LIFETIME', 28800),
    'institution' => [
        'name' => 'Dirección Departamental de Educación Cochabamba',
        'short' => 'DDE-CBBA',
        'system' => 'SIGA-DDE',
        'currency' => 'BOB',
    ],
];
