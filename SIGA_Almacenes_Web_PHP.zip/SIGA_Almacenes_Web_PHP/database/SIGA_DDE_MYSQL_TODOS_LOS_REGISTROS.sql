-- Estructura y datos de SIGA-DDE. Los comentarios describen las secciones, no cambian registros.
-- =============================================================
-- SIGA-DDE - SISTEMA INTEGRADO DE GESTION DE ALMACENES
-- Base de datos oficial para MySQL / MySQL Workbench
-- Compatible con MySQL 5.7, 8.0, 8.4+ y MariaDB
-- =============================================================

CREATE DATABASE IF NOT EXISTS `siga_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `siga_db`;

SET FOREIGN_KEY_CHECKS = 0;
SET NAMES utf8mb4;

DROP TABLE IF EXISTS `layer_consumptions`;
DROP TABLE IF EXISTS `dispatch_items`;
DROP TABLE IF EXISTS `stock_dispatches`;
DROP TABLE IF EXISTS `request_history`;
DROP TABLE IF EXISTS `request_approvals`;
DROP TABLE IF EXISTS `request_items`;
DROP TABLE IF EXISTS `requests`;
DROP TABLE IF EXISTS `approval_route_steps`;
DROP TABLE IF EXISTS `approval_routes`;
DROP TABLE IF EXISTS `adjustment_items`;
DROP TABLE IF EXISTS `adjustments`;
DROP TABLE IF EXISTS `kardex_movements`;
DROP TABLE IF EXISTS `stock_layers`;
DROP TABLE IF EXISTS `stock_entry_items`;
DROP TABLE IF EXISTS `stock_entries`;
DROP TABLE IF EXISTS `products`;
DROP TABLE IF EXISTS `user_roles`;
DROP TABLE IF EXISTS `sessions`;
DROP TABLE IF EXISTS `audit_log`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `role_permissions`;
DROP TABLE IF EXISTS `permissions`;
DROP TABLE IF EXISTS `roles`;
DROP TABLE IF EXISTS `areas`;
DROP TABLE IF EXISTS `suppliers`;
DROP TABLE IF EXISTS `locations`;
DROP TABLE IF EXISTS `units`;
DROP TABLE IF EXISTS `subcategories`;
DROP TABLE IF EXISTS `categories`;
DROP TABLE IF EXISTS `period_closes`;
DROP TABLE IF EXISTS `settings`;
DROP TABLE IF EXISTS `sequences`;

-- ================= TABLAS DE CATALOGO =================
-- Tabla categories: almacena información de este componente del sistema.

-- Función: Clasificación principal del catálogo de productos.
CREATE TABLE `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(20) NOT NULL UNIQUE,
  `name` VARCHAR(100) NOT NULL,
  `description` TEXT,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla subcategories: almacena información de este componente del sistema.
-- Función: Clasificación detallada vinculada a las categorías.
CREATE TABLE `subcategories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT NOT NULL,
  `code` VARCHAR(20) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  UNIQUE KEY `subcategories_category_code_unq` (`category_id`, `code`),
  CONSTRAINT `fk_subcategories_cat` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla units: almacena información de este componente del sistema.
-- Función: Unidades de medida utilizadas en los movimientos.
CREATE TABLE `units` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(10) NOT NULL UNIQUE,
  `name` VARCHAR(60) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla locations: almacena información de este componente del sistema.
-- Función: Ubicaciones físicas de los productos dentro del almacén.
CREATE TABLE `locations` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(30) NOT NULL UNIQUE,
  `name` VARCHAR(100) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla suppliers: almacena información de este componente del sistema.
-- Función: Proveedores registrados para los ingresos de materiales.
CREATE TABLE `suppliers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nit` VARCHAR(30) UNIQUE,
  `name` VARCHAR(200) NOT NULL,
  `contact_name` VARCHAR(120),
  `phone` VARCHAR(50),
  `email` VARCHAR(120),
  `address` TEXT,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla areas: almacena información de este componente del sistema.
-- Función: Dependencias institucionales que solicitan materiales.
CREATE TABLE `areas` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `parent_id` INT DEFAULT NULL,
  `code` VARCHAR(30) NOT NULL UNIQUE,
  `name` VARCHAR(150) NOT NULL,
  `type` VARCHAR(30) NOT NULL DEFAULT 'UNIDAD',
  `jefe_uaa_id` INT DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= TABLAS DE SEGURIDAD =================
-- Tabla roles: almacena información de este componente del sistema.

-- Función: Perfiles que determinan responsabilidades dentro del sistema.
CREATE TABLE `roles` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(30) NOT NULL UNIQUE,
  `name` VARCHAR(80) NOT NULL,
  `description` TEXT,
  `is_system` TINYINT(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla permissions: almacena información de este componente del sistema.
-- Función: Acciones protegidas que puede ejecutar cada perfil.
CREATE TABLE `permissions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(60) NOT NULL UNIQUE,
  `module` VARCHAR(40) NOT NULL,
  `description` VARCHAR(200)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla role_permissions: almacena información de este componente del sistema.
-- Función: Relación entre roles y permisos asignados.
CREATE TABLE `role_permissions` (
  `role_id` INT NOT NULL,
  `permission_id` INT NOT NULL,
  PRIMARY KEY (`role_id`, `permission_id`),
  CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_role_permissions_perm` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla users: almacena información de este componente del sistema.
-- Función: Cuentas del personal, datos de acceso, área y responsable inmediato.
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(40) NOT NULL UNIQUE,
  `email` VARCHAR(120),
  `password_hash` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(200) NOT NULL,
  `ci` VARCHAR(30),
  `position` VARCHAR(120),
  `office` VARCHAR(120),
  `area_id` INT DEFAULT NULL,
  `jefe_inmediato_id` INT DEFAULT NULL,
  `role_id` INT NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `must_change_password` TINYINT(1) NOT NULL DEFAULT 1,
  `failed_attempts` INT NOT NULL DEFAULT 0,
  `locked_until` DATETIME DEFAULT NULL,
  `last_login_at` DATETIME DEFAULT NULL,
  `password_changed_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `fk_users_area` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla user_roles: almacena información de este componente del sistema.
CREATE TABLE `user_roles` (
  `user_id` INT NOT NULL,
  `role_id` INT NOT NULL,
  PRIMARY KEY (`user_id`, `role_id`),
  CONSTRAINT `fk_user_roles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_user_roles_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla sessions: almacena información de este componente del sistema.
CREATE TABLE `sessions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `token_hash` VARCHAR(200) NOT NULL UNIQUE,
  `ip` VARCHAR(60),
  `user_agent` TEXT,
  `expires_at` DATETIME NOT NULL,
  `revoked_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= TABLA DE PRODUCTOS =================
-- Tabla products: almacena información de este componente del sistema.

-- Función: Catálogo de artículos con existencias y valores referenciales.
CREATE TABLE `products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(30) NOT NULL UNIQUE,
  `name` VARCHAR(200) NOT NULL,
  `description` TEXT,
  `brand` VARCHAR(80),
  `category_id` INT NOT NULL,
  `subcategory_id` INT NOT NULL,
  `unit_id` INT NOT NULL,
  `location_id` INT DEFAULT NULL,
  `min_stock` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `max_stock` DECIMAL(14,3) DEFAULT 0.000,
  `reference_cost` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `stock_qty` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `stock_value` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `status` VARCHAR(20) NOT NULL DEFAULT 'ACTIVO',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_products_status` (`status`),
  INDEX `idx_products_cat` (`category_id`, `subcategory_id`),
  CONSTRAINT `fk_products_cat` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `fk_products_sub` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`id`),
  CONSTRAINT `fk_products_unit` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`),
  CONSTRAINT `fk_products_loc` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= INGRESOS Y CAPAS PEPS =================
-- Tabla stock_entries: almacena información de este componente del sistema.

-- Función: Documentos de ingreso al almacén.
CREATE TABLE `stock_entries` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `number` VARCHAR(30) NOT NULL UNIQUE,
  `type` VARCHAR(30) NOT NULL,
  `supplier_id` INT DEFAULT NULL,
  `doc_type` VARCHAR(40),
  `doc_number` VARCHAR(60),
  `doc_date` DATETIME,
  `entry_date` DATETIME NOT NULL,
  `posted_at` DATETIME,
  `total_amount` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `notes` TEXT,
  `status` VARCHAR(20) NOT NULL DEFAULT 'BORRADOR',
  `voided_by` INT DEFAULT NULL,
  `voided_at` DATETIME DEFAULT NULL,
  `void_reason` TEXT,
  `created_by` INT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_entries_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_entries_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla stock_entry_items: almacena información de este componente del sistema.
-- Función: Detalle de productos, cantidades y costos ingresados.
CREATE TABLE `stock_entry_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `entry_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `location_id` INT DEFAULT NULL,
  `quantity` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `total` DECIMAL(16,2) NOT NULL,
  `notes` TEXT,
  CONSTRAINT `fk_entry_items_entry` FOREIGN KEY (`entry_id`) REFERENCES `stock_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_entry_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla stock_layers: almacena información de este componente del sistema.
-- Función: Capas de ingreso que permiten valorar existencias según PEPS.
CREATE TABLE `stock_layers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `product_id` INT NOT NULL,
  `entry_id` INT NOT NULL,
  `entry_item_id` INT DEFAULT NULL,
  `layer_date` DATETIME NOT NULL,
  `sequence` INT NOT NULL DEFAULT 1,
  `original_qty` DECIMAL(14,3) NOT NULL,
  `remaining_qty` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'ABIERTA',
  INDEX `idx_layers_product_date` (`product_id`, `layer_date`, `sequence`),
  CONSTRAINT `fk_layers_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `fk_layers_entry` FOREIGN KEY (`entry_id`) REFERENCES `stock_entries` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= RUTAS Y SOLICITUDES =================
-- Tabla approval_routes: almacena información de este componente del sistema.

-- Función: Rutas institucionales de aprobación definidas por área.
CREATE TABLE `approval_routes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `area_id` INT DEFAULT NULL,
  `name` VARCHAR(100) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  CONSTRAINT `fk_approval_routes_area` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla approval_route_steps: almacena información de este componente del sistema.
-- Función: Orden y rol responsable de cada etapa de aprobación.
CREATE TABLE `approval_route_steps` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `route_id` INT NOT NULL,
  `step_order` INT NOT NULL,
  `role_id` INT NOT NULL,
  `sla_hours` INT NOT NULL DEFAULT 48,
  `is_required` TINYINT(1) NOT NULL DEFAULT 1,
  CONSTRAINT `fk_steps_route` FOREIGN KEY (`route_id`) REFERENCES `approval_routes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_steps_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla requests: almacena información de este componente del sistema.
-- Función: Cabeceras de pedidos con estado, solicitante y ruta.
CREATE TABLE `requests` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(30) NOT NULL UNIQUE,
  `correspondence_number` VARCHAR(60) NOT NULL UNIQUE,
  `applicant_id` INT NOT NULL,
  `area_id` INT NOT NULL,
  `office` VARCHAR(120),
  `justification` TEXT,
  `route_id` INT DEFAULT NULL,
  `current_step` INT NOT NULL DEFAULT 0,
  `status` VARCHAR(30) NOT NULL DEFAULT 'BORRADOR',
  `submitted_at` DATETIME DEFAULT NULL,
  `approved_at` DATETIME DEFAULT NULL,
  `closed_at` DATETIME DEFAULT NULL,
  `rejection_reason` TEXT,
  `observation` TEXT,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_requests_user` FOREIGN KEY (`applicant_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_requests_area` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla request_items: almacena información de este componente del sistema.
-- Función: Productos y cantidades solicitadas y autorizadas.
CREATE TABLE `request_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `request_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `qty_requested` DECIMAL(14,3) NOT NULL,
  `qty_approved` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `qty_proposed` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `qty_authorized` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `qty_delivered` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `stock_at_request` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `status` VARCHAR(20) NOT NULL DEFAULT 'PENDIENTE',
  `notes` TEXT,
  CONSTRAINT `fk_req_items_request` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_req_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla request_approvals: almacena información de este componente del sistema.
-- Función: Decisiones, observaciones y responsables de cada etapa.
CREATE TABLE `request_approvals` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `request_id` INT NOT NULL,
  `step_order` INT NOT NULL,
  `approver_user_id` INT DEFAULT NULL,
  `role_id` INT NOT NULL,
  `action` VARCHAR(20) NOT NULL DEFAULT 'PENDIENTE',
  `action_at` DATETIME DEFAULT NULL,
  `comments` TEXT,
  CONSTRAINT `fk_req_appr_request` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_req_appr_user` FOREIGN KEY (`approver_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_req_appr_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla request_history: almacena información de este componente del sistema.
-- Función: Historial de cambios de estado de las solicitudes.
CREATE TABLE `request_history` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `request_id` INT NOT NULL,
  `from_state` VARCHAR(30) NOT NULL,
  `to_state` VARCHAR(30) NOT NULL,
  `actor_id` INT NOT NULL,
  `role_id` INT NOT NULL,
  `comments` TEXT,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_req_hist_req` (`request_id`, `created_at`),
  CONSTRAINT `fk_req_hist_req` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_req_hist_actor` FOREIGN KEY (`actor_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_req_hist_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= DESPACHOS Y CONSUMOS PEPS =================
-- Tabla stock_dispatches: almacena información de este componente del sistema.

-- Función: Documentos de salida y entregas de inventario.
CREATE TABLE `stock_dispatches` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `number` VARCHAR(30) NOT NULL UNIQUE,
  `request_id` INT NOT NULL,
  `dispatch_date` DATETIME NOT NULL,
  `dispatched_by` INT NOT NULL,
  `received_by` VARCHAR(200),
  `received_ci` VARCHAR(30),
  `received_signature_at` DATETIME DEFAULT NULL,
  `total_value` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `status` VARCHAR(20) NOT NULL DEFAULT 'BORRADOR',
  `voided_by` INT DEFAULT NULL,
  `voided_at` DATETIME DEFAULT NULL,
  `void_reason` TEXT,
  `notes` TEXT,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_dispatches_req` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`),
  CONSTRAINT `fk_dispatches_user` FOREIGN KEY (`dispatched_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla dispatch_items: almacena información de este componente del sistema.
CREATE TABLE `dispatch_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `dispatch_id` INT NOT NULL,
  `request_item_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `qty` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `total_value` DECIMAL(16,2) NOT NULL,
  CONSTRAINT `fk_disp_items_disp` FOREIGN KEY (`dispatch_id`) REFERENCES `stock_dispatches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_disp_items_reqitem` FOREIGN KEY (`request_item_id`) REFERENCES `request_items` (`id`),
  CONSTRAINT `fk_disp_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla layer_consumptions: almacena información de este componente del sistema.
CREATE TABLE `layer_consumptions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `dispatch_item_id` INT NOT NULL,
  `layer_id` INT NOT NULL,
  `qty` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `total_value` DECIMAL(16,2) NOT NULL,
  CONSTRAINT `fk_layer_cons_item` FOREIGN KEY (`dispatch_item_id`) REFERENCES `dispatch_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_layer_cons_layer` FOREIGN KEY (`layer_id`) REFERENCES `stock_layers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= KARDEX =================
-- Tabla kardex_movements: almacena información de este componente del sistema.

-- Función: Movimientos históricos de entrada, salida y saldo.
CREATE TABLE `kardex_movements` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `product_id` INT NOT NULL,
  `movement_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `doc_type` VARCHAR(20) NOT NULL,
  `doc_id` INT DEFAULT NULL,
  `reference` VARCHAR(60),
  `qty_in` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `qty_out` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `unit_cost_in` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `unit_cost_out` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `total_in` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `total_out` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `balance_qty` DECIMAL(14,3) NOT NULL,
  `balance_value` DECIMAL(16,2) NOT NULL,
  `balance_unit_cost` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_kardex_product_date` (`product_id`, `movement_date`),
  CONSTRAINT `fk_kardex_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= AJUSTES =================
-- Tabla adjustments: almacena información de este componente del sistema.

-- Función: Ajustes autorizados sobre las cantidades de inventario.
CREATE TABLE `adjustments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `number` VARCHAR(30) NOT NULL UNIQUE,
  `type` VARCHAR(20) NOT NULL,
  `reason` TEXT NOT NULL,
  `act_number` VARCHAR(60),
  `adjustment_date` DATETIME NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'BORRADOR',
  `approved_almacenes_by` INT DEFAULT NULL,
  `approved_almacenes_at` DATETIME DEFAULT NULL,
  `approved_contrataciones_by` INT DEFAULT NULL,
  `approved_contrataciones_at` DATETIME DEFAULT NULL,
  `approved_admin_by` INT DEFAULT NULL,
  `approved_admin_at` DATETIME DEFAULT NULL,
  `created_by` INT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_adjustments_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla adjustment_items: almacena información de este componente del sistema.
CREATE TABLE `adjustment_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `adjustment_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `qty` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `total_value` DECIMAL(16,2) NOT NULL,
  `notes` TEXT,
  CONSTRAINT `fk_adj_items_adj` FOREIGN KEY (`adjustment_id`) REFERENCES `adjustments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_adj_items_prod` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= PERIODOS, AUDITORIA Y CONFIGURACION =================
-- Tabla period_closes: almacena información de este componente del sistema.

CREATE TABLE `period_closes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `year` INT NOT NULL,
  `month` INT NOT NULL,
  `closed_at` DATETIME DEFAULT NULL,
  `closed_by` INT DEFAULT NULL,
  `total_qty_snapshot` DECIMAL(14,3) DEFAULT 0.000,
  `total_value_snapshot` DECIMAL(16,2) DEFAULT 0.00,
  `status` VARCHAR(20) NOT NULL DEFAULT 'ABIERTO',
  `reopen_reason` TEXT,
  UNIQUE KEY `period_closes_year_month_unq` (`year`, `month`),
  CONSTRAINT `fk_period_closes_user` FOREIGN KEY (`closed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla audit_log: almacena información de este componente del sistema.
CREATE TABLE `audit_log` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT DEFAULT NULL,
  `action` VARCHAR(60) NOT NULL,
  `entity` VARCHAR(60),
  `entity_id` INT,
  `before` JSON,
  `after` JSON,
  `ip` VARCHAR(60),
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla settings: almacena información de este componente del sistema.
CREATE TABLE `settings` (
  `key` VARCHAR(80) PRIMARY KEY,
  `value` JSON
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla sequences: almacena información de este componente del sistema.
CREATE TABLE `sequences` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `key` VARCHAR(30) NOT NULL,
  `year` INT NOT NULL,
  `current_value` INT NOT NULL DEFAULT 0,
  UNIQUE KEY `sequences_key_year_unq` (`key`, `year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- DATOS COMPLETOS MIGRADOS DESDE database/siga.sqlite DEL ZIP ORIGINAL
-- Este script recrea las tablas y sustituye TODOS los datos que ya existan en siga_db.
-- Incluye registros operativos y datos de pruebas que no estaban en mysql_schema_and_seed.sql.
-- HAZ COPIA DE SEGURIDAD antes de importar; NO ejecutar sobre una base con datos nuevos.

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- adjustment_items: 1 registros
INSERT INTO `adjustment_items` (`id`, `adjustment_id`, `product_id`, `qty`, `unit_cost`, `total_value`, `notes`) VALUES
(1, 1, 68, 2.0, 18.0, 36.0, 'Faltante de papel institucional 500m');

-- adjustments: 1 registros
INSERT INTO `adjustments` (`id`, `number`, `type`, `reason`, `act_number`, `adjustment_date`, `status`, `approved_almacenes_by`, `approved_almacenes_at`, `approved_contrataciones_by`, `approved_contrataciones_at`, `approved_admin_by`, `approved_admin_at`, `created_by`, `created_at`) VALUES
(1, 'AJ-2026-000001', 'FALTANTE', 'Diferencia detectada en conteo físico de material de limpieza del 09/08/2026', 'ACTA-AJ-001', '2026-08-15 10:00:00', 'EN_REVISION', NULL, NULL, NULL, NULL, NULL, NULL, 5, '2026-10-27 23:36:12');

-- approval_route_steps: 24 registros
INSERT INTO `approval_route_steps` (`id`, `route_id`, `step_order`, `role_id`, `sla_hours`, `is_required`) VALUES
(1, 1, 1, 3, 48, 1),
(2, 1, 2, 5, 48, 1),
(3, 1, 3, 4, 48, 1),
(4, 2, 1, 3, 48, 1),
(5, 2, 2, 5, 48, 1),
(6, 2, 3, 4, 48, 1),
(7, 3, 1, 3, 48, 1),
(8, 3, 2, 5, 48, 1),
(9, 3, 3, 4, 48, 1),
(10, 4, 1, 3, 48, 1),
(11, 4, 2, 5, 48, 1),
(12, 4, 3, 4, 48, 1),
(13, 5, 1, 3, 48, 1),
(14, 5, 2, 5, 48, 1),
(15, 5, 3, 4, 48, 1),
(16, 6, 1, 3, 48, 1),
(17, 6, 2, 5, 48, 1),
(18, 6, 3, 4, 48, 1),
(19, 7, 1, 3, 48, 1),
(20, 7, 2, 5, 48, 1),
(21, 7, 3, 4, 48, 1),
(22, 8, 1, 3, 48, 1),
(23, 8, 2, 5, 48, 1),
(24, 8, 3, 4, 48, 1);

-- approval_routes: 8 registros
INSERT INTO `approval_routes` (`id`, `area_id`, `name`, `is_active`) VALUES
(1, 1, 'Ruta estándar - Dirección Departamental de Educación', 1),
(2, 2, 'Ruta estándar - Dirección Administrativa', 1),
(3, 3, 'Ruta estándar - Subdirección Académica', 1),
(4, 4, 'Ruta estándar - Almacén', 1),
(5, 5, 'Ruta estándar - Contrataciones', 1),
(6, 6, 'Ruta estándar - Jefatura de Asuntos Administrativos', 1),
(7, 7, 'Ruta estándar - Finanzas', 1),
(8, 8, 'Ruta estándar - Recursos Humanos', 1);

-- areas: 8 registros
INSERT INTO `areas` (`id`, `parent_id`, `code`, `name`, `type`, `jefe_uaa_id`, `is_active`) VALUES
(1, NULL, 'DDE', 'Dirección Departamental de Educación', 'DIRECCION', NULL, 1),
(2, NULL, 'ADM', 'Dirección Administrativa', 'DIRECCION', NULL, 1),
(3, NULL, 'ACA', 'Subdirección Académica', 'DIRECCION', NULL, 1),
(4, 2, 'ALM', 'Almacén', 'UNIDAD', NULL, 1),
(5, 2, 'CON', 'Contrataciones', 'UNIDAD', NULL, 1),
(6, 2, 'JAA', 'Jefatura de Asuntos Administrativos', 'UNIDAD', NULL, 1),
(7, 2, 'FIN', 'Finanzas', 'UNIDAD', NULL, 1),
(8, 1, 'REC', 'Recursos Humanos', 'DEPENDENCIA', NULL, 1);

-- audit_log: 0 registros

-- categories: 6 registros
INSERT INTO `categories` (`id`, `code`, `name`, `description`, `is_active`) VALUES
(1, 'PAP', 'Papelería y escritorio', 'Material de oficina, hojas y cartulinas', 1),
(2, 'TIN', 'Tintas y tóners', 'Cartuchos de tinta y tóner para impresión', 1),
(3, 'LIM', 'Limpieza e higiene', 'Productos de limpieza y desinfección', 1),
(4, 'INF', 'Informática', 'Accesorios, cables y periféricos de computación', 1),
(5, 'ESC', 'Escritorio y mobiliario menor', 'Accesorios de escritorio y archivo', 1),
(6, 'ELE', 'Eléctrico', 'Material eléctrico y luminarias', 1);

-- dispatch_items: 4 registros
INSERT INTO `dispatch_items` (`id`, `dispatch_id`, `request_item_id`, `product_id`, `qty`, `unit_cost`, `total_value`) VALUES
(1, 1, 1, 1, 2.0, 32.5, 65.0),
(2, 1, 2, 2, 2.0, 38.2, 76.4),
(3, 1, 3, 3, 2.0, 30.8, 61.6),
(4, 2, 4, 1, 3.0, 32.5, 97.5);

-- kardex_movements: 185 registros
INSERT INTO `kardex_movements` (`id`, `product_id`, `movement_date`, `doc_type`, `doc_id`, `reference`, `qty_in`, `qty_out`, `unit_cost_in`, `unit_cost_out`, `total_in`, `total_out`, `balance_qty`, `balance_value`, `balance_unit_cost`, `created_at`) VALUES
(1, 1, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 480.0, 0.0, 32.5, 0.0, 15600.0, 0.0, 480.0, 15600.0, 32.5, '2026-10-27 23:36:12'),
(2, 2, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 85.0, 0.0, 38.2, 0.0, 3247.0, 0.0, 85.0, 3247.0, 38.2, '2026-10-27 23:36:12'),
(3, 3, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.0, 0.0, 30.8, 0.0, 1848.0, 0.0, 60.0, 1848.0, 30.8, '2026-10-27 23:36:12'),
(4, 4, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 24.0, 0.0, 95.0, 0.0, 2280.0, 0.0, 24.0, 2280.0, 95.0, '2026-10-27 23:36:12'),
(5, 5, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 140.0, 0.0, 1.5, 0.0, 210.0, 0.0, 140.0, 210.0, 1.5, '2026-10-27 23:36:12'),
(6, 6, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 15.0, 0.0, 34.0, 0.0, 510.0, 0.0, 15.0, 510.0, 34.0, '2026-10-27 23:36:12'),
(7, 7, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 540.0, 0.0, 2.8, 0.0, 1512.0, 0.0, 540.0, 1512.0, 2.8, '2026-10-27 23:36:12'),
(8, 8, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 430.0, 0.0, 2.8, 0.0, 1204.0, 0.0, 430.0, 1204.0, 2.8, '2026-10-27 23:36:12'),
(9, 9, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 320.0, 0.0, 2.8, 0.0, 896.0, 0.0, 320.0, 896.0, 2.8, '2026-10-27 23:36:12'),
(10, 10, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 150.0, 0.0, 2.8, 0.0, 420.0, 0.0, 150.0, 420.0, 2.8, '2026-10-27 23:36:12'),
(11, 11, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 600.0, 0.0, 1.2, 0.0, 720.0, 0.0, 600.0, 720.0, 1.2, '2026-10-27 23:36:12'),
(12, 12, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 120.0, 0.0, 1.5, 0.0, 180.0, 0.0, 120.0, 180.0, 1.5, '2026-10-27 23:36:12'),
(13, 13, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 88.0, 0.0, 5.5, 0.0, 484.0, 0.0, 88.0, 484.0, 5.5, '2026-10-27 23:36:12'),
(14, 14, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 75.0, 0.0, 5.5, 0.0, 412.5, 0.0, 75.0, 412.5, 5.5, '2026-10-27 23:36:12'),
(15, 15, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.0, 0.0, 5.5, 0.0, 330.0, 0.0, 60.0, 330.0, 5.5, '2026-10-27 23:36:12'),
(16, 16, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 95.0, 0.0, 6.0, 0.0, 570.0, 0.0, 95.0, 570.0, 6.0, '2026-10-27 23:36:12'),
(17, 17, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 70.0, 0.0, 6.0, 0.0, 420.0, 0.0, 70.0, 420.0, 6.0, '2026-10-27 23:36:12'),
(18, 18, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 55.0, 0.0, 6.0, 0.0, 330.0, 0.0, 55.0, 330.0, 6.0, '2026-10-27 23:36:12'),
(19, 19, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 250.0, 0.0, 4.5, 0.0, 1125.0, 0.0, 250.0, 1125.0, 4.5, '2026-10-27 23:36:12'),
(20, 20, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 200.0, 0.0, 6.8, 0.0, 1360.0, 0.0, 200.0, 1360.0, 6.8, '2026-10-27 23:36:12'),
(21, 21, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 95.0, 0.0, 22.0, 0.0, 2090.0, 0.0, 95.0, 2090.0, 22.0, '2026-10-27 23:36:12'),
(22, 22, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 65.0, 0.0, 28.0, 0.0, 1820.0, 0.0, 65.0, 1820.0, 28.0, '2026-10-27 23:36:12'),
(23, 23, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 180.0, 0.0, 7.5, 0.0, 1350.0, 0.0, 180.0, 1350.0, 7.5, '2026-10-27 23:36:12'),
(24, 24, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 540.0, 0.0, 0.9, 0.0, 486.0, 0.0, 540.0, 486.0, 0.9, '2026-10-27 23:36:12'),
(25, 25, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 420.0, 0.0, 1.2, 0.0, 504.0, 0.0, 420.0, 504.0, 1.2, '2026-10-27 23:36:12'),
(26, 26, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 380.0, 0.0, 1.0, 0.0, 380.0, 0.0, 380.0, 380.0, 1.0, '2026-10-27 23:36:12'),
(27, 27, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 150.0, 0.0, 2.5, 0.0, 375.0, 0.0, 150.0, 375.0, 2.5, '2026-10-27 23:36:12'),
(28, 28, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 220.0, 0.0, 1.1, 0.0, 242.0, 0.0, 220.0, 242.0, 1.1, '2026-10-27 23:36:12'),
(29, 29, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 85.0, 0.0, 7.5, 0.0, 637.5, 0.0, 85.0, 637.5, 7.5, '2026-10-27 23:36:12'),
(30, 30, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.0, 0.0, 9.0, 0.0, 540.0, 0.0, 60.0, 540.0, 9.0, '2026-10-27 23:36:12'),
(31, 31, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 120.0, 0.0, 4.5, 0.0, 540.0, 0.0, 120.0, 540.0, 4.5, '2026-10-27 23:36:12'),
(32, 32, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 40.0, 0.0, 5.0, 0.0, 200.0, 0.0, 40.0, 200.0, 5.0, '2026-10-27 23:36:12'),
(33, 33, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 150.0, 0.0, 5.0, 0.0, 750.0, 0.0, 150.0, 750.0, 5.0, '2026-10-27 23:36:12'),
(34, 34, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 70.0, 0.0, 9.5, 0.0, 665.0, 0.0, 70.0, 665.0, 9.5, '2026-10-27 23:36:12'),
(35, 35, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 45.0, 0.0, 16.0, 0.0, 720.0, 0.0, 45.0, 720.0, 16.0, '2026-10-27 23:36:12'),
(36, 36, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 130.0, 0.0, 6.0, 0.0, 780.0, 0.0, 130.0, 780.0, 6.0, '2026-10-27 23:36:12'),
(37, 37, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 35.0, 0.0, 12.0, 0.0, 420.0, 0.0, 35.0, 420.0, 12.0, '2026-10-27 23:36:12'),
(38, 38, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.0, 0.0, 28.0, 0.0, 504.0, 0.0, 18.0, 504.0, 28.0, '2026-10-27 23:36:12'),
(39, 39, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 220.0, 0.0, 1.0, 0.0, 220.0, 0.0, 220.0, 220.0, 1.0, '2026-10-27 23:36:12'),
(40, 40, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.0, 0.0, 2.5, 0.0, 150.0, 0.0, 60.0, 150.0, 2.5, '2026-10-27 23:36:12'),
(41, 41, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 90.0, 0.0, 18.0, 0.0, 1620.0, 0.0, 90.0, 1620.0, 18.0, '2026-10-27 23:36:12'),
(42, 42, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 75.0, 0.0, 9.5, 0.0, 712.5, 0.0, 75.0, 712.5, 9.5, '2026-10-27 23:36:12'),
(43, 43, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 55.0, 0.0, 11.0, 0.0, 605.0, 0.0, 55.0, 605.0, 11.0, '2026-10-27 23:36:12'),
(44, 44, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.0, 0.0, 3.5, 0.0, 105.0, 0.0, 30.0, 105.0, 3.5, '2026-10-27 23:36:12'),
(45, 45, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 22.0, 0.0, 65.0, 0.0, 1430.0, 0.0, 22.0, 1430.0, 65.0, '2026-10-27 23:36:12'),
(46, 46, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 28.0, 0.0, 38.0, 0.0, 1064.0, 0.0, 28.0, 1064.0, 38.0, '2026-10-27 23:36:12'),
(47, 47, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 25.0, 0.0, 45.0, 0.0, 1125.0, 0.0, 25.0, 1125.0, 45.0, '2026-10-27 23:36:12'),
(48, 48, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 50.0, 0.0, 22.0, 0.0, 1100.0, 0.0, 50.0, 1100.0, 22.0, '2026-10-27 23:36:12'),
(49, 49, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 38.0, 0.0, 95.0, 0.0, 3610.0, 0.0, 38.0, 3610.0, 95.0, '2026-10-27 23:36:12'),
(50, 50, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.0, 0.0, 110.0, 0.0, 3300.0, 0.0, 30.0, 3300.0, 110.0, '2026-10-27 23:36:12'),
(51, 51, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 22.0, 0.0, 75.0, 0.0, 1650.0, 0.0, 22.0, 1650.0, 75.0, '2026-10-27 23:36:12'),
(52, 52, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.0, 0.0, 75.0, 0.0, 1350.0, 0.0, 18.0, 1350.0, 75.0, '2026-10-27 23:36:12'),
(53, 53, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.0, 0.0, 75.0, 0.0, 1350.0, 0.0, 18.0, 1350.0, 75.0, '2026-10-27 23:36:12'),
(54, 54, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.0, 0.0, 75.0, 0.0, 1350.0, 0.0, 18.0, 1350.0, 75.0, '2026-10-27 23:36:12'),
(55, 55, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 25.0, 0.0, 88.0, 0.0, 2200.0, 0.0, 25.0, 2200.0, 88.0, '2026-10-27 23:36:12'),
(56, 56, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 20.0, 0.0, 125.0, 0.0, 2500.0, 0.0, 20.0, 2500.0, 125.0, '2026-10-27 23:36:12'),
(57, 57, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 14.0, 0.0, 280.0, 0.0, 3920.0, 0.0, 14.0, 3920.0, 280.0, '2026-10-27 23:36:12'),
(58, 58, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 12.0, 0.0, 310.0, 0.0, 3720.0, 0.0, 12.0, 3720.0, 310.0, '2026-10-27 23:36:12'),
(59, 59, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 8.0, 0.0, 360.0, 0.0, 2880.0, 0.0, 8.0, 2880.0, 360.0, '2026-10-27 23:36:12'),
(60, 60, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 10.0, 0.0, 290.0, 0.0, 2900.0, 0.0, 10.0, 2900.0, 290.0, '2026-10-27 23:36:12');
-- Datos iniciales de kardex_movements: se conservan los registros originales.
INSERT INTO `kardex_movements` (`id`, `product_id`, `movement_date`, `doc_type`, `doc_id`, `reference`, `qty_in`, `qty_out`, `unit_cost_in`, `unit_cost_out`, `total_in`, `total_out`, `balance_qty`, `balance_value`, `balance_unit_cost`, `created_at`) VALUES
(61, 61, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 6.0, 0.0, 320.0, 0.0, 1920.0, 0.0, 6.0, 1920.0, 320.0, '2026-10-27 23:36:12'),
(62, 62, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 5.0, 0.0, 410.0, 0.0, 2050.0, 0.0, 5.0, 2050.0, 410.0, '2026-10-27 23:36:12'),
(63, 63, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 4.0, 0.0, 480.0, 0.0, 1920.0, 0.0, 4.0, 1920.0, 480.0, '2026-10-27 23:36:12'),
(64, 64, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 240.0, 0.0, 18.0, 0.0, 4320.0, 0.0, 240.0, 4320.0, 18.0, '2026-10-27 23:36:12'),
(65, 65, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 95.0, 0.0, 22.0, 0.0, 2090.0, 0.0, 95.0, 2090.0, 22.0, '2026-10-27 23:36:12'),
(66, 66, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 40.0, 0.0, 12.0, 0.0, 480.0, 0.0, 40.0, 480.0, 12.0, '2026-10-27 23:36:12'),
(67, 67, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 35.0, 0.0, 22.0, 0.0, 770.0, 0.0, 35.0, 770.0, 22.0, '2026-10-27 23:36:12'),
(68, 68, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.0, 0.0, 28.0, 0.0, 840.0, 0.0, 30.0, 840.0, 28.0, '2026-10-27 23:36:12'),
(69, 69, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 50.0, 0.0, 25.0, 0.0, 1250.0, 0.0, 50.0, 1250.0, 25.0, '2026-10-27 23:36:12'),
(70, 70, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.0, 0.0, 14.0, 0.0, 840.0, 0.0, 60.0, 840.0, 14.0, '2026-10-27 23:36:12'),
(71, 71, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 40.0, 0.0, 38.0, 0.0, 1520.0, 0.0, 40.0, 1520.0, 38.0, '2026-10-27 23:36:12'),
(72, 72, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 35.0, 0.0, 42.0, 0.0, 1470.0, 0.0, 35.0, 1470.0, 42.0, '2026-10-27 23:36:12'),
(73, 73, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 180.0, 0.0, 2.5, 0.0, 450.0, 0.0, 180.0, 450.0, 2.5, '2026-10-27 23:36:12'),
(74, 74, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 70.0, 0.0, 8.0, 0.0, 560.0, 0.0, 70.0, 560.0, 8.0, '2026-10-27 23:36:12'),
(75, 75, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 200.0, 0.0, 1.5, 0.0, 300.0, 0.0, 200.0, 300.0, 1.5, '2026-10-27 23:36:12'),
(76, 76, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 120.0, 0.0, 2.2, 0.0, 264.0, 0.0, 120.0, 264.0, 2.2, '2026-10-27 23:36:12'),
(77, 77, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 22.0, 0.0, 25.0, 0.0, 550.0, 0.0, 22.0, 550.0, 25.0, '2026-10-27 23:36:12'),
(78, 78, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.0, 0.0, 28.0, 0.0, 504.0, 0.0, 18.0, 504.0, 28.0, '2026-10-27 23:36:12'),
(79, 79, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 16.0, 0.0, 18.0, 0.0, 288.0, 0.0, 16.0, 288.0, 18.0, '2026-10-27 23:36:12'),
(80, 80, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.0, 0.0, 8.5, 0.0, 510.0, 0.0, 60.0, 510.0, 8.5, '2026-10-27 23:36:12'),
(81, 81, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 28.0, 0.0, 32.0, 0.0, 896.0, 0.0, 28.0, 896.0, 32.0, '2026-10-27 23:36:12'),
(82, 82, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 25.0, 0.0, 26.0, 0.0, 650.0, 0.0, 25.0, 650.0, 26.0, '2026-10-27 23:36:12'),
(83, 83, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 22.0, 0.0, 18.0, 0.0, 396.0, 0.0, 22.0, 396.0, 18.0, '2026-10-27 23:36:12'),
(84, 84, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 45.0, 0.0, 55.0, 0.0, 2475.0, 0.0, 45.0, 2475.0, 55.0, '2026-10-27 23:36:12'),
(85, 85, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 28.0, 0.0, 95.0, 0.0, 2660.0, 0.0, 28.0, 2660.0, 95.0, '2026-10-27 23:36:12'),
(86, 86, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 80.0, 0.0, 12.0, 0.0, 960.0, 0.0, 80.0, 960.0, 12.0, '2026-10-27 23:36:12'),
(87, 87, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.0, 0.0, 85.0, 0.0, 2550.0, 0.0, 30.0, 2550.0, 85.0, '2026-10-27 23:36:12'),
(88, 88, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.0, 0.0, 145.0, 0.0, 2610.0, 0.0, 18.0, 2610.0, 145.0, '2026-10-27 23:36:12'),
(89, 89, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 15.0, 0.0, 165.0, 0.0, 2475.0, 0.0, 15.0, 2475.0, 165.0, '2026-10-27 23:36:12'),
(90, 90, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 22.0, 0.0, 35.0, 0.0, 770.0, 0.0, 22.0, 770.0, 35.0, '2026-10-27 23:36:12'),
(91, 91, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.0, 0.0, 28.0, 0.0, 504.0, 0.0, 18.0, 504.0, 28.0, '2026-10-27 23:36:12'),
(92, 92, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.0, 0.0, 18.0, 0.0, 540.0, 0.0, 30.0, 540.0, 18.0, '2026-10-27 23:36:12'),
(93, 93, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 250.0, 0.0, 4.5, 0.0, 1125.0, 0.0, 250.0, 1125.0, 4.5, '2026-10-27 23:36:12'),
(94, 94, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 40.0, 0.0, 22.0, 0.0, 880.0, 0.0, 40.0, 880.0, 22.0, '2026-10-27 23:36:12'),
(95, 95, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 14.0, 0.0, 65.0, 0.0, 910.0, 0.0, 14.0, 910.0, 65.0, '2026-10-27 23:36:12'),
(96, 96, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 35.0, 0.0, 22.0, 0.0, 770.0, 0.0, 35.0, 770.0, 22.0, '2026-10-27 23:36:12'),
(97, 97, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 38.0, 0.0, 65.0, 0.0, 2470.0, 0.0, 38.0, 2470.0, 65.0, '2026-10-27 23:36:12'),
(98, 98, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.0, 0.0, 90.0, 0.0, 2700.0, 0.0, 30.0, 2700.0, 90.0, '2026-10-27 23:36:12'),
(99, 99, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.0, 0.0, 145.0, 0.0, 2610.0, 0.0, 18.0, 2610.0, 145.0, '2026-10-27 23:36:12'),
(100, 100, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 8.0, 0.0, 580.0, 0.0, 4640.0, 0.0, 8.0, 4640.0, 580.0, '2026-10-27 23:36:12'),
(101, 101, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 5.0, 0.0, 820.0, 0.0, 4100.0, 0.0, 5.0, 4100.0, 820.0, '2026-10-27 23:36:12'),
(102, 102, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 25.0, 0.0, 25.0, 0.0, 625.0, 0.0, 25.0, 625.0, 25.0, '2026-10-27 23:36:12'),
(103, 103, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.0, 0.0, 42.0, 0.0, 756.0, 0.0, 18.0, 756.0, 42.0, '2026-10-27 23:36:12'),
(104, 104, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.0, 0.0, 7.5, 0.0, 450.0, 0.0, 60.0, 450.0, 7.5, '2026-10-27 23:36:12'),
(105, 105, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 55.0, 0.0, 7.5, 0.0, 412.5, 0.0, 55.0, 412.5, 7.5, '2026-10-27 23:36:12'),
(106, 106, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.0, 0.0, 11.0, 0.0, 330.0, 0.0, 30.0, 330.0, 11.0, '2026-10-27 23:36:12'),
(107, 107, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 22.0, 0.0, 85.0, 0.0, 1870.0, 0.0, 22.0, 1870.0, 85.0, '2026-10-27 23:36:12'),
(108, 108, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 12.0, 0.0, 130.0, 0.0, 1560.0, 0.0, 12.0, 1560.0, 130.0, '2026-10-27 23:36:12'),
(109, 109, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 4.0, 0.0, 480.0, 0.0, 1920.0, 0.0, 4.0, 1920.0, 480.0, '2026-10-27 23:36:12'),
(110, 110, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 5.0, 0.0, 380.0, 0.0, 1900.0, 0.0, 5.0, 1900.0, 380.0, '2026-10-27 23:36:12'),
(111, 111, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 25.0, 0.0, 65.0, 0.0, 1625.0, 0.0, 25.0, 1625.0, 65.0, '2026-10-27 23:36:12'),
(112, 112, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 3.0, 0.0, 980.0, 0.0, 2940.0, 0.0, 3.0, 2940.0, 980.0, '2026-10-27 23:36:12'),
(113, 113, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 2.0, 0.0, 2400.0, 0.0, 4800.0, 0.0, 2.0, 4800.0, 2400.0, '2026-10-27 23:36:12'),
(114, 114, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 35.0, 0.0, 38.0, 0.0, 1330.0, 0.0, 35.0, 1330.0, 38.0, '2026-10-27 23:36:12'),
(115, 115, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 110.0, 0.0, 2.0, 0.0, 220.0, 0.0, 110.0, 220.0, 2.0, '2026-10-27 23:36:12'),
(116, 116, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 65.0, 0.0, 25.0, 0.0, 1625.0, 0.0, 65.0, 1625.0, 25.0, '2026-10-27 23:36:12'),
(117, 117, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 120.0, 0.0, 18.0, 0.0, 2160.0, 0.0, 120.0, 2160.0, 18.0, '2026-10-27 23:36:12'),
(118, 118, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 85.0, 0.0, 24.0, 0.0, 2040.0, 0.0, 85.0, 2040.0, 24.0, '2026-10-27 23:36:12'),
(119, 119, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.0, 0.0, 32.0, 0.0, 1920.0, 0.0, 60.0, 1920.0, 32.0, '2026-10-27 23:36:12'),
(120, 120, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 45.0, 0.0, 48.0, 0.0, 2160.0, 0.0, 45.0, 2160.0, 48.0, '2026-10-27 23:36:12');
INSERT INTO `kardex_movements` (`id`, `product_id`, `movement_date`, `doc_type`, `doc_id`, `reference`, `qty_in`, `qty_out`, `unit_cost_in`, `unit_cost_out`, `total_in`, `total_out`, `balance_qty`, `balance_value`, `balance_unit_cost`, `created_at`) VALUES
(121, 121, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 12.0, 0.0, 220.0, 0.0, 2640.0, 0.0, 12.0, 2640.0, 220.0, '2026-10-27 23:36:12'),
(122, 122, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.0, 0.0, 95.0, 0.0, 1710.0, 0.0, 18.0, 1710.0, 95.0, '2026-10-27 23:36:12'),
(123, 123, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.0, 0.0, 45.0, 0.0, 1350.0, 0.0, 30.0, 1350.0, 45.0, '2026-10-27 23:36:12'),
(124, 124, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 6.0, 0.0, 1150.0, 0.0, 6900.0, 0.0, 6.0, 6900.0, 1150.0, '2026-10-27 23:36:12'),
(125, 125, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 8.0, 0.0, 580.0, 0.0, 4640.0, 0.0, 8.0, 4640.0, 580.0, '2026-10-27 23:36:12'),
(126, 126, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 12.0, 0.0, 95.0, 0.0, 1140.0, 0.0, 12.0, 1140.0, 95.0, '2026-10-27 23:36:12'),
(127, 127, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 15.0, 0.0, 85.0, 0.0, 1275.0, 0.0, 15.0, 1275.0, 85.0, '2026-10-27 23:36:12'),
(128, 128, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 65.0, 0.0, 9.0, 0.0, 585.0, 0.0, 65.0, 585.0, 9.0, '2026-10-27 23:36:12'),
(129, 129, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 48.0, 0.0, 22.0, 0.0, 1056.0, 0.0, 48.0, 1056.0, 22.0, '2026-10-27 23:36:12'),
(130, 130, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 42.0, 0.0, 22.0, 0.0, 924.0, 0.0, 42.0, 924.0, 22.0, '2026-10-27 23:36:12'),
(131, 131, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 25.0, 0.0, 35.0, 0.0, 875.0, 0.0, 25.0, 875.0, 35.0, '2026-10-27 23:36:12'),
(132, 132, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 80.0, 0.0, 2.8, 0.0, 224.0, 0.0, 80.0, 224.0, 2.8, '2026-10-27 23:36:12'),
(133, 133, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 65.0, 0.0, 3.2, 0.0, 208.0, 0.0, 65.0, 208.0, 3.2, '2026-10-27 23:36:12'),
(134, 134, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 45.0, 0.0, 4.5, 0.0, 202.5, 0.0, 45.0, 202.5, 4.5, '2026-10-27 23:36:12'),
(135, 135, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 35.0, 0.0, 5.0, 0.0, 175.0, 0.0, 35.0, 175.0, 5.0, '2026-10-27 23:36:12'),
(136, 136, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 50.0, 0.0, 18.0, 0.0, 900.0, 0.0, 50.0, 900.0, 18.0, '2026-10-27 23:36:12'),
(137, 137, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 38.0, 0.0, 26.0, 0.0, 988.0, 0.0, 38.0, 988.0, 26.0, '2026-10-27 23:36:12'),
(138, 138, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 24.0, 0.0, 42.0, 0.0, 1008.0, 0.0, 24.0, 1008.0, 42.0, '2026-10-27 23:36:12'),
(139, 139, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 180.0, 0.0, 1.8, 0.0, 324.0, 0.0, 180.0, 324.0, 1.8, '2026-10-27 23:36:12'),
(140, 140, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 90.0, 0.0, 3.5, 0.0, 315.0, 0.0, 90.0, 315.0, 3.5, '2026-10-27 23:36:12'),
(141, 141, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 75.0, 0.0, 5.0, 0.0, 375.0, 0.0, 75.0, 375.0, 5.0, '2026-10-27 23:36:12'),
(142, 142, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.0, 0.0, 7.5, 0.0, 450.0, 0.0, 60.0, 450.0, 7.5, '2026-10-27 23:36:12'),
(143, 143, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 70.0, 0.0, 8.5, 0.0, 595.0, 0.0, 70.0, 595.0, 8.5, '2026-10-27 23:36:12'),
(144, 144, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 45.0, 0.0, 9.0, 0.0, 405.0, 0.0, 45.0, 405.0, 9.0, '2026-10-27 23:36:12'),
(145, 145, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 45.0, 0.0, 9.0, 0.0, 405.0, 0.0, 45.0, 405.0, 9.0, '2026-10-27 23:36:12'),
(146, 146, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 35.0, 0.0, 9.0, 0.0, 315.0, 0.0, 35.0, 315.0, 9.0, '2026-10-27 23:36:12'),
(147, 147, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.0, 0.0, 8.0, 0.0, 240.0, 0.0, 30.0, 240.0, 8.0, '2026-10-27 23:36:12'),
(148, 148, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 28.0, 0.0, 8.0, 0.0, 224.0, 0.0, 28.0, 224.0, 8.0, '2026-10-27 23:36:12'),
(149, 149, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 55.0, 0.0, 6.0, 0.0, 330.0, 0.0, 55.0, 330.0, 6.0, '2026-10-27 23:36:12'),
(150, 150, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 40.0, 0.0, 14.0, 0.0, 560.0, 0.0, 40.0, 560.0, 14.0, '2026-10-27 23:36:12'),
(151, 151, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 50.0, 0.0, 4.5, 0.0, 225.0, 0.0, 50.0, 225.0, 4.5, '2026-10-27 23:36:12'),
(152, 152, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 35.0, 0.0, 5.5, 0.0, 192.5, 0.0, 35.0, 192.5, 5.5, '2026-10-27 23:36:12'),
(153, 153, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.0, 0.0, 1.5, 0.0, 90.0, 0.0, 60.0, 90.0, 1.5, '2026-10-27 23:36:12'),
(154, 154, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 8.0, 0.0, 45.0, 0.0, 360.0, 0.0, 8.0, 360.0, 45.0, '2026-10-27 23:36:12'),
(155, 155, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 12.0, 0.0, 22.0, 0.0, 264.0, 0.0, 12.0, 264.0, 22.0, '2026-10-27 23:36:12'),
(156, 156, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.0, 0.0, 18.0, 0.0, 324.0, 0.0, 18.0, 324.0, 18.0, '2026-10-27 23:36:12'),
(157, 157, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 15.0, 0.0, 95.0, 0.0, 1425.0, 0.0, 15.0, 1425.0, 95.0, '2026-10-27 23:36:12'),
(158, 158, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 22.0, 0.0, 78.0, 0.0, 1716.0, 0.0, 22.0, 1716.0, 78.0, '2026-10-27 23:36:12'),
(159, 159, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 14.0, 0.0, 55.0, 0.0, 770.0, 0.0, 14.0, 770.0, 55.0, '2026-10-27 23:36:12'),
(160, 160, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 10.0, 0.0, 38.0, 0.0, 380.0, 0.0, 10.0, 380.0, 38.0, '2026-10-27 23:36:12'),
(161, 161, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 28.0, 0.0, 22.0, 0.0, 616.0, 0.0, 28.0, 616.0, 22.0, '2026-10-27 23:36:12'),
(162, 162, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 20.0, 0.0, 28.0, 0.0, 560.0, 0.0, 20.0, 560.0, 28.0, '2026-10-27 23:36:12'),
(163, 163, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 25.0, 0.0, 18.0, 0.0, 450.0, 0.0, 25.0, 450.0, 18.0, '2026-10-27 23:36:12'),
(164, 164, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.0, 0.0, 75.0, 0.0, 1350.0, 0.0, 18.0, 1350.0, 75.0, '2026-10-27 23:36:12'),
(165, 165, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 12.0, 0.0, 125.0, 0.0, 1500.0, 0.0, 12.0, 1500.0, 125.0, '2026-10-27 23:36:12'),
(166, 166, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 10.0, 0.0, 55.0, 0.0, 550.0, 0.0, 10.0, 550.0, 55.0, '2026-10-27 23:36:12'),
(167, 167, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 14.0, 0.0, 78.0, 0.0, 1092.0, 0.0, 14.0, 1092.0, 78.0, '2026-10-27 23:36:12'),
(168, 168, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 8.0, 0.0, 180.0, 0.0, 1440.0, 0.0, 8.0, 1440.0, 180.0, '2026-10-27 23:36:12'),
(169, 169, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 15.0, 0.0, 85.0, 0.0, 1275.0, 0.0, 15.0, 1275.0, 85.0, '2026-10-27 23:36:12'),
(170, 170, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 6.0, 0.0, 380.0, 0.0, 2280.0, 0.0, 6.0, 2280.0, 380.0, '2026-10-27 23:36:12'),
(171, 171, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 8.0, 0.0, 95.0, 0.0, 760.0, 0.0, 8.0, 760.0, 95.0, '2026-10-27 23:36:12'),
(172, 172, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 10.0, 0.0, 320.0, 0.0, 3200.0, 0.0, 10.0, 3200.0, 320.0, '2026-10-27 23:36:12'),
(173, 173, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.0, 0.0, 95.0, 0.0, 1710.0, 0.0, 18.0, 1710.0, 95.0, '2026-10-27 23:36:12'),
(174, 174, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 12.0, 0.0, 65.0, 0.0, 780.0, 0.0, 12.0, 780.0, 65.0, '2026-10-27 23:36:12'),
(175, 175, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 22.0, 0.0, 22.0, 0.0, 484.0, 0.0, 22.0, 484.0, 22.0, '2026-10-27 23:36:12'),
(176, 176, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 28.0, 0.0, 45.0, 0.0, 1260.0, 0.0, 28.0, 1260.0, 45.0, '2026-10-27 23:36:12'),
(177, 177, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 8.0, 0.0, 165.0, 0.0, 1320.0, 0.0, 8.0, 1320.0, 165.0, '2026-10-27 23:36:12'),
(178, 178, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 6.0, 0.0, 78.0, 0.0, 468.0, 0.0, 6.0, 468.0, 78.0, '2026-10-27 23:36:12'),
(179, 179, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 14.0, 0.0, 32.0, 0.0, 448.0, 0.0, 14.0, 448.0, 32.0, '2026-10-27 23:36:12'),
(180, 180, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 3.0, 0.0, 2200.0, 0.0, 6600.0, 0.0, 3.0, 6600.0, 2200.0, '2026-10-27 23:36:12');
INSERT INTO `kardex_movements` (`id`, `product_id`, `movement_date`, `doc_type`, `doc_id`, `reference`, `qty_in`, `qty_out`, `unit_cost_in`, `unit_cost_out`, `total_in`, `total_out`, `balance_qty`, `balance_value`, `balance_unit_cost`, `created_at`) VALUES
(181, 181, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 2.0, 0.0, 1850.0, 0.0, 3700.0, 0.0, 2.0, 3700.0, 1850.0, '2026-10-27 23:36:12'),
(182, 1, '2026-08-10 16:30:00', 'SALIDA', 1, 'SAL-2026-000001', 0.0, 2.0, 0.0, 32.5, 0.0, 65.0, 478.0, 15535.0, 32.5, '2026-10-27 23:36:12'),
(183, 2, '2026-08-10 16:30:00', 'SALIDA', 1, 'SAL-2026-000001', 0.0, 2.0, 0.0, 38.2, 0.0, 76.4, 83.0, 3170.6, 38.2, '2026-10-27 23:36:12'),
(184, 3, '2026-08-10 16:30:00', 'SALIDA', 1, 'SAL-2026-000001', 0.0, 2.0, 0.0, 30.8, 0.0, 61.6, 58.0, 1786.4, 30.8, '2026-10-27 23:36:12'),
(185, 1, '2026-10-27 19:56:41', 'SALIDA', 2, 'SAL-2026-000002', 0.0, 3.0, 0.0, 32.5, 0.0, 97.5, 475.0, 15437.5, 32.5, '2026-10-27 19:56:41');

-- layer_consumptions: 4 registros
INSERT INTO `layer_consumptions` (`id`, `dispatch_item_id`, `layer_id`, `qty`, `unit_cost`, `total_value`) VALUES
(1, 1, 1, 2.0, 32.5, 65.0),
(2, 2, 2, 2.0, 38.2, 76.4),
(3, 3, 3, 2.0, 30.8, 61.6),
(4, 4, 1, 3.0, 32.5, 97.5);

-- locations: 5 registros
INSERT INTO `locations` (`id`, `code`, `name`, `is_active`) VALUES
(1, 'A1', 'Almacén principal - Estante A1', 1),
(2, 'A2', 'Almacén principal - Estante A2', 1),
(3, 'B1', 'Almacén principal - Estante B1', 1),
(4, 'B2', 'Almacén principal - Estante B2', 1),
(5, 'C1', 'Almacén principal - Estante C1', 1);

-- period_closes: 1 registros
INSERT INTO `period_closes` (`id`, `year`, `month`, `closed_at`, `closed_by`, `total_qty_snapshot`, `total_value_snapshot`, `status`, `reopen_reason`) VALUES
(1, 2026, 10, NULL, NULL, 0.0, 0.0, 'ABIERTO', NULL);

-- permissions: 38 registros
INSERT INTO `permissions` (`id`, `code`, `module`, `description`) VALUES
(1, 'solicitudes.crear', 'solicitudes', 'Crear solicitudes de materiales'),
(2, 'solicitudes.ver_propias', 'solicitudes', 'Ver solicitudes propias'),
(3, 'solicitudes.ver_area', 'solicitudes', 'Ver solicitudes del área'),
(4, 'solicitudes.ver_todas', 'solicitudes', 'Ver todas las solicitudes'),
(5, 'solicitudes.aprobar', 'solicitudes', 'Aprobar solicitudes en paso inicial'),
(6, 'solicitudes.reducir', 'solicitudes', 'Reducir cantidades solicitadas'),
(7, 'solicitudes.devolver', 'solicitudes', 'Devolver u observar solicitudes'),
(8, 'solicitudes.rechazar', 'solicitudes', 'Rechazar solicitudes'),
(9, 'solicitudes.autorizar', 'solicitudes', 'Autorizar definitivamente solicitud'),
(10, 'solicitudes.preparar', 'solicitudes', 'Preparar entrega en almacén'),
(11, 'solicitudes.entregar', 'solicitudes', 'Registrar entrega de materiales'),
(12, 'inventario.ver_basico', 'inventario', 'Ver catálogo básico de productos'),
(13, 'inventario.ver_stock', 'inventario', 'Ver existencias y saldos físicos'),
(14, 'inventario.ver_valores', 'inventario', 'Ver valor monetario del inventario'),
(15, 'productos.ver', 'productos', 'Ver detalle de productos'),
(16, 'catalogos.ver', 'catalogos', 'Ver catálogos del sistema'),
(17, 'catalogos.editar', 'catalogos', 'Administrar catálogos'),
(18, 'dashboard.solicitudes', 'dashboard', 'Ver métricas de solicitudes'),
(19, 'dashboard.despachos', 'dashboard', 'Ver métricas de despachos'),
(20, 'dashboard.ajustes', 'dashboard', 'Ver métricas de ajustes'),
(21, 'aprobaciones.ver', 'aprobaciones', 'Ver bandeja de aprobaciones'),
(22, 'aprobaciones.decidir', 'aprobaciones', 'Tomar decisión en aprobaciones'),
(23, 'ingresos.ver', 'ingresos', 'Ver comprobantes de ingreso'),
(24, 'salidas.ver', 'salidas', 'Ver comprobantes de salida'),
(25, 'salidas.preparar', 'salidas', 'Preparar salidas de material'),
(26, 'salidas.confirmar', 'salidas', 'Confirmar entrega y salida'),
(27, 'ajustes.ver', 'ajustes', 'Ver ajustes de inventario'),
(28, 'ajustes.crear', 'ajustes', 'Registrar nuevos ajustes'),
(29, 'ajustes.aprobar', 'ajustes', 'Firmar aprobación de ajustes'),
(30, 'reportes.ver', 'reportes', 'Consultar reportes oficiales'),
(31, 'reportes.exportar', 'reportes', 'Exportar información contable'),
(32, 'arqueo.ver', 'arqueo', 'Realizar arqueo físico'),
(33, 'auditoria.ver', 'auditoria', 'Consultar bitácora de auditoría'),
(34, 'usuarios.ver', 'usuarios', 'Ver lista de usuarios'),
(35, 'usuarios.editar', 'usuarios', 'Editar información de usuarios'),
(36, 'usuarios.gestionar', 'usuarios', 'Crear y desactivar cuentas'),
(37, 'config.ver', 'config', 'Ver configuración institucional'),
(38, 'config.editar', 'config', 'Modificar configuración');

-- products: 181 registros
INSERT INTO `products` (`id`, `code`, `name`, `description`, `brand`, `category_id`, `subcategory_id`, `unit_id`, `location_id`, `min_stock`, `max_stock`, `reference_cost`, `stock_qty`, `stock_value`, `status`, `is_active`, `created_at`) VALUES
(1, 'PAP-HOJ-001', 'Papel bond tamaño carta 75 gr', 'Papel bond tamaño carta 75 gr - SKU institucional', NULL, 1, 1, 2, 2, 48.0, 1440.0, 32.5, 475.0, 15437.5, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(2, 'PAP-HOJ-002', 'Papel bond tamaño oficio 75 gr', 'Papel bond tamaño oficio 75 gr - SKU institucional', NULL, 1, 1, 2, 3, 8.0, 255.0, 38.2, 83.0, 3170.6, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(3, 'PAP-HOJ-003', 'Papel bond A4 75 gr', 'Papel bond A4 75 gr - SKU institucional', NULL, 1, 1, 2, 4, 6.0, 180.0, 30.8, 58.0, 1786.4, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(4, 'PAP-HOJ-004', 'Papel fotográfico carta', 'Papel fotográfico carta - SKU institucional', NULL, 1, 1, 4, 5, 2.0, 72.0, 95.0, 24.0, 2280.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(5, 'PAP-HOJ-005', 'Papel milimetrado', 'Papel milimetrado - SKU institucional', NULL, 1, 1, 1, 1, 14.0, 420.0, 1.5, 140.0, 210.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(6, 'PAP-HOJ-006', 'Papel cuadriculado A4', 'Papel cuadriculado A4 - SKU institucional', NULL, 1, 1, 2, 2, 1.0, 45.0, 34.0, 15.0, 510.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(7, 'PAP-BOL-001', 'Bolígrafo azul', 'Bolígrafo azul - SKU institucional', NULL, 1, 2, 1, 3, 54.0, 1620.0, 2.8, 540.0, 1512.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(8, 'PAP-BOL-002', 'Bolígrafo negro', 'Bolígrafo negro - SKU institucional', NULL, 1, 2, 1, 4, 43.0, 1290.0, 2.8, 430.0, 1204.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(9, 'PAP-BOL-003', 'Bolígrafo rojo', 'Bolígrafo rojo - SKU institucional', NULL, 1, 2, 1, 5, 32.0, 960.0, 2.8, 320.0, 896.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(10, 'PAP-BOL-004', 'Bolígrafo verde', 'Bolígrafo verde - SKU institucional', NULL, 1, 2, 1, 1, 15.0, 450.0, 2.8, 150.0, 420.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(11, 'PAP-BOL-005', 'Lápiz negro HB', 'Lápiz negro HB - SKU institucional', NULL, 1, 2, 1, 2, 60.0, 1800.0, 1.2, 600.0, 720.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(12, 'PAP-BOL-006', 'Lápiz 2B', 'Lápiz 2B - SKU institucional', NULL, 1, 2, 1, 3, 12.0, 360.0, 1.5, 120.0, 180.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(13, 'PAP-BOL-007', 'Marcador fino negro', 'Marcador fino negro - SKU institucional', NULL, 1, 2, 1, 4, 8.0, 264.0, 5.5, 88.0, 484.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(14, 'PAP-BOL-008', 'Marcador fino azul', 'Marcador fino azul - SKU institucional', NULL, 1, 2, 1, 5, 7.0, 225.0, 5.5, 75.0, 412.5, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(15, 'PAP-BOL-009', 'Marcador fino rojo', 'Marcador fino rojo - SKU institucional', NULL, 1, 2, 1, 1, 6.0, 180.0, 5.5, 60.0, 330.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(16, 'PAP-BOL-010', 'Resaltador amarillo', 'Resaltador amarillo - SKU institucional', NULL, 1, 2, 1, 2, 9.0, 285.0, 6.0, 95.0, 570.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(17, 'PAP-BOL-011', 'Resaltador verde', 'Resaltador verde - SKU institucional', NULL, 1, 2, 1, 3, 7.0, 210.0, 6.0, 70.0, 420.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(18, 'PAP-BOL-012', 'Resaltador rosado', 'Resaltador rosado - SKU institucional', NULL, 1, 2, 1, 4, 5.0, 165.0, 6.0, 55.0, 330.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(19, 'PAP-CAR-001', 'Carpeta de cartón oficio', 'Carpeta de cartón oficio - SKU institucional', NULL, 1, 3, 1, 5, 25.0, 750.0, 4.5, 250.0, 1125.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(20, 'PAP-CAR-002', 'Carpeta con fastener', 'Carpeta con fastener - SKU institucional', NULL, 1, 3, 1, 1, 20.0, 600.0, 6.8, 200.0, 1360.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(21, 'PAP-CAR-003', 'Carpeta plástica de palanca', 'Carpeta plástica de palanca - SKU institucional', NULL, 1, 3, 1, 2, 9.0, 285.0, 22.0, 95.0, 2090.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(22, 'PAP-CAR-004', 'Archivador de palanca oficio', 'Archivador de palanca oficio - SKU institucional', NULL, 1, 3, 1, 3, 6.0, 195.0, 28.0, 65.0, 1820.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(23, 'PAP-CAR-005', 'Folder colgante', 'Folder colgante - SKU institucional', NULL, 1, 3, 1, 4, 18.0, 540.0, 7.5, 180.0, 1350.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(24, 'PAP-CAR-006', 'Folder manila', 'Folder manila - SKU institucional', NULL, 1, 3, 1, 5, 54.0, 1620.0, 0.9, 540.0, 486.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(25, 'PAP-SOB-001', 'Sobre manila oficio', 'Sobre manila oficio - SKU institucional', NULL, 1, 4, 1, 1, 42.0, 1260.0, 1.2, 420.0, 504.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(26, 'PAP-SOB-002', 'Sobre manila carta', 'Sobre manila carta - SKU institucional', NULL, 1, 4, 1, 2, 38.0, 1140.0, 1.0, 380.0, 380.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(27, 'PAP-SOB-003', 'Sobre manila extra oficio', 'Sobre manila extra oficio - SKU institucional', NULL, 1, 4, 1, 3, 15.0, 450.0, 2.5, 150.0, 375.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(28, 'PAP-SOB-004', 'Sobre blanco con ventana', 'Sobre blanco con ventana - SKU institucional', NULL, 1, 4, 1, 4, 22.0, 660.0, 1.1, 220.0, 242.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(29, 'PAP-GRAP-001', 'Grapas estándar 26/6 caja', 'Grapas estándar 26/6 caja - SKU institucional', NULL, 1, 5, 3, 5, 8.0, 255.0, 7.5, 85.0, 637.5, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(30, 'PAP-GRAP-002', 'Clips mariposa 50mm', 'Clips mariposa 50mm - SKU institucional', NULL, 1, 5, 3, 1, 6.0, 180.0, 9.0, 60.0, 540.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(31, 'PAP-GRAP-003', 'Clips estándar 28mm', 'Clips estándar 28mm - SKU institucional', NULL, 1, 5, 3, 2, 12.0, 360.0, 4.5, 120.0, 540.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(32, 'PAP-GRAP-004', 'Chinchetas', 'Chinchetas - SKU institucional', NULL, 1, 5, 3, 3, 4.0, 120.0, 5.0, 40.0, 200.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(33, 'PAP-GRAP-005', 'Cinta adhesiva transparente', 'Cinta adhesiva transparente - SKU institucional', NULL, 1, 5, 1, 4, 15.0, 450.0, 5.0, 150.0, 750.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(34, 'PAP-GRAP-006', 'Cinta masking 24mm', 'Cinta masking 24mm - SKU institucional', NULL, 1, 5, 1, 5, 7.0, 210.0, 9.5, 70.0, 665.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(35, 'PAP-GRAP-007', 'Cinta doble contacto', 'Cinta doble contacto - SKU institucional', NULL, 1, 5, 1, 1, 4.0, 135.0, 16.0, 45.0, 720.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(36, 'PAP-GRAP-008', 'Pegamento en barra 21gr', 'Pegamento en barra 21gr - SKU institucional', NULL, 1, 5, 1, 2, 13.0, 390.0, 6.0, 130.0, 780.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(37, 'PAP-GRAP-009', 'Tijera escolar', 'Tijera escolar - SKU institucional', NULL, 1, 5, 1, 3, 3.0, 105.0, 12.0, 35.0, 420.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(38, 'PAP-GRAP-010', 'Dispensador de cinta', 'Dispensador de cinta - SKU institucional', NULL, 1, 5, 1, 4, 1.0, 54.0, 28.0, 18.0, 504.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(39, 'PAP-GRAP-011', 'Goma de borrar', 'Goma de borrar - SKU institucional', NULL, 1, 5, 1, 5, 22.0, 660.0, 1.0, 220.0, 220.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(40, 'PAP-GRAP-012', 'Sacagrapas', 'Sacagrapas - SKU institucional', NULL, 1, 5, 1, 1, 6.0, 180.0, 2.5, 60.0, 150.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(41, 'PAP-GRAP-013', 'Cuaderno universitario 100h', 'Cuaderno universitario 100h - SKU institucional', NULL, 1, 5, 1, 2, 9.0, 270.0, 18.0, 90.0, 1620.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(42, 'PAP-GRAP-014', 'Cuaderno empastado 50h', 'Cuaderno empastado 50h - SKU institucional', NULL, 1, 5, 1, 3, 7.0, 225.0, 9.5, 75.0, 712.5, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(43, 'PAP-GRAP-015', 'Notas adhesivas 3x3', 'Notas adhesivas 3x3 - SKU institucional', NULL, 1, 5, 4, 4, 5.0, 165.0, 11.0, 55.0, 605.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(44, 'PAP-GRAP-016', 'Regla 30cm', 'Regla 30cm - SKU institucional', NULL, 1, 5, 1, 5, 3.0, 90.0, 3.5, 30.0, 105.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(45, 'PAP-GRAP-017', 'Calculadora básica', 'Calculadora básica - SKU institucional', NULL, 1, 5, 1, 1, 2.0, 66.0, 65.0, 22.0, 1430.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(46, 'PAP-GRAP-018', 'Perforadora 2 hoyos', 'Perforadora 2 hoyos - SKU institucional', NULL, 1, 5, 1, 2, 2.0, 84.0, 38.0, 28.0, 1064.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(47, 'PAP-GRAP-019', 'Engrapadora estándar', 'Engrapadora estándar - SKU institucional', NULL, 1, 5, 1, 3, 2.0, 75.0, 45.0, 25.0, 1125.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(48, 'PAP-GRAP-020', 'Tablero de apoyo', 'Tablero de apoyo - SKU institucional', NULL, 1, 5, 1, 4, 5.0, 150.0, 22.0, 50.0, 1100.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(49, 'TIN-TIN-001', 'Tinta HP 664 negro', 'Tinta HP 664 negro - SKU institucional', NULL, 2, 6, 1, 5, 3.0, 114.0, 95.0, 38.0, 3610.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(50, 'TIN-TIN-002', 'Tinta HP 664 color', 'Tinta HP 664 color - SKU institucional', NULL, 2, 6, 1, 1, 3.0, 90.0, 110.0, 30.0, 3300.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(51, 'TIN-TIN-003', 'Tinta Epson 544 negro', 'Tinta Epson 544 negro - SKU institucional', NULL, 2, 6, 1, 2, 2.0, 66.0, 75.0, 22.0, 1650.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(52, 'TIN-TIN-004', 'Tinta Epson 544 cian', 'Tinta Epson 544 cian - SKU institucional', NULL, 2, 6, 1, 3, 1.0, 54.0, 75.0, 18.0, 1350.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(53, 'TIN-TIN-005', 'Tinta Epson 544 magenta', 'Tinta Epson 544 magenta - SKU institucional', NULL, 2, 6, 1, 4, 1.0, 54.0, 75.0, 18.0, 1350.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(54, 'TIN-TIN-006', 'Tinta Epson 544 amarillo', 'Tinta Epson 544 amarillo - SKU institucional', NULL, 2, 6, 1, 5, 1.0, 54.0, 75.0, 18.0, 1350.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(55, 'TIN-TIN-007', 'Tinta Canon PG-145 negro', 'Tinta Canon PG-145 negro - SKU institucional', NULL, 2, 6, 1, 1, 2.0, 75.0, 88.0, 25.0, 2200.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(56, 'TIN-TIN-008', 'Tinta Canon CL-146 color', 'Tinta Canon CL-146 color - SKU institucional', NULL, 2, 6, 1, 2, 2.0, 60.0, 125.0, 20.0, 2500.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(57, 'TIN-TON-001', 'Tóner HP 85A negro', 'Tóner HP 85A negro - SKU institucional', NULL, 2, 7, 1, 3, 1.0, 42.0, 280.0, 14.0, 3920.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(58, 'TIN-TON-002', 'Tóner HP 26A negro', 'Tóner HP 26A negro - SKU institucional', NULL, 2, 7, 1, 4, 1.0, 36.0, 310.0, 12.0, 3720.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(59, 'TIN-TON-003', 'Tóner HP 305A negro', 'Tóner HP 305A negro - SKU institucional', NULL, 2, 7, 1, 5, 1.0, 24.0, 360.0, 8.0, 2880.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(60, 'TIN-TON-004', 'Tóner Samsung MLT-D101S', 'Tóner Samsung MLT-D101S - SKU institucional', NULL, 2, 7, 1, 1, 1.0, 30.0, 290.0, 10.0, 2900.0, 'ACTIVO', 1, '2026-10-27 23:36:12');
-- Datos iniciales de products: se conservan los registros originales.
INSERT INTO `products` (`id`, `code`, `name`, `description`, `brand`, `category_id`, `subcategory_id`, `unit_id`, `location_id`, `min_stock`, `max_stock`, `reference_cost`, `stock_qty`, `stock_value`, `status`, `is_active`, `created_at`) VALUES
(61, 'TIN-TON-005', 'Tóner Brother TN-1060', 'Tóner Brother TN-1060 - SKU institucional', NULL, 2, 7, 1, 2, 1.0, 18.0, 320.0, 6.0, 1920.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(62, 'TIN-TON-006', 'Tóner Xerox 106R01604', 'Tóner Xerox 106R01604 - SKU institucional', NULL, 2, 7, 1, 3, 1.0, 15.0, 410.0, 5.0, 2050.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(63, 'TIN-TON-007', 'Tóner Lexmark 50F2H00', 'Tóner Lexmark 50F2H00 - SKU institucional', NULL, 2, 7, 1, 4, 1.0, 12.0, 480.0, 4.0, 1920.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(64, 'LIM-PAP-001', 'Papel higiénico institucional 500m', 'Papel higiénico institucional 500m - SKU institucional', NULL, 3, 8, 1, 5, 24.0, 720.0, 18.0, 240.0, 4320.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(65, 'LIM-PAP-002', 'Papel toalla interfoliado', 'Papel toalla interfoliado - SKU institucional', NULL, 3, 8, 4, 1, 9.0, 285.0, 22.0, 95.0, 2090.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(66, 'LIM-PAP-003', 'Servilletas', 'Servilletas - SKU institucional', NULL, 3, 8, 4, 2, 4.0, 120.0, 12.0, 40.0, 480.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(67, 'LIM-DET-001', 'Detergente en polvo 1kg', 'Detergente en polvo 1kg - SKU institucional', NULL, 3, 9, 8, 3, 3.0, 105.0, 22.0, 35.0, 770.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(68, 'LIM-DET-002', 'Detergente líquido 1L', 'Detergente líquido 1L - SKU institucional', NULL, 3, 9, 7, 4, 3.0, 90.0, 28.0, 30.0, 840.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(69, 'LIM-DET-003', 'Jabón líquido para manos 1L', 'Jabón líquido para manos 1L - SKU institucional', NULL, 3, 9, 7, 5, 5.0, 150.0, 25.0, 50.0, 1250.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(70, 'LIM-DET-004', 'Lavandina 1L', 'Lavandina 1L - SKU institucional', NULL, 3, 9, 7, 1, 6.0, 180.0, 14.0, 60.0, 840.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(71, 'LIM-DES-001', 'Desinfectante en aerosol 360cc', 'Desinfectante en aerosol 360cc - SKU institucional', NULL, 3, 10, 1, 2, 4.0, 120.0, 38.0, 40.0, 1520.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(72, 'LIM-DES-002', 'Alcohol en gel 1L', 'Alcohol en gel 1L - SKU institucional', NULL, 3, 10, 7, 3, 3.0, 105.0, 42.0, 35.0, 1470.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(73, 'LIM-DES-003', 'Esponja doble uso', 'Esponja doble uso - SKU institucional', NULL, 3, 10, 1, 4, 18.0, 540.0, 2.5, 180.0, 450.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(74, 'LIM-DES-004', 'Paño de microfibra', 'Paño de microfibra - SKU institucional', NULL, 3, 10, 1, 5, 7.0, 210.0, 8.0, 70.0, 560.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(75, 'LIM-DES-005', 'Bolsa de basura 50L', 'Bolsa de basura 50L - SKU institucional', NULL, 3, 10, 1, 1, 20.0, 600.0, 1.5, 200.0, 300.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(76, 'LIM-DES-006', 'Bolsa de basura 100L', 'Bolsa de basura 100L - SKU institucional', NULL, 3, 10, 1, 2, 12.0, 360.0, 2.2, 120.0, 264.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(77, 'LIM-DES-007', 'Trapeador de piso', 'Trapeador de piso - SKU institucional', NULL, 3, 10, 1, 3, 2.0, 66.0, 25.0, 22.0, 550.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(78, 'LIM-DES-008', 'Escoba', 'Escoba - SKU institucional', NULL, 3, 10, 1, 4, 1.0, 54.0, 28.0, 18.0, 504.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(79, 'LIM-DES-009', 'Recogedor', 'Recogedor - SKU institucional', NULL, 3, 10, 1, 5, 1.0, 48.0, 18.0, 16.0, 288.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(80, 'LIM-DES-010', 'Guantes de limpieza', 'Guantes de limpieza - SKU institucional', NULL, 3, 10, 10, 1, 6.0, 180.0, 8.5, 60.0, 510.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(81, 'LIM-DES-011', 'Ambientador en aerosol', 'Ambientador en aerosol - SKU institucional', NULL, 3, 10, 1, 2, 2.0, 84.0, 32.0, 28.0, 896.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(82, 'LIM-DES-012', 'Limpiador multiusos 1L', 'Limpiador multiusos 1L - SKU institucional', NULL, 3, 10, 7, 3, 2.0, 75.0, 26.0, 25.0, 650.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(83, 'LIM-DES-013', 'Limpiavidrios 500ml', 'Limpiavidrios 500ml - SKU institucional', NULL, 3, 10, 1, 4, 2.0, 66.0, 18.0, 22.0, 396.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(84, 'INF-MOU-001', 'Mouse óptico USB', 'Mouse óptico USB - SKU institucional', NULL, 4, 11, 1, 5, 4.0, 135.0, 55.0, 45.0, 2475.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(85, 'INF-MOU-002', 'Mouse inalámbrico', 'Mouse inalámbrico - SKU institucional', NULL, 4, 11, 1, 1, 2.0, 84.0, 95.0, 28.0, 2660.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(86, 'INF-MOU-003', 'Pad mouse', 'Pad mouse - SKU institucional', NULL, 4, 11, 1, 2, 8.0, 240.0, 12.0, 80.0, 960.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(87, 'INF-TEC-001', 'Teclado USB español', 'Teclado USB español - SKU institucional', NULL, 4, 12, 1, 3, 3.0, 90.0, 85.0, 30.0, 2550.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(88, 'INF-TEC-002', 'Teclado inalámbrico', 'Teclado inalámbrico - SKU institucional', NULL, 4, 12, 1, 4, 1.0, 54.0, 145.0, 18.0, 2610.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(89, 'INF-TEC-003', 'Combo teclado + mouse', 'Combo teclado + mouse - SKU institucional', NULL, 4, 12, 1, 5, 1.0, 45.0, 165.0, 15.0, 2475.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(90, 'INF-CAB-001', 'Cable HDMI 1.5m', 'Cable HDMI 1.5m - SKU institucional', NULL, 4, 13, 1, 1, 2.0, 66.0, 35.0, 22.0, 770.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(91, 'INF-CAB-002', 'Cable VGA 1.8m', 'Cable VGA 1.8m - SKU institucional', NULL, 4, 13, 1, 2, 1.0, 54.0, 28.0, 18.0, 504.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(92, 'INF-CAB-003', 'Cable USB 2.0 tipo A-B 1.8m', 'Cable USB 2.0 tipo A-B 1.8m - SKU institucional', NULL, 4, 13, 1, 3, 3.0, 90.0, 18.0, 30.0, 540.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(93, 'INF-CAB-004', 'Cable de red UTP cat6 1m', 'Cable de red UTP cat6 1m - SKU institucional', NULL, 4, 13, 6, 4, 25.0, 750.0, 4.5, 250.0, 1125.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(94, 'INF-CAB-005', 'Cable de red UTP cat6 3m', 'Cable de red UTP cat6 3m - SKU institucional', NULL, 4, 13, 1, 5, 4.0, 120.0, 22.0, 40.0, 880.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(95, 'INF-CAB-006', 'Adaptador HDMI a VGA', 'Adaptador HDMI a VGA - SKU institucional', NULL, 4, 13, 1, 1, 1.0, 42.0, 65.0, 14.0, 910.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(96, 'INF-CAB-007', 'Cable de poder 1.5m', 'Cable de poder 1.5m - SKU institucional', NULL, 4, 13, 1, 2, 3.0, 105.0, 22.0, 35.0, 770.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(97, 'INF-USB-001', 'Memoria USB 16GB', 'Memoria USB 16GB - SKU institucional', NULL, 4, 14, 1, 3, 3.0, 114.0, 65.0, 38.0, 2470.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(98, 'INF-USB-002', 'Memoria USB 32GB', 'Memoria USB 32GB - SKU institucional', NULL, 4, 14, 1, 4, 3.0, 90.0, 90.0, 30.0, 2700.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(99, 'INF-USB-003', 'Memoria USB 64GB', 'Memoria USB 64GB - SKU institucional', NULL, 4, 14, 1, 5, 1.0, 54.0, 145.0, 18.0, 2610.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(100, 'INF-USB-004', 'Disco duro externo 1TB', 'Disco duro externo 1TB - SKU institucional', NULL, 4, 14, 1, 1, 1.0, 24.0, 580.0, 8.0, 4640.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(101, 'INF-USB-005', 'Disco duro externo 2TB', 'Disco duro externo 2TB - SKU institucional', NULL, 4, 14, 1, 2, 1.0, 15.0, 820.0, 5.0, 4100.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(102, 'ESC-SEL-001', 'Sello de goma redondo', 'Sello de goma redondo - SKU institucional', NULL, 5, 15, 1, 3, 2.0, 75.0, 25.0, 25.0, 625.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(103, 'ESC-SEL-002', 'Sello fechador', 'Sello fechador - SKU institucional', NULL, 5, 15, 1, 4, 1.0, 54.0, 42.0, 18.0, 756.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(104, 'ESC-SEL-003', 'Tinta para sello azul', 'Tinta para sello azul - SKU institucional', NULL, 5, 15, 1, 5, 6.0, 180.0, 7.5, 60.0, 450.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(105, 'ESC-SEL-004', 'Tinta para sello negra', 'Tinta para sello negra - SKU institucional', NULL, 5, 15, 1, 1, 5.0, 165.0, 7.5, 55.0, 412.5, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(106, 'ESC-SEL-005', 'Almohadilla para sello', 'Almohadilla para sello - SKU institucional', NULL, 5, 15, 1, 2, 3.0, 90.0, 11.0, 30.0, 330.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(107, 'ESC-PER-001', 'Perforadora 2 hoyos 25h', 'Perforadora 2 hoyos 25h - SKU institucional', NULL, 5, 16, 1, 3, 2.0, 66.0, 85.0, 22.0, 1870.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(108, 'ESC-PER-002', 'Perforadora 3 hoyos', 'Perforadora 3 hoyos - SKU institucional', NULL, 5, 16, 1, 4, 1.0, 36.0, 130.0, 12.0, 1560.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(109, 'ESC-PER-003', 'Perforadora industrial 60h', 'Perforadora industrial 60h - SKU institucional', NULL, 5, 16, 1, 5, 1.0, 12.0, 480.0, 4.0, 1920.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(110, 'ESC-PER-004', 'Engrapadora industrial 100h', 'Engrapadora industrial 100h - SKU institucional', NULL, 5, 16, 1, 1, 1.0, 15.0, 380.0, 5.0, 1900.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(111, 'ESC-PER-005', 'Engrapadora estándar 25h', 'Engrapadora estándar 25h - SKU institucional', NULL, 5, 16, 1, 2, 2.0, 75.0, 65.0, 25.0, 1625.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(112, 'ESC-PER-006', 'Plastificadora A4', 'Plastificadora A4 - SKU institucional', NULL, 5, 16, 1, 3, 1.0, 9.0, 980.0, 3.0, 2940.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(113, 'ESC-PER-007', 'Caja fuerte 50L', 'Caja fuerte 50L - SKU institucional', NULL, 5, 16, 1, 4, 1.0, 6.0, 2400.0, 2.0, 4800.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(114, 'ESC-PER-008', 'Caja archivadora plástica', 'Caja archivadora plástica - SKU institucional', NULL, 5, 16, 1, 5, 3.0, 105.0, 38.0, 35.0, 1330.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(115, 'ESC-PER-009', 'Separador de colores', 'Separador de colores - SKU institucional', NULL, 5, 16, 1, 1, 11.0, 330.0, 2.0, 110.0, 220.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(116, 'ESC-PER-010', 'Carpeta clasificadora', 'Carpeta clasificadora - SKU institucional', NULL, 5, 16, 1, 2, 6.0, 195.0, 25.0, 65.0, 1625.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(117, 'ELE-FOC-001', 'Foco LED 9W E27', 'Foco LED 9W E27 - SKU institucional', NULL, 6, 17, 1, 3, 12.0, 360.0, 18.0, 120.0, 2160.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(118, 'ELE-FOC-002', 'Foco LED 12W E27', 'Foco LED 12W E27 - SKU institucional', NULL, 6, 17, 1, 4, 8.0, 255.0, 24.0, 85.0, 2040.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(119, 'ELE-FOC-003', 'Foco LED 15W E27', 'Foco LED 15W E27 - SKU institucional', NULL, 6, 17, 1, 5, 6.0, 180.0, 32.0, 60.0, 1920.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(120, 'ELE-FOC-004', 'Tubo LED T8 18W', 'Tubo LED T8 18W - SKU institucional', NULL, 6, 17, 1, 1, 4.0, 135.0, 48.0, 45.0, 2160.0, 'ACTIVO', 1, '2026-10-27 23:36:12');
INSERT INTO `products` (`id`, `code`, `name`, `description`, `brand`, `category_id`, `subcategory_id`, `unit_id`, `location_id`, `min_stock`, `max_stock`, `reference_cost`, `stock_qty`, `stock_value`, `status`, `is_active`, `created_at`) VALUES
(121, 'ELE-FOC-005', 'Reflector LED 50W', 'Reflector LED 50W - SKU institucional', NULL, 6, 17, 1, 2, 1.0, 36.0, 220.0, 12.0, 2640.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(122, 'ELE-EXT-001', 'Extensión 5m 6 tomas', 'Extensión 5m 6 tomas - SKU institucional', NULL, 6, 18, 1, 3, 1.0, 54.0, 95.0, 18.0, 1710.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(123, 'ELE-EXT-002', 'Regleta 4 tomas', 'Regleta 4 tomas - SKU institucional', NULL, 6, 18, 1, 4, 3.0, 90.0, 45.0, 30.0, 1350.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(124, 'ELE-EXT-003', 'UPS 1000VA', 'UPS 1000VA - SKU institucional', NULL, 6, 18, 1, 5, 1.0, 18.0, 1150.0, 6.0, 6900.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(125, 'ELE-EXT-004', 'Regulador de voltaje 1000VA', 'Regulador de voltaje 1000VA - SKU institucional', NULL, 6, 18, 1, 1, 1.0, 24.0, 580.0, 8.0, 4640.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(126, 'ELE-EXT-005', 'Supresor de picos', 'Supresor de picos - SKU institucional', NULL, 6, 18, 1, 2, 1.0, 36.0, 95.0, 12.0, 1140.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(127, 'ELE-EXT-006', 'Multitoma con USB', 'Multitoma con USB - SKU institucional', NULL, 6, 18, 1, 3, 1.0, 45.0, 85.0, 15.0, 1275.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(128, 'ELE-EXT-007', 'Cinta aislante', 'Cinta aislante - SKU institucional', NULL, 6, 18, 1, 4, 6.0, 195.0, 9.0, 65.0, 585.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(129, 'ELE-EXT-008', 'Pila AA paquete x4', 'Pila AA paquete x4 - SKU institucional', NULL, 6, 18, 4, 5, 4.0, 144.0, 22.0, 48.0, 1056.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(130, 'ELE-EXT-009', 'Pila AAA paquete x4', 'Pila AAA paquete x4 - SKU institucional', NULL, 6, 18, 4, 1, 4.0, 126.0, 22.0, 42.0, 924.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(131, 'ELE-EXT-010', 'Pila D paquete x2', 'Pila D paquete x2 - SKU institucional', NULL, 6, 18, 4, 2, 2.0, 75.0, 35.0, 25.0, 875.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(132, 'PAP-HOJ-007', 'Cartulina blanca', 'Cartulina blanca - SKU institucional', NULL, 1, 1, 1, 3, 8.0, 240.0, 2.8, 80.0, 224.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(133, 'PAP-HOJ-008', 'Cartulina de colores', 'Cartulina de colores - SKU institucional', NULL, 1, 1, 1, 4, 6.0, 195.0, 3.2, 65.0, 208.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(134, 'PAP-HOJ-009', 'Papel crepe', 'Papel crepe - SKU institucional', NULL, 1, 1, 1, 5, 4.0, 135.0, 4.5, 45.0, 202.5, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(135, 'PAP-HOJ-010', 'Papel kraft', 'Papel kraft - SKU institucional', NULL, 1, 1, 1, 1, 3.0, 105.0, 5.0, 35.0, 175.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(136, 'PAP-CAR-007', 'Carpeta con anillos 1/2 pulgada', 'Carpeta con anillos 1/2 pulgada - SKU institucional', NULL, 1, 3, 1, 2, 5.0, 150.0, 18.0, 50.0, 900.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(137, 'PAP-CAR-008', 'Carpeta con anillos 1 pulgada', 'Carpeta con anillos 1 pulgada - SKU institucional', NULL, 1, 3, 1, 3, 3.0, 114.0, 26.0, 38.0, 988.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(138, 'PAP-CAR-009', 'Carpeta con anillos 2 pulgadas', 'Carpeta con anillos 2 pulgadas - SKU institucional', NULL, 1, 3, 1, 4, 2.0, 72.0, 42.0, 24.0, 1008.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(139, 'PAP-CAR-010', 'Carpeta L tamaño carta', 'Carpeta L tamaño carta - SKU institucional', NULL, 1, 3, 1, 5, 18.0, 540.0, 1.8, 180.0, 324.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(140, 'PAP-SOB-005', 'Sobre acolchado pequeño', 'Sobre acolchado pequeño - SKU institucional', NULL, 1, 4, 1, 1, 9.0, 270.0, 3.5, 90.0, 315.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(141, 'PAP-SOB-006', 'Sobre acolchado mediano', 'Sobre acolchado mediano - SKU institucional', NULL, 1, 4, 1, 2, 7.0, 225.0, 5.0, 75.0, 375.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(142, 'PAP-SOB-007', 'Sobre acolchado grande', 'Sobre acolchado grande - SKU institucional', NULL, 1, 4, 1, 3, 6.0, 180.0, 7.5, 60.0, 450.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(143, 'PAP-BOL-013', 'Marcador grueso negro', 'Marcador grueso negro - SKU institucional', NULL, 1, 2, 1, 4, 7.0, 210.0, 8.5, 70.0, 595.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(144, 'PAP-BOL-014', 'Marcador pizarra azul', 'Marcador pizarra azul - SKU institucional', NULL, 1, 2, 1, 5, 4.0, 135.0, 9.0, 45.0, 405.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(145, 'PAP-BOL-015', 'Marcador pizarra negro', 'Marcador pizarra negro - SKU institucional', NULL, 1, 2, 1, 1, 4.0, 135.0, 9.0, 45.0, 405.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(146, 'PAP-BOL-016', 'Marcador pizarra rojo', 'Marcador pizarra rojo - SKU institucional', NULL, 1, 2, 1, 2, 3.0, 105.0, 9.0, 35.0, 315.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(147, 'PAP-BOL-017', 'Marcador permanente rojo', 'Marcador permanente rojo - SKU institucional', NULL, 1, 2, 1, 3, 3.0, 90.0, 8.0, 30.0, 240.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(148, 'PAP-BOL-018', 'Marcador permanente verde', 'Marcador permanente verde - SKU institucional', NULL, 1, 2, 1, 4, 2.0, 84.0, 8.0, 28.0, 224.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(149, 'PAP-BOL-019', 'Corrector líquido', 'Corrector líquido - SKU institucional', NULL, 1, 2, 1, 5, 5.0, 165.0, 6.0, 55.0, 330.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(150, 'PAP-BOL-020', 'Corrector en cinta', 'Corrector en cinta - SKU institucional', NULL, 1, 2, 1, 1, 4.0, 120.0, 14.0, 40.0, 560.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(151, 'PAP-GRAP-021', 'Disco compacto CD-R', 'Disco compacto CD-R - SKU institucional', NULL, 1, 5, 1, 2, 5.0, 150.0, 4.5, 50.0, 225.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(152, 'PAP-GRAP-022', 'DVD-R grabable', 'DVD-R grabable - SKU institucional', NULL, 1, 5, 1, 3, 3.0, 105.0, 5.5, 35.0, 192.5, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(153, 'PAP-GRAP-023', 'Sobre plástico CD/DVD', 'Sobre plástico CD/DVD - SKU institucional', NULL, 1, 5, 1, 4, 6.0, 180.0, 1.5, 60.0, 90.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(154, 'PAP-GRAP-024', 'Lupa de oficina', 'Lupa de oficina - SKU institucional', NULL, 1, 5, 1, 5, 1.0, 24.0, 45.0, 8.0, 360.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(155, 'PAP-GRAP-025', 'Porta clips magnético', 'Porta clips magnético - SKU institucional', NULL, 1, 5, 1, 1, 1.0, 36.0, 22.0, 12.0, 264.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(156, 'PAP-GRAP-026', 'Porta lapiceros', 'Porta lapiceros - SKU institucional', NULL, 1, 5, 1, 2, 1.0, 54.0, 18.0, 18.0, 324.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(157, 'PAP-GRAP-027', 'Organizador de escritorio', 'Organizador de escritorio - SKU institucional', NULL, 1, 5, 1, 3, 1.0, 45.0, 95.0, 15.0, 1425.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(158, 'PAP-GRAP-028', 'Bandeja portapapeles 2 pisos', 'Bandeja portapapeles 2 pisos - SKU institucional', NULL, 1, 5, 1, 4, 2.0, 66.0, 78.0, 22.0, 1716.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(159, 'PAP-GRAP-029', 'Revistero de mesa', 'Revistero de mesa - SKU institucional', NULL, 1, 5, 1, 5, 1.0, 42.0, 55.0, 14.0, 770.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(160, 'PAP-GRAP-030', 'Dispensador de cinta adhesiva', 'Dispensador de cinta adhesiva - SKU institucional', NULL, 1, 5, 1, 1, 1.0, 30.0, 38.0, 10.0, 380.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(161, 'INF-CAB-008', 'Cable USB tipo C 1m', 'Cable USB tipo C 1m - SKU institucional', NULL, 4, 13, 1, 2, 2.0, 84.0, 22.0, 28.0, 616.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(162, 'INF-CAB-009', 'Cable USB Lightning 1m', 'Cable USB Lightning 1m - SKU institucional', NULL, 4, 13, 1, 3, 2.0, 60.0, 28.0, 20.0, 560.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(163, 'INF-CAB-010', 'Cable USB micro USB 1m', 'Cable USB micro USB 1m - SKU institucional', NULL, 4, 13, 1, 4, 2.0, 75.0, 18.0, 25.0, 450.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(164, 'INF-USB-006', 'Tarjeta SD 32GB', 'Tarjeta SD 32GB - SKU institucional', NULL, 4, 14, 1, 5, 1.0, 54.0, 75.0, 18.0, 1350.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(165, 'INF-USB-007', 'Tarjeta SD 64GB', 'Tarjeta SD 64GB - SKU institucional', NULL, 4, 14, 1, 1, 1.0, 36.0, 125.0, 12.0, 1500.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(166, 'INF-USB-008', 'Lector de tarjetas', 'Lector de tarjetas - SKU institucional', NULL, 4, 14, 1, 2, 1.0, 30.0, 55.0, 10.0, 550.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(167, 'INF-USB-009', 'Hub USB 4 puertos', 'Hub USB 4 puertos - SKU institucional', NULL, 4, 14, 1, 3, 1.0, 42.0, 78.0, 14.0, 1092.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(168, 'INF-MOU-004', 'Mouse ergonómico', 'Mouse ergonómico - SKU institucional', NULL, 4, 11, 1, 4, 1.0, 24.0, 180.0, 8.0, 1440.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(169, 'INF-MOU-005', 'Mouse con cable tipo C', 'Mouse con cable tipo C - SKU institucional', NULL, 4, 11, 1, 5, 1.0, 45.0, 85.0, 15.0, 1275.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(170, 'INF-TEC-004', 'Teclado mecánico', 'Teclado mecánico - SKU institucional', NULL, 4, 12, 1, 1, 1.0, 18.0, 380.0, 6.0, 2280.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(171, 'INF-TEC-005', 'Teclado numérico externo', 'Teclado numérico externo - SKU institucional', NULL, 4, 12, 1, 2, 1.0, 24.0, 95.0, 8.0, 760.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(172, 'ELE-FOC-006', 'Panel LED 60x60 48W', 'Panel LED 60x60 48W - SKU institucional', NULL, 6, 17, 1, 3, 1.0, 30.0, 320.0, 10.0, 3200.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(173, 'ELE-FOC-007', 'Downlight LED 18W', 'Downlight LED 18W - SKU institucional', NULL, 6, 17, 1, 4, 1.0, 54.0, 95.0, 18.0, 1710.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(174, 'ELE-EXT-011', 'Enchufe industrial 220V', 'Enchufe industrial 220V - SKU institucional', NULL, 6, 18, 1, 5, 1.0, 36.0, 65.0, 12.0, 780.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(175, 'ELE-EXT-012', 'Adaptador de enchufe universal', 'Adaptador de enchufe universal - SKU institucional', NULL, 6, 18, 1, 1, 2.0, 66.0, 22.0, 22.0, 484.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(176, 'ELE-EXT-013', 'Cargador USB de pared', 'Cargador USB de pared - SKU institucional', NULL, 6, 18, 1, 2, 2.0, 84.0, 45.0, 28.0, 1260.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(177, 'ELE-EXT-014', 'Cargador inalámbrico', 'Cargador inalámbrico - SKU institucional', NULL, 6, 18, 1, 3, 1.0, 24.0, 165.0, 8.0, 1320.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(178, 'ESC-SEL-006', 'Sello numerador', 'Sello numerador - SKU institucional', NULL, 5, 15, 1, 4, 1.0, 18.0, 78.0, 6.0, 468.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(179, 'ESC-SEL-007', 'Sello de bolsillo', 'Sello de bolsillo - SKU institucional', NULL, 5, 15, 1, 5, 1.0, 42.0, 32.0, 14.0, 448.0, 'ACTIVO', 1, '2026-10-27 23:36:12'),
(180, 'ESC-PER-011', 'Destructora de papel', 'Destructora de papel - SKU institucional', NULL, 5, 16, 1, 1, 1.0, 9.0, 2200.0, 3.0, 6600.0, 'ACTIVO', 1, '2026-10-27 23:36:12');
INSERT INTO `products` (`id`, `code`, `name`, `description`, `brand`, `category_id`, `subcategory_id`, `unit_id`, `location_id`, `min_stock`, `max_stock`, `reference_cost`, `stock_qty`, `stock_value`, `status`, `is_active`, `created_at`) VALUES
(181, 'ESC-PER-012', 'Cortador de papel industrial', 'Cortador de papel industrial - SKU institucional', NULL, 5, 16, 1, 2, 1.0, 6.0, 1850.0, 2.0, 3700.0, 'ACTIVO', 1, '2026-10-27 23:36:12');

-- request_approvals: 5 registros
INSERT INTO `request_approvals` (`id`, `request_id`, `step_order`, `approver_user_id`, `role_id`, `action`, `action_at`, `comments`) VALUES
(1, 1, 1, 3, 3, 'APROBADO', '2026-08-10 14:20:00', 'Aprobado conforme a presupuesto'),
(2, 2, 1, 1, 1, 'APROBAR', '2026-10-27 23:55:41', 'Aprobado por el Administrador en prueba'),
(3, 3, 1, 3, 3, 'APROBAR', '2026-10-28 00:31:13', ''),
(4, 3, 2, 5, 5, 'APROBAR', '2026-10-28 00:32:05', ''),
(5, 3, 3, 4, 4, 'APROBAR', '2026-10-28 00:32:35', '');

-- request_history: 10 registros
INSERT INTO `request_history` (`id`, `request_id`, `from_state`, `to_state`, `actor_id`, `role_id`, `comments`, `created_at`) VALUES
(1, 1, 'BORRADOR', 'EN_APROBACION', 2, 2, 'Envío a revisión', '2026-08-10 09:30:00'),
(2, 1, 'EN_APROBACION', 'APROBADA', 3, 3, 'Visto Bueno de Jefatura', '2026-08-10 14:20:00'),
(3, 1, 'APROBADA', 'ATENDIDA', 5, 5, 'Despacho físico y entrega realizada', '2026-08-10 16:45:00'),
(4, 2, 'INICIO', 'EN_APROBACION', 1, 1, 'Enviado para aprobación jerárquica', '2026-10-27 23:55:32'),
(5, 2, 'EN_APROBACION', 'APROBADA', 1, 1, 'Decisión [APROBAR]: Aprobado por el Administrador en prueba', '2026-10-27 23:55:41'),
(6, 2, 'APROBADA', 'ATENDIDA', 1, 1, 'Entrega física realizada bajo comprobante SAL-2026-000002 a Prof. Juan Mamani', '2026-10-27 23:56:41'),
(7, 3, 'INICIO', 'EN_APROBACION', 2, 2, 'Enviado para aprobación jerárquica', '2026-10-28 00:06:26'),
(8, 3, 'EN_APROBACION', 'EN_APROBACION', 3, 3, 'Decisión [APROBAR]: ', '2026-10-28 00:31:13'),
(9, 3, 'EN_APROBACION', 'EN_APROBACION', 5, 5, 'Decisión [APROBAR]: ', '2026-10-28 00:32:05'),
(10, 3, 'EN_APROBACION', 'APROBADA', 4, 4, 'Decisión [APROBAR]: ', '2026-10-28 00:32:35');

-- request_items: 6 registros
INSERT INTO `request_items` (`id`, `request_id`, `product_id`, `qty_requested`, `qty_approved`, `qty_proposed`, `qty_authorized`, `qty_delivered`, `stock_at_request`, `status`, `notes`) VALUES
(1, 1, 1, 2.0, 2.0, 2.0, 2.0, 2.0, 480.0, 'ENTREGADO', 'Resmas carta'),
(2, 1, 2, 2.0, 2.0, 2.0, 2.0, 2.0, 85.0, 'ENTREGADO', 'Resmas oficio'),
(3, 1, 3, 2.0, 2.0, 2.0, 2.0, 2.0, 60.0, 'ENTREGADO', 'Resmas A4'),
(4, 2, 1, 3.0, 3.0, 3.0, 3.0, 3.0, 478.0, 'ENTREGADO', 'Resmas carta para prueba'),
(5, 3, 7, 1.001, 1.001, 1.001, 1.001, 0.0, 540.0, 'PENDIENTE', ''),
(6, 3, 177, 1.001, 1.001, 1.001, 1.001, 0.0, 8.0, 'PENDIENTE', '');

-- requests: 3 registros
INSERT INTO `requests` (`id`, `code`, `correspondence_number`, `applicant_id`, `area_id`, `office`, `justification`, `route_id`, `current_step`, `status`, `submitted_at`, `approved_at`, `closed_at`, `rejection_reason`, `observation`, `created_at`) VALUES
(1, 'SOL-2026-000001', 'DDE-2026-00123', 2, 8, 'Recursos Humanos', 'Material de escritorio para inicio de gestión del área de RRHH', 8, 3, 'ATENDIDA', '2026-08-10 09:30:00', '2026-08-10 14:20:00', '2026-08-10 16:45:00', NULL, NULL, '2026-10-27 23:36:12'),
(2, 'SOL-2026-000002', 'TEST-CORR-1793145332', 1, 4, 'Almacen General', 'Prueba automatizada de pedido de material', 4, 3, 'ATENDIDA', '2026-10-27 23:55:32', '2026-10-27 23:55:41', '2026-10-27 23:56:41', NULL, NULL, '2026-10-27 23:55:32'),
(3, 'SOL-2026-000003', '006677', 2, 8, 'Recursos Humanos', '', 8, 3, 'APROBADA', '2026-10-28 00:06:26', '2026-10-28 00:32:35', NULL, NULL, NULL, '2026-10-28 00:06:26');

-- role_permissions: 111 registros
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(1, 13),
(1, 14),
(1, 15),
(1, 16),
(1, 17),
(1, 18),
(1, 19),
(1, 20),
(1, 21),
(1, 22),
(1, 23),
(1, 24),
(1, 25),
(1, 26),
(1, 27),
(1, 28),
(1, 29),
(1, 30),
(1, 31),
(1, 32),
(1, 33),
(1, 34),
(1, 35),
(1, 36),
(1, 37),
(1, 38),
(2, 1),
(2, 2),
(2, 12),
(2, 15),
(2, 16),
(2, 18),
(3, 1),
(3, 2),
(3, 3),
(3, 5),
(3, 6),
(3, 7),
(3, 8),
(3, 21),
(3, 22),
(3, 18),
(4, 1),
(4, 2),
(4, 4),
(4, 3),
(4, 6),
(4, 7);
-- Datos iniciales de role_permissions: se conservan los registros originales.
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(4, 8),
(4, 9),
(4, 21),
(4, 22),
(4, 18),
(4, 30),
(4, 13),
(4, 14),
(4, 15),
(4, 16),
(5, 2),
(5, 4),
(5, 3),
(5, 6),
(5, 7),
(5, 8),
(5, 21),
(5, 22),
(5, 10),
(5, 11),
(5, 13),
(5, 14),
(5, 15),
(5, 23),
(5, 24),
(5, 25),
(5, 26),
(5, 16),
(5, 18),
(5, 19),
(5, 30),
(5, 31),
(5, 32),
(6, 4),
(6, 13),
(6, 14),
(6, 30),
(6, 31),
(7, 4),
(7, 21),
(7, 13),
(7, 14),
(7, 15),
(7, 23),
(7, 24),
(7, 16),
(7, 30),
(7, 31),
(7, 33),
(7, 18),
(7, 19);

-- roles: 7 registros
INSERT INTO `roles` (`id`, `code`, `name`, `description`, `is_system`) VALUES
(1, 'ADMIN', 'Administrador', 'Administración técnica total', 1),
(2, 'SOLICITANTE', 'Solicitante', 'Solicita material', 1),
(3, 'JEFE_INMEDIATO', 'Inmediato Superior', 'Valida necesidad (Aprueba)', 1),
(4, 'JEFE_UAA', 'Jefatura de UAA', 'Autoriza solicitud (Decisión final)', 1),
(5, 'TECNICO_ALMACEN', 'Técnica de Almacenes', 'Prepara y entrega', 1),
(6, 'CONSULTA', 'Consulta', 'Solo lectura', 1),
(7, 'AUDITOR', 'Auditor del Sistema', 'Auditoría global (solo lectura)', 1);

-- sequences: 4 registros
INSERT INTO `sequences` (`id`, `key`, `year`, `current_value`) VALUES
(1, 'SOL', 2026, 3),
(2, 'DES', 2026, 2),
(3, 'ING', 2026, 1),
(4, 'AJ', 2026, 1);

-- sessions: 0 registros

-- settings: 8 registros
INSERT INTO `settings` (`key`, `value`) VALUES
('institucion.nombre', '{"value": "Dirección Departamental de Educación - Cochabamba"}'),
('institucion.sigla', '{"value": "DDE-CBBA"}'),
('impresion.offsetX_mm', '{"value": 0}'),
('impresion.offsetY_mm', '{"value": 0}'),
('impresion.escala', '{"value": 100}'),
('impresion.hoja', '{"value": "carta"}'),
('general.zona_horaria', '{"value": "America/La_Paz"}'),
('general.moneda', '{"value": "BOB"}');

-- stock_dispatches: 2 registros
INSERT INTO `stock_dispatches` (`id`, `number`, `request_id`, `dispatch_date`, `dispatched_by`, `received_by`, `received_ci`, `received_signature_at`, `total_value`, `status`, `voided_by`, `voided_at`, `void_reason`, `notes`, `created_at`) VALUES
(1, 'SAL-2026-000001', 1, '2026-08-10 16:30:00', 5, 'Carlos Quispe Mamani', '3456789', '2026-08-10 16:45:00', 203.0, 'CONFIRMADO', NULL, NULL, NULL, 'Entrega completa contra firma de acta', '2026-10-27 23:36:12'),
(2, 'SAL-2026-000002', 2, '2026-10-27 19:56:41', 1, 'Prof. Juan Mamani', '4938291', '2026-10-27 23:56:41', 97.5, 'CONFIRMADO', NULL, NULL, NULL, 'Entrega exitosa de 3 resmas', '2026-10-27 23:56:41');

-- stock_entries: 1 registros
INSERT INTO `stock_entries` (`id`, `number`, `type`, `supplier_id`, `doc_type`, `doc_number`, `doc_date`, `entry_date`, `posted_at`, `total_amount`, `notes`, `status`, `voided_by`, `voided_at`, `void_reason`, `created_by`, `created_at`) VALUES
(1, 'ING-2026-000001', 'APERTURA', NULL, 'INVENTARIO_INICIAL', 'ACTA-2026-001', '2026-08-09 08:00:00', '2026-08-09 08:00:00', '2026-08-09 08:00:00', 245682.0, 'Acta de conciliación de apertura del sistema SIGA-DDE al 09/08/2026. Saldo valorado total conciliado contra inventario oficial clasificado.', 'CONFIRMADO', NULL, NULL, NULL, 1, '2026-08-09 08:00:00');

-- stock_entry_items: 181 registros
INSERT INTO `stock_entry_items` (`id`, `entry_id`, `product_id`, `location_id`, `quantity`, `unit_cost`, `total`, `notes`) VALUES
(1, 1, 1, 2, 480.0, 32.5, 15600.0, 'Inventario inicial conciliado'),
(2, 1, 2, 3, 85.0, 38.2, 3247.0, 'Inventario inicial conciliado'),
(3, 1, 3, 4, 60.0, 30.8, 1848.0, 'Inventario inicial conciliado'),
(4, 1, 4, 5, 24.0, 95.0, 2280.0, 'Inventario inicial conciliado'),
(5, 1, 5, 1, 140.0, 1.5, 210.0, 'Inventario inicial conciliado'),
(6, 1, 6, 2, 15.0, 34.0, 510.0, 'Inventario inicial conciliado'),
(7, 1, 7, 3, 540.0, 2.8, 1512.0, 'Inventario inicial conciliado'),
(8, 1, 8, 4, 430.0, 2.8, 1204.0, 'Inventario inicial conciliado'),
(9, 1, 9, 5, 320.0, 2.8, 896.0, 'Inventario inicial conciliado'),
(10, 1, 10, 1, 150.0, 2.8, 420.0, 'Inventario inicial conciliado'),
(11, 1, 11, 2, 600.0, 1.2, 720.0, 'Inventario inicial conciliado'),
(12, 1, 12, 3, 120.0, 1.5, 180.0, 'Inventario inicial conciliado'),
(13, 1, 13, 4, 88.0, 5.5, 484.0, 'Inventario inicial conciliado'),
(14, 1, 14, 5, 75.0, 5.5, 412.5, 'Inventario inicial conciliado'),
(15, 1, 15, 1, 60.0, 5.5, 330.0, 'Inventario inicial conciliado'),
(16, 1, 16, 2, 95.0, 6.0, 570.0, 'Inventario inicial conciliado'),
(17, 1, 17, 3, 70.0, 6.0, 420.0, 'Inventario inicial conciliado'),
(18, 1, 18, 4, 55.0, 6.0, 330.0, 'Inventario inicial conciliado'),
(19, 1, 19, 5, 250.0, 4.5, 1125.0, 'Inventario inicial conciliado'),
(20, 1, 20, 1, 200.0, 6.8, 1360.0, 'Inventario inicial conciliado'),
(21, 1, 21, 2, 95.0, 22.0, 2090.0, 'Inventario inicial conciliado'),
(22, 1, 22, 3, 65.0, 28.0, 1820.0, 'Inventario inicial conciliado'),
(23, 1, 23, 4, 180.0, 7.5, 1350.0, 'Inventario inicial conciliado'),
(24, 1, 24, 5, 540.0, 0.9, 486.0, 'Inventario inicial conciliado'),
(25, 1, 25, 1, 420.0, 1.2, 504.0, 'Inventario inicial conciliado'),
(26, 1, 26, 2, 380.0, 1.0, 380.0, 'Inventario inicial conciliado'),
(27, 1, 27, 3, 150.0, 2.5, 375.0, 'Inventario inicial conciliado'),
(28, 1, 28, 4, 220.0, 1.1, 242.0, 'Inventario inicial conciliado'),
(29, 1, 29, 5, 85.0, 7.5, 637.5, 'Inventario inicial conciliado'),
(30, 1, 30, 1, 60.0, 9.0, 540.0, 'Inventario inicial conciliado'),
(31, 1, 31, 2, 120.0, 4.5, 540.0, 'Inventario inicial conciliado'),
(32, 1, 32, 3, 40.0, 5.0, 200.0, 'Inventario inicial conciliado'),
(33, 1, 33, 4, 150.0, 5.0, 750.0, 'Inventario inicial conciliado'),
(34, 1, 34, 5, 70.0, 9.5, 665.0, 'Inventario inicial conciliado'),
(35, 1, 35, 1, 45.0, 16.0, 720.0, 'Inventario inicial conciliado'),
(36, 1, 36, 2, 130.0, 6.0, 780.0, 'Inventario inicial conciliado'),
(37, 1, 37, 3, 35.0, 12.0, 420.0, 'Inventario inicial conciliado'),
(38, 1, 38, 4, 18.0, 28.0, 504.0, 'Inventario inicial conciliado'),
(39, 1, 39, 5, 220.0, 1.0, 220.0, 'Inventario inicial conciliado'),
(40, 1, 40, 1, 60.0, 2.5, 150.0, 'Inventario inicial conciliado'),
(41, 1, 41, 2, 90.0, 18.0, 1620.0, 'Inventario inicial conciliado'),
(42, 1, 42, 3, 75.0, 9.5, 712.5, 'Inventario inicial conciliado'),
(43, 1, 43, 4, 55.0, 11.0, 605.0, 'Inventario inicial conciliado'),
(44, 1, 44, 5, 30.0, 3.5, 105.0, 'Inventario inicial conciliado'),
(45, 1, 45, 1, 22.0, 65.0, 1430.0, 'Inventario inicial conciliado'),
(46, 1, 46, 2, 28.0, 38.0, 1064.0, 'Inventario inicial conciliado'),
(47, 1, 47, 3, 25.0, 45.0, 1125.0, 'Inventario inicial conciliado'),
(48, 1, 48, 4, 50.0, 22.0, 1100.0, 'Inventario inicial conciliado'),
(49, 1, 49, 5, 38.0, 95.0, 3610.0, 'Inventario inicial conciliado'),
(50, 1, 50, 1, 30.0, 110.0, 3300.0, 'Inventario inicial conciliado'),
(51, 1, 51, 2, 22.0, 75.0, 1650.0, 'Inventario inicial conciliado'),
(52, 1, 52, 3, 18.0, 75.0, 1350.0, 'Inventario inicial conciliado'),
(53, 1, 53, 4, 18.0, 75.0, 1350.0, 'Inventario inicial conciliado'),
(54, 1, 54, 5, 18.0, 75.0, 1350.0, 'Inventario inicial conciliado'),
(55, 1, 55, 1, 25.0, 88.0, 2200.0, 'Inventario inicial conciliado'),
(56, 1, 56, 2, 20.0, 125.0, 2500.0, 'Inventario inicial conciliado'),
(57, 1, 57, 3, 14.0, 280.0, 3920.0, 'Inventario inicial conciliado'),
(58, 1, 58, 4, 12.0, 310.0, 3720.0, 'Inventario inicial conciliado'),
(59, 1, 59, 5, 8.0, 360.0, 2880.0, 'Inventario inicial conciliado'),
(60, 1, 60, 1, 10.0, 290.0, 2900.0, 'Inventario inicial conciliado');
-- Datos iniciales de stock_entry_items: se conservan los registros originales.
INSERT INTO `stock_entry_items` (`id`, `entry_id`, `product_id`, `location_id`, `quantity`, `unit_cost`, `total`, `notes`) VALUES
(61, 1, 61, 2, 6.0, 320.0, 1920.0, 'Inventario inicial conciliado'),
(62, 1, 62, 3, 5.0, 410.0, 2050.0, 'Inventario inicial conciliado'),
(63, 1, 63, 4, 4.0, 480.0, 1920.0, 'Inventario inicial conciliado'),
(64, 1, 64, 5, 240.0, 18.0, 4320.0, 'Inventario inicial conciliado'),
(65, 1, 65, 1, 95.0, 22.0, 2090.0, 'Inventario inicial conciliado'),
(66, 1, 66, 2, 40.0, 12.0, 480.0, 'Inventario inicial conciliado'),
(67, 1, 67, 3, 35.0, 22.0, 770.0, 'Inventario inicial conciliado'),
(68, 1, 68, 4, 30.0, 28.0, 840.0, 'Inventario inicial conciliado'),
(69, 1, 69, 5, 50.0, 25.0, 1250.0, 'Inventario inicial conciliado'),
(70, 1, 70, 1, 60.0, 14.0, 840.0, 'Inventario inicial conciliado'),
(71, 1, 71, 2, 40.0, 38.0, 1520.0, 'Inventario inicial conciliado'),
(72, 1, 72, 3, 35.0, 42.0, 1470.0, 'Inventario inicial conciliado'),
(73, 1, 73, 4, 180.0, 2.5, 450.0, 'Inventario inicial conciliado'),
(74, 1, 74, 5, 70.0, 8.0, 560.0, 'Inventario inicial conciliado'),
(75, 1, 75, 1, 200.0, 1.5, 300.0, 'Inventario inicial conciliado'),
(76, 1, 76, 2, 120.0, 2.2, 264.0, 'Inventario inicial conciliado'),
(77, 1, 77, 3, 22.0, 25.0, 550.0, 'Inventario inicial conciliado'),
(78, 1, 78, 4, 18.0, 28.0, 504.0, 'Inventario inicial conciliado'),
(79, 1, 79, 5, 16.0, 18.0, 288.0, 'Inventario inicial conciliado'),
(80, 1, 80, 1, 60.0, 8.5, 510.0, 'Inventario inicial conciliado'),
(81, 1, 81, 2, 28.0, 32.0, 896.0, 'Inventario inicial conciliado'),
(82, 1, 82, 3, 25.0, 26.0, 650.0, 'Inventario inicial conciliado'),
(83, 1, 83, 4, 22.0, 18.0, 396.0, 'Inventario inicial conciliado'),
(84, 1, 84, 5, 45.0, 55.0, 2475.0, 'Inventario inicial conciliado'),
(85, 1, 85, 1, 28.0, 95.0, 2660.0, 'Inventario inicial conciliado'),
(86, 1, 86, 2, 80.0, 12.0, 960.0, 'Inventario inicial conciliado'),
(87, 1, 87, 3, 30.0, 85.0, 2550.0, 'Inventario inicial conciliado'),
(88, 1, 88, 4, 18.0, 145.0, 2610.0, 'Inventario inicial conciliado'),
(89, 1, 89, 5, 15.0, 165.0, 2475.0, 'Inventario inicial conciliado'),
(90, 1, 90, 1, 22.0, 35.0, 770.0, 'Inventario inicial conciliado'),
(91, 1, 91, 2, 18.0, 28.0, 504.0, 'Inventario inicial conciliado'),
(92, 1, 92, 3, 30.0, 18.0, 540.0, 'Inventario inicial conciliado'),
(93, 1, 93, 4, 250.0, 4.5, 1125.0, 'Inventario inicial conciliado'),
(94, 1, 94, 5, 40.0, 22.0, 880.0, 'Inventario inicial conciliado'),
(95, 1, 95, 1, 14.0, 65.0, 910.0, 'Inventario inicial conciliado'),
(96, 1, 96, 2, 35.0, 22.0, 770.0, 'Inventario inicial conciliado'),
(97, 1, 97, 3, 38.0, 65.0, 2470.0, 'Inventario inicial conciliado'),
(98, 1, 98, 4, 30.0, 90.0, 2700.0, 'Inventario inicial conciliado'),
(99, 1, 99, 5, 18.0, 145.0, 2610.0, 'Inventario inicial conciliado'),
(100, 1, 100, 1, 8.0, 580.0, 4640.0, 'Inventario inicial conciliado'),
(101, 1, 101, 2, 5.0, 820.0, 4100.0, 'Inventario inicial conciliado'),
(102, 1, 102, 3, 25.0, 25.0, 625.0, 'Inventario inicial conciliado'),
(103, 1, 103, 4, 18.0, 42.0, 756.0, 'Inventario inicial conciliado'),
(104, 1, 104, 5, 60.0, 7.5, 450.0, 'Inventario inicial conciliado'),
(105, 1, 105, 1, 55.0, 7.5, 412.5, 'Inventario inicial conciliado'),
(106, 1, 106, 2, 30.0, 11.0, 330.0, 'Inventario inicial conciliado'),
(107, 1, 107, 3, 22.0, 85.0, 1870.0, 'Inventario inicial conciliado'),
(108, 1, 108, 4, 12.0, 130.0, 1560.0, 'Inventario inicial conciliado'),
(109, 1, 109, 5, 4.0, 480.0, 1920.0, 'Inventario inicial conciliado'),
(110, 1, 110, 1, 5.0, 380.0, 1900.0, 'Inventario inicial conciliado'),
(111, 1, 111, 2, 25.0, 65.0, 1625.0, 'Inventario inicial conciliado'),
(112, 1, 112, 3, 3.0, 980.0, 2940.0, 'Inventario inicial conciliado'),
(113, 1, 113, 4, 2.0, 2400.0, 4800.0, 'Inventario inicial conciliado'),
(114, 1, 114, 5, 35.0, 38.0, 1330.0, 'Inventario inicial conciliado'),
(115, 1, 115, 1, 110.0, 2.0, 220.0, 'Inventario inicial conciliado'),
(116, 1, 116, 2, 65.0, 25.0, 1625.0, 'Inventario inicial conciliado'),
(117, 1, 117, 3, 120.0, 18.0, 2160.0, 'Inventario inicial conciliado'),
(118, 1, 118, 4, 85.0, 24.0, 2040.0, 'Inventario inicial conciliado'),
(119, 1, 119, 5, 60.0, 32.0, 1920.0, 'Inventario inicial conciliado'),
(120, 1, 120, 1, 45.0, 48.0, 2160.0, 'Inventario inicial conciliado');
INSERT INTO `stock_entry_items` (`id`, `entry_id`, `product_id`, `location_id`, `quantity`, `unit_cost`, `total`, `notes`) VALUES
(121, 1, 121, 2, 12.0, 220.0, 2640.0, 'Inventario inicial conciliado'),
(122, 1, 122, 3, 18.0, 95.0, 1710.0, 'Inventario inicial conciliado'),
(123, 1, 123, 4, 30.0, 45.0, 1350.0, 'Inventario inicial conciliado'),
(124, 1, 124, 5, 6.0, 1150.0, 6900.0, 'Inventario inicial conciliado'),
(125, 1, 125, 1, 8.0, 580.0, 4640.0, 'Inventario inicial conciliado'),
(126, 1, 126, 2, 12.0, 95.0, 1140.0, 'Inventario inicial conciliado'),
(127, 1, 127, 3, 15.0, 85.0, 1275.0, 'Inventario inicial conciliado'),
(128, 1, 128, 4, 65.0, 9.0, 585.0, 'Inventario inicial conciliado'),
(129, 1, 129, 5, 48.0, 22.0, 1056.0, 'Inventario inicial conciliado'),
(130, 1, 130, 1, 42.0, 22.0, 924.0, 'Inventario inicial conciliado'),
(131, 1, 131, 2, 25.0, 35.0, 875.0, 'Inventario inicial conciliado'),
(132, 1, 132, 3, 80.0, 2.8, 224.0, 'Inventario inicial conciliado'),
(133, 1, 133, 4, 65.0, 3.2, 208.0, 'Inventario inicial conciliado'),
(134, 1, 134, 5, 45.0, 4.5, 202.5, 'Inventario inicial conciliado'),
(135, 1, 135, 1, 35.0, 5.0, 175.0, 'Inventario inicial conciliado'),
(136, 1, 136, 2, 50.0, 18.0, 900.0, 'Inventario inicial conciliado'),
(137, 1, 137, 3, 38.0, 26.0, 988.0, 'Inventario inicial conciliado'),
(138, 1, 138, 4, 24.0, 42.0, 1008.0, 'Inventario inicial conciliado'),
(139, 1, 139, 5, 180.0, 1.8, 324.0, 'Inventario inicial conciliado'),
(140, 1, 140, 1, 90.0, 3.5, 315.0, 'Inventario inicial conciliado'),
(141, 1, 141, 2, 75.0, 5.0, 375.0, 'Inventario inicial conciliado'),
(142, 1, 142, 3, 60.0, 7.5, 450.0, 'Inventario inicial conciliado'),
(143, 1, 143, 4, 70.0, 8.5, 595.0, 'Inventario inicial conciliado'),
(144, 1, 144, 5, 45.0, 9.0, 405.0, 'Inventario inicial conciliado'),
(145, 1, 145, 1, 45.0, 9.0, 405.0, 'Inventario inicial conciliado'),
(146, 1, 146, 2, 35.0, 9.0, 315.0, 'Inventario inicial conciliado'),
(147, 1, 147, 3, 30.0, 8.0, 240.0, 'Inventario inicial conciliado'),
(148, 1, 148, 4, 28.0, 8.0, 224.0, 'Inventario inicial conciliado'),
(149, 1, 149, 5, 55.0, 6.0, 330.0, 'Inventario inicial conciliado'),
(150, 1, 150, 1, 40.0, 14.0, 560.0, 'Inventario inicial conciliado'),
(151, 1, 151, 2, 50.0, 4.5, 225.0, 'Inventario inicial conciliado'),
(152, 1, 152, 3, 35.0, 5.5, 192.5, 'Inventario inicial conciliado'),
(153, 1, 153, 4, 60.0, 1.5, 90.0, 'Inventario inicial conciliado'),
(154, 1, 154, 5, 8.0, 45.0, 360.0, 'Inventario inicial conciliado'),
(155, 1, 155, 1, 12.0, 22.0, 264.0, 'Inventario inicial conciliado'),
(156, 1, 156, 2, 18.0, 18.0, 324.0, 'Inventario inicial conciliado'),
(157, 1, 157, 3, 15.0, 95.0, 1425.0, 'Inventario inicial conciliado'),
(158, 1, 158, 4, 22.0, 78.0, 1716.0, 'Inventario inicial conciliado'),
(159, 1, 159, 5, 14.0, 55.0, 770.0, 'Inventario inicial conciliado'),
(160, 1, 160, 1, 10.0, 38.0, 380.0, 'Inventario inicial conciliado'),
(161, 1, 161, 2, 28.0, 22.0, 616.0, 'Inventario inicial conciliado'),
(162, 1, 162, 3, 20.0, 28.0, 560.0, 'Inventario inicial conciliado'),
(163, 1, 163, 4, 25.0, 18.0, 450.0, 'Inventario inicial conciliado'),
(164, 1, 164, 5, 18.0, 75.0, 1350.0, 'Inventario inicial conciliado'),
(165, 1, 165, 1, 12.0, 125.0, 1500.0, 'Inventario inicial conciliado'),
(166, 1, 166, 2, 10.0, 55.0, 550.0, 'Inventario inicial conciliado'),
(167, 1, 167, 3, 14.0, 78.0, 1092.0, 'Inventario inicial conciliado'),
(168, 1, 168, 4, 8.0, 180.0, 1440.0, 'Inventario inicial conciliado'),
(169, 1, 169, 5, 15.0, 85.0, 1275.0, 'Inventario inicial conciliado'),
(170, 1, 170, 1, 6.0, 380.0, 2280.0, 'Inventario inicial conciliado'),
(171, 1, 171, 2, 8.0, 95.0, 760.0, 'Inventario inicial conciliado'),
(172, 1, 172, 3, 10.0, 320.0, 3200.0, 'Inventario inicial conciliado'),
(173, 1, 173, 4, 18.0, 95.0, 1710.0, 'Inventario inicial conciliado'),
(174, 1, 174, 5, 12.0, 65.0, 780.0, 'Inventario inicial conciliado'),
(175, 1, 175, 1, 22.0, 22.0, 484.0, 'Inventario inicial conciliado'),
(176, 1, 176, 2, 28.0, 45.0, 1260.0, 'Inventario inicial conciliado'),
(177, 1, 177, 3, 8.0, 165.0, 1320.0, 'Inventario inicial conciliado'),
(178, 1, 178, 4, 6.0, 78.0, 468.0, 'Inventario inicial conciliado'),
(179, 1, 179, 5, 14.0, 32.0, 448.0, 'Inventario inicial conciliado'),
(180, 1, 180, 1, 3.0, 2200.0, 6600.0, 'Inventario inicial conciliado');
INSERT INTO `stock_entry_items` (`id`, `entry_id`, `product_id`, `location_id`, `quantity`, `unit_cost`, `total`, `notes`) VALUES
(181, 1, 181, 2, 2.0, 1850.0, 3700.0, 'Inventario inicial conciliado');

-- stock_layers: 181 registros
INSERT INTO `stock_layers` (`id`, `product_id`, `entry_id`, `entry_item_id`, `layer_date`, `sequence`, `original_qty`, `remaining_qty`, `unit_cost`, `status`) VALUES
(1, 1, 1, 1, '2026-08-09 08:00:00', 1, 480.0, 475.0, 32.5, 'ABIERTA'),
(2, 2, 1, 2, '2026-08-09 08:00:00', 1, 85.0, 83.0, 38.2, 'ABIERTA'),
(3, 3, 1, 3, '2026-08-09 08:00:00', 1, 60.0, 58.0, 30.8, 'ABIERTA'),
(4, 4, 1, 4, '2026-08-09 08:00:00', 1, 24.0, 24.0, 95.0, 'ABIERTA'),
(5, 5, 1, 5, '2026-08-09 08:00:00', 1, 140.0, 140.0, 1.5, 'ABIERTA'),
(6, 6, 1, 6, '2026-08-09 08:00:00', 1, 15.0, 15.0, 34.0, 'ABIERTA'),
(7, 7, 1, 7, '2026-08-09 08:00:00', 1, 540.0, 540.0, 2.8, 'ABIERTA'),
(8, 8, 1, 8, '2026-08-09 08:00:00', 1, 430.0, 430.0, 2.8, 'ABIERTA'),
(9, 9, 1, 9, '2026-08-09 08:00:00', 1, 320.0, 320.0, 2.8, 'ABIERTA'),
(10, 10, 1, 10, '2026-08-09 08:00:00', 1, 150.0, 150.0, 2.8, 'ABIERTA'),
(11, 11, 1, 11, '2026-08-09 08:00:00', 1, 600.0, 600.0, 1.2, 'ABIERTA'),
(12, 12, 1, 12, '2026-08-09 08:00:00', 1, 120.0, 120.0, 1.5, 'ABIERTA'),
(13, 13, 1, 13, '2026-08-09 08:00:00', 1, 88.0, 88.0, 5.5, 'ABIERTA'),
(14, 14, 1, 14, '2026-08-09 08:00:00', 1, 75.0, 75.0, 5.5, 'ABIERTA'),
(15, 15, 1, 15, '2026-08-09 08:00:00', 1, 60.0, 60.0, 5.5, 'ABIERTA'),
(16, 16, 1, 16, '2026-08-09 08:00:00', 1, 95.0, 95.0, 6.0, 'ABIERTA'),
(17, 17, 1, 17, '2026-08-09 08:00:00', 1, 70.0, 70.0, 6.0, 'ABIERTA'),
(18, 18, 1, 18, '2026-08-09 08:00:00', 1, 55.0, 55.0, 6.0, 'ABIERTA'),
(19, 19, 1, 19, '2026-08-09 08:00:00', 1, 250.0, 250.0, 4.5, 'ABIERTA'),
(20, 20, 1, 20, '2026-08-09 08:00:00', 1, 200.0, 200.0, 6.8, 'ABIERTA'),
(21, 21, 1, 21, '2026-08-09 08:00:00', 1, 95.0, 95.0, 22.0, 'ABIERTA'),
(22, 22, 1, 22, '2026-08-09 08:00:00', 1, 65.0, 65.0, 28.0, 'ABIERTA'),
(23, 23, 1, 23, '2026-08-09 08:00:00', 1, 180.0, 180.0, 7.5, 'ABIERTA'),
(24, 24, 1, 24, '2026-08-09 08:00:00', 1, 540.0, 540.0, 0.9, 'ABIERTA'),
(25, 25, 1, 25, '2026-08-09 08:00:00', 1, 420.0, 420.0, 1.2, 'ABIERTA'),
(26, 26, 1, 26, '2026-08-09 08:00:00', 1, 380.0, 380.0, 1.0, 'ABIERTA'),
(27, 27, 1, 27, '2026-08-09 08:00:00', 1, 150.0, 150.0, 2.5, 'ABIERTA'),
(28, 28, 1, 28, '2026-08-09 08:00:00', 1, 220.0, 220.0, 1.1, 'ABIERTA'),
(29, 29, 1, 29, '2026-08-09 08:00:00', 1, 85.0, 85.0, 7.5, 'ABIERTA'),
(30, 30, 1, 30, '2026-08-09 08:00:00', 1, 60.0, 60.0, 9.0, 'ABIERTA'),
(31, 31, 1, 31, '2026-08-09 08:00:00', 1, 120.0, 120.0, 4.5, 'ABIERTA'),
(32, 32, 1, 32, '2026-08-09 08:00:00', 1, 40.0, 40.0, 5.0, 'ABIERTA'),
(33, 33, 1, 33, '2026-08-09 08:00:00', 1, 150.0, 150.0, 5.0, 'ABIERTA'),
(34, 34, 1, 34, '2026-08-09 08:00:00', 1, 70.0, 70.0, 9.5, 'ABIERTA'),
(35, 35, 1, 35, '2026-08-09 08:00:00', 1, 45.0, 45.0, 16.0, 'ABIERTA'),
(36, 36, 1, 36, '2026-08-09 08:00:00', 1, 130.0, 130.0, 6.0, 'ABIERTA'),
(37, 37, 1, 37, '2026-08-09 08:00:00', 1, 35.0, 35.0, 12.0, 'ABIERTA'),
(38, 38, 1, 38, '2026-08-09 08:00:00', 1, 18.0, 18.0, 28.0, 'ABIERTA'),
(39, 39, 1, 39, '2026-08-09 08:00:00', 1, 220.0, 220.0, 1.0, 'ABIERTA'),
(40, 40, 1, 40, '2026-08-09 08:00:00', 1, 60.0, 60.0, 2.5, 'ABIERTA'),
(41, 41, 1, 41, '2026-08-09 08:00:00', 1, 90.0, 90.0, 18.0, 'ABIERTA'),
(42, 42, 1, 42, '2026-08-09 08:00:00', 1, 75.0, 75.0, 9.5, 'ABIERTA'),
(43, 43, 1, 43, '2026-08-09 08:00:00', 1, 55.0, 55.0, 11.0, 'ABIERTA'),
(44, 44, 1, 44, '2026-08-09 08:00:00', 1, 30.0, 30.0, 3.5, 'ABIERTA'),
(45, 45, 1, 45, '2026-08-09 08:00:00', 1, 22.0, 22.0, 65.0, 'ABIERTA'),
(46, 46, 1, 46, '2026-08-09 08:00:00', 1, 28.0, 28.0, 38.0, 'ABIERTA'),
(47, 47, 1, 47, '2026-08-09 08:00:00', 1, 25.0, 25.0, 45.0, 'ABIERTA'),
(48, 48, 1, 48, '2026-08-09 08:00:00', 1, 50.0, 50.0, 22.0, 'ABIERTA'),
(49, 49, 1, 49, '2026-08-09 08:00:00', 1, 38.0, 38.0, 95.0, 'ABIERTA'),
(50, 50, 1, 50, '2026-08-09 08:00:00', 1, 30.0, 30.0, 110.0, 'ABIERTA'),
(51, 51, 1, 51, '2026-08-09 08:00:00', 1, 22.0, 22.0, 75.0, 'ABIERTA'),
(52, 52, 1, 52, '2026-08-09 08:00:00', 1, 18.0, 18.0, 75.0, 'ABIERTA'),
(53, 53, 1, 53, '2026-08-09 08:00:00', 1, 18.0, 18.0, 75.0, 'ABIERTA'),
(54, 54, 1, 54, '2026-08-09 08:00:00', 1, 18.0, 18.0, 75.0, 'ABIERTA'),
(55, 55, 1, 55, '2026-08-09 08:00:00', 1, 25.0, 25.0, 88.0, 'ABIERTA'),
(56, 56, 1, 56, '2026-08-09 08:00:00', 1, 20.0, 20.0, 125.0, 'ABIERTA'),
(57, 57, 1, 57, '2026-08-09 08:00:00', 1, 14.0, 14.0, 280.0, 'ABIERTA'),
(58, 58, 1, 58, '2026-08-09 08:00:00', 1, 12.0, 12.0, 310.0, 'ABIERTA'),
(59, 59, 1, 59, '2026-08-09 08:00:00', 1, 8.0, 8.0, 360.0, 'ABIERTA'),
(60, 60, 1, 60, '2026-08-09 08:00:00', 1, 10.0, 10.0, 290.0, 'ABIERTA');
-- Datos iniciales de stock_layers: se conservan los registros originales.
INSERT INTO `stock_layers` (`id`, `product_id`, `entry_id`, `entry_item_id`, `layer_date`, `sequence`, `original_qty`, `remaining_qty`, `unit_cost`, `status`) VALUES
(61, 61, 1, 61, '2026-08-09 08:00:00', 1, 6.0, 6.0, 320.0, 'ABIERTA'),
(62, 62, 1, 62, '2026-08-09 08:00:00', 1, 5.0, 5.0, 410.0, 'ABIERTA'),
(63, 63, 1, 63, '2026-08-09 08:00:00', 1, 4.0, 4.0, 480.0, 'ABIERTA'),
(64, 64, 1, 64, '2026-08-09 08:00:00', 1, 240.0, 240.0, 18.0, 'ABIERTA'),
(65, 65, 1, 65, '2026-08-09 08:00:00', 1, 95.0, 95.0, 22.0, 'ABIERTA'),
(66, 66, 1, 66, '2026-08-09 08:00:00', 1, 40.0, 40.0, 12.0, 'ABIERTA'),
(67, 67, 1, 67, '2026-08-09 08:00:00', 1, 35.0, 35.0, 22.0, 'ABIERTA'),
(68, 68, 1, 68, '2026-08-09 08:00:00', 1, 30.0, 30.0, 28.0, 'ABIERTA'),
(69, 69, 1, 69, '2026-08-09 08:00:00', 1, 50.0, 50.0, 25.0, 'ABIERTA'),
(70, 70, 1, 70, '2026-08-09 08:00:00', 1, 60.0, 60.0, 14.0, 'ABIERTA'),
(71, 71, 1, 71, '2026-08-09 08:00:00', 1, 40.0, 40.0, 38.0, 'ABIERTA'),
(72, 72, 1, 72, '2026-08-09 08:00:00', 1, 35.0, 35.0, 42.0, 'ABIERTA'),
(73, 73, 1, 73, '2026-08-09 08:00:00', 1, 180.0, 180.0, 2.5, 'ABIERTA'),
(74, 74, 1, 74, '2026-08-09 08:00:00', 1, 70.0, 70.0, 8.0, 'ABIERTA'),
(75, 75, 1, 75, '2026-08-09 08:00:00', 1, 200.0, 200.0, 1.5, 'ABIERTA'),
(76, 76, 1, 76, '2026-08-09 08:00:00', 1, 120.0, 120.0, 2.2, 'ABIERTA'),
(77, 77, 1, 77, '2026-08-09 08:00:00', 1, 22.0, 22.0, 25.0, 'ABIERTA'),
(78, 78, 1, 78, '2026-08-09 08:00:00', 1, 18.0, 18.0, 28.0, 'ABIERTA'),
(79, 79, 1, 79, '2026-08-09 08:00:00', 1, 16.0, 16.0, 18.0, 'ABIERTA'),
(80, 80, 1, 80, '2026-08-09 08:00:00', 1, 60.0, 60.0, 8.5, 'ABIERTA'),
(81, 81, 1, 81, '2026-08-09 08:00:00', 1, 28.0, 28.0, 32.0, 'ABIERTA'),
(82, 82, 1, 82, '2026-08-09 08:00:00', 1, 25.0, 25.0, 26.0, 'ABIERTA'),
(83, 83, 1, 83, '2026-08-09 08:00:00', 1, 22.0, 22.0, 18.0, 'ABIERTA'),
(84, 84, 1, 84, '2026-08-09 08:00:00', 1, 45.0, 45.0, 55.0, 'ABIERTA'),
(85, 85, 1, 85, '2026-08-09 08:00:00', 1, 28.0, 28.0, 95.0, 'ABIERTA'),
(86, 86, 1, 86, '2026-08-09 08:00:00', 1, 80.0, 80.0, 12.0, 'ABIERTA'),
(87, 87, 1, 87, '2026-08-09 08:00:00', 1, 30.0, 30.0, 85.0, 'ABIERTA'),
(88, 88, 1, 88, '2026-08-09 08:00:00', 1, 18.0, 18.0, 145.0, 'ABIERTA'),
(89, 89, 1, 89, '2026-08-09 08:00:00', 1, 15.0, 15.0, 165.0, 'ABIERTA'),
(90, 90, 1, 90, '2026-08-09 08:00:00', 1, 22.0, 22.0, 35.0, 'ABIERTA'),
(91, 91, 1, 91, '2026-08-09 08:00:00', 1, 18.0, 18.0, 28.0, 'ABIERTA'),
(92, 92, 1, 92, '2026-08-09 08:00:00', 1, 30.0, 30.0, 18.0, 'ABIERTA'),
(93, 93, 1, 93, '2026-08-09 08:00:00', 1, 250.0, 250.0, 4.5, 'ABIERTA'),
(94, 94, 1, 94, '2026-08-09 08:00:00', 1, 40.0, 40.0, 22.0, 'ABIERTA'),
(95, 95, 1, 95, '2026-08-09 08:00:00', 1, 14.0, 14.0, 65.0, 'ABIERTA'),
(96, 96, 1, 96, '2026-08-09 08:00:00', 1, 35.0, 35.0, 22.0, 'ABIERTA'),
(97, 97, 1, 97, '2026-08-09 08:00:00', 1, 38.0, 38.0, 65.0, 'ABIERTA'),
(98, 98, 1, 98, '2026-08-09 08:00:00', 1, 30.0, 30.0, 90.0, 'ABIERTA'),
(99, 99, 1, 99, '2026-08-09 08:00:00', 1, 18.0, 18.0, 145.0, 'ABIERTA'),
(100, 100, 1, 100, '2026-08-09 08:00:00', 1, 8.0, 8.0, 580.0, 'ABIERTA'),
(101, 101, 1, 101, '2026-08-09 08:00:00', 1, 5.0, 5.0, 820.0, 'ABIERTA'),
(102, 102, 1, 102, '2026-08-09 08:00:00', 1, 25.0, 25.0, 25.0, 'ABIERTA'),
(103, 103, 1, 103, '2026-08-09 08:00:00', 1, 18.0, 18.0, 42.0, 'ABIERTA'),
(104, 104, 1, 104, '2026-08-09 08:00:00', 1, 60.0, 60.0, 7.5, 'ABIERTA'),
(105, 105, 1, 105, '2026-08-09 08:00:00', 1, 55.0, 55.0, 7.5, 'ABIERTA'),
(106, 106, 1, 106, '2026-08-09 08:00:00', 1, 30.0, 30.0, 11.0, 'ABIERTA'),
(107, 107, 1, 107, '2026-08-09 08:00:00', 1, 22.0, 22.0, 85.0, 'ABIERTA'),
(108, 108, 1, 108, '2026-08-09 08:00:00', 1, 12.0, 12.0, 130.0, 'ABIERTA'),
(109, 109, 1, 109, '2026-08-09 08:00:00', 1, 4.0, 4.0, 480.0, 'ABIERTA'),
(110, 110, 1, 110, '2026-08-09 08:00:00', 1, 5.0, 5.0, 380.0, 'ABIERTA'),
(111, 111, 1, 111, '2026-08-09 08:00:00', 1, 25.0, 25.0, 65.0, 'ABIERTA'),
(112, 112, 1, 112, '2026-08-09 08:00:00', 1, 3.0, 3.0, 980.0, 'ABIERTA'),
(113, 113, 1, 113, '2026-08-09 08:00:00', 1, 2.0, 2.0, 2400.0, 'ABIERTA'),
(114, 114, 1, 114, '2026-08-09 08:00:00', 1, 35.0, 35.0, 38.0, 'ABIERTA'),
(115, 115, 1, 115, '2026-08-09 08:00:00', 1, 110.0, 110.0, 2.0, 'ABIERTA'),
(116, 116, 1, 116, '2026-08-09 08:00:00', 1, 65.0, 65.0, 25.0, 'ABIERTA'),
(117, 117, 1, 117, '2026-08-09 08:00:00', 1, 120.0, 120.0, 18.0, 'ABIERTA'),
(118, 118, 1, 118, '2026-08-09 08:00:00', 1, 85.0, 85.0, 24.0, 'ABIERTA'),
(119, 119, 1, 119, '2026-08-09 08:00:00', 1, 60.0, 60.0, 32.0, 'ABIERTA'),
(120, 120, 1, 120, '2026-08-09 08:00:00', 1, 45.0, 45.0, 48.0, 'ABIERTA');
INSERT INTO `stock_layers` (`id`, `product_id`, `entry_id`, `entry_item_id`, `layer_date`, `sequence`, `original_qty`, `remaining_qty`, `unit_cost`, `status`) VALUES
(121, 121, 1, 121, '2026-08-09 08:00:00', 1, 12.0, 12.0, 220.0, 'ABIERTA'),
(122, 122, 1, 122, '2026-08-09 08:00:00', 1, 18.0, 18.0, 95.0, 'ABIERTA'),
(123, 123, 1, 123, '2026-08-09 08:00:00', 1, 30.0, 30.0, 45.0, 'ABIERTA'),
(124, 124, 1, 124, '2026-08-09 08:00:00', 1, 6.0, 6.0, 1150.0, 'ABIERTA'),
(125, 125, 1, 125, '2026-08-09 08:00:00', 1, 8.0, 8.0, 580.0, 'ABIERTA'),
(126, 126, 1, 126, '2026-08-09 08:00:00', 1, 12.0, 12.0, 95.0, 'ABIERTA'),
(127, 127, 1, 127, '2026-08-09 08:00:00', 1, 15.0, 15.0, 85.0, 'ABIERTA'),
(128, 128, 1, 128, '2026-08-09 08:00:00', 1, 65.0, 65.0, 9.0, 'ABIERTA'),
(129, 129, 1, 129, '2026-08-09 08:00:00', 1, 48.0, 48.0, 22.0, 'ABIERTA'),
(130, 130, 1, 130, '2026-08-09 08:00:00', 1, 42.0, 42.0, 22.0, 'ABIERTA'),
(131, 131, 1, 131, '2026-08-09 08:00:00', 1, 25.0, 25.0, 35.0, 'ABIERTA'),
(132, 132, 1, 132, '2026-08-09 08:00:00', 1, 80.0, 80.0, 2.8, 'ABIERTA'),
(133, 133, 1, 133, '2026-08-09 08:00:00', 1, 65.0, 65.0, 3.2, 'ABIERTA'),
(134, 134, 1, 134, '2026-08-09 08:00:00', 1, 45.0, 45.0, 4.5, 'ABIERTA'),
(135, 135, 1, 135, '2026-08-09 08:00:00', 1, 35.0, 35.0, 5.0, 'ABIERTA'),
(136, 136, 1, 136, '2026-08-09 08:00:00', 1, 50.0, 50.0, 18.0, 'ABIERTA'),
(137, 137, 1, 137, '2026-08-09 08:00:00', 1, 38.0, 38.0, 26.0, 'ABIERTA'),
(138, 138, 1, 138, '2026-08-09 08:00:00', 1, 24.0, 24.0, 42.0, 'ABIERTA'),
(139, 139, 1, 139, '2026-08-09 08:00:00', 1, 180.0, 180.0, 1.8, 'ABIERTA'),
(140, 140, 1, 140, '2026-08-09 08:00:00', 1, 90.0, 90.0, 3.5, 'ABIERTA'),
(141, 141, 1, 141, '2026-08-09 08:00:00', 1, 75.0, 75.0, 5.0, 'ABIERTA'),
(142, 142, 1, 142, '2026-08-09 08:00:00', 1, 60.0, 60.0, 7.5, 'ABIERTA'),
(143, 143, 1, 143, '2026-08-09 08:00:00', 1, 70.0, 70.0, 8.5, 'ABIERTA'),
(144, 144, 1, 144, '2026-08-09 08:00:00', 1, 45.0, 45.0, 9.0, 'ABIERTA'),
(145, 145, 1, 145, '2026-08-09 08:00:00', 1, 45.0, 45.0, 9.0, 'ABIERTA'),
(146, 146, 1, 146, '2026-08-09 08:00:00', 1, 35.0, 35.0, 9.0, 'ABIERTA'),
(147, 147, 1, 147, '2026-08-09 08:00:00', 1, 30.0, 30.0, 8.0, 'ABIERTA'),
(148, 148, 1, 148, '2026-08-09 08:00:00', 1, 28.0, 28.0, 8.0, 'ABIERTA'),
(149, 149, 1, 149, '2026-08-09 08:00:00', 1, 55.0, 55.0, 6.0, 'ABIERTA'),
(150, 150, 1, 150, '2026-08-09 08:00:00', 1, 40.0, 40.0, 14.0, 'ABIERTA'),
(151, 151, 1, 151, '2026-08-09 08:00:00', 1, 50.0, 50.0, 4.5, 'ABIERTA'),
(152, 152, 1, 152, '2026-08-09 08:00:00', 1, 35.0, 35.0, 5.5, 'ABIERTA'),
(153, 153, 1, 153, '2026-08-09 08:00:00', 1, 60.0, 60.0, 1.5, 'ABIERTA'),
(154, 154, 1, 154, '2026-08-09 08:00:00', 1, 8.0, 8.0, 45.0, 'ABIERTA'),
(155, 155, 1, 155, '2026-08-09 08:00:00', 1, 12.0, 12.0, 22.0, 'ABIERTA'),
(156, 156, 1, 156, '2026-08-09 08:00:00', 1, 18.0, 18.0, 18.0, 'ABIERTA'),
(157, 157, 1, 157, '2026-08-09 08:00:00', 1, 15.0, 15.0, 95.0, 'ABIERTA'),
(158, 158, 1, 158, '2026-08-09 08:00:00', 1, 22.0, 22.0, 78.0, 'ABIERTA'),
(159, 159, 1, 159, '2026-08-09 08:00:00', 1, 14.0, 14.0, 55.0, 'ABIERTA'),
(160, 160, 1, 160, '2026-08-09 08:00:00', 1, 10.0, 10.0, 38.0, 'ABIERTA'),
(161, 161, 1, 161, '2026-08-09 08:00:00', 1, 28.0, 28.0, 22.0, 'ABIERTA'),
(162, 162, 1, 162, '2026-08-09 08:00:00', 1, 20.0, 20.0, 28.0, 'ABIERTA'),
(163, 163, 1, 163, '2026-08-09 08:00:00', 1, 25.0, 25.0, 18.0, 'ABIERTA'),
(164, 164, 1, 164, '2026-08-09 08:00:00', 1, 18.0, 18.0, 75.0, 'ABIERTA'),
(165, 165, 1, 165, '2026-08-09 08:00:00', 1, 12.0, 12.0, 125.0, 'ABIERTA'),
(166, 166, 1, 166, '2026-08-09 08:00:00', 1, 10.0, 10.0, 55.0, 'ABIERTA'),
(167, 167, 1, 167, '2026-08-09 08:00:00', 1, 14.0, 14.0, 78.0, 'ABIERTA'),
(168, 168, 1, 168, '2026-08-09 08:00:00', 1, 8.0, 8.0, 180.0, 'ABIERTA'),
(169, 169, 1, 169, '2026-08-09 08:00:00', 1, 15.0, 15.0, 85.0, 'ABIERTA'),
(170, 170, 1, 170, '2026-08-09 08:00:00', 1, 6.0, 6.0, 380.0, 'ABIERTA'),
(171, 171, 1, 171, '2026-08-09 08:00:00', 1, 8.0, 8.0, 95.0, 'ABIERTA'),
(172, 172, 1, 172, '2026-08-09 08:00:00', 1, 10.0, 10.0, 320.0, 'ABIERTA'),
(173, 173, 1, 173, '2026-08-09 08:00:00', 1, 18.0, 18.0, 95.0, 'ABIERTA'),
(174, 174, 1, 174, '2026-08-09 08:00:00', 1, 12.0, 12.0, 65.0, 'ABIERTA'),
(175, 175, 1, 175, '2026-08-09 08:00:00', 1, 22.0, 22.0, 22.0, 'ABIERTA'),
(176, 176, 1, 176, '2026-08-09 08:00:00', 1, 28.0, 28.0, 45.0, 'ABIERTA'),
(177, 177, 1, 177, '2026-08-09 08:00:00', 1, 8.0, 8.0, 165.0, 'ABIERTA'),
(178, 178, 1, 178, '2026-08-09 08:00:00', 1, 6.0, 6.0, 78.0, 'ABIERTA'),
(179, 179, 1, 179, '2026-08-09 08:00:00', 1, 14.0, 14.0, 32.0, 'ABIERTA'),
(180, 180, 1, 180, '2026-08-09 08:00:00', 1, 3.0, 3.0, 2200.0, 'ABIERTA');
INSERT INTO `stock_layers` (`id`, `product_id`, `entry_id`, `entry_item_id`, `layer_date`, `sequence`, `original_qty`, `remaining_qty`, `unit_cost`, `status`) VALUES
(181, 181, 1, 181, '2026-08-09 08:00:00', 1, 2.0, 2.0, 1850.0, 'ABIERTA');

-- subcategories: 18 registros
INSERT INTO `subcategories` (`id`, `category_id`, `code`, `name`, `is_active`) VALUES
(1, 1, 'HOJ', 'Hojas y resmas', 1),
(2, 1, 'BOL', 'Bolígrafos y lápices', 1),
(3, 1, 'CAR', 'Carpetas y archivadores', 1),
(4, 1, 'SOB', 'Sobres', 1),
(5, 1, 'GRAP', 'Grapas y clips', 1),
(6, 2, 'TIN-TIN', 'Tintas', 1),
(7, 2, 'TIN-TON', 'Tóners', 1),
(8, 3, 'LIM-PAP', 'Papel higiénico', 1),
(9, 3, 'LIM-DET', 'Detergentes', 1),
(10, 3, 'LIM-DES', 'Desinfectantes', 1),
(11, 4, 'INF-MOU', 'Mouse', 1),
(12, 4, 'INF-TEC', 'Teclados', 1),
(13, 4, 'INF-CAB', 'Cables', 1),
(14, 4, 'INF-USB', 'Memorias USB', 1),
(15, 5, 'ESC-SEL', 'Sellos', 1),
(16, 5, 'ESC-PER', 'Perforadoras', 1),
(17, 6, 'ELE-FOC', 'Focos', 1),
(18, 6, 'ELE-EXT', 'Extensiones', 1);

-- suppliers: 4 registros
INSERT INTO `suppliers` (`id`, `nit`, `name`, `contact_name`, `phone`, `email`, `address`, `is_active`) VALUES
(1, '1000123022', 'Librería Unión SRL', 'Juan Pérez', '4250001', 'contacto@union.bo', 'Calle Bolívar 123', 1),
(2, '1000234033', 'Distribuidora Andina SRL', 'María Prado', '4250002', 'ventas@andina.bo', 'Av. Heroínas 456', 1),
(3, '1000345044', 'Suministros Cochabamba', 'Pedro Gómez', '4250003', 'info@suministroscbba.bo', 'Calle Sucre 789', 1),
(4, '1000456055', 'Tecnología del Sur', 'Lucía Morales', '4250004', 'sur@tecnologia.bo', 'Av. Ballivián 321', 1);

-- units: 10 registros
INSERT INTO `units` (`id`, `code`, `name`, `is_active`) VALUES
(1, 'UND', 'Unidad', 1),
(2, 'RES', 'Resma', 1),
(3, 'CAJ', 'Caja', 1),
(4, 'PAQ', 'Paquete', 1),
(5, 'DOC', 'Docena', 1),
(6, 'M', 'Metro', 1),
(7, 'LT', 'Litro', 1),
(8, 'KG', 'Kilogramo', 1),
(9, 'GAL', 'Galón', 1),
(10, 'PAR', 'Par', 1);

-- user_roles: 7 registros
INSERT INTO `user_roles` (`user_id`, `role_id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 7),
(7, 6);

-- users: 7 registros
INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `full_name`, `ci`, `position`, `office`, `area_id`, `jefe_inmediato_id`, `role_id`, `is_active`, `must_change_password`, `failed_attempts`, `locked_until`, `last_login_at`, `password_changed_at`, `created_at`) VALUES
(1, 'admin', 'admin@dde.gob.bo', '$2y$12$eFLXUIClyt3lcADkCMXtR.tcFjlRKcRAgmSK5FNV1XsJDKk.u794.', 'María Pérez Vargas', '1234567', 'Administrador del Sistema', 'Unidad de Sistemas', 4, NULL, 1, 1, 0, 0, NULL, '2026-10-28 00:25:34', NULL, '2026-10-27 23:36:12'),
(2, 'solicitante', 'cquispe@dde.gob.bo', '$2y$12$3i/dlkLc1/VR/75ZS5OBP.Xhjm2q3sGE818VMsAOjDC2tH60WA8pi', 'Carlos Quispe Mamani', '3456789', 'Profesional III', 'Recursos Humanos', 8, NULL, 2, 1, 0, 0, NULL, '2026-10-28 00:04:40', NULL, '2026-10-27 23:36:12'),
(3, 'jefe_inmediato', 'rvargas@dde.gob.bo', '$2y$12$QGX5sgCHx8mBD0h8/6Xg6eaXD9vCnIuByqa2F9.zj75tF7fvD1gde', 'Roberto Vargas Cruz', '5678901', 'Jefe de Recursos Humanos', 'Recursos Humanos', 8, NULL, 3, 1, 0, 0, NULL, '2026-10-28 00:30:54', NULL, '2026-10-27 23:36:12'),
(4, 'jefe_uaa', 'aflores@dde.gob.bo', '$2y$12$8aU4YeN5g3bwM9obika9MeN5s.fjxLYXGLVscpfbvhJYXt6RuHiBK', 'Ana Flores Rojas', '4567890', 'Jefa de Asuntos Administrativos', 'Jefatura UAA', 6, NULL, 4, 1, 0, 0, NULL, '2026-10-28 00:32:24', NULL, '2026-10-27 23:36:12'),
(5, 'almacen', 'almacen@dde.gob.bo', '$2y$12$g9ZkdT7SVBlPpOPlRC7gTukhdLktghguPo2L4eBRTuKczlny01bMa', 'Juana Mamani Lima', '2345678', 'Técnica de Almacenes', 'Almacén DDE', 4, NULL, 5, 1, 0, 0, NULL, '2026-10-28 00:32:49', NULL, '2026-10-27 23:36:12'),
(6, 'auditor', 'auditor@dde.gob.bo', '$2y$12$QIXJIJ3KKtDJ7a6wn3Cbp.JfUX2ZqPtTPXa7cpLNEDxzUsDpKzJ.S', 'Patricia Rojas Auditora', '8888888', 'Auditora Interna', 'Unidad de Auditoría', NULL, NULL, 7, 1, 0, 0, NULL, NULL, NULL, '2026-10-27 23:36:12'),
(7, 'consulta', 'consulta@dde.gob.bo', '$2y$12$UY/UX8Fo5tpJZL7Gxg8Z..VaDY/D56FaAQS4ardJqdnkJQRi9tnNS', 'Visitante Externo', '0000000', 'Visitante', 'Externa', NULL, NULL, 6, 1, 0, 0, NULL, NULL, NULL, '2026-10-27 23:36:12');

SET FOREIGN_KEY_CHECKS = 1;

-- Conteo de filas esperado tras importar:
-- adjustment_items=1, adjustments=1, approval_route_steps=24, approval_routes=8, areas=8, audit_log=0, categories=6, dispatch_items=4, kardex_movements=185, layer_consumptions=4, locations=5, period_closes=1, permissions=38, products=181, request_approvals=5, request_history=10, request_items=6, requests=3, role_permissions=111, roles=7, sequences=4, sessions=0, settings=8, stock_dispatches=2, stock_entries=1, stock_entry_items=181, stock_layers=181, subcategories=18, suppliers=4, units=10, user_roles=7, users=7
