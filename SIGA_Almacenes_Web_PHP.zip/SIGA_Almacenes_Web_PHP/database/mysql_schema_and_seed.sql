-- Estructura y datos de SIGA-DDE. Los comentarios describen las secciones, no cambian registros.
-- =============================================================
-- SIGA-DDE - SISTEMA INTEGRADO DE GESTION DE ALMACENES
-- Base de datos oficial para MySQL / MySQL Workbench
-- Compatible con MySQL 5.7, 8.0, 8.4+ y MariaDB
-- =============================================================

CREATE DATABASE IF NOT EXISTS `siga_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `siga_db`;

SET FOREIGN_KEY_CHECKS = 0;
SET NAMES utf8mb4;

DROP TABLE IF EXISTS `layer_consumptions`;
DROP TABLE IF EXISTS `dispatch_items`;
DROP TABLE IF EXISTS `stock_dispatches`;
DROP TABLE IF EXISTS `request_history`;
DROP TABLE IF EXISTS `request_approvals`;
DROP TABLE IF EXISTS `request_items`;
DROP TABLE IF EXISTS `requests`;
DROP TABLE IF EXISTS `approval_route_steps`;
DROP TABLE IF EXISTS `approval_routes`;
DROP TABLE IF EXISTS `adjustment_items`;
DROP TABLE IF EXISTS `adjustments`;
DROP TABLE IF EXISTS `kardex_movements`;
DROP TABLE IF EXISTS `stock_layers`;
DROP TABLE IF EXISTS `stock_entry_items`;
DROP TABLE IF EXISTS `stock_entries`;
DROP TABLE IF EXISTS `products`;
DROP TABLE IF EXISTS `user_roles`;
DROP TABLE IF EXISTS `sessions`;
DROP TABLE IF EXISTS `audit_log`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `role_permissions`;
DROP TABLE IF EXISTS `permissions`;
DROP TABLE IF EXISTS `roles`;
DROP TABLE IF EXISTS `areas`;
DROP TABLE IF EXISTS `suppliers`;
DROP TABLE IF EXISTS `locations`;
DROP TABLE IF EXISTS `units`;
DROP TABLE IF EXISTS `subcategories`;
DROP TABLE IF EXISTS `categories`;
DROP TABLE IF EXISTS `period_closes`;
DROP TABLE IF EXISTS `settings`;
DROP TABLE IF EXISTS `sequences`;

-- ================= TABLAS DE CATALOGO =================
-- Tabla categories: almacena información de este componente del sistema.

-- Función: Clasificación principal del catálogo de productos.
CREATE TABLE `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(20) NOT NULL UNIQUE,
  `name` VARCHAR(100) NOT NULL,
  `description` TEXT,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla subcategories: almacena información de este componente del sistema.
-- Función: Clasificación detallada vinculada a las categorías.
CREATE TABLE `subcategories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT NOT NULL,
  `code` VARCHAR(20) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  UNIQUE KEY `subcategories_category_code_unq` (`category_id`, `code`),
  CONSTRAINT `fk_subcategories_cat` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla units: almacena información de este componente del sistema.
-- Función: Unidades de medida utilizadas en los movimientos.
CREATE TABLE `units` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(10) NOT NULL UNIQUE,
  `name` VARCHAR(60) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla locations: almacena información de este componente del sistema.
-- Función: Ubicaciones físicas de los productos dentro del almacén.
CREATE TABLE `locations` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(30) NOT NULL UNIQUE,
  `name` VARCHAR(100) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla suppliers: almacena información de este componente del sistema.
-- Función: Proveedores registrados para los ingresos de materiales.
CREATE TABLE `suppliers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nit` VARCHAR(30) UNIQUE,
  `name` VARCHAR(200) NOT NULL,
  `contact_name` VARCHAR(120),
  `phone` VARCHAR(50),
  `email` VARCHAR(120),
  `address` TEXT,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla areas: almacena información de este componente del sistema.
-- Función: Dependencias institucionales que solicitan materiales.
CREATE TABLE `areas` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `parent_id` INT DEFAULT NULL,
  `code` VARCHAR(30) NOT NULL UNIQUE,
  `name` VARCHAR(150) NOT NULL,
  `type` VARCHAR(30) NOT NULL DEFAULT 'UNIDAD',
  `jefe_uaa_id` INT DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= TABLAS DE SEGURIDAD =================
-- Tabla roles: almacena información de este componente del sistema.

-- Función: Perfiles que determinan responsabilidades dentro del sistema.
CREATE TABLE `roles` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(30) NOT NULL UNIQUE,
  `name` VARCHAR(80) NOT NULL,
  `description` TEXT,
  `is_system` TINYINT(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla permissions: almacena información de este componente del sistema.
-- Función: Acciones protegidas que puede ejecutar cada perfil.
CREATE TABLE `permissions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(60) NOT NULL UNIQUE,
  `module` VARCHAR(40) NOT NULL,
  `description` VARCHAR(200)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla role_permissions: almacena información de este componente del sistema.
-- Función: Relación entre roles y permisos asignados.
CREATE TABLE `role_permissions` (
  `role_id` INT NOT NULL,
  `permission_id` INT NOT NULL,
  PRIMARY KEY (`role_id`, `permission_id`),
  CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_role_permissions_perm` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla users: almacena información de este componente del sistema.
-- Función: Cuentas del personal, datos de acceso, área y responsable inmediato.
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(40) NOT NULL UNIQUE,
  `email` VARCHAR(120),
  `password_hash` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(200) NOT NULL,
  `ci` VARCHAR(30),
  `position` VARCHAR(120),
  `office` VARCHAR(120),
  `area_id` INT DEFAULT NULL,
  `jefe_inmediato_id` INT DEFAULT NULL,
  `role_id` INT NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `must_change_password` TINYINT(1) NOT NULL DEFAULT 1,
  `failed_attempts` INT NOT NULL DEFAULT 0,
  `locked_until` DATETIME DEFAULT NULL,
  `last_login_at` DATETIME DEFAULT NULL,
  `password_changed_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `fk_users_area` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla user_roles: almacena información de este componente del sistema.
CREATE TABLE `user_roles` (
  `user_id` INT NOT NULL,
  `role_id` INT NOT NULL,
  PRIMARY KEY (`user_id`, `role_id`),
  CONSTRAINT `fk_user_roles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_user_roles_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla sessions: almacena información de este componente del sistema.
CREATE TABLE `sessions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `token_hash` VARCHAR(200) NOT NULL UNIQUE,
  `ip` VARCHAR(60),
  `user_agent` TEXT,
  `expires_at` DATETIME NOT NULL,
  `revoked_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= TABLA DE PRODUCTOS =================
-- Tabla products: almacena información de este componente del sistema.

-- Función: Catálogo de artículos con existencias y valores referenciales.
CREATE TABLE `products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(30) NOT NULL UNIQUE,
  `name` VARCHAR(200) NOT NULL,
  `description` TEXT,
  `brand` VARCHAR(80),
  `category_id` INT NOT NULL,
  `subcategory_id` INT NOT NULL,
  `unit_id` INT NOT NULL,
  `location_id` INT DEFAULT NULL,
  `min_stock` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `max_stock` DECIMAL(14,3) DEFAULT 0.000,
  `reference_cost` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `stock_qty` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `stock_value` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `status` VARCHAR(20) NOT NULL DEFAULT 'ACTIVO',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_products_status` (`status`),
  INDEX `idx_products_cat` (`category_id`, `subcategory_id`),
  CONSTRAINT `fk_products_cat` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `fk_products_sub` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`id`),
  CONSTRAINT `fk_products_unit` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`),
  CONSTRAINT `fk_products_loc` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= INGRESOS Y CAPAS PEPS =================
-- Tabla stock_entries: almacena información de este componente del sistema.

-- Función: Documentos de ingreso al almacén.
CREATE TABLE `stock_entries` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `number` VARCHAR(30) NOT NULL UNIQUE,
  `type` VARCHAR(30) NOT NULL,
  `supplier_id` INT DEFAULT NULL,
  `doc_type` VARCHAR(40),
  `doc_number` VARCHAR(60),
  `doc_date` DATETIME,
  `entry_date` DATETIME NOT NULL,
  `posted_at` DATETIME,
  `total_amount` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `notes` TEXT,
  `status` VARCHAR(20) NOT NULL DEFAULT 'BORRADOR',
  `voided_by` INT DEFAULT NULL,
  `voided_at` DATETIME DEFAULT NULL,
  `void_reason` TEXT,
  `created_by` INT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_entries_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_entries_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla stock_entry_items: almacena información de este componente del sistema.
-- Función: Detalle de productos, cantidades y costos ingresados.
CREATE TABLE `stock_entry_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `entry_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `location_id` INT DEFAULT NULL,
  `quantity` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `total` DECIMAL(16,2) NOT NULL,
  `notes` TEXT,
  CONSTRAINT `fk_entry_items_entry` FOREIGN KEY (`entry_id`) REFERENCES `stock_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_entry_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla stock_layers: almacena información de este componente del sistema.
-- Función: Capas de ingreso que permiten valorar existencias según PEPS.
CREATE TABLE `stock_layers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `product_id` INT NOT NULL,
  `entry_id` INT NOT NULL,
  `entry_item_id` INT DEFAULT NULL,
  `layer_date` DATETIME NOT NULL,
  `sequence` INT NOT NULL DEFAULT 1,
  `original_qty` DECIMAL(14,3) NOT NULL,
  `remaining_qty` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'ABIERTA',
  INDEX `idx_layers_product_date` (`product_id`, `layer_date`, `sequence`),
  CONSTRAINT `fk_layers_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `fk_layers_entry` FOREIGN KEY (`entry_id`) REFERENCES `stock_entries` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= RUTAS Y SOLICITUDES =================
-- Tabla approval_routes: almacena información de este componente del sistema.

-- Función: Rutas institucionales de aprobación definidas por área.
CREATE TABLE `approval_routes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `area_id` INT DEFAULT NULL,
  `name` VARCHAR(100) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  CONSTRAINT `fk_approval_routes_area` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla approval_route_steps: almacena información de este componente del sistema.
-- Función: Orden y rol responsable de cada etapa de aprobación.
CREATE TABLE `approval_route_steps` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `route_id` INT NOT NULL,
  `step_order` INT NOT NULL,
  `role_id` INT NOT NULL,
  `sla_hours` INT NOT NULL DEFAULT 48,
  `is_required` TINYINT(1) NOT NULL DEFAULT 1,
  CONSTRAINT `fk_steps_route` FOREIGN KEY (`route_id`) REFERENCES `approval_routes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_steps_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla requests: almacena información de este componente del sistema.
-- Función: Cabeceras de pedidos con estado, solicitante y ruta.
CREATE TABLE `requests` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(30) NOT NULL UNIQUE,
  `correspondence_number` VARCHAR(60) NOT NULL UNIQUE,
  `applicant_id` INT NOT NULL,
  `area_id` INT NOT NULL,
  `office` VARCHAR(120),
  `justification` TEXT,
  `route_id` INT DEFAULT NULL,
  `current_step` INT NOT NULL DEFAULT 0,
  `status` VARCHAR(30) NOT NULL DEFAULT 'BORRADOR',
  `submitted_at` DATETIME DEFAULT NULL,
  `approved_at` DATETIME DEFAULT NULL,
  `closed_at` DATETIME DEFAULT NULL,
  `rejection_reason` TEXT,
  `observation` TEXT,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_requests_user` FOREIGN KEY (`applicant_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_requests_area` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla request_items: almacena información de este componente del sistema.
-- Función: Productos y cantidades solicitadas y autorizadas.
CREATE TABLE `request_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `request_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `qty_requested` DECIMAL(14,3) NOT NULL,
  `qty_approved` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `qty_proposed` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `qty_authorized` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `qty_delivered` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `stock_at_request` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `status` VARCHAR(20) NOT NULL DEFAULT 'PENDIENTE',
  `notes` TEXT,
  CONSTRAINT `fk_req_items_request` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_req_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla request_approvals: almacena información de este componente del sistema.
-- Función: Decisiones, observaciones y responsables de cada etapa.
CREATE TABLE `request_approvals` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `request_id` INT NOT NULL,
  `step_order` INT NOT NULL,
  `approver_user_id` INT DEFAULT NULL,
  `role_id` INT NOT NULL,
  `action` VARCHAR(20) NOT NULL DEFAULT 'PENDIENTE',
  `action_at` DATETIME DEFAULT NULL,
  `comments` TEXT,
  CONSTRAINT `fk_req_appr_request` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_req_appr_user` FOREIGN KEY (`approver_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_req_appr_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla request_history: almacena información de este componente del sistema.
-- Función: Historial de cambios de estado de las solicitudes.
CREATE TABLE `request_history` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `request_id` INT NOT NULL,
  `from_state` VARCHAR(30) NOT NULL,
  `to_state` VARCHAR(30) NOT NULL,
  `actor_id` INT NOT NULL,
  `role_id` INT NOT NULL,
  `comments` TEXT,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_req_hist_req` (`request_id`, `created_at`),
  CONSTRAINT `fk_req_hist_req` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_req_hist_actor` FOREIGN KEY (`actor_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_req_hist_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= DESPACHOS Y CONSUMOS PEPS =================
-- Tabla stock_dispatches: almacena información de este componente del sistema.

-- Función: Documentos de salida y entregas de inventario.
CREATE TABLE `stock_dispatches` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `number` VARCHAR(30) NOT NULL UNIQUE,
  `request_id` INT NOT NULL,
  `dispatch_date` DATETIME NOT NULL,
  `dispatched_by` INT NOT NULL,
  `received_by` VARCHAR(200),
  `received_ci` VARCHAR(30),
  `received_signature_at` DATETIME DEFAULT NULL,
  `total_value` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `status` VARCHAR(20) NOT NULL DEFAULT 'BORRADOR',
  `voided_by` INT DEFAULT NULL,
  `voided_at` DATETIME DEFAULT NULL,
  `void_reason` TEXT,
  `notes` TEXT,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_dispatches_req` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`),
  CONSTRAINT `fk_dispatches_user` FOREIGN KEY (`dispatched_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla dispatch_items: almacena información de este componente del sistema.
CREATE TABLE `dispatch_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `dispatch_id` INT NOT NULL,
  `request_item_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `qty` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `total_value` DECIMAL(16,2) NOT NULL,
  CONSTRAINT `fk_disp_items_disp` FOREIGN KEY (`dispatch_id`) REFERENCES `stock_dispatches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_disp_items_reqitem` FOREIGN KEY (`request_item_id`) REFERENCES `request_items` (`id`),
  CONSTRAINT `fk_disp_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla layer_consumptions: almacena información de este componente del sistema.
CREATE TABLE `layer_consumptions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `dispatch_item_id` INT NOT NULL,
  `layer_id` INT NOT NULL,
  `qty` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `total_value` DECIMAL(16,2) NOT NULL,
  CONSTRAINT `fk_layer_cons_item` FOREIGN KEY (`dispatch_item_id`) REFERENCES `dispatch_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_layer_cons_layer` FOREIGN KEY (`layer_id`) REFERENCES `stock_layers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= KARDEX =================
-- Tabla kardex_movements: almacena información de este componente del sistema.

-- Función: Movimientos históricos de entrada, salida y saldo.
CREATE TABLE `kardex_movements` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `product_id` INT NOT NULL,
  `movement_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `doc_type` VARCHAR(20) NOT NULL,
  `doc_id` INT DEFAULT NULL,
  `reference` VARCHAR(60),
  `qty_in` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `qty_out` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `unit_cost_in` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `unit_cost_out` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `total_in` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `total_out` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `balance_qty` DECIMAL(14,3) NOT NULL,
  `balance_value` DECIMAL(16,2) NOT NULL,
  `balance_unit_cost` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_kardex_product_date` (`product_id`, `movement_date`),
  CONSTRAINT `fk_kardex_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= AJUSTES =================
-- Tabla adjustments: almacena información de este componente del sistema.

-- Función: Ajustes autorizados sobre las cantidades de inventario.
CREATE TABLE `adjustments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `number` VARCHAR(30) NOT NULL UNIQUE,
  `type` VARCHAR(20) NOT NULL,
  `reason` TEXT NOT NULL,
  `act_number` VARCHAR(60),
  `adjustment_date` DATETIME NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'BORRADOR',
  `approved_almacenes_by` INT DEFAULT NULL,
  `approved_almacenes_at` DATETIME DEFAULT NULL,
  `approved_contrataciones_by` INT DEFAULT NULL,
  `approved_contrataciones_at` DATETIME DEFAULT NULL,
  `approved_admin_by` INT DEFAULT NULL,
  `approved_admin_at` DATETIME DEFAULT NULL,
  `created_by` INT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_adjustments_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla adjustment_items: almacena información de este componente del sistema.
CREATE TABLE `adjustment_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `adjustment_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `qty` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `total_value` DECIMAL(16,2) NOT NULL,
  `notes` TEXT,
  CONSTRAINT `fk_adj_items_adj` FOREIGN KEY (`adjustment_id`) REFERENCES `adjustments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_adj_items_prod` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= PERIODOS, AUDITORIA Y CONFIGURACION =================
-- Tabla period_closes: almacena información de este componente del sistema.

CREATE TABLE `period_closes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `year` INT NOT NULL,
  `month` INT NOT NULL,
  `closed_at` DATETIME DEFAULT NULL,
  `closed_by` INT DEFAULT NULL,
  `total_qty_snapshot` DECIMAL(14,3) DEFAULT 0.000,
  `total_value_snapshot` DECIMAL(16,2) DEFAULT 0.00,
  `status` VARCHAR(20) NOT NULL DEFAULT 'ABIERTO',
  `reopen_reason` TEXT,
  UNIQUE KEY `period_closes_year_month_unq` (`year`, `month`),
  CONSTRAINT `fk_period_closes_user` FOREIGN KEY (`closed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla audit_log: almacena información de este componente del sistema.
CREATE TABLE `audit_log` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT DEFAULT NULL,
  `action` VARCHAR(60) NOT NULL,
  `entity` VARCHAR(60),
  `entity_id` INT,
  `before` JSON,
  `after` JSON,
  `ip` VARCHAR(60),
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla settings: almacena información de este componente del sistema.
CREATE TABLE `settings` (
  `key` VARCHAR(80) PRIMARY KEY,
  `value` JSON
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Tabla sequences: almacena información de este componente del sistema.
CREATE TABLE `sequences` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `key` VARCHAR(30) NOT NULL,
  `year` INT NOT NULL,
  `current_value` INT NOT NULL DEFAULT 0,
  UNIQUE KEY `sequences_key_year_unq` (`key`, `year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================= INSERCIONES DE DATOS BASE =================

INSERT INTO `roles` (`id`, `code`, `name`, `description`, `is_system`) VALUES
(1, 'ADMIN', 'Administrador', 'Administración técnica total', 1),
(2, 'SOLICITANTE', 'Solicitante', 'Solicita material', 1),
(3, 'JEFE_INMEDIATO', 'Inmediato Superior', 'Valida necesidad (Aprueba)', 1),
(4, 'JEFE_UAA', 'Jefatura de UAA', 'Autoriza solicitud (Decisión final)', 1),
(5, 'TECNICO_ALMACEN', 'Técnica de Almacenes', 'Prepara y entrega', 1),
(6, 'CONSULTA', 'Consulta', 'Solo lectura', 1),
(7, 'AUDITOR', 'Auditor del Sistema', 'Auditoría global (solo lectura)', 1);

-- Datos iniciales de permissions: se conservan los registros originales.
INSERT INTO `permissions` (`id`, `code`, `module`, `description`) VALUES
(1, 'solicitudes.crear', 'solicitudes', 'Crear solicitudes de materiales'),
(2, 'solicitudes.ver_propias', 'solicitudes', 'Ver solicitudes propias'),
(3, 'solicitudes.ver_area', 'solicitudes', 'Ver solicitudes del área'),
(4, 'solicitudes.ver_todas', 'solicitudes', 'Ver todas las solicitudes'),
(5, 'solicitudes.aprobar', 'solicitudes', 'Aprobar solicitudes en paso inicial'),
(6, 'solicitudes.reducir', 'solicitudes', 'Reducir cantidades solicitadas'),
(7, 'solicitudes.devolver', 'solicitudes', 'Devolver u observar solicitudes'),
(8, 'solicitudes.rechazar', 'solicitudes', 'Rechazar solicitudes'),
(9, 'solicitudes.autorizar', 'solicitudes', 'Autorizar definitivamente solicitud'),
(10, 'solicitudes.preparar', 'solicitudes', 'Preparar entrega en almacén'),
(11, 'solicitudes.entregar', 'solicitudes', 'Registrar entrega de materiales'),
(12, 'inventario.ver_basico', 'inventario', 'Ver catálogo básico de productos'),
(13, 'inventario.ver_stock', 'inventario', 'Ver existencias y saldos físicos'),
(14, 'inventario.ver_valores', 'inventario', 'Ver valor monetario del inventario'),
(15, 'productos.ver', 'productos', 'Ver detalle de productos'),
(16, 'catalogos.ver', 'catalogos', 'Ver catálogos del sistema'),
(17, 'catalogos.editar', 'catalogos', 'Administrar catálogos'),
(18, 'dashboard.solicitudes', 'dashboard', 'Ver métricas de solicitudes'),
(19, 'dashboard.despachos', 'dashboard', 'Ver métricas de despachos'),
(20, 'dashboard.ajustes', 'dashboard', 'Ver métricas de ajustes'),
(21, 'aprobaciones.ver', 'aprobaciones', 'Ver bandeja de aprobaciones'),
(22, 'aprobaciones.decidir', 'aprobaciones', 'Tomar decisión en aprobaciones'),
(23, 'ingresos.ver', 'ingresos', 'Ver comprobantes de ingreso'),
(24, 'salidas.ver', 'salidas', 'Ver comprobantes de salida'),
(25, 'salidas.preparar', 'salidas', 'Preparar salidas de material'),
(26, 'salidas.confirmar', 'salidas', 'Confirmar entrega y salida'),
(27, 'ajustes.ver', 'ajustes', 'Ver ajustes de inventario'),
(28, 'ajustes.crear', 'ajustes', 'Registrar nuevos ajustes'),
(29, 'ajustes.aprobar', 'ajustes', 'Firmar aprobación de ajustes'),
(30, 'reportes.ver', 'reportes', 'Consultar reportes oficiales'),
(31, 'reportes.exportar', 'reportes', 'Exportar información contable'),
(32, 'arqueo.ver', 'arqueo', 'Realizar arqueo físico'),
(33, 'auditoria.ver', 'auditoria', 'Consultar bitácora de auditoría'),
(34, 'usuarios.ver', 'usuarios', 'Ver lista de usuarios'),
(35, 'usuarios.editar', 'usuarios', 'Editar información de usuarios'),
(36, 'usuarios.gestionar', 'usuarios', 'Crear y desactivar cuentas'),
(37, 'config.ver', 'config', 'Ver configuración institucional'),
(38, 'config.editar', 'config', 'Modificar configuración');

-- Datos iniciales de role_permissions: se conservan los registros originales.
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(1, 13),
(1, 14),
(1, 15),
(1, 16),
(1, 17),
(1, 18),
(1, 19),
(1, 20),
(1, 21),
(1, 22),
(1, 23),
(1, 24),
(1, 25),
(1, 26),
(1, 27),
(1, 28),
(1, 29),
(1, 30),
(1, 31),
(1, 32),
(1, 33),
(1, 34),
(1, 35),
(1, 36),
(1, 37),
(1, 38),
(2, 1),
(2, 2),
(2, 12),
(2, 15),
(2, 16),
(2, 18),
(3, 1),
(3, 2),
(3, 3),
(3, 5),
(3, 6),
(3, 7),
(3, 8),
(3, 21),
(3, 22),
(3, 18),
(4, 1),
(4, 2),
(4, 4),
(4, 3),
(4, 6),
(4, 7),
(4, 8),
(4, 9),
(4, 21),
(4, 22),
(4, 18),
(4, 30),
(4, 13),
(4, 14),
(4, 15),
(4, 16),
(5, 2),
(5, 4),
(5, 3),
(5, 6),
(5, 7),
(5, 8),
(5, 21),
(5, 22),
(5, 10),
(5, 11),
(5, 13),
(5, 14),
(5, 15),
(5, 23),
(5, 24),
(5, 25),
(5, 26),
(5, 16),
(5, 18),
(5, 19),
(5, 30),
(5, 31),
(5, 32),
(6, 4),
(6, 13),
(6, 14),
(6, 30),
(6, 31),
(7, 4),
(7, 21),
(7, 13),
(7, 14),
(7, 15),
(7, 23),
(7, 24),
(7, 16),
(7, 30),
(7, 31),
(7, 33),
(7, 18),
(7, 19);

-- Datos iniciales de categories: se conservan los registros originales.
INSERT INTO `categories` (`id`, `code`, `name`, `description`, `is_active`) VALUES
(1, 'PAP', 'Papelería y escritorio', 'Material de oficina, hojas y cartulinas', 1),
(2, 'TIN', 'Tintas y tóners', 'Cartuchos de tinta y tóner para impresión', 1),
(3, 'LIM', 'Limpieza e higiene', 'Productos de limpieza y desinfección', 1),
(4, 'INF', 'Informática', 'Accesorios, cables y periféricos de computación', 1),
(5, 'ESC', 'Escritorio y mobiliario menor', 'Accesorios de escritorio y archivo', 1),
(6, 'ELE', 'Eléctrico', 'Material eléctrico y luminarias', 1);

-- Datos iniciales de subcategories: se conservan los registros originales.
INSERT INTO `subcategories` (`id`, `category_id`, `code`, `name`, `is_active`) VALUES
(1, 1, 'HOJ', 'Hojas y resmas', 1),
(2, 1, 'BOL', 'Bolígrafos y lápices', 1),
(3, 1, 'CAR', 'Carpetas y archivadores', 1),
(4, 1, 'SOB', 'Sobres', 1),
(5, 1, 'GRAP', 'Grapas y clips', 1),
(6, 2, 'TIN-TIN', 'Tintas', 1),
(7, 2, 'TIN-TON', 'Tóners', 1),
(8, 3, 'LIM-PAP', 'Papel higiénico', 1),
(9, 3, 'LIM-DET', 'Detergentes', 1),
(10, 3, 'LIM-DES', 'Desinfectantes', 1),
(11, 4, 'INF-MOU', 'Mouse', 1),
(12, 4, 'INF-TEC', 'Teclados', 1),
(13, 4, 'INF-CAB', 'Cables', 1),
(14, 4, 'INF-USB', 'Memorias USB', 1),
(15, 5, 'ESC-SEL', 'Sellos', 1),
(16, 5, 'ESC-PER', 'Perforadoras', 1),
(17, 6, 'ELE-FOC', 'Focos', 1),
(18, 6, 'ELE-EXT', 'Extensiones', 1);

-- Datos iniciales de units: se conservan los registros originales.
INSERT INTO `units` (`id`, `code`, `name`, `is_active`) VALUES
(1, 'UND', 'Unidad', 1),
(2, 'RES', 'Resma', 1),
(3, 'CAJ', 'Caja', 1),
(4, 'PAQ', 'Paquete', 1),
(5, 'DOC', 'Docena', 1),
(6, 'M', 'Metro', 1),
(7, 'LT', 'Litro', 1),
(8, 'KG', 'Kilogramo', 1),
(9, 'GAL', 'Galón', 1),
(10, 'PAR', 'Par', 1);

-- Datos iniciales de locations: se conservan los registros originales.
INSERT INTO `locations` (`id`, `code`, `name`, `is_active`) VALUES
(1, 'A1', 'Almacén principal - Estante A1', 1),
(2, 'A2', 'Almacén principal - Estante A2', 1),
(3, 'B1', 'Almacén principal - Estante B1', 1),
(4, 'B2', 'Almacén principal - Estante B2', 1),
(5, 'C1', 'Almacén principal - Estante C1', 1);

-- Datos iniciales de suppliers: se conservan los registros originales.
INSERT INTO `suppliers` (`id`, `nit`, `name`, `contact_name`, `phone`, `email`, `address`, `is_active`) VALUES
(1, '1000123022', 'Librería Unión SRL', 'Juan Pérez', '4250001', 'contacto@union.bo', 'Calle Bolívar 123', 1),
(2, '1000234033', 'Distribuidora Andina SRL', 'María Prado', '4250002', 'ventas@andina.bo', 'Av. Heroínas 456', 1),
(3, '1000345044', 'Suministros Cochabamba', 'Pedro Gómez', '4250003', 'info@suministroscbba.bo', 'Calle Sucre 789', 1),
(4, '1000456055', 'Tecnología del Sur', 'Lucía Morales', '4250004', 'sur@tecnologia.bo', 'Av. Ballivián 321', 1);

-- Datos iniciales de areas: se conservan los registros originales.
INSERT INTO `areas` (`id`, `parent_id`, `code`, `name`, `type`, `is_active`) VALUES
(1, NULL, 'DDE', 'Dirección Departamental de Educación', 'DIRECCION', 1),
(2, NULL, 'ADM', 'Dirección Administrativa', 'DIRECCION', 1),
(3, NULL, 'ACA', 'Subdirección Académica', 'DIRECCION', 1),
(4, 2, 'ALM', 'Almacén', 'UNIDAD', 1),
(5, 2, 'CON', 'Contrataciones', 'UNIDAD', 1),
(6, 2, 'JAA', 'Jefatura de Asuntos Administrativos', 'UNIDAD', 1),
(7, 2, 'FIN', 'Finanzas', 'UNIDAD', 1),
(8, 1, 'REC', 'Recursos Humanos', 'DEPENDENCIA', 1);

-- Datos iniciales de users: se conservan los registros originales.
INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `full_name`, `ci`, `position`, `office`, `area_id`, `role_id`, `must_change_password`, `is_active`) VALUES
(1, 'admin', 'admin@dde.gob.bo', '$2y$12$eFLXUIClyt3lcADkCMXtR.tcFjlRKcRAgmSK5FNV1XsJDKk.u794.', 'María Pérez Vargas', '1234567', 'Administrador del Sistema', 'Unidad de Sistemas', 4, 1, 0, 1),
(2, 'solicitante', 'cquispe@dde.gob.bo', '$2y$12$3i/dlkLc1/VR/75ZS5OBP.Xhjm2q3sGE818VMsAOjDC2tH60WA8pi', 'Carlos Quispe Mamani', '3456789', 'Profesional III', 'Recursos Humanos', 8, 2, 0, 1),
(3, 'jefe_inmediato', 'rvargas@dde.gob.bo', '$2y$12$QGX5sgCHx8mBD0h8/6Xg6eaXD9vCnIuByqa2F9.zj75tF7fvD1gde', 'Roberto Vargas Cruz', '5678901', 'Jefe de Recursos Humanos', 'Recursos Humanos', 8, 3, 0, 1),
(4, 'jefe_uaa', 'aflores@dde.gob.bo', '$2y$12$8aU4YeN5g3bwM9obika9MeN5s.fjxLYXGLVscpfbvhJYXt6RuHiBK', 'Ana Flores Rojas', '4567890', 'Jefa de Asuntos Administrativos', 'Jefatura UAA', 6, 4, 0, 1),
(5, 'almacen', 'almacen@dde.gob.bo', '$2y$12$g9ZkdT7SVBlPpOPlRC7gTukhdLktghguPo2L4eBRTuKczlny01bMa', 'Juana Mamani Lima', '2345678', 'Técnica de Almacenes', 'Almacén DDE', 4, 5, 0, 1),
(6, 'auditor', 'auditor@dde.gob.bo', '$2y$12$QIXJIJ3KKtDJ7a6wn3Cbp.JfUX2ZqPtTPXa7cpLNEDxzUsDpKzJ.S', 'Patricia Rojas Auditora', '8888888', 'Auditora Interna', 'Unidad de Auditoría', NULL, 7, 0, 1),
(7, 'consulta', 'consulta@dde.gob.bo', '$2y$12$UY/UX8Fo5tpJZL7Gxg8Z..VaDY/D56FaAQS4ardJqdnkJQRi9tnNS', 'Visitante Externo', '0000000', 'Visitante', 'Externa', NULL, 6, 0, 1);

-- Datos iniciales de user_roles: se conservan los registros originales.
INSERT INTO `user_roles` (`user_id`, `role_id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 7),
(7, 6);

-- Datos iniciales de products: se conservan los registros originales.
INSERT INTO `products` (`id`, `code`, `name`, `description`, `category_id`, `subcategory_id`, `unit_id`, `location_id`, `min_stock`, `max_stock`, `reference_cost`, `stock_qty`, `stock_value`, `status`, `is_active`) VALUES
(1, 'PAP-HOJ-001', 'Papel bond tamaño carta 75 gr', 'Papel bond tamaño carta 75 gr - SKU institucional', 1, 1, 2, 2, 48.000, 1440.000, 32.5000, 480.000, 15600.00, 'ACTIVO', 1),
(2, 'PAP-HOJ-002', 'Papel bond tamaño oficio 75 gr', 'Papel bond tamaño oficio 75 gr - SKU institucional', 1, 1, 2, 3, 8.000, 255.000, 38.2000, 85.000, 3247.00, 'ACTIVO', 1),
(3, 'PAP-HOJ-003', 'Papel bond A4 75 gr', 'Papel bond A4 75 gr - SKU institucional', 1, 1, 2, 4, 6.000, 180.000, 30.8000, 60.000, 1848.00, 'ACTIVO', 1),
(4, 'PAP-HOJ-004', 'Papel fotográfico carta', 'Papel fotográfico carta - SKU institucional', 1, 1, 4, 5, 2.000, 72.000, 95.0000, 24.000, 2280.00, 'ACTIVO', 1),
(5, 'PAP-HOJ-005', 'Papel milimetrado', 'Papel milimetrado - SKU institucional', 1, 1, 1, 1, 14.000, 420.000, 1.5000, 140.000, 210.00, 'ACTIVO', 1),
(6, 'PAP-HOJ-006', 'Papel cuadriculado A4', 'Papel cuadriculado A4 - SKU institucional', 1, 1, 2, 2, 1.000, 45.000, 34.0000, 15.000, 510.00, 'ACTIVO', 1),
(7, 'PAP-BOL-001', 'Bolígrafo azul', 'Bolígrafo azul - SKU institucional', 1, 2, 1, 3, 54.000, 1620.000, 2.8000, 540.000, 1512.00, 'ACTIVO', 1),
(8, 'PAP-BOL-002', 'Bolígrafo negro', 'Bolígrafo negro - SKU institucional', 1, 2, 1, 4, 43.000, 1290.000, 2.8000, 430.000, 1204.00, 'ACTIVO', 1),
(9, 'PAP-BOL-003', 'Bolígrafo rojo', 'Bolígrafo rojo - SKU institucional', 1, 2, 1, 5, 32.000, 960.000, 2.8000, 320.000, 896.00, 'ACTIVO', 1),
(10, 'PAP-BOL-004', 'Bolígrafo verde', 'Bolígrafo verde - SKU institucional', 1, 2, 1, 1, 15.000, 450.000, 2.8000, 150.000, 420.00, 'ACTIVO', 1),
(11, 'PAP-BOL-005', 'Lápiz negro HB', 'Lápiz negro HB - SKU institucional', 1, 2, 1, 2, 60.000, 1800.000, 1.2000, 600.000, 720.00, 'ACTIVO', 1),
(12, 'PAP-BOL-006', 'Lápiz 2B', 'Lápiz 2B - SKU institucional', 1, 2, 1, 3, 12.000, 360.000, 1.5000, 120.000, 180.00, 'ACTIVO', 1),
(13, 'PAP-BOL-007', 'Marcador fino negro', 'Marcador fino negro - SKU institucional', 1, 2, 1, 4, 8.000, 264.000, 5.5000, 88.000, 484.00, 'ACTIVO', 1),
(14, 'PAP-BOL-008', 'Marcador fino azul', 'Marcador fino azul - SKU institucional', 1, 2, 1, 5, 7.000, 225.000, 5.5000, 75.000, 412.50, 'ACTIVO', 1),
(15, 'PAP-BOL-009', 'Marcador fino rojo', 'Marcador fino rojo - SKU institucional', 1, 2, 1, 1, 6.000, 180.000, 5.5000, 60.000, 330.00, 'ACTIVO', 1),
(16, 'PAP-BOL-010', 'Resaltador amarillo', 'Resaltador amarillo - SKU institucional', 1, 2, 1, 2, 9.000, 285.000, 6.0000, 95.000, 570.00, 'ACTIVO', 1),
(17, 'PAP-BOL-011', 'Resaltador verde', 'Resaltador verde - SKU institucional', 1, 2, 1, 3, 7.000, 210.000, 6.0000, 70.000, 420.00, 'ACTIVO', 1),
(18, 'PAP-BOL-012', 'Resaltador rosado', 'Resaltador rosado - SKU institucional', 1, 2, 1, 4, 5.000, 165.000, 6.0000, 55.000, 330.00, 'ACTIVO', 1),
(19, 'PAP-CAR-001', 'Carpeta de cartón oficio', 'Carpeta de cartón oficio - SKU institucional', 1, 3, 1, 5, 25.000, 750.000, 4.5000, 250.000, 1125.00, 'ACTIVO', 1),
(20, 'PAP-CAR-002', 'Carpeta con fastener', 'Carpeta con fastener - SKU institucional', 1, 3, 1, 1, 20.000, 600.000, 6.8000, 200.000, 1360.00, 'ACTIVO', 1),
(21, 'PAP-CAR-003', 'Carpeta plástica de palanca', 'Carpeta plástica de palanca - SKU institucional', 1, 3, 1, 2, 9.000, 285.000, 22.0000, 95.000, 2090.00, 'ACTIVO', 1),
(22, 'PAP-CAR-004', 'Archivador de palanca oficio', 'Archivador de palanca oficio - SKU institucional', 1, 3, 1, 3, 6.000, 195.000, 28.0000, 65.000, 1820.00, 'ACTIVO', 1),
(23, 'PAP-CAR-005', 'Folder colgante', 'Folder colgante - SKU institucional', 1, 3, 1, 4, 18.000, 540.000, 7.5000, 180.000, 1350.00, 'ACTIVO', 1),
(24, 'PAP-CAR-006', 'Folder manila', 'Folder manila - SKU institucional', 1, 3, 1, 5, 54.000, 1620.000, 0.9000, 540.000, 486.00, 'ACTIVO', 1),
(25, 'PAP-SOB-001', 'Sobre manila oficio', 'Sobre manila oficio - SKU institucional', 1, 4, 1, 1, 42.000, 1260.000, 1.2000, 420.000, 504.00, 'ACTIVO', 1),
(26, 'PAP-SOB-002', 'Sobre manila carta', 'Sobre manila carta - SKU institucional', 1, 4, 1, 2, 38.000, 1140.000, 1.0000, 380.000, 380.00, 'ACTIVO', 1),
(27, 'PAP-SOB-003', 'Sobre manila extra oficio', 'Sobre manila extra oficio - SKU institucional', 1, 4, 1, 3, 15.000, 450.000, 2.5000, 150.000, 375.00, 'ACTIVO', 1),
(28, 'PAP-SOB-004', 'Sobre blanco con ventana', 'Sobre blanco con ventana - SKU institucional', 1, 4, 1, 4, 22.000, 660.000, 1.1000, 220.000, 242.00, 'ACTIVO', 1),
(29, 'PAP-GRAP-001', 'Grapas estándar 26/6 caja', 'Grapas estándar 26/6 caja - SKU institucional', 1, 5, 3, 5, 8.000, 255.000, 7.5000, 85.000, 637.50, 'ACTIVO', 1),
(30, 'PAP-GRAP-002', 'Clips mariposa 50mm', 'Clips mariposa 50mm - SKU institucional', 1, 5, 3, 1, 6.000, 180.000, 9.0000, 60.000, 540.00, 'ACTIVO', 1),
(31, 'PAP-GRAP-003', 'Clips estándar 28mm', 'Clips estándar 28mm - SKU institucional', 1, 5, 3, 2, 12.000, 360.000, 4.5000, 120.000, 540.00, 'ACTIVO', 1),
(32, 'PAP-GRAP-004', 'Chinchetas', 'Chinchetas - SKU institucional', 1, 5, 3, 3, 4.000, 120.000, 5.0000, 40.000, 200.00, 'ACTIVO', 1),
(33, 'PAP-GRAP-005', 'Cinta adhesiva transparente', 'Cinta adhesiva transparente - SKU institucional', 1, 5, 1, 4, 15.000, 450.000, 5.0000, 150.000, 750.00, 'ACTIVO', 1),
(34, 'PAP-GRAP-006', 'Cinta masking 24mm', 'Cinta masking 24mm - SKU institucional', 1, 5, 1, 5, 7.000, 210.000, 9.5000, 70.000, 665.00, 'ACTIVO', 1),
(35, 'PAP-GRAP-007', 'Cinta doble contacto', 'Cinta doble contacto - SKU institucional', 1, 5, 1, 1, 4.000, 135.000, 16.0000, 45.000, 720.00, 'ACTIVO', 1),
(36, 'PAP-GRAP-008', 'Pegamento en barra 21gr', 'Pegamento en barra 21gr - SKU institucional', 1, 5, 1, 2, 13.000, 390.000, 6.0000, 130.000, 780.00, 'ACTIVO', 1),
(37, 'PAP-GRAP-009', 'Tijera escolar', 'Tijera escolar - SKU institucional', 1, 5, 1, 3, 3.000, 105.000, 12.0000, 35.000, 420.00, 'ACTIVO', 1),
(38, 'PAP-GRAP-010', 'Dispensador de cinta', 'Dispensador de cinta - SKU institucional', 1, 5, 1, 4, 1.000, 54.000, 28.0000, 18.000, 504.00, 'ACTIVO', 1),
(39, 'PAP-GRAP-011', 'Goma de borrar', 'Goma de borrar - SKU institucional', 1, 5, 1, 5, 22.000, 660.000, 1.0000, 220.000, 220.00, 'ACTIVO', 1),
(40, 'PAP-GRAP-012', 'Sacagrapas', 'Sacagrapas - SKU institucional', 1, 5, 1, 1, 6.000, 180.000, 2.5000, 60.000, 150.00, 'ACTIVO', 1),
(41, 'PAP-GRAP-013', 'Cuaderno universitario 100h', 'Cuaderno universitario 100h - SKU institucional', 1, 5, 1, 2, 9.000, 270.000, 18.0000, 90.000, 1620.00, 'ACTIVO', 1),
(42, 'PAP-GRAP-014', 'Cuaderno empastado 50h', 'Cuaderno empastado 50h - SKU institucional', 1, 5, 1, 3, 7.000, 225.000, 9.5000, 75.000, 712.50, 'ACTIVO', 1),
(43, 'PAP-GRAP-015', 'Notas adhesivas 3x3', 'Notas adhesivas 3x3 - SKU institucional', 1, 5, 4, 4, 5.000, 165.000, 11.0000, 55.000, 605.00, 'ACTIVO', 1),
(44, 'PAP-GRAP-016', 'Regla 30cm', 'Regla 30cm - SKU institucional', 1, 5, 1, 5, 3.000, 90.000, 3.5000, 30.000, 105.00, 'ACTIVO', 1),
(45, 'PAP-GRAP-017', 'Calculadora básica', 'Calculadora básica - SKU institucional', 1, 5, 1, 1, 2.000, 66.000, 65.0000, 22.000, 1430.00, 'ACTIVO', 1),
(46, 'PAP-GRAP-018', 'Perforadora 2 hoyos', 'Perforadora 2 hoyos - SKU institucional', 1, 5, 1, 2, 2.000, 84.000, 38.0000, 28.000, 1064.00, 'ACTIVO', 1),
(47, 'PAP-GRAP-019', 'Engrapadora estándar', 'Engrapadora estándar - SKU institucional', 1, 5, 1, 3, 2.000, 75.000, 45.0000, 25.000, 1125.00, 'ACTIVO', 1),
(48, 'PAP-GRAP-020', 'Tablero de apoyo', 'Tablero de apoyo - SKU institucional', 1, 5, 1, 4, 5.000, 150.000, 22.0000, 50.000, 1100.00, 'ACTIVO', 1),
(49, 'TIN-TIN-001', 'Tinta HP 664 negro', 'Tinta HP 664 negro - SKU institucional', 2, 6, 1, 5, 3.000, 114.000, 95.0000, 38.000, 3610.00, 'ACTIVO', 1),
(50, 'TIN-TIN-002', 'Tinta HP 664 color', 'Tinta HP 664 color - SKU institucional', 2, 6, 1, 1, 3.000, 90.000, 110.0000, 30.000, 3300.00, 'ACTIVO', 1),
(51, 'TIN-TIN-003', 'Tinta Epson 544 negro', 'Tinta Epson 544 negro - SKU institucional', 2, 6, 1, 2, 2.000, 66.000, 75.0000, 22.000, 1650.00, 'ACTIVO', 1),
(52, 'TIN-TIN-004', 'Tinta Epson 544 cian', 'Tinta Epson 544 cian - SKU institucional', 2, 6, 1, 3, 1.000, 54.000, 75.0000, 18.000, 1350.00, 'ACTIVO', 1),
(53, 'TIN-TIN-005', 'Tinta Epson 544 magenta', 'Tinta Epson 544 magenta - SKU institucional', 2, 6, 1, 4, 1.000, 54.000, 75.0000, 18.000, 1350.00, 'ACTIVO', 1),
(54, 'TIN-TIN-006', 'Tinta Epson 544 amarillo', 'Tinta Epson 544 amarillo - SKU institucional', 2, 6, 1, 5, 1.000, 54.000, 75.0000, 18.000, 1350.00, 'ACTIVO', 1),
(55, 'TIN-TIN-007', 'Tinta Canon PG-145 negro', 'Tinta Canon PG-145 negro - SKU institucional', 2, 6, 1, 1, 2.000, 75.000, 88.0000, 25.000, 2200.00, 'ACTIVO', 1),
(56, 'TIN-TIN-008', 'Tinta Canon CL-146 color', 'Tinta Canon CL-146 color - SKU institucional', 2, 6, 1, 2, 2.000, 60.000, 125.0000, 20.000, 2500.00, 'ACTIVO', 1),
(57, 'TIN-TON-001', 'Tóner HP 85A negro', 'Tóner HP 85A negro - SKU institucional', 2, 7, 1, 3, 1.000, 42.000, 280.0000, 14.000, 3920.00, 'ACTIVO', 1),
(58, 'TIN-TON-002', 'Tóner HP 26A negro', 'Tóner HP 26A negro - SKU institucional', 2, 7, 1, 4, 1.000, 36.000, 310.0000, 12.000, 3720.00, 'ACTIVO', 1),
(59, 'TIN-TON-003', 'Tóner HP 305A negro', 'Tóner HP 305A negro - SKU institucional', 2, 7, 1, 5, 1.000, 24.000, 360.0000, 8.000, 2880.00, 'ACTIVO', 1),
(60, 'TIN-TON-004', 'Tóner Samsung MLT-D101S', 'Tóner Samsung MLT-D101S - SKU institucional', 2, 7, 1, 1, 1.000, 30.000, 290.0000, 10.000, 2900.00, 'ACTIVO', 1),
(61, 'TIN-TON-005', 'Tóner Brother TN-1060', 'Tóner Brother TN-1060 - SKU institucional', 2, 7, 1, 2, 1.000, 18.000, 320.0000, 6.000, 1920.00, 'ACTIVO', 1),
(62, 'TIN-TON-006', 'Tóner Xerox 106R01604', 'Tóner Xerox 106R01604 - SKU institucional', 2, 7, 1, 3, 1.000, 15.000, 410.0000, 5.000, 2050.00, 'ACTIVO', 1),
(63, 'TIN-TON-007', 'Tóner Lexmark 50F2H00', 'Tóner Lexmark 50F2H00 - SKU institucional', 2, 7, 1, 4, 1.000, 12.000, 480.0000, 4.000, 1920.00, 'ACTIVO', 1),
(64, 'LIM-PAP-001', 'Papel higiénico institucional 500m', 'Papel higiénico institucional 500m - SKU institucional', 3, 8, 1, 5, 24.000, 720.000, 18.0000, 240.000, 4320.00, 'ACTIVO', 1),
(65, 'LIM-PAP-002', 'Papel toalla interfoliado', 'Papel toalla interfoliado - SKU institucional', 3, 8, 4, 1, 9.000, 285.000, 22.0000, 95.000, 2090.00, 'ACTIVO', 1),
(66, 'LIM-PAP-003', 'Servilletas', 'Servilletas - SKU institucional', 3, 8, 4, 2, 4.000, 120.000, 12.0000, 40.000, 480.00, 'ACTIVO', 1),
(67, 'LIM-DET-001', 'Detergente en polvo 1kg', 'Detergente en polvo 1kg - SKU institucional', 3, 9, 8, 3, 3.000, 105.000, 22.0000, 35.000, 770.00, 'ACTIVO', 1),
(68, 'LIM-DET-002', 'Detergente líquido 1L', 'Detergente líquido 1L - SKU institucional', 3, 9, 7, 4, 3.000, 90.000, 28.0000, 30.000, 840.00, 'ACTIVO', 1),
(69, 'LIM-DET-003', 'Jabón líquido para manos 1L', 'Jabón líquido para manos 1L - SKU institucional', 3, 9, 7, 5, 5.000, 150.000, 25.0000, 50.000, 1250.00, 'ACTIVO', 1),
(70, 'LIM-DET-004', 'Lavandina 1L', 'Lavandina 1L - SKU institucional', 3, 9, 7, 1, 6.000, 180.000, 14.0000, 60.000, 840.00, 'ACTIVO', 1),
(71, 'LIM-DES-001', 'Desinfectante en aerosol 360cc', 'Desinfectante en aerosol 360cc - SKU institucional', 3, 10, 1, 2, 4.000, 120.000, 38.0000, 40.000, 1520.00, 'ACTIVO', 1),
(72, 'LIM-DES-002', 'Alcohol en gel 1L', 'Alcohol en gel 1L - SKU institucional', 3, 10, 7, 3, 3.000, 105.000, 42.0000, 35.000, 1470.00, 'ACTIVO', 1),
(73, 'LIM-DES-003', 'Esponja doble uso', 'Esponja doble uso - SKU institucional', 3, 10, 1, 4, 18.000, 540.000, 2.5000, 180.000, 450.00, 'ACTIVO', 1),
(74, 'LIM-DES-004', 'Paño de microfibra', 'Paño de microfibra - SKU institucional', 3, 10, 1, 5, 7.000, 210.000, 8.0000, 70.000, 560.00, 'ACTIVO', 1),
(75, 'LIM-DES-005', 'Bolsa de basura 50L', 'Bolsa de basura 50L - SKU institucional', 3, 10, 1, 1, 20.000, 600.000, 1.5000, 200.000, 300.00, 'ACTIVO', 1),
(76, 'LIM-DES-006', 'Bolsa de basura 100L', 'Bolsa de basura 100L - SKU institucional', 3, 10, 1, 2, 12.000, 360.000, 2.2000, 120.000, 264.00, 'ACTIVO', 1),
(77, 'LIM-DES-007', 'Trapeador de piso', 'Trapeador de piso - SKU institucional', 3, 10, 1, 3, 2.000, 66.000, 25.0000, 22.000, 550.00, 'ACTIVO', 1),
(78, 'LIM-DES-008', 'Escoba', 'Escoba - SKU institucional', 3, 10, 1, 4, 1.000, 54.000, 28.0000, 18.000, 504.00, 'ACTIVO', 1),
(79, 'LIM-DES-009', 'Recogedor', 'Recogedor - SKU institucional', 3, 10, 1, 5, 1.000, 48.000, 18.0000, 16.000, 288.00, 'ACTIVO', 1),
(80, 'LIM-DES-010', 'Guantes de limpieza', 'Guantes de limpieza - SKU institucional', 3, 10, 10, 1, 6.000, 180.000, 8.5000, 60.000, 510.00, 'ACTIVO', 1),
(81, 'LIM-DES-011', 'Ambientador en aerosol', 'Ambientador en aerosol - SKU institucional', 3, 10, 1, 2, 2.000, 84.000, 32.0000, 28.000, 896.00, 'ACTIVO', 1),
(82, 'LIM-DES-012', 'Limpiador multiusos 1L', 'Limpiador multiusos 1L - SKU institucional', 3, 10, 7, 3, 2.000, 75.000, 26.0000, 25.000, 650.00, 'ACTIVO', 1),
(83, 'LIM-DES-013', 'Limpiavidrios 500ml', 'Limpiavidrios 500ml - SKU institucional', 3, 10, 1, 4, 2.000, 66.000, 18.0000, 22.000, 396.00, 'ACTIVO', 1),
(84, 'INF-MOU-001', 'Mouse óptico USB', 'Mouse óptico USB - SKU institucional', 4, 11, 1, 5, 4.000, 135.000, 55.0000, 45.000, 2475.00, 'ACTIVO', 1),
(85, 'INF-MOU-002', 'Mouse inalámbrico', 'Mouse inalámbrico - SKU institucional', 4, 11, 1, 1, 2.000, 84.000, 95.0000, 28.000, 2660.00, 'ACTIVO', 1),
(86, 'INF-MOU-003', 'Pad mouse', 'Pad mouse - SKU institucional', 4, 11, 1, 2, 8.000, 240.000, 12.0000, 80.000, 960.00, 'ACTIVO', 1),
(87, 'INF-TEC-001', 'Teclado USB español', 'Teclado USB español - SKU institucional', 4, 12, 1, 3, 3.000, 90.000, 85.0000, 30.000, 2550.00, 'ACTIVO', 1),
(88, 'INF-TEC-002', 'Teclado inalámbrico', 'Teclado inalámbrico - SKU institucional', 4, 12, 1, 4, 1.000, 54.000, 145.0000, 18.000, 2610.00, 'ACTIVO', 1),
(89, 'INF-TEC-003', 'Combo teclado + mouse', 'Combo teclado + mouse - SKU institucional', 4, 12, 1, 5, 1.000, 45.000, 165.0000, 15.000, 2475.00, 'ACTIVO', 1),
(90, 'INF-CAB-001', 'Cable HDMI 1.5m', 'Cable HDMI 1.5m - SKU institucional', 4, 13, 1, 1, 2.000, 66.000, 35.0000, 22.000, 770.00, 'ACTIVO', 1),
(91, 'INF-CAB-002', 'Cable VGA 1.8m', 'Cable VGA 1.8m - SKU institucional', 4, 13, 1, 2, 1.000, 54.000, 28.0000, 18.000, 504.00, 'ACTIVO', 1),
(92, 'INF-CAB-003', 'Cable USB 2.0 tipo A-B 1.8m', 'Cable USB 2.0 tipo A-B 1.8m - SKU institucional', 4, 13, 1, 3, 3.000, 90.000, 18.0000, 30.000, 540.00, 'ACTIVO', 1),
(93, 'INF-CAB-004', 'Cable de red UTP cat6 1m', 'Cable de red UTP cat6 1m - SKU institucional', 4, 13, 6, 4, 25.000, 750.000, 4.5000, 250.000, 1125.00, 'ACTIVO', 1),
(94, 'INF-CAB-005', 'Cable de red UTP cat6 3m', 'Cable de red UTP cat6 3m - SKU institucional', 4, 13, 1, 5, 4.000, 120.000, 22.0000, 40.000, 880.00, 'ACTIVO', 1),
(95, 'INF-CAB-006', 'Adaptador HDMI a VGA', 'Adaptador HDMI a VGA - SKU institucional', 4, 13, 1, 1, 1.000, 42.000, 65.0000, 14.000, 910.00, 'ACTIVO', 1),
(96, 'INF-CAB-007', 'Cable de poder 1.5m', 'Cable de poder 1.5m - SKU institucional', 4, 13, 1, 2, 3.000, 105.000, 22.0000, 35.000, 770.00, 'ACTIVO', 1),
(97, 'INF-USB-001', 'Memoria USB 16GB', 'Memoria USB 16GB - SKU institucional', 4, 14, 1, 3, 3.000, 114.000, 65.0000, 38.000, 2470.00, 'ACTIVO', 1),
(98, 'INF-USB-002', 'Memoria USB 32GB', 'Memoria USB 32GB - SKU institucional', 4, 14, 1, 4, 3.000, 90.000, 90.0000, 30.000, 2700.00, 'ACTIVO', 1),
(99, 'INF-USB-003', 'Memoria USB 64GB', 'Memoria USB 64GB - SKU institucional', 4, 14, 1, 5, 1.000, 54.000, 145.0000, 18.000, 2610.00, 'ACTIVO', 1),
(100, 'INF-USB-004', 'Disco duro externo 1TB', 'Disco duro externo 1TB - SKU institucional', 4, 14, 1, 1, 1.000, 24.000, 580.0000, 8.000, 4640.00, 'ACTIVO', 1),
(101, 'INF-USB-005', 'Disco duro externo 2TB', 'Disco duro externo 2TB - SKU institucional', 4, 14, 1, 2, 1.000, 15.000, 820.0000, 5.000, 4100.00, 'ACTIVO', 1),
(102, 'ESC-SEL-001', 'Sello de goma redondo', 'Sello de goma redondo - SKU institucional', 5, 15, 1, 3, 2.000, 75.000, 25.0000, 25.000, 625.00, 'ACTIVO', 1),
(103, 'ESC-SEL-002', 'Sello fechador', 'Sello fechador - SKU institucional', 5, 15, 1, 4, 1.000, 54.000, 42.0000, 18.000, 756.00, 'ACTIVO', 1),
(104, 'ESC-SEL-003', 'Tinta para sello azul', 'Tinta para sello azul - SKU institucional', 5, 15, 1, 5, 6.000, 180.000, 7.5000, 60.000, 450.00, 'ACTIVO', 1),
(105, 'ESC-SEL-004', 'Tinta para sello negra', 'Tinta para sello negra - SKU institucional', 5, 15, 1, 1, 5.000, 165.000, 7.5000, 55.000, 412.50, 'ACTIVO', 1),
(106, 'ESC-SEL-005', 'Almohadilla para sello', 'Almohadilla para sello - SKU institucional', 5, 15, 1, 2, 3.000, 90.000, 11.0000, 30.000, 330.00, 'ACTIVO', 1),
(107, 'ESC-PER-001', 'Perforadora 2 hoyos 25h', 'Perforadora 2 hoyos 25h - SKU institucional', 5, 16, 1, 3, 2.000, 66.000, 85.0000, 22.000, 1870.00, 'ACTIVO', 1),
(108, 'ESC-PER-002', 'Perforadora 3 hoyos', 'Perforadora 3 hoyos - SKU institucional', 5, 16, 1, 4, 1.000, 36.000, 130.0000, 12.000, 1560.00, 'ACTIVO', 1),
(109, 'ESC-PER-003', 'Perforadora industrial 60h', 'Perforadora industrial 60h - SKU institucional', 5, 16, 1, 5, 1.000, 12.000, 480.0000, 4.000, 1920.00, 'ACTIVO', 1),
(110, 'ESC-PER-004', 'Engrapadora industrial 100h', 'Engrapadora industrial 100h - SKU institucional', 5, 16, 1, 1, 1.000, 15.000, 380.0000, 5.000, 1900.00, 'ACTIVO', 1),
(111, 'ESC-PER-005', 'Engrapadora estándar 25h', 'Engrapadora estándar 25h - SKU institucional', 5, 16, 1, 2, 2.000, 75.000, 65.0000, 25.000, 1625.00, 'ACTIVO', 1),
(112, 'ESC-PER-006', 'Plastificadora A4', 'Plastificadora A4 - SKU institucional', 5, 16, 1, 3, 1.000, 9.000, 980.0000, 3.000, 2940.00, 'ACTIVO', 1),
(113, 'ESC-PER-007', 'Caja fuerte 50L', 'Caja fuerte 50L - SKU institucional', 5, 16, 1, 4, 1.000, 6.000, 2400.0000, 2.000, 4800.00, 'ACTIVO', 1),
(114, 'ESC-PER-008', 'Caja archivadora plástica', 'Caja archivadora plástica - SKU institucional', 5, 16, 1, 5, 3.000, 105.000, 38.0000, 35.000, 1330.00, 'ACTIVO', 1),
(115, 'ESC-PER-009', 'Separador de colores', 'Separador de colores - SKU institucional', 5, 16, 1, 1, 11.000, 330.000, 2.0000, 110.000, 220.00, 'ACTIVO', 1),
(116, 'ESC-PER-010', 'Carpeta clasificadora', 'Carpeta clasificadora - SKU institucional', 5, 16, 1, 2, 6.000, 195.000, 25.0000, 65.000, 1625.00, 'ACTIVO', 1),
(117, 'ELE-FOC-001', 'Foco LED 9W E27', 'Foco LED 9W E27 - SKU institucional', 6, 17, 1, 3, 12.000, 360.000, 18.0000, 120.000, 2160.00, 'ACTIVO', 1),
(118, 'ELE-FOC-002', 'Foco LED 12W E27', 'Foco LED 12W E27 - SKU institucional', 6, 17, 1, 4, 8.000, 255.000, 24.0000, 85.000, 2040.00, 'ACTIVO', 1),
(119, 'ELE-FOC-003', 'Foco LED 15W E27', 'Foco LED 15W E27 - SKU institucional', 6, 17, 1, 5, 6.000, 180.000, 32.0000, 60.000, 1920.00, 'ACTIVO', 1),
(120, 'ELE-FOC-004', 'Tubo LED T8 18W', 'Tubo LED T8 18W - SKU institucional', 6, 17, 1, 1, 4.000, 135.000, 48.0000, 45.000, 2160.00, 'ACTIVO', 1),
(121, 'ELE-FOC-005', 'Reflector LED 50W', 'Reflector LED 50W - SKU institucional', 6, 17, 1, 2, 1.000, 36.000, 220.0000, 12.000, 2640.00, 'ACTIVO', 1),
(122, 'ELE-EXT-001', 'Extensión 5m 6 tomas', 'Extensión 5m 6 tomas - SKU institucional', 6, 18, 1, 3, 1.000, 54.000, 95.0000, 18.000, 1710.00, 'ACTIVO', 1),
(123, 'ELE-EXT-002', 'Regleta 4 tomas', 'Regleta 4 tomas - SKU institucional', 6, 18, 1, 4, 3.000, 90.000, 45.0000, 30.000, 1350.00, 'ACTIVO', 1),
(124, 'ELE-EXT-003', 'UPS 1000VA', 'UPS 1000VA - SKU institucional', 6, 18, 1, 5, 1.000, 18.000, 1150.0000, 6.000, 6900.00, 'ACTIVO', 1),
(125, 'ELE-EXT-004', 'Regulador de voltaje 1000VA', 'Regulador de voltaje 1000VA - SKU institucional', 6, 18, 1, 1, 1.000, 24.000, 580.0000, 8.000, 4640.00, 'ACTIVO', 1),
(126, 'ELE-EXT-005', 'Supresor de picos', 'Supresor de picos - SKU institucional', 6, 18, 1, 2, 1.000, 36.000, 95.0000, 12.000, 1140.00, 'ACTIVO', 1),
(127, 'ELE-EXT-006', 'Multitoma con USB', 'Multitoma con USB - SKU institucional', 6, 18, 1, 3, 1.000, 45.000, 85.0000, 15.000, 1275.00, 'ACTIVO', 1),
(128, 'ELE-EXT-007', 'Cinta aislante', 'Cinta aislante - SKU institucional', 6, 18, 1, 4, 6.000, 195.000, 9.0000, 65.000, 585.00, 'ACTIVO', 1),
(129, 'ELE-EXT-008', 'Pila AA paquete x4', 'Pila AA paquete x4 - SKU institucional', 6, 18, 4, 5, 4.000, 144.000, 22.0000, 48.000, 1056.00, 'ACTIVO', 1),
(130, 'ELE-EXT-009', 'Pila AAA paquete x4', 'Pila AAA paquete x4 - SKU institucional', 6, 18, 4, 1, 4.000, 126.000, 22.0000, 42.000, 924.00, 'ACTIVO', 1),
(131, 'ELE-EXT-010', 'Pila D paquete x2', 'Pila D paquete x2 - SKU institucional', 6, 18, 4, 2, 2.000, 75.000, 35.0000, 25.000, 875.00, 'ACTIVO', 1),
(132, 'PAP-HOJ-007', 'Cartulina blanca', 'Cartulina blanca - SKU institucional', 1, 1, 1, 3, 8.000, 240.000, 2.8000, 80.000, 224.00, 'ACTIVO', 1),
(133, 'PAP-HOJ-008', 'Cartulina de colores', 'Cartulina de colores - SKU institucional', 1, 1, 1, 4, 6.000, 195.000, 3.2000, 65.000, 208.00, 'ACTIVO', 1),
(134, 'PAP-HOJ-009', 'Papel crepe', 'Papel crepe - SKU institucional', 1, 1, 1, 5, 4.000, 135.000, 4.5000, 45.000, 202.50, 'ACTIVO', 1),
(135, 'PAP-HOJ-010', 'Papel kraft', 'Papel kraft - SKU institucional', 1, 1, 1, 1, 3.000, 105.000, 5.0000, 35.000, 175.00, 'ACTIVO', 1),
(136, 'PAP-CAR-007', 'Carpeta con anillos 1/2 pulgada', 'Carpeta con anillos 1/2 pulgada - SKU institucional', 1, 3, 1, 2, 5.000, 150.000, 18.0000, 50.000, 900.00, 'ACTIVO', 1),
(137, 'PAP-CAR-008', 'Carpeta con anillos 1 pulgada', 'Carpeta con anillos 1 pulgada - SKU institucional', 1, 3, 1, 3, 3.000, 114.000, 26.0000, 38.000, 988.00, 'ACTIVO', 1),
(138, 'PAP-CAR-009', 'Carpeta con anillos 2 pulgadas', 'Carpeta con anillos 2 pulgadas - SKU institucional', 1, 3, 1, 4, 2.000, 72.000, 42.0000, 24.000, 1008.00, 'ACTIVO', 1),
(139, 'PAP-CAR-010', 'Carpeta L tamaño carta', 'Carpeta L tamaño carta - SKU institucional', 1, 3, 1, 5, 18.000, 540.000, 1.8000, 180.000, 324.00, 'ACTIVO', 1),
(140, 'PAP-SOB-005', 'Sobre acolchado pequeño', 'Sobre acolchado pequeño - SKU institucional', 1, 4, 1, 1, 9.000, 270.000, 3.5000, 90.000, 315.00, 'ACTIVO', 1),
(141, 'PAP-SOB-006', 'Sobre acolchado mediano', 'Sobre acolchado mediano - SKU institucional', 1, 4, 1, 2, 7.000, 225.000, 5.0000, 75.000, 375.00, 'ACTIVO', 1),
(142, 'PAP-SOB-007', 'Sobre acolchado grande', 'Sobre acolchado grande - SKU institucional', 1, 4, 1, 3, 6.000, 180.000, 7.5000, 60.000, 450.00, 'ACTIVO', 1),
(143, 'PAP-BOL-013', 'Marcador grueso negro', 'Marcador grueso negro - SKU institucional', 1, 2, 1, 4, 7.000, 210.000, 8.5000, 70.000, 595.00, 'ACTIVO', 1),
(144, 'PAP-BOL-014', 'Marcador pizarra azul', 'Marcador pizarra azul - SKU institucional', 1, 2, 1, 5, 4.000, 135.000, 9.0000, 45.000, 405.00, 'ACTIVO', 1),
(145, 'PAP-BOL-015', 'Marcador pizarra negro', 'Marcador pizarra negro - SKU institucional', 1, 2, 1, 1, 4.000, 135.000, 9.0000, 45.000, 405.00, 'ACTIVO', 1),
(146, 'PAP-BOL-016', 'Marcador pizarra rojo', 'Marcador pizarra rojo - SKU institucional', 1, 2, 1, 2, 3.000, 105.000, 9.0000, 35.000, 315.00, 'ACTIVO', 1),
(147, 'PAP-BOL-017', 'Marcador permanente rojo', 'Marcador permanente rojo - SKU institucional', 1, 2, 1, 3, 3.000, 90.000, 8.0000, 30.000, 240.00, 'ACTIVO', 1),
(148, 'PAP-BOL-018', 'Marcador permanente verde', 'Marcador permanente verde - SKU institucional', 1, 2, 1, 4, 2.000, 84.000, 8.0000, 28.000, 224.00, 'ACTIVO', 1),
(149, 'PAP-BOL-019', 'Corrector líquido', 'Corrector líquido - SKU institucional', 1, 2, 1, 5, 5.000, 165.000, 6.0000, 55.000, 330.00, 'ACTIVO', 1),
(150, 'PAP-BOL-020', 'Corrector en cinta', 'Corrector en cinta - SKU institucional', 1, 2, 1, 1, 4.000, 120.000, 14.0000, 40.000, 560.00, 'ACTIVO', 1),
(151, 'PAP-GRAP-021', 'Disco compacto CD-R', 'Disco compacto CD-R - SKU institucional', 1, 5, 1, 2, 5.000, 150.000, 4.5000, 50.000, 225.00, 'ACTIVO', 1),
(152, 'PAP-GRAP-022', 'DVD-R grabable', 'DVD-R grabable - SKU institucional', 1, 5, 1, 3, 3.000, 105.000, 5.5000, 35.000, 192.50, 'ACTIVO', 1),
(153, 'PAP-GRAP-023', 'Sobre plástico CD/DVD', 'Sobre plástico CD/DVD - SKU institucional', 1, 5, 1, 4, 6.000, 180.000, 1.5000, 60.000, 90.00, 'ACTIVO', 1),
(154, 'PAP-GRAP-024', 'Lupa de oficina', 'Lupa de oficina - SKU institucional', 1, 5, 1, 5, 1.000, 24.000, 45.0000, 8.000, 360.00, 'ACTIVO', 1),
(155, 'PAP-GRAP-025', 'Porta clips magnético', 'Porta clips magnético - SKU institucional', 1, 5, 1, 1, 1.000, 36.000, 22.0000, 12.000, 264.00, 'ACTIVO', 1),
(156, 'PAP-GRAP-026', 'Porta lapiceros', 'Porta lapiceros - SKU institucional', 1, 5, 1, 2, 1.000, 54.000, 18.0000, 18.000, 324.00, 'ACTIVO', 1),
(157, 'PAP-GRAP-027', 'Organizador de escritorio', 'Organizador de escritorio - SKU institucional', 1, 5, 1, 3, 1.000, 45.000, 95.0000, 15.000, 1425.00, 'ACTIVO', 1),
(158, 'PAP-GRAP-028', 'Bandeja portapapeles 2 pisos', 'Bandeja portapapeles 2 pisos - SKU institucional', 1, 5, 1, 4, 2.000, 66.000, 78.0000, 22.000, 1716.00, 'ACTIVO', 1),
(159, 'PAP-GRAP-029', 'Revistero de mesa', 'Revistero de mesa - SKU institucional', 1, 5, 1, 5, 1.000, 42.000, 55.0000, 14.000, 770.00, 'ACTIVO', 1),
(160, 'PAP-GRAP-030', 'Dispensador de cinta adhesiva', 'Dispensador de cinta adhesiva - SKU institucional', 1, 5, 1, 1, 1.000, 30.000, 38.0000, 10.000, 380.00, 'ACTIVO', 1),
(161, 'INF-CAB-008', 'Cable USB tipo C 1m', 'Cable USB tipo C 1m - SKU institucional', 4, 13, 1, 2, 2.000, 84.000, 22.0000, 28.000, 616.00, 'ACTIVO', 1),
(162, 'INF-CAB-009', 'Cable USB Lightning 1m', 'Cable USB Lightning 1m - SKU institucional', 4, 13, 1, 3, 2.000, 60.000, 28.0000, 20.000, 560.00, 'ACTIVO', 1),
(163, 'INF-CAB-010', 'Cable USB micro USB 1m', 'Cable USB micro USB 1m - SKU institucional', 4, 13, 1, 4, 2.000, 75.000, 18.0000, 25.000, 450.00, 'ACTIVO', 1),
(164, 'INF-USB-006', 'Tarjeta SD 32GB', 'Tarjeta SD 32GB - SKU institucional', 4, 14, 1, 5, 1.000, 54.000, 75.0000, 18.000, 1350.00, 'ACTIVO', 1),
(165, 'INF-USB-007', 'Tarjeta SD 64GB', 'Tarjeta SD 64GB - SKU institucional', 4, 14, 1, 1, 1.000, 36.000, 125.0000, 12.000, 1500.00, 'ACTIVO', 1),
(166, 'INF-USB-008', 'Lector de tarjetas', 'Lector de tarjetas - SKU institucional', 4, 14, 1, 2, 1.000, 30.000, 55.0000, 10.000, 550.00, 'ACTIVO', 1),
(167, 'INF-USB-009', 'Hub USB 4 puertos', 'Hub USB 4 puertos - SKU institucional', 4, 14, 1, 3, 1.000, 42.000, 78.0000, 14.000, 1092.00, 'ACTIVO', 1),
(168, 'INF-MOU-004', 'Mouse ergonómico', 'Mouse ergonómico - SKU institucional', 4, 11, 1, 4, 1.000, 24.000, 180.0000, 8.000, 1440.00, 'ACTIVO', 1),
(169, 'INF-MOU-005', 'Mouse con cable tipo C', 'Mouse con cable tipo C - SKU institucional', 4, 11, 1, 5, 1.000, 45.000, 85.0000, 15.000, 1275.00, 'ACTIVO', 1),
(170, 'INF-TEC-004', 'Teclado mecánico', 'Teclado mecánico - SKU institucional', 4, 12, 1, 1, 1.000, 18.000, 380.0000, 6.000, 2280.00, 'ACTIVO', 1),
(171, 'INF-TEC-005', 'Teclado numérico externo', 'Teclado numérico externo - SKU institucional', 4, 12, 1, 2, 1.000, 24.000, 95.0000, 8.000, 760.00, 'ACTIVO', 1),
(172, 'ELE-FOC-006', 'Panel LED 60x60 48W', 'Panel LED 60x60 48W - SKU institucional', 6, 17, 1, 3, 1.000, 30.000, 320.0000, 10.000, 3200.00, 'ACTIVO', 1),
(173, 'ELE-FOC-007', 'Downlight LED 18W', 'Downlight LED 18W - SKU institucional', 6, 17, 1, 4, 1.000, 54.000, 95.0000, 18.000, 1710.00, 'ACTIVO', 1),
(174, 'ELE-EXT-011', 'Enchufe industrial 220V', 'Enchufe industrial 220V - SKU institucional', 6, 18, 1, 5, 1.000, 36.000, 65.0000, 12.000, 780.00, 'ACTIVO', 1),
(175, 'ELE-EXT-012', 'Adaptador de enchufe universal', 'Adaptador de enchufe universal - SKU institucional', 6, 18, 1, 1, 2.000, 66.000, 22.0000, 22.000, 484.00, 'ACTIVO', 1),
(176, 'ELE-EXT-013', 'Cargador USB de pared', 'Cargador USB de pared - SKU institucional', 6, 18, 1, 2, 2.000, 84.000, 45.0000, 28.000, 1260.00, 'ACTIVO', 1),
(177, 'ELE-EXT-014', 'Cargador inalámbrico', 'Cargador inalámbrico - SKU institucional', 6, 18, 1, 3, 1.000, 24.000, 165.0000, 8.000, 1320.00, 'ACTIVO', 1),
(178, 'ESC-SEL-006', 'Sello numerador', 'Sello numerador - SKU institucional', 5, 15, 1, 4, 1.000, 18.000, 78.0000, 6.000, 468.00, 'ACTIVO', 1),
(179, 'ESC-SEL-007', 'Sello de bolsillo', 'Sello de bolsillo - SKU institucional', 5, 15, 1, 5, 1.000, 42.000, 32.0000, 14.000, 448.00, 'ACTIVO', 1),
(180, 'ESC-PER-011', 'Destructora de papel', 'Destructora de papel - SKU institucional', 5, 16, 1, 1, 1.000, 9.000, 2200.0000, 3.000, 6600.00, 'ACTIVO', 1),
(181, 'ESC-PER-012', 'Cortador de papel industrial', 'Cortador de papel industrial - SKU institucional', 5, 16, 1, 2, 1.000, 6.000, 1850.0000, 2.000, 3700.00, 'ACTIVO', 1);

-- Comprobante de Ingreso de Apertura
INSERT INTO `stock_entries` (`id`, `number`, `type`, `doc_type`, `doc_number`, `doc_date`, `entry_date`, `posted_at`, `total_amount`, `notes`, `status`, `created_by`, `created_at`) VALUES
(1, 'ING-2026-000001', 'APERTURA', 'INVENTARIO_INICIAL', 'ACTA-2026-001', '2026-08-09 08:00:00', '2026-08-09 08:00:00', '2026-08-09 08:00:00', 245682.00, 'Acta de conciliación de apertura del sistema SIGA-DDE al 09/08/2026. Saldo valorado total conciliado contra inventario oficial clasificado.', 'CONFIRMADO', 1, '2026-08-09 08:00:00');

-- Datos iniciales de stock_entry_items: se conservan los registros originales.
INSERT INTO `stock_entry_items` (`id`, `entry_id`, `product_id`, `location_id`, `quantity`, `unit_cost`, `total`, `notes`) VALUES
(1, 1, 1, 2, 480.000, 32.5000, 15600.00, 'Inventario inicial conciliado'),
(2, 1, 2, 3, 85.000, 38.2000, 3247.00, 'Inventario inicial conciliado'),
(3, 1, 3, 4, 60.000, 30.8000, 1848.00, 'Inventario inicial conciliado'),
(4, 1, 4, 5, 24.000, 95.0000, 2280.00, 'Inventario inicial conciliado'),
(5, 1, 5, 1, 140.000, 1.5000, 210.00, 'Inventario inicial conciliado'),
(6, 1, 6, 2, 15.000, 34.0000, 510.00, 'Inventario inicial conciliado'),
(7, 1, 7, 3, 540.000, 2.8000, 1512.00, 'Inventario inicial conciliado'),
(8, 1, 8, 4, 430.000, 2.8000, 1204.00, 'Inventario inicial conciliado'),
(9, 1, 9, 5, 320.000, 2.8000, 896.00, 'Inventario inicial conciliado'),
(10, 1, 10, 1, 150.000, 2.8000, 420.00, 'Inventario inicial conciliado'),
(11, 1, 11, 2, 600.000, 1.2000, 720.00, 'Inventario inicial conciliado'),
(12, 1, 12, 3, 120.000, 1.5000, 180.00, 'Inventario inicial conciliado'),
(13, 1, 13, 4, 88.000, 5.5000, 484.00, 'Inventario inicial conciliado'),
(14, 1, 14, 5, 75.000, 5.5000, 412.50, 'Inventario inicial conciliado'),
(15, 1, 15, 1, 60.000, 5.5000, 330.00, 'Inventario inicial conciliado'),
(16, 1, 16, 2, 95.000, 6.0000, 570.00, 'Inventario inicial conciliado'),
(17, 1, 17, 3, 70.000, 6.0000, 420.00, 'Inventario inicial conciliado'),
(18, 1, 18, 4, 55.000, 6.0000, 330.00, 'Inventario inicial conciliado'),
(19, 1, 19, 5, 250.000, 4.5000, 1125.00, 'Inventario inicial conciliado'),
(20, 1, 20, 1, 200.000, 6.8000, 1360.00, 'Inventario inicial conciliado'),
(21, 1, 21, 2, 95.000, 22.0000, 2090.00, 'Inventario inicial conciliado'),
(22, 1, 22, 3, 65.000, 28.0000, 1820.00, 'Inventario inicial conciliado'),
(23, 1, 23, 4, 180.000, 7.5000, 1350.00, 'Inventario inicial conciliado'),
(24, 1, 24, 5, 540.000, 0.9000, 486.00, 'Inventario inicial conciliado'),
(25, 1, 25, 1, 420.000, 1.2000, 504.00, 'Inventario inicial conciliado'),
(26, 1, 26, 2, 380.000, 1.0000, 380.00, 'Inventario inicial conciliado'),
(27, 1, 27, 3, 150.000, 2.5000, 375.00, 'Inventario inicial conciliado'),
(28, 1, 28, 4, 220.000, 1.1000, 242.00, 'Inventario inicial conciliado'),
(29, 1, 29, 5, 85.000, 7.5000, 637.50, 'Inventario inicial conciliado'),
(30, 1, 30, 1, 60.000, 9.0000, 540.00, 'Inventario inicial conciliado'),
(31, 1, 31, 2, 120.000, 4.5000, 540.00, 'Inventario inicial conciliado'),
(32, 1, 32, 3, 40.000, 5.0000, 200.00, 'Inventario inicial conciliado'),
(33, 1, 33, 4, 150.000, 5.0000, 750.00, 'Inventario inicial conciliado'),
(34, 1, 34, 5, 70.000, 9.5000, 665.00, 'Inventario inicial conciliado'),
(35, 1, 35, 1, 45.000, 16.0000, 720.00, 'Inventario inicial conciliado'),
(36, 1, 36, 2, 130.000, 6.0000, 780.00, 'Inventario inicial conciliado'),
(37, 1, 37, 3, 35.000, 12.0000, 420.00, 'Inventario inicial conciliado'),
(38, 1, 38, 4, 18.000, 28.0000, 504.00, 'Inventario inicial conciliado'),
(39, 1, 39, 5, 220.000, 1.0000, 220.00, 'Inventario inicial conciliado'),
(40, 1, 40, 1, 60.000, 2.5000, 150.00, 'Inventario inicial conciliado'),
(41, 1, 41, 2, 90.000, 18.0000, 1620.00, 'Inventario inicial conciliado'),
(42, 1, 42, 3, 75.000, 9.5000, 712.50, 'Inventario inicial conciliado'),
(43, 1, 43, 4, 55.000, 11.0000, 605.00, 'Inventario inicial conciliado'),
(44, 1, 44, 5, 30.000, 3.5000, 105.00, 'Inventario inicial conciliado'),
(45, 1, 45, 1, 22.000, 65.0000, 1430.00, 'Inventario inicial conciliado'),
(46, 1, 46, 2, 28.000, 38.0000, 1064.00, 'Inventario inicial conciliado'),
(47, 1, 47, 3, 25.000, 45.0000, 1125.00, 'Inventario inicial conciliado'),
(48, 1, 48, 4, 50.000, 22.0000, 1100.00, 'Inventario inicial conciliado'),
(49, 1, 49, 5, 38.000, 95.0000, 3610.00, 'Inventario inicial conciliado'),
(50, 1, 50, 1, 30.000, 110.0000, 3300.00, 'Inventario inicial conciliado'),
(51, 1, 51, 2, 22.000, 75.0000, 1650.00, 'Inventario inicial conciliado'),
(52, 1, 52, 3, 18.000, 75.0000, 1350.00, 'Inventario inicial conciliado'),
(53, 1, 53, 4, 18.000, 75.0000, 1350.00, 'Inventario inicial conciliado'),
(54, 1, 54, 5, 18.000, 75.0000, 1350.00, 'Inventario inicial conciliado'),
(55, 1, 55, 1, 25.000, 88.0000, 2200.00, 'Inventario inicial conciliado'),
(56, 1, 56, 2, 20.000, 125.0000, 2500.00, 'Inventario inicial conciliado'),
(57, 1, 57, 3, 14.000, 280.0000, 3920.00, 'Inventario inicial conciliado'),
(58, 1, 58, 4, 12.000, 310.0000, 3720.00, 'Inventario inicial conciliado'),
(59, 1, 59, 5, 8.000, 360.0000, 2880.00, 'Inventario inicial conciliado'),
(60, 1, 60, 1, 10.000, 290.0000, 2900.00, 'Inventario inicial conciliado'),
(61, 1, 61, 2, 6.000, 320.0000, 1920.00, 'Inventario inicial conciliado'),
(62, 1, 62, 3, 5.000, 410.0000, 2050.00, 'Inventario inicial conciliado'),
(63, 1, 63, 4, 4.000, 480.0000, 1920.00, 'Inventario inicial conciliado'),
(64, 1, 64, 5, 240.000, 18.0000, 4320.00, 'Inventario inicial conciliado'),
(65, 1, 65, 1, 95.000, 22.0000, 2090.00, 'Inventario inicial conciliado'),
(66, 1, 66, 2, 40.000, 12.0000, 480.00, 'Inventario inicial conciliado'),
(67, 1, 67, 3, 35.000, 22.0000, 770.00, 'Inventario inicial conciliado'),
(68, 1, 68, 4, 30.000, 28.0000, 840.00, 'Inventario inicial conciliado'),
(69, 1, 69, 5, 50.000, 25.0000, 1250.00, 'Inventario inicial conciliado'),
(70, 1, 70, 1, 60.000, 14.0000, 840.00, 'Inventario inicial conciliado'),
(71, 1, 71, 2, 40.000, 38.0000, 1520.00, 'Inventario inicial conciliado'),
(72, 1, 72, 3, 35.000, 42.0000, 1470.00, 'Inventario inicial conciliado'),
(73, 1, 73, 4, 180.000, 2.5000, 450.00, 'Inventario inicial conciliado'),
(74, 1, 74, 5, 70.000, 8.0000, 560.00, 'Inventario inicial conciliado'),
(75, 1, 75, 1, 200.000, 1.5000, 300.00, 'Inventario inicial conciliado'),
(76, 1, 76, 2, 120.000, 2.2000, 264.00, 'Inventario inicial conciliado'),
(77, 1, 77, 3, 22.000, 25.0000, 550.00, 'Inventario inicial conciliado'),
(78, 1, 78, 4, 18.000, 28.0000, 504.00, 'Inventario inicial conciliado'),
(79, 1, 79, 5, 16.000, 18.0000, 288.00, 'Inventario inicial conciliado'),
(80, 1, 80, 1, 60.000, 8.5000, 510.00, 'Inventario inicial conciliado'),
(81, 1, 81, 2, 28.000, 32.0000, 896.00, 'Inventario inicial conciliado'),
(82, 1, 82, 3, 25.000, 26.0000, 650.00, 'Inventario inicial conciliado'),
(83, 1, 83, 4, 22.000, 18.0000, 396.00, 'Inventario inicial conciliado'),
(84, 1, 84, 5, 45.000, 55.0000, 2475.00, 'Inventario inicial conciliado'),
(85, 1, 85, 1, 28.000, 95.0000, 2660.00, 'Inventario inicial conciliado'),
(86, 1, 86, 2, 80.000, 12.0000, 960.00, 'Inventario inicial conciliado'),
(87, 1, 87, 3, 30.000, 85.0000, 2550.00, 'Inventario inicial conciliado'),
(88, 1, 88, 4, 18.000, 145.0000, 2610.00, 'Inventario inicial conciliado'),
(89, 1, 89, 5, 15.000, 165.0000, 2475.00, 'Inventario inicial conciliado'),
(90, 1, 90, 1, 22.000, 35.0000, 770.00, 'Inventario inicial conciliado'),
(91, 1, 91, 2, 18.000, 28.0000, 504.00, 'Inventario inicial conciliado'),
(92, 1, 92, 3, 30.000, 18.0000, 540.00, 'Inventario inicial conciliado'),
(93, 1, 93, 4, 250.000, 4.5000, 1125.00, 'Inventario inicial conciliado'),
(94, 1, 94, 5, 40.000, 22.0000, 880.00, 'Inventario inicial conciliado'),
(95, 1, 95, 1, 14.000, 65.0000, 910.00, 'Inventario inicial conciliado'),
(96, 1, 96, 2, 35.000, 22.0000, 770.00, 'Inventario inicial conciliado'),
(97, 1, 97, 3, 38.000, 65.0000, 2470.00, 'Inventario inicial conciliado'),
(98, 1, 98, 4, 30.000, 90.0000, 2700.00, 'Inventario inicial conciliado'),
(99, 1, 99, 5, 18.000, 145.0000, 2610.00, 'Inventario inicial conciliado'),
(100, 1, 100, 1, 8.000, 580.0000, 4640.00, 'Inventario inicial conciliado'),
(101, 1, 101, 2, 5.000, 820.0000, 4100.00, 'Inventario inicial conciliado'),
(102, 1, 102, 3, 25.000, 25.0000, 625.00, 'Inventario inicial conciliado'),
(103, 1, 103, 4, 18.000, 42.0000, 756.00, 'Inventario inicial conciliado'),
(104, 1, 104, 5, 60.000, 7.5000, 450.00, 'Inventario inicial conciliado'),
(105, 1, 105, 1, 55.000, 7.5000, 412.50, 'Inventario inicial conciliado'),
(106, 1, 106, 2, 30.000, 11.0000, 330.00, 'Inventario inicial conciliado'),
(107, 1, 107, 3, 22.000, 85.0000, 1870.00, 'Inventario inicial conciliado'),
(108, 1, 108, 4, 12.000, 130.0000, 1560.00, 'Inventario inicial conciliado'),
(109, 1, 109, 5, 4.000, 480.0000, 1920.00, 'Inventario inicial conciliado'),
(110, 1, 110, 1, 5.000, 380.0000, 1900.00, 'Inventario inicial conciliado'),
(111, 1, 111, 2, 25.000, 65.0000, 1625.00, 'Inventario inicial conciliado'),
(112, 1, 112, 3, 3.000, 980.0000, 2940.00, 'Inventario inicial conciliado'),
(113, 1, 113, 4, 2.000, 2400.0000, 4800.00, 'Inventario inicial conciliado'),
(114, 1, 114, 5, 35.000, 38.0000, 1330.00, 'Inventario inicial conciliado'),
(115, 1, 115, 1, 110.000, 2.0000, 220.00, 'Inventario inicial conciliado'),
(116, 1, 116, 2, 65.000, 25.0000, 1625.00, 'Inventario inicial conciliado'),
(117, 1, 117, 3, 120.000, 18.0000, 2160.00, 'Inventario inicial conciliado'),
(118, 1, 118, 4, 85.000, 24.0000, 2040.00, 'Inventario inicial conciliado'),
(119, 1, 119, 5, 60.000, 32.0000, 1920.00, 'Inventario inicial conciliado'),
(120, 1, 120, 1, 45.000, 48.0000, 2160.00, 'Inventario inicial conciliado'),
(121, 1, 121, 2, 12.000, 220.0000, 2640.00, 'Inventario inicial conciliado'),
(122, 1, 122, 3, 18.000, 95.0000, 1710.00, 'Inventario inicial conciliado'),
(123, 1, 123, 4, 30.000, 45.0000, 1350.00, 'Inventario inicial conciliado'),
(124, 1, 124, 5, 6.000, 1150.0000, 6900.00, 'Inventario inicial conciliado'),
(125, 1, 125, 1, 8.000, 580.0000, 4640.00, 'Inventario inicial conciliado'),
(126, 1, 126, 2, 12.000, 95.0000, 1140.00, 'Inventario inicial conciliado'),
(127, 1, 127, 3, 15.000, 85.0000, 1275.00, 'Inventario inicial conciliado'),
(128, 1, 128, 4, 65.000, 9.0000, 585.00, 'Inventario inicial conciliado'),
(129, 1, 129, 5, 48.000, 22.0000, 1056.00, 'Inventario inicial conciliado'),
(130, 1, 130, 1, 42.000, 22.0000, 924.00, 'Inventario inicial conciliado'),
(131, 1, 131, 2, 25.000, 35.0000, 875.00, 'Inventario inicial conciliado'),
(132, 1, 132, 3, 80.000, 2.8000, 224.00, 'Inventario inicial conciliado'),
(133, 1, 133, 4, 65.000, 3.2000, 208.00, 'Inventario inicial conciliado'),
(134, 1, 134, 5, 45.000, 4.5000, 202.50, 'Inventario inicial conciliado'),
(135, 1, 135, 1, 35.000, 5.0000, 175.00, 'Inventario inicial conciliado'),
(136, 1, 136, 2, 50.000, 18.0000, 900.00, 'Inventario inicial conciliado'),
(137, 1, 137, 3, 38.000, 26.0000, 988.00, 'Inventario inicial conciliado'),
(138, 1, 138, 4, 24.000, 42.0000, 1008.00, 'Inventario inicial conciliado'),
(139, 1, 139, 5, 180.000, 1.8000, 324.00, 'Inventario inicial conciliado'),
(140, 1, 140, 1, 90.000, 3.5000, 315.00, 'Inventario inicial conciliado'),
(141, 1, 141, 2, 75.000, 5.0000, 375.00, 'Inventario inicial conciliado'),
(142, 1, 142, 3, 60.000, 7.5000, 450.00, 'Inventario inicial conciliado'),
(143, 1, 143, 4, 70.000, 8.5000, 595.00, 'Inventario inicial conciliado'),
(144, 1, 144, 5, 45.000, 9.0000, 405.00, 'Inventario inicial conciliado'),
(145, 1, 145, 1, 45.000, 9.0000, 405.00, 'Inventario inicial conciliado'),
(146, 1, 146, 2, 35.000, 9.0000, 315.00, 'Inventario inicial conciliado'),
(147, 1, 147, 3, 30.000, 8.0000, 240.00, 'Inventario inicial conciliado'),
(148, 1, 148, 4, 28.000, 8.0000, 224.00, 'Inventario inicial conciliado'),
(149, 1, 149, 5, 55.000, 6.0000, 330.00, 'Inventario inicial conciliado'),
(150, 1, 150, 1, 40.000, 14.0000, 560.00, 'Inventario inicial conciliado'),
(151, 1, 151, 2, 50.000, 4.5000, 225.00, 'Inventario inicial conciliado'),
(152, 1, 152, 3, 35.000, 5.5000, 192.50, 'Inventario inicial conciliado'),
(153, 1, 153, 4, 60.000, 1.5000, 90.00, 'Inventario inicial conciliado'),
(154, 1, 154, 5, 8.000, 45.0000, 360.00, 'Inventario inicial conciliado'),
(155, 1, 155, 1, 12.000, 22.0000, 264.00, 'Inventario inicial conciliado'),
(156, 1, 156, 2, 18.000, 18.0000, 324.00, 'Inventario inicial conciliado'),
(157, 1, 157, 3, 15.000, 95.0000, 1425.00, 'Inventario inicial conciliado'),
(158, 1, 158, 4, 22.000, 78.0000, 1716.00, 'Inventario inicial conciliado'),
(159, 1, 159, 5, 14.000, 55.0000, 770.00, 'Inventario inicial conciliado'),
(160, 1, 160, 1, 10.000, 38.0000, 380.00, 'Inventario inicial conciliado'),
(161, 1, 161, 2, 28.000, 22.0000, 616.00, 'Inventario inicial conciliado'),
(162, 1, 162, 3, 20.000, 28.0000, 560.00, 'Inventario inicial conciliado'),
(163, 1, 163, 4, 25.000, 18.0000, 450.00, 'Inventario inicial conciliado'),
(164, 1, 164, 5, 18.000, 75.0000, 1350.00, 'Inventario inicial conciliado'),
(165, 1, 165, 1, 12.000, 125.0000, 1500.00, 'Inventario inicial conciliado'),
(166, 1, 166, 2, 10.000, 55.0000, 550.00, 'Inventario inicial conciliado'),
(167, 1, 167, 3, 14.000, 78.0000, 1092.00, 'Inventario inicial conciliado'),
(168, 1, 168, 4, 8.000, 180.0000, 1440.00, 'Inventario inicial conciliado'),
(169, 1, 169, 5, 15.000, 85.0000, 1275.00, 'Inventario inicial conciliado'),
(170, 1, 170, 1, 6.000, 380.0000, 2280.00, 'Inventario inicial conciliado'),
(171, 1, 171, 2, 8.000, 95.0000, 760.00, 'Inventario inicial conciliado'),
(172, 1, 172, 3, 10.000, 320.0000, 3200.00, 'Inventario inicial conciliado'),
(173, 1, 173, 4, 18.000, 95.0000, 1710.00, 'Inventario inicial conciliado'),
(174, 1, 174, 5, 12.000, 65.0000, 780.00, 'Inventario inicial conciliado'),
(175, 1, 175, 1, 22.000, 22.0000, 484.00, 'Inventario inicial conciliado'),
(176, 1, 176, 2, 28.000, 45.0000, 1260.00, 'Inventario inicial conciliado'),
(177, 1, 177, 3, 8.000, 165.0000, 1320.00, 'Inventario inicial conciliado'),
(178, 1, 178, 4, 6.000, 78.0000, 468.00, 'Inventario inicial conciliado'),
(179, 1, 179, 5, 14.000, 32.0000, 448.00, 'Inventario inicial conciliado'),
(180, 1, 180, 1, 3.000, 2200.0000, 6600.00, 'Inventario inicial conciliado'),
(181, 1, 181, 2, 2.000, 1850.0000, 3700.00, 'Inventario inicial conciliado');

-- Datos iniciales de stock_layers: se conservan los registros originales.
INSERT INTO `stock_layers` (`id`, `product_id`, `entry_id`, `entry_item_id`, `layer_date`, `sequence`, `original_qty`, `remaining_qty`, `unit_cost`, `status`) VALUES
(1, 1, 1, 1, '2026-08-09 08:00:00', 1, 480.000, 480.000, 32.5000, 'ABIERTA'),
(2, 2, 1, 2, '2026-08-09 08:00:00', 1, 85.000, 85.000, 38.2000, 'ABIERTA'),
(3, 3, 1, 3, '2026-08-09 08:00:00', 1, 60.000, 60.000, 30.8000, 'ABIERTA'),
(4, 4, 1, 4, '2026-08-09 08:00:00', 1, 24.000, 24.000, 95.0000, 'ABIERTA'),
(5, 5, 1, 5, '2026-08-09 08:00:00', 1, 140.000, 140.000, 1.5000, 'ABIERTA'),
(6, 6, 1, 6, '2026-08-09 08:00:00', 1, 15.000, 15.000, 34.0000, 'ABIERTA'),
(7, 7, 1, 7, '2026-08-09 08:00:00', 1, 540.000, 540.000, 2.8000, 'ABIERTA'),
(8, 8, 1, 8, '2026-08-09 08:00:00', 1, 430.000, 430.000, 2.8000, 'ABIERTA'),
(9, 9, 1, 9, '2026-08-09 08:00:00', 1, 320.000, 320.000, 2.8000, 'ABIERTA'),
(10, 10, 1, 10, '2026-08-09 08:00:00', 1, 150.000, 150.000, 2.8000, 'ABIERTA'),
(11, 11, 1, 11, '2026-08-09 08:00:00', 1, 600.000, 600.000, 1.2000, 'ABIERTA'),
(12, 12, 1, 12, '2026-08-09 08:00:00', 1, 120.000, 120.000, 1.5000, 'ABIERTA'),
(13, 13, 1, 13, '2026-08-09 08:00:00', 1, 88.000, 88.000, 5.5000, 'ABIERTA'),
(14, 14, 1, 14, '2026-08-09 08:00:00', 1, 75.000, 75.000, 5.5000, 'ABIERTA'),
(15, 15, 1, 15, '2026-08-09 08:00:00', 1, 60.000, 60.000, 5.5000, 'ABIERTA'),
(16, 16, 1, 16, '2026-08-09 08:00:00', 1, 95.000, 95.000, 6.0000, 'ABIERTA'),
(17, 17, 1, 17, '2026-08-09 08:00:00', 1, 70.000, 70.000, 6.0000, 'ABIERTA'),
(18, 18, 1, 18, '2026-08-09 08:00:00', 1, 55.000, 55.000, 6.0000, 'ABIERTA'),
(19, 19, 1, 19, '2026-08-09 08:00:00', 1, 250.000, 250.000, 4.5000, 'ABIERTA'),
(20, 20, 1, 20, '2026-08-09 08:00:00', 1, 200.000, 200.000, 6.8000, 'ABIERTA'),
(21, 21, 1, 21, '2026-08-09 08:00:00', 1, 95.000, 95.000, 22.0000, 'ABIERTA'),
(22, 22, 1, 22, '2026-08-09 08:00:00', 1, 65.000, 65.000, 28.0000, 'ABIERTA'),
(23, 23, 1, 23, '2026-08-09 08:00:00', 1, 180.000, 180.000, 7.5000, 'ABIERTA'),
(24, 24, 1, 24, '2026-08-09 08:00:00', 1, 540.000, 540.000, 0.9000, 'ABIERTA'),
(25, 25, 1, 25, '2026-08-09 08:00:00', 1, 420.000, 420.000, 1.2000, 'ABIERTA'),
(26, 26, 1, 26, '2026-08-09 08:00:00', 1, 380.000, 380.000, 1.0000, 'ABIERTA'),
(27, 27, 1, 27, '2026-08-09 08:00:00', 1, 150.000, 150.000, 2.5000, 'ABIERTA'),
(28, 28, 1, 28, '2026-08-09 08:00:00', 1, 220.000, 220.000, 1.1000, 'ABIERTA'),
(29, 29, 1, 29, '2026-08-09 08:00:00', 1, 85.000, 85.000, 7.5000, 'ABIERTA'),
(30, 30, 1, 30, '2026-08-09 08:00:00', 1, 60.000, 60.000, 9.0000, 'ABIERTA'),
(31, 31, 1, 31, '2026-08-09 08:00:00', 1, 120.000, 120.000, 4.5000, 'ABIERTA'),
(32, 32, 1, 32, '2026-08-09 08:00:00', 1, 40.000, 40.000, 5.0000, 'ABIERTA'),
(33, 33, 1, 33, '2026-08-09 08:00:00', 1, 150.000, 150.000, 5.0000, 'ABIERTA'),
(34, 34, 1, 34, '2026-08-09 08:00:00', 1, 70.000, 70.000, 9.5000, 'ABIERTA'),
(35, 35, 1, 35, '2026-08-09 08:00:00', 1, 45.000, 45.000, 16.0000, 'ABIERTA'),
(36, 36, 1, 36, '2026-08-09 08:00:00', 1, 130.000, 130.000, 6.0000, 'ABIERTA'),
(37, 37, 1, 37, '2026-08-09 08:00:00', 1, 35.000, 35.000, 12.0000, 'ABIERTA'),
(38, 38, 1, 38, '2026-08-09 08:00:00', 1, 18.000, 18.000, 28.0000, 'ABIERTA'),
(39, 39, 1, 39, '2026-08-09 08:00:00', 1, 220.000, 220.000, 1.0000, 'ABIERTA'),
(40, 40, 1, 40, '2026-08-09 08:00:00', 1, 60.000, 60.000, 2.5000, 'ABIERTA'),
(41, 41, 1, 41, '2026-08-09 08:00:00', 1, 90.000, 90.000, 18.0000, 'ABIERTA'),
(42, 42, 1, 42, '2026-08-09 08:00:00', 1, 75.000, 75.000, 9.5000, 'ABIERTA'),
(43, 43, 1, 43, '2026-08-09 08:00:00', 1, 55.000, 55.000, 11.0000, 'ABIERTA'),
(44, 44, 1, 44, '2026-08-09 08:00:00', 1, 30.000, 30.000, 3.5000, 'ABIERTA'),
(45, 45, 1, 45, '2026-08-09 08:00:00', 1, 22.000, 22.000, 65.0000, 'ABIERTA'),
(46, 46, 1, 46, '2026-08-09 08:00:00', 1, 28.000, 28.000, 38.0000, 'ABIERTA'),
(47, 47, 1, 47, '2026-08-09 08:00:00', 1, 25.000, 25.000, 45.0000, 'ABIERTA'),
(48, 48, 1, 48, '2026-08-09 08:00:00', 1, 50.000, 50.000, 22.0000, 'ABIERTA'),
(49, 49, 1, 49, '2026-08-09 08:00:00', 1, 38.000, 38.000, 95.0000, 'ABIERTA'),
(50, 50, 1, 50, '2026-08-09 08:00:00', 1, 30.000, 30.000, 110.0000, 'ABIERTA'),
(51, 51, 1, 51, '2026-08-09 08:00:00', 1, 22.000, 22.000, 75.0000, 'ABIERTA'),
(52, 52, 1, 52, '2026-08-09 08:00:00', 1, 18.000, 18.000, 75.0000, 'ABIERTA'),
(53, 53, 1, 53, '2026-08-09 08:00:00', 1, 18.000, 18.000, 75.0000, 'ABIERTA'),
(54, 54, 1, 54, '2026-08-09 08:00:00', 1, 18.000, 18.000, 75.0000, 'ABIERTA'),
(55, 55, 1, 55, '2026-08-09 08:00:00', 1, 25.000, 25.000, 88.0000, 'ABIERTA'),
(56, 56, 1, 56, '2026-08-09 08:00:00', 1, 20.000, 20.000, 125.0000, 'ABIERTA'),
(57, 57, 1, 57, '2026-08-09 08:00:00', 1, 14.000, 14.000, 280.0000, 'ABIERTA'),
(58, 58, 1, 58, '2026-08-09 08:00:00', 1, 12.000, 12.000, 310.0000, 'ABIERTA'),
(59, 59, 1, 59, '2026-08-09 08:00:00', 1, 8.000, 8.000, 360.0000, 'ABIERTA'),
(60, 60, 1, 60, '2026-08-09 08:00:00', 1, 10.000, 10.000, 290.0000, 'ABIERTA'),
(61, 61, 1, 61, '2026-08-09 08:00:00', 1, 6.000, 6.000, 320.0000, 'ABIERTA'),
(62, 62, 1, 62, '2026-08-09 08:00:00', 1, 5.000, 5.000, 410.0000, 'ABIERTA'),
(63, 63, 1, 63, '2026-08-09 08:00:00', 1, 4.000, 4.000, 480.0000, 'ABIERTA'),
(64, 64, 1, 64, '2026-08-09 08:00:00', 1, 240.000, 240.000, 18.0000, 'ABIERTA'),
(65, 65, 1, 65, '2026-08-09 08:00:00', 1, 95.000, 95.000, 22.0000, 'ABIERTA'),
(66, 66, 1, 66, '2026-08-09 08:00:00', 1, 40.000, 40.000, 12.0000, 'ABIERTA'),
(67, 67, 1, 67, '2026-08-09 08:00:00', 1, 35.000, 35.000, 22.0000, 'ABIERTA'),
(68, 68, 1, 68, '2026-08-09 08:00:00', 1, 30.000, 30.000, 28.0000, 'ABIERTA'),
(69, 69, 1, 69, '2026-08-09 08:00:00', 1, 50.000, 50.000, 25.0000, 'ABIERTA'),
(70, 70, 1, 70, '2026-08-09 08:00:00', 1, 60.000, 60.000, 14.0000, 'ABIERTA'),
(71, 71, 1, 71, '2026-08-09 08:00:00', 1, 40.000, 40.000, 38.0000, 'ABIERTA'),
(72, 72, 1, 72, '2026-08-09 08:00:00', 1, 35.000, 35.000, 42.0000, 'ABIERTA'),
(73, 73, 1, 73, '2026-08-09 08:00:00', 1, 180.000, 180.000, 2.5000, 'ABIERTA'),
(74, 74, 1, 74, '2026-08-09 08:00:00', 1, 70.000, 70.000, 8.0000, 'ABIERTA'),
(75, 75, 1, 75, '2026-08-09 08:00:00', 1, 200.000, 200.000, 1.5000, 'ABIERTA'),
(76, 76, 1, 76, '2026-08-09 08:00:00', 1, 120.000, 120.000, 2.2000, 'ABIERTA'),
(77, 77, 1, 77, '2026-08-09 08:00:00', 1, 22.000, 22.000, 25.0000, 'ABIERTA'),
(78, 78, 1, 78, '2026-08-09 08:00:00', 1, 18.000, 18.000, 28.0000, 'ABIERTA'),
(79, 79, 1, 79, '2026-08-09 08:00:00', 1, 16.000, 16.000, 18.0000, 'ABIERTA'),
(80, 80, 1, 80, '2026-08-09 08:00:00', 1, 60.000, 60.000, 8.5000, 'ABIERTA'),
(81, 81, 1, 81, '2026-08-09 08:00:00', 1, 28.000, 28.000, 32.0000, 'ABIERTA'),
(82, 82, 1, 82, '2026-08-09 08:00:00', 1, 25.000, 25.000, 26.0000, 'ABIERTA'),
(83, 83, 1, 83, '2026-08-09 08:00:00', 1, 22.000, 22.000, 18.0000, 'ABIERTA'),
(84, 84, 1, 84, '2026-08-09 08:00:00', 1, 45.000, 45.000, 55.0000, 'ABIERTA'),
(85, 85, 1, 85, '2026-08-09 08:00:00', 1, 28.000, 28.000, 95.0000, 'ABIERTA'),
(86, 86, 1, 86, '2026-08-09 08:00:00', 1, 80.000, 80.000, 12.0000, 'ABIERTA'),
(87, 87, 1, 87, '2026-08-09 08:00:00', 1, 30.000, 30.000, 85.0000, 'ABIERTA'),
(88, 88, 1, 88, '2026-08-09 08:00:00', 1, 18.000, 18.000, 145.0000, 'ABIERTA'),
(89, 89, 1, 89, '2026-08-09 08:00:00', 1, 15.000, 15.000, 165.0000, 'ABIERTA'),
(90, 90, 1, 90, '2026-08-09 08:00:00', 1, 22.000, 22.000, 35.0000, 'ABIERTA'),
(91, 91, 1, 91, '2026-08-09 08:00:00', 1, 18.000, 18.000, 28.0000, 'ABIERTA'),
(92, 92, 1, 92, '2026-08-09 08:00:00', 1, 30.000, 30.000, 18.0000, 'ABIERTA'),
(93, 93, 1, 93, '2026-08-09 08:00:00', 1, 250.000, 250.000, 4.5000, 'ABIERTA'),
(94, 94, 1, 94, '2026-08-09 08:00:00', 1, 40.000, 40.000, 22.0000, 'ABIERTA'),
(95, 95, 1, 95, '2026-08-09 08:00:00', 1, 14.000, 14.000, 65.0000, 'ABIERTA'),
(96, 96, 1, 96, '2026-08-09 08:00:00', 1, 35.000, 35.000, 22.0000, 'ABIERTA'),
(97, 97, 1, 97, '2026-08-09 08:00:00', 1, 38.000, 38.000, 65.0000, 'ABIERTA'),
(98, 98, 1, 98, '2026-08-09 08:00:00', 1, 30.000, 30.000, 90.0000, 'ABIERTA'),
(99, 99, 1, 99, '2026-08-09 08:00:00', 1, 18.000, 18.000, 145.0000, 'ABIERTA'),
(100, 100, 1, 100, '2026-08-09 08:00:00', 1, 8.000, 8.000, 580.0000, 'ABIERTA'),
(101, 101, 1, 101, '2026-08-09 08:00:00', 1, 5.000, 5.000, 820.0000, 'ABIERTA'),
(102, 102, 1, 102, '2026-08-09 08:00:00', 1, 25.000, 25.000, 25.0000, 'ABIERTA'),
(103, 103, 1, 103, '2026-08-09 08:00:00', 1, 18.000, 18.000, 42.0000, 'ABIERTA'),
(104, 104, 1, 104, '2026-08-09 08:00:00', 1, 60.000, 60.000, 7.5000, 'ABIERTA'),
(105, 105, 1, 105, '2026-08-09 08:00:00', 1, 55.000, 55.000, 7.5000, 'ABIERTA'),
(106, 106, 1, 106, '2026-08-09 08:00:00', 1, 30.000, 30.000, 11.0000, 'ABIERTA'),
(107, 107, 1, 107, '2026-08-09 08:00:00', 1, 22.000, 22.000, 85.0000, 'ABIERTA'),
(108, 108, 1, 108, '2026-08-09 08:00:00', 1, 12.000, 12.000, 130.0000, 'ABIERTA'),
(109, 109, 1, 109, '2026-08-09 08:00:00', 1, 4.000, 4.000, 480.0000, 'ABIERTA'),
(110, 110, 1, 110, '2026-08-09 08:00:00', 1, 5.000, 5.000, 380.0000, 'ABIERTA'),
(111, 111, 1, 111, '2026-08-09 08:00:00', 1, 25.000, 25.000, 65.0000, 'ABIERTA'),
(112, 112, 1, 112, '2026-08-09 08:00:00', 1, 3.000, 3.000, 980.0000, 'ABIERTA'),
(113, 113, 1, 113, '2026-08-09 08:00:00', 1, 2.000, 2.000, 2400.0000, 'ABIERTA'),
(114, 114, 1, 114, '2026-08-09 08:00:00', 1, 35.000, 35.000, 38.0000, 'ABIERTA'),
(115, 115, 1, 115, '2026-08-09 08:00:00', 1, 110.000, 110.000, 2.0000, 'ABIERTA'),
(116, 116, 1, 116, '2026-08-09 08:00:00', 1, 65.000, 65.000, 25.0000, 'ABIERTA'),
(117, 117, 1, 117, '2026-08-09 08:00:00', 1, 120.000, 120.000, 18.0000, 'ABIERTA'),
(118, 118, 1, 118, '2026-08-09 08:00:00', 1, 85.000, 85.000, 24.0000, 'ABIERTA'),
(119, 119, 1, 119, '2026-08-09 08:00:00', 1, 60.000, 60.000, 32.0000, 'ABIERTA'),
(120, 120, 1, 120, '2026-08-09 08:00:00', 1, 45.000, 45.000, 48.0000, 'ABIERTA'),
(121, 121, 1, 121, '2026-08-09 08:00:00', 1, 12.000, 12.000, 220.0000, 'ABIERTA'),
(122, 122, 1, 122, '2026-08-09 08:00:00', 1, 18.000, 18.000, 95.0000, 'ABIERTA'),
(123, 123, 1, 123, '2026-08-09 08:00:00', 1, 30.000, 30.000, 45.0000, 'ABIERTA'),
(124, 124, 1, 124, '2026-08-09 08:00:00', 1, 6.000, 6.000, 1150.0000, 'ABIERTA'),
(125, 125, 1, 125, '2026-08-09 08:00:00', 1, 8.000, 8.000, 580.0000, 'ABIERTA'),
(126, 126, 1, 126, '2026-08-09 08:00:00', 1, 12.000, 12.000, 95.0000, 'ABIERTA'),
(127, 127, 1, 127, '2026-08-09 08:00:00', 1, 15.000, 15.000, 85.0000, 'ABIERTA'),
(128, 128, 1, 128, '2026-08-09 08:00:00', 1, 65.000, 65.000, 9.0000, 'ABIERTA'),
(129, 129, 1, 129, '2026-08-09 08:00:00', 1, 48.000, 48.000, 22.0000, 'ABIERTA'),
(130, 130, 1, 130, '2026-08-09 08:00:00', 1, 42.000, 42.000, 22.0000, 'ABIERTA'),
(131, 131, 1, 131, '2026-08-09 08:00:00', 1, 25.000, 25.000, 35.0000, 'ABIERTA'),
(132, 132, 1, 132, '2026-08-09 08:00:00', 1, 80.000, 80.000, 2.8000, 'ABIERTA'),
(133, 133, 1, 133, '2026-08-09 08:00:00', 1, 65.000, 65.000, 3.2000, 'ABIERTA'),
(134, 134, 1, 134, '2026-08-09 08:00:00', 1, 45.000, 45.000, 4.5000, 'ABIERTA'),
(135, 135, 1, 135, '2026-08-09 08:00:00', 1, 35.000, 35.000, 5.0000, 'ABIERTA'),
(136, 136, 1, 136, '2026-08-09 08:00:00', 1, 50.000, 50.000, 18.0000, 'ABIERTA'),
(137, 137, 1, 137, '2026-08-09 08:00:00', 1, 38.000, 38.000, 26.0000, 'ABIERTA'),
(138, 138, 1, 138, '2026-08-09 08:00:00', 1, 24.000, 24.000, 42.0000, 'ABIERTA'),
(139, 139, 1, 139, '2026-08-09 08:00:00', 1, 180.000, 180.000, 1.8000, 'ABIERTA'),
(140, 140, 1, 140, '2026-08-09 08:00:00', 1, 90.000, 90.000, 3.5000, 'ABIERTA'),
(141, 141, 1, 141, '2026-08-09 08:00:00', 1, 75.000, 75.000, 5.0000, 'ABIERTA'),
(142, 142, 1, 142, '2026-08-09 08:00:00', 1, 60.000, 60.000, 7.5000, 'ABIERTA'),
(143, 143, 1, 143, '2026-08-09 08:00:00', 1, 70.000, 70.000, 8.5000, 'ABIERTA'),
(144, 144, 1, 144, '2026-08-09 08:00:00', 1, 45.000, 45.000, 9.0000, 'ABIERTA'),
(145, 145, 1, 145, '2026-08-09 08:00:00', 1, 45.000, 45.000, 9.0000, 'ABIERTA'),
(146, 146, 1, 146, '2026-08-09 08:00:00', 1, 35.000, 35.000, 9.0000, 'ABIERTA'),
(147, 147, 1, 147, '2026-08-09 08:00:00', 1, 30.000, 30.000, 8.0000, 'ABIERTA'),
(148, 148, 1, 148, '2026-08-09 08:00:00', 1, 28.000, 28.000, 8.0000, 'ABIERTA'),
(149, 149, 1, 149, '2026-08-09 08:00:00', 1, 55.000, 55.000, 6.0000, 'ABIERTA'),
(150, 150, 1, 150, '2026-08-09 08:00:00', 1, 40.000, 40.000, 14.0000, 'ABIERTA'),
(151, 151, 1, 151, '2026-08-09 08:00:00', 1, 50.000, 50.000, 4.5000, 'ABIERTA'),
(152, 152, 1, 152, '2026-08-09 08:00:00', 1, 35.000, 35.000, 5.5000, 'ABIERTA'),
(153, 153, 1, 153, '2026-08-09 08:00:00', 1, 60.000, 60.000, 1.5000, 'ABIERTA'),
(154, 154, 1, 154, '2026-08-09 08:00:00', 1, 8.000, 8.000, 45.0000, 'ABIERTA'),
(155, 155, 1, 155, '2026-08-09 08:00:00', 1, 12.000, 12.000, 22.0000, 'ABIERTA'),
(156, 156, 1, 156, '2026-08-09 08:00:00', 1, 18.000, 18.000, 18.0000, 'ABIERTA'),
(157, 157, 1, 157, '2026-08-09 08:00:00', 1, 15.000, 15.000, 95.0000, 'ABIERTA'),
(158, 158, 1, 158, '2026-08-09 08:00:00', 1, 22.000, 22.000, 78.0000, 'ABIERTA'),
(159, 159, 1, 159, '2026-08-09 08:00:00', 1, 14.000, 14.000, 55.0000, 'ABIERTA'),
(160, 160, 1, 160, '2026-08-09 08:00:00', 1, 10.000, 10.000, 38.0000, 'ABIERTA'),
(161, 161, 1, 161, '2026-08-09 08:00:00', 1, 28.000, 28.000, 22.0000, 'ABIERTA'),
(162, 162, 1, 162, '2026-08-09 08:00:00', 1, 20.000, 20.000, 28.0000, 'ABIERTA'),
(163, 163, 1, 163, '2026-08-09 08:00:00', 1, 25.000, 25.000, 18.0000, 'ABIERTA'),
(164, 164, 1, 164, '2026-08-09 08:00:00', 1, 18.000, 18.000, 75.0000, 'ABIERTA'),
(165, 165, 1, 165, '2026-08-09 08:00:00', 1, 12.000, 12.000, 125.0000, 'ABIERTA'),
(166, 166, 1, 166, '2026-08-09 08:00:00', 1, 10.000, 10.000, 55.0000, 'ABIERTA'),
(167, 167, 1, 167, '2026-08-09 08:00:00', 1, 14.000, 14.000, 78.0000, 'ABIERTA'),
(168, 168, 1, 168, '2026-08-09 08:00:00', 1, 8.000, 8.000, 180.0000, 'ABIERTA'),
(169, 169, 1, 169, '2026-08-09 08:00:00', 1, 15.000, 15.000, 85.0000, 'ABIERTA'),
(170, 170, 1, 170, '2026-08-09 08:00:00', 1, 6.000, 6.000, 380.0000, 'ABIERTA'),
(171, 171, 1, 171, '2026-08-09 08:00:00', 1, 8.000, 8.000, 95.0000, 'ABIERTA'),
(172, 172, 1, 172, '2026-08-09 08:00:00', 1, 10.000, 10.000, 320.0000, 'ABIERTA'),
(173, 173, 1, 173, '2026-08-09 08:00:00', 1, 18.000, 18.000, 95.0000, 'ABIERTA'),
(174, 174, 1, 174, '2026-08-09 08:00:00', 1, 12.000, 12.000, 65.0000, 'ABIERTA'),
(175, 175, 1, 175, '2026-08-09 08:00:00', 1, 22.000, 22.000, 22.0000, 'ABIERTA'),
(176, 176, 1, 176, '2026-08-09 08:00:00', 1, 28.000, 28.000, 45.0000, 'ABIERTA'),
(177, 177, 1, 177, '2026-08-09 08:00:00', 1, 8.000, 8.000, 165.0000, 'ABIERTA'),
(178, 178, 1, 178, '2026-08-09 08:00:00', 1, 6.000, 6.000, 78.0000, 'ABIERTA'),
(179, 179, 1, 179, '2026-08-09 08:00:00', 1, 14.000, 14.000, 32.0000, 'ABIERTA'),
(180, 180, 1, 180, '2026-08-09 08:00:00', 1, 3.000, 3.000, 2200.0000, 'ABIERTA'),
(181, 181, 1, 181, '2026-08-09 08:00:00', 1, 2.000, 2.000, 1850.0000, 'ABIERTA');

-- Datos iniciales de kardex_movements: se conservan los registros originales.
INSERT INTO `kardex_movements` (`id`, `product_id`, `movement_date`, `doc_type`, `doc_id`, `reference`, `qty_in`, `qty_out`, `unit_cost_in`, `unit_cost_out`, `total_in`, `total_out`, `balance_qty`, `balance_value`, `balance_unit_cost`) VALUES
(1, 1, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 480.000, 0.000, 32.5000, 0.0000, 15600.00, 0.00, 480.000, 15600.00, 32.5000),
(2, 2, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 85.000, 0.000, 38.2000, 0.0000, 3247.00, 0.00, 85.000, 3247.00, 38.2000),
(3, 3, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.000, 0.000, 30.8000, 0.0000, 1848.00, 0.00, 60.000, 1848.00, 30.8000),
(4, 4, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 24.000, 0.000, 95.0000, 0.0000, 2280.00, 0.00, 24.000, 2280.00, 95.0000),
(5, 5, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 140.000, 0.000, 1.5000, 0.0000, 210.00, 0.00, 140.000, 210.00, 1.5000),
(6, 6, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 15.000, 0.000, 34.0000, 0.0000, 510.00, 0.00, 15.000, 510.00, 34.0000),
(7, 7, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 540.000, 0.000, 2.8000, 0.0000, 1512.00, 0.00, 540.000, 1512.00, 2.8000),
(8, 8, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 430.000, 0.000, 2.8000, 0.0000, 1204.00, 0.00, 430.000, 1204.00, 2.8000),
(9, 9, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 320.000, 0.000, 2.8000, 0.0000, 896.00, 0.00, 320.000, 896.00, 2.8000),
(10, 10, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 150.000, 0.000, 2.8000, 0.0000, 420.00, 0.00, 150.000, 420.00, 2.8000),
(11, 11, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 600.000, 0.000, 1.2000, 0.0000, 720.00, 0.00, 600.000, 720.00, 1.2000),
(12, 12, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 120.000, 0.000, 1.5000, 0.0000, 180.00, 0.00, 120.000, 180.00, 1.5000),
(13, 13, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 88.000, 0.000, 5.5000, 0.0000, 484.00, 0.00, 88.000, 484.00, 5.5000),
(14, 14, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 75.000, 0.000, 5.5000, 0.0000, 412.50, 0.00, 75.000, 412.50, 5.5000),
(15, 15, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.000, 0.000, 5.5000, 0.0000, 330.00, 0.00, 60.000, 330.00, 5.5000),
(16, 16, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 95.000, 0.000, 6.0000, 0.0000, 570.00, 0.00, 95.000, 570.00, 6.0000),
(17, 17, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 70.000, 0.000, 6.0000, 0.0000, 420.00, 0.00, 70.000, 420.00, 6.0000),
(18, 18, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 55.000, 0.000, 6.0000, 0.0000, 330.00, 0.00, 55.000, 330.00, 6.0000),
(19, 19, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 250.000, 0.000, 4.5000, 0.0000, 1125.00, 0.00, 250.000, 1125.00, 4.5000),
(20, 20, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 200.000, 0.000, 6.8000, 0.0000, 1360.00, 0.00, 200.000, 1360.00, 6.8000),
(21, 21, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 95.000, 0.000, 22.0000, 0.0000, 2090.00, 0.00, 95.000, 2090.00, 22.0000),
(22, 22, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 65.000, 0.000, 28.0000, 0.0000, 1820.00, 0.00, 65.000, 1820.00, 28.0000),
(23, 23, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 180.000, 0.000, 7.5000, 0.0000, 1350.00, 0.00, 180.000, 1350.00, 7.5000),
(24, 24, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 540.000, 0.000, 0.9000, 0.0000, 486.00, 0.00, 540.000, 486.00, 0.9000),
(25, 25, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 420.000, 0.000, 1.2000, 0.0000, 504.00, 0.00, 420.000, 504.00, 1.2000),
(26, 26, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 380.000, 0.000, 1.0000, 0.0000, 380.00, 0.00, 380.000, 380.00, 1.0000),
(27, 27, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 150.000, 0.000, 2.5000, 0.0000, 375.00, 0.00, 150.000, 375.00, 2.5000),
(28, 28, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 220.000, 0.000, 1.1000, 0.0000, 242.00, 0.00, 220.000, 242.00, 1.1000),
(29, 29, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 85.000, 0.000, 7.5000, 0.0000, 637.50, 0.00, 85.000, 637.50, 7.5000),
(30, 30, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.000, 0.000, 9.0000, 0.0000, 540.00, 0.00, 60.000, 540.00, 9.0000),
(31, 31, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 120.000, 0.000, 4.5000, 0.0000, 540.00, 0.00, 120.000, 540.00, 4.5000),
(32, 32, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 40.000, 0.000, 5.0000, 0.0000, 200.00, 0.00, 40.000, 200.00, 5.0000),
(33, 33, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 150.000, 0.000, 5.0000, 0.0000, 750.00, 0.00, 150.000, 750.00, 5.0000),
(34, 34, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 70.000, 0.000, 9.5000, 0.0000, 665.00, 0.00, 70.000, 665.00, 9.5000),
(35, 35, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 45.000, 0.000, 16.0000, 0.0000, 720.00, 0.00, 45.000, 720.00, 16.0000),
(36, 36, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 130.000, 0.000, 6.0000, 0.0000, 780.00, 0.00, 130.000, 780.00, 6.0000),
(37, 37, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 35.000, 0.000, 12.0000, 0.0000, 420.00, 0.00, 35.000, 420.00, 12.0000),
(38, 38, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.000, 0.000, 28.0000, 0.0000, 504.00, 0.00, 18.000, 504.00, 28.0000),
(39, 39, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 220.000, 0.000, 1.0000, 0.0000, 220.00, 0.00, 220.000, 220.00, 1.0000),
(40, 40, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.000, 0.000, 2.5000, 0.0000, 150.00, 0.00, 60.000, 150.00, 2.5000),
(41, 41, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 90.000, 0.000, 18.0000, 0.0000, 1620.00, 0.00, 90.000, 1620.00, 18.0000),
(42, 42, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 75.000, 0.000, 9.5000, 0.0000, 712.50, 0.00, 75.000, 712.50, 9.5000),
(43, 43, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 55.000, 0.000, 11.0000, 0.0000, 605.00, 0.00, 55.000, 605.00, 11.0000),
(44, 44, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.000, 0.000, 3.5000, 0.0000, 105.00, 0.00, 30.000, 105.00, 3.5000),
(45, 45, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 22.000, 0.000, 65.0000, 0.0000, 1430.00, 0.00, 22.000, 1430.00, 65.0000),
(46, 46, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 28.000, 0.000, 38.0000, 0.0000, 1064.00, 0.00, 28.000, 1064.00, 38.0000),
(47, 47, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 25.000, 0.000, 45.0000, 0.0000, 1125.00, 0.00, 25.000, 1125.00, 45.0000),
(48, 48, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 50.000, 0.000, 22.0000, 0.0000, 1100.00, 0.00, 50.000, 1100.00, 22.0000),
(49, 49, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 38.000, 0.000, 95.0000, 0.0000, 3610.00, 0.00, 38.000, 3610.00, 95.0000),
(50, 50, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.000, 0.000, 110.0000, 0.0000, 3300.00, 0.00, 30.000, 3300.00, 110.0000),
(51, 51, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 22.000, 0.000, 75.0000, 0.0000, 1650.00, 0.00, 22.000, 1650.00, 75.0000),
(52, 52, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.000, 0.000, 75.0000, 0.0000, 1350.00, 0.00, 18.000, 1350.00, 75.0000),
(53, 53, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.000, 0.000, 75.0000, 0.0000, 1350.00, 0.00, 18.000, 1350.00, 75.0000),
(54, 54, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.000, 0.000, 75.0000, 0.0000, 1350.00, 0.00, 18.000, 1350.00, 75.0000),
(55, 55, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 25.000, 0.000, 88.0000, 0.0000, 2200.00, 0.00, 25.000, 2200.00, 88.0000),
(56, 56, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 20.000, 0.000, 125.0000, 0.0000, 2500.00, 0.00, 20.000, 2500.00, 125.0000),
(57, 57, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 14.000, 0.000, 280.0000, 0.0000, 3920.00, 0.00, 14.000, 3920.00, 280.0000),
(58, 58, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 12.000, 0.000, 310.0000, 0.0000, 3720.00, 0.00, 12.000, 3720.00, 310.0000),
(59, 59, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 8.000, 0.000, 360.0000, 0.0000, 2880.00, 0.00, 8.000, 2880.00, 360.0000),
(60, 60, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 10.000, 0.000, 290.0000, 0.0000, 2900.00, 0.00, 10.000, 2900.00, 290.0000),
(61, 61, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 6.000, 0.000, 320.0000, 0.0000, 1920.00, 0.00, 6.000, 1920.00, 320.0000),
(62, 62, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 5.000, 0.000, 410.0000, 0.0000, 2050.00, 0.00, 5.000, 2050.00, 410.0000),
(63, 63, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 4.000, 0.000, 480.0000, 0.0000, 1920.00, 0.00, 4.000, 1920.00, 480.0000),
(64, 64, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 240.000, 0.000, 18.0000, 0.0000, 4320.00, 0.00, 240.000, 4320.00, 18.0000),
(65, 65, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 95.000, 0.000, 22.0000, 0.0000, 2090.00, 0.00, 95.000, 2090.00, 22.0000),
(66, 66, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 40.000, 0.000, 12.0000, 0.0000, 480.00, 0.00, 40.000, 480.00, 12.0000),
(67, 67, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 35.000, 0.000, 22.0000, 0.0000, 770.00, 0.00, 35.000, 770.00, 22.0000),
(68, 68, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.000, 0.000, 28.0000, 0.0000, 840.00, 0.00, 30.000, 840.00, 28.0000),
(69, 69, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 50.000, 0.000, 25.0000, 0.0000, 1250.00, 0.00, 50.000, 1250.00, 25.0000),
(70, 70, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.000, 0.000, 14.0000, 0.0000, 840.00, 0.00, 60.000, 840.00, 14.0000),
(71, 71, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 40.000, 0.000, 38.0000, 0.0000, 1520.00, 0.00, 40.000, 1520.00, 38.0000),
(72, 72, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 35.000, 0.000, 42.0000, 0.0000, 1470.00, 0.00, 35.000, 1470.00, 42.0000),
(73, 73, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 180.000, 0.000, 2.5000, 0.0000, 450.00, 0.00, 180.000, 450.00, 2.5000),
(74, 74, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 70.000, 0.000, 8.0000, 0.0000, 560.00, 0.00, 70.000, 560.00, 8.0000),
(75, 75, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 200.000, 0.000, 1.5000, 0.0000, 300.00, 0.00, 200.000, 300.00, 1.5000),
(76, 76, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 120.000, 0.000, 2.2000, 0.0000, 264.00, 0.00, 120.000, 264.00, 2.2000),
(77, 77, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 22.000, 0.000, 25.0000, 0.0000, 550.00, 0.00, 22.000, 550.00, 25.0000),
(78, 78, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.000, 0.000, 28.0000, 0.0000, 504.00, 0.00, 18.000, 504.00, 28.0000),
(79, 79, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 16.000, 0.000, 18.0000, 0.0000, 288.00, 0.00, 16.000, 288.00, 18.0000),
(80, 80, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.000, 0.000, 8.5000, 0.0000, 510.00, 0.00, 60.000, 510.00, 8.5000),
(81, 81, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 28.000, 0.000, 32.0000, 0.0000, 896.00, 0.00, 28.000, 896.00, 32.0000),
(82, 82, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 25.000, 0.000, 26.0000, 0.0000, 650.00, 0.00, 25.000, 650.00, 26.0000),
(83, 83, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 22.000, 0.000, 18.0000, 0.0000, 396.00, 0.00, 22.000, 396.00, 18.0000),
(84, 84, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 45.000, 0.000, 55.0000, 0.0000, 2475.00, 0.00, 45.000, 2475.00, 55.0000),
(85, 85, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 28.000, 0.000, 95.0000, 0.0000, 2660.00, 0.00, 28.000, 2660.00, 95.0000),
(86, 86, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 80.000, 0.000, 12.0000, 0.0000, 960.00, 0.00, 80.000, 960.00, 12.0000),
(87, 87, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.000, 0.000, 85.0000, 0.0000, 2550.00, 0.00, 30.000, 2550.00, 85.0000),
(88, 88, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.000, 0.000, 145.0000, 0.0000, 2610.00, 0.00, 18.000, 2610.00, 145.0000),
(89, 89, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 15.000, 0.000, 165.0000, 0.0000, 2475.00, 0.00, 15.000, 2475.00, 165.0000),
(90, 90, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 22.000, 0.000, 35.0000, 0.0000, 770.00, 0.00, 22.000, 770.00, 35.0000),
(91, 91, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.000, 0.000, 28.0000, 0.0000, 504.00, 0.00, 18.000, 504.00, 28.0000),
(92, 92, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.000, 0.000, 18.0000, 0.0000, 540.00, 0.00, 30.000, 540.00, 18.0000),
(93, 93, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 250.000, 0.000, 4.5000, 0.0000, 1125.00, 0.00, 250.000, 1125.00, 4.5000),
(94, 94, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 40.000, 0.000, 22.0000, 0.0000, 880.00, 0.00, 40.000, 880.00, 22.0000),
(95, 95, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 14.000, 0.000, 65.0000, 0.0000, 910.00, 0.00, 14.000, 910.00, 65.0000),
(96, 96, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 35.000, 0.000, 22.0000, 0.0000, 770.00, 0.00, 35.000, 770.00, 22.0000),
(97, 97, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 38.000, 0.000, 65.0000, 0.0000, 2470.00, 0.00, 38.000, 2470.00, 65.0000),
(98, 98, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.000, 0.000, 90.0000, 0.0000, 2700.00, 0.00, 30.000, 2700.00, 90.0000),
(99, 99, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.000, 0.000, 145.0000, 0.0000, 2610.00, 0.00, 18.000, 2610.00, 145.0000),
(100, 100, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 8.000, 0.000, 580.0000, 0.0000, 4640.00, 0.00, 8.000, 4640.00, 580.0000),
(101, 101, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 5.000, 0.000, 820.0000, 0.0000, 4100.00, 0.00, 5.000, 4100.00, 820.0000),
(102, 102, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 25.000, 0.000, 25.0000, 0.0000, 625.00, 0.00, 25.000, 625.00, 25.0000),
(103, 103, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.000, 0.000, 42.0000, 0.0000, 756.00, 0.00, 18.000, 756.00, 42.0000),
(104, 104, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.000, 0.000, 7.5000, 0.0000, 450.00, 0.00, 60.000, 450.00, 7.5000),
(105, 105, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 55.000, 0.000, 7.5000, 0.0000, 412.50, 0.00, 55.000, 412.50, 7.5000),
(106, 106, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.000, 0.000, 11.0000, 0.0000, 330.00, 0.00, 30.000, 330.00, 11.0000),
(107, 107, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 22.000, 0.000, 85.0000, 0.0000, 1870.00, 0.00, 22.000, 1870.00, 85.0000),
(108, 108, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 12.000, 0.000, 130.0000, 0.0000, 1560.00, 0.00, 12.000, 1560.00, 130.0000),
(109, 109, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 4.000, 0.000, 480.0000, 0.0000, 1920.00, 0.00, 4.000, 1920.00, 480.0000),
(110, 110, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 5.000, 0.000, 380.0000, 0.0000, 1900.00, 0.00, 5.000, 1900.00, 380.0000),
(111, 111, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 25.000, 0.000, 65.0000, 0.0000, 1625.00, 0.00, 25.000, 1625.00, 65.0000),
(112, 112, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 3.000, 0.000, 980.0000, 0.0000, 2940.00, 0.00, 3.000, 2940.00, 980.0000),
(113, 113, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 2.000, 0.000, 2400.0000, 0.0000, 4800.00, 0.00, 2.000, 4800.00, 2400.0000),
(114, 114, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 35.000, 0.000, 38.0000, 0.0000, 1330.00, 0.00, 35.000, 1330.00, 38.0000),
(115, 115, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 110.000, 0.000, 2.0000, 0.0000, 220.00, 0.00, 110.000, 220.00, 2.0000),
(116, 116, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 65.000, 0.000, 25.0000, 0.0000, 1625.00, 0.00, 65.000, 1625.00, 25.0000),
(117, 117, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 120.000, 0.000, 18.0000, 0.0000, 2160.00, 0.00, 120.000, 2160.00, 18.0000),
(118, 118, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 85.000, 0.000, 24.0000, 0.0000, 2040.00, 0.00, 85.000, 2040.00, 24.0000),
(119, 119, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.000, 0.000, 32.0000, 0.0000, 1920.00, 0.00, 60.000, 1920.00, 32.0000),
(120, 120, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 45.000, 0.000, 48.0000, 0.0000, 2160.00, 0.00, 45.000, 2160.00, 48.0000),
(121, 121, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 12.000, 0.000, 220.0000, 0.0000, 2640.00, 0.00, 12.000, 2640.00, 220.0000),
(122, 122, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.000, 0.000, 95.0000, 0.0000, 1710.00, 0.00, 18.000, 1710.00, 95.0000),
(123, 123, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.000, 0.000, 45.0000, 0.0000, 1350.00, 0.00, 30.000, 1350.00, 45.0000),
(124, 124, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 6.000, 0.000, 1150.0000, 0.0000, 6900.00, 0.00, 6.000, 6900.00, 1150.0000),
(125, 125, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 8.000, 0.000, 580.0000, 0.0000, 4640.00, 0.00, 8.000, 4640.00, 580.0000),
(126, 126, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 12.000, 0.000, 95.0000, 0.0000, 1140.00, 0.00, 12.000, 1140.00, 95.0000),
(127, 127, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 15.000, 0.000, 85.0000, 0.0000, 1275.00, 0.00, 15.000, 1275.00, 85.0000),
(128, 128, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 65.000, 0.000, 9.0000, 0.0000, 585.00, 0.00, 65.000, 585.00, 9.0000),
(129, 129, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 48.000, 0.000, 22.0000, 0.0000, 1056.00, 0.00, 48.000, 1056.00, 22.0000),
(130, 130, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 42.000, 0.000, 22.0000, 0.0000, 924.00, 0.00, 42.000, 924.00, 22.0000),
(131, 131, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 25.000, 0.000, 35.0000, 0.0000, 875.00, 0.00, 25.000, 875.00, 35.0000),
(132, 132, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 80.000, 0.000, 2.8000, 0.0000, 224.00, 0.00, 80.000, 224.00, 2.8000),
(133, 133, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 65.000, 0.000, 3.2000, 0.0000, 208.00, 0.00, 65.000, 208.00, 3.2000),
(134, 134, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 45.000, 0.000, 4.5000, 0.0000, 202.50, 0.00, 45.000, 202.50, 4.5000),
(135, 135, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 35.000, 0.000, 5.0000, 0.0000, 175.00, 0.00, 35.000, 175.00, 5.0000),
(136, 136, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 50.000, 0.000, 18.0000, 0.0000, 900.00, 0.00, 50.000, 900.00, 18.0000),
(137, 137, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 38.000, 0.000, 26.0000, 0.0000, 988.00, 0.00, 38.000, 988.00, 26.0000),
(138, 138, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 24.000, 0.000, 42.0000, 0.0000, 1008.00, 0.00, 24.000, 1008.00, 42.0000),
(139, 139, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 180.000, 0.000, 1.8000, 0.0000, 324.00, 0.00, 180.000, 324.00, 1.8000),
(140, 140, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 90.000, 0.000, 3.5000, 0.0000, 315.00, 0.00, 90.000, 315.00, 3.5000),
(141, 141, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 75.000, 0.000, 5.0000, 0.0000, 375.00, 0.00, 75.000, 375.00, 5.0000),
(142, 142, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.000, 0.000, 7.5000, 0.0000, 450.00, 0.00, 60.000, 450.00, 7.5000),
(143, 143, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 70.000, 0.000, 8.5000, 0.0000, 595.00, 0.00, 70.000, 595.00, 8.5000),
(144, 144, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 45.000, 0.000, 9.0000, 0.0000, 405.00, 0.00, 45.000, 405.00, 9.0000),
(145, 145, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 45.000, 0.000, 9.0000, 0.0000, 405.00, 0.00, 45.000, 405.00, 9.0000),
(146, 146, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 35.000, 0.000, 9.0000, 0.0000, 315.00, 0.00, 35.000, 315.00, 9.0000),
(147, 147, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 30.000, 0.000, 8.0000, 0.0000, 240.00, 0.00, 30.000, 240.00, 8.0000),
(148, 148, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 28.000, 0.000, 8.0000, 0.0000, 224.00, 0.00, 28.000, 224.00, 8.0000),
(149, 149, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 55.000, 0.000, 6.0000, 0.0000, 330.00, 0.00, 55.000, 330.00, 6.0000),
(150, 150, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 40.000, 0.000, 14.0000, 0.0000, 560.00, 0.00, 40.000, 560.00, 14.0000),
(151, 151, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 50.000, 0.000, 4.5000, 0.0000, 225.00, 0.00, 50.000, 225.00, 4.5000),
(152, 152, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 35.000, 0.000, 5.5000, 0.0000, 192.50, 0.00, 35.000, 192.50, 5.5000),
(153, 153, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 60.000, 0.000, 1.5000, 0.0000, 90.00, 0.00, 60.000, 90.00, 1.5000),
(154, 154, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 8.000, 0.000, 45.0000, 0.0000, 360.00, 0.00, 8.000, 360.00, 45.0000),
(155, 155, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 12.000, 0.000, 22.0000, 0.0000, 264.00, 0.00, 12.000, 264.00, 22.0000),
(156, 156, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.000, 0.000, 18.0000, 0.0000, 324.00, 0.00, 18.000, 324.00, 18.0000),
(157, 157, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 15.000, 0.000, 95.0000, 0.0000, 1425.00, 0.00, 15.000, 1425.00, 95.0000),
(158, 158, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 22.000, 0.000, 78.0000, 0.0000, 1716.00, 0.00, 22.000, 1716.00, 78.0000),
(159, 159, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 14.000, 0.000, 55.0000, 0.0000, 770.00, 0.00, 14.000, 770.00, 55.0000),
(160, 160, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 10.000, 0.000, 38.0000, 0.0000, 380.00, 0.00, 10.000, 380.00, 38.0000),
(161, 161, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 28.000, 0.000, 22.0000, 0.0000, 616.00, 0.00, 28.000, 616.00, 22.0000),
(162, 162, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 20.000, 0.000, 28.0000, 0.0000, 560.00, 0.00, 20.000, 560.00, 28.0000),
(163, 163, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 25.000, 0.000, 18.0000, 0.0000, 450.00, 0.00, 25.000, 450.00, 18.0000),
(164, 164, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.000, 0.000, 75.0000, 0.0000, 1350.00, 0.00, 18.000, 1350.00, 75.0000),
(165, 165, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 12.000, 0.000, 125.0000, 0.0000, 1500.00, 0.00, 12.000, 1500.00, 125.0000),
(166, 166, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 10.000, 0.000, 55.0000, 0.0000, 550.00, 0.00, 10.000, 550.00, 55.0000),
(167, 167, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 14.000, 0.000, 78.0000, 0.0000, 1092.00, 0.00, 14.000, 1092.00, 78.0000),
(168, 168, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 8.000, 0.000, 180.0000, 0.0000, 1440.00, 0.00, 8.000, 1440.00, 180.0000),
(169, 169, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 15.000, 0.000, 85.0000, 0.0000, 1275.00, 0.00, 15.000, 1275.00, 85.0000),
(170, 170, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 6.000, 0.000, 380.0000, 0.0000, 2280.00, 0.00, 6.000, 2280.00, 380.0000),
(171, 171, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 8.000, 0.000, 95.0000, 0.0000, 760.00, 0.00, 8.000, 760.00, 95.0000),
(172, 172, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 10.000, 0.000, 320.0000, 0.0000, 3200.00, 0.00, 10.000, 3200.00, 320.0000),
(173, 173, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 18.000, 0.000, 95.0000, 0.0000, 1710.00, 0.00, 18.000, 1710.00, 95.0000),
(174, 174, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 12.000, 0.000, 65.0000, 0.0000, 780.00, 0.00, 12.000, 780.00, 65.0000),
(175, 175, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 22.000, 0.000, 22.0000, 0.0000, 484.00, 0.00, 22.000, 484.00, 22.0000),
(176, 176, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 28.000, 0.000, 45.0000, 0.0000, 1260.00, 0.00, 28.000, 1260.00, 45.0000),
(177, 177, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 8.000, 0.000, 165.0000, 0.0000, 1320.00, 0.00, 8.000, 1320.00, 165.0000),
(178, 178, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 6.000, 0.000, 78.0000, 0.0000, 468.00, 0.00, 6.000, 468.00, 78.0000),
(179, 179, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 14.000, 0.000, 32.0000, 0.0000, 448.00, 0.00, 14.000, 448.00, 32.0000),
(180, 180, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 3.000, 0.000, 2200.0000, 0.0000, 6600.00, 0.00, 3.000, 6600.00, 2200.0000),
(181, 181, '2026-08-09 08:00:00', 'INGRESO', 1, 'ING-2026-000001', 2.000, 0.000, 1850.0000, 0.0000, 3700.00, 0.00, 2.000, 3700.00, 1850.0000);

-- Datos iniciales de approval_routes: se conservan los registros originales.
INSERT INTO `approval_routes` (`id`, `area_id`, `name`, `is_active`) VALUES
(1, 1, 'Ruta estándar - Dirección Departamental de Educación', 1),
(2, 2, 'Ruta estándar - Dirección Administrativa', 1),
(3, 3, 'Ruta estándar - Subdirección Académica', 1),
(4, 4, 'Ruta estándar - Almacén', 1),
(5, 5, 'Ruta estándar - Contrataciones', 1),
(6, 6, 'Ruta estándar - Jefatura de Asuntos Administrativos', 1),
(7, 7, 'Ruta estándar - Finanzas', 1),
(8, 8, 'Ruta estándar - Recursos Humanos', 1);

-- Datos iniciales de approval_route_steps: se conservan los registros originales.
INSERT INTO `approval_route_steps` (`id`, `route_id`, `step_order`, `role_id`, `sla_hours`, `is_required`) VALUES
(1, 1, 1, 3, 48, 1),
(2, 1, 2, 5, 48, 1),
(3, 1, 3, 4, 48, 1),
(4, 2, 1, 3, 48, 1),
(5, 2, 2, 5, 48, 1),
(6, 2, 3, 4, 48, 1),
(7, 3, 1, 3, 48, 1),
(8, 3, 2, 5, 48, 1),
(9, 3, 3, 4, 48, 1),
(10, 4, 1, 3, 48, 1),
(11, 4, 2, 5, 48, 1),
(12, 4, 3, 4, 48, 1),
(13, 5, 1, 3, 48, 1),
(14, 5, 2, 5, 48, 1),
(15, 5, 3, 4, 48, 1),
(16, 6, 1, 3, 48, 1),
(17, 6, 2, 5, 48, 1),
(18, 6, 3, 4, 48, 1),
(19, 7, 1, 3, 48, 1),
(20, 7, 2, 5, 48, 1),
(21, 7, 3, 4, 48, 1),
(22, 8, 1, 3, 48, 1),
(23, 8, 2, 5, 48, 1),
(24, 8, 3, 4, 48, 1);

-- Datos iniciales de period_closes: se conservan los registros originales.
INSERT INTO `period_closes` (`id`, `year`, `month`, `status`, `reopen_reason`) VALUES
(1, 2026, 10, 'ABIERTO', NULL);

-- Solicitud de demostración atendida
INSERT INTO `requests` (`id`, `code`, `correspondence_number`, `applicant_id`, `area_id`, `office`, `justification`, `route_id`, `current_step`, `status`, `submitted_at`, `approved_at`, `closed_at`) VALUES
(1, 'SOL-2026-000001', 'DDE-2026-00123', 2, 8, 'Recursos Humanos', 'Material de escritorio para inicio de gestión del área de RRHH', 8, 3, 'ATENDIDA', '2026-08-10 09:30:00', '2026-08-10 14:20:00', '2026-08-10 16:45:00');

-- Datos iniciales de request_items: se conservan los registros originales.
INSERT INTO `request_items` (`id`, `request_id`, `product_id`, `qty_requested`, `qty_approved`, `qty_proposed`, `qty_authorized`, `qty_delivered`, `stock_at_request`, `status`, `notes`) VALUES
(1, 1, 1, 2.000, 2.000, 2.000, 2.000, 2.000, 480.000, 'ENTREGADO', 'Resmas carta'),
(2, 1, 2, 2.000, 2.000, 2.000, 2.000, 2.000, 85.000, 'ENTREGADO', 'Resmas oficio'),
(3, 1, 3, 2.000, 2.000, 2.000, 2.000, 2.000, 60.000, 'ENTREGADO', 'Resmas A4');

-- Datos iniciales de request_approvals: se conservan los registros originales.
INSERT INTO `request_approvals` (`id`, `request_id`, `step_order`, `approver_user_id`, `role_id`, `action`, `action_at`, `comments`) VALUES
(1, 1, 1, 3, 3, 'APROBADO', '2026-08-10 14:20:00', 'Aprobado conforme a presupuesto');

-- Datos iniciales de request_history: se conservan los registros originales.
INSERT INTO `request_history` (`id`, `request_id`, `from_state`, `to_state`, `actor_id`, `role_id`, `comments`, `created_at`) VALUES
(1, 1, 'BORRADOR', 'EN_APROBACION', 2, 2, 'Envío a revisión', '2026-08-10 09:30:00'),
(2, 1, 'EN_APROBACION', 'APROBADA', 3, 3, 'Visto Bueno de Jefatura', '2026-08-10 14:20:00'),
(3, 1, 'APROBADA', 'ATENDIDA', 5, 5, 'Despacho físico y entrega realizada', '2026-08-10 16:45:00');

-- Datos iniciales de stock_dispatches: se conservan los registros originales.
INSERT INTO `stock_dispatches` (`id`, `number`, `request_id`, `dispatch_date`, `dispatched_by`, `received_by`, `received_ci`, `received_signature_at`, `total_value`, `status`, `notes`) VALUES
(1, 'SAL-2026-000001', 1, '2026-08-10 16:30:00', 5, 'Carlos Quispe Mamani', '3456789', '2026-08-10 16:45:00', 203.00, 'CONFIRMADO', 'Entrega completa contra firma de acta');

-- Datos iniciales de dispatch_items: se conservan los registros originales.
INSERT INTO `dispatch_items` (`id`, `dispatch_id`, `request_item_id`, `product_id`, `qty`, `unit_cost`, `total_value`) VALUES
(1, 1, 1, 1, 2.000, 32.5000, 65.00),
(2, 1, 2, 2, 2.000, 38.2000, 76.40),
(3, 1, 3, 3, 2.000, 30.8000, 61.60);

-- Datos iniciales de layer_consumptions: se conservan los registros originales.
INSERT INTO `layer_consumptions` (`id`, `dispatch_item_id`, `layer_id`, `qty`, `unit_cost`, `total_value`) VALUES
(1, 1, 1, 2.000, 32.5000, 65.00),
(2, 2, 2, 2.000, 38.2000, 76.40),
(3, 3, 3, 2.000, 30.8000, 61.60);

-- Actualización del saldo consumido en las primeras 3 capas
UPDATE `stock_layers` SET `remaining_qty` = 478.000 WHERE `id` = 1;
UPDATE `stock_layers` SET `remaining_qty` = 83.000 WHERE `id` = 2;
UPDATE `stock_layers` SET `remaining_qty` = 58.000 WHERE `id` = 3;

-- Actualización del stock de los primeros 3 productos
UPDATE `products` SET `stock_qty` = 478.000, `stock_value` = 15535.00 WHERE `id` = 1;
UPDATE `products` SET `stock_qty` = 83.000, `stock_value` = 3170.60 WHERE `id` = 2;
UPDATE `products` SET `stock_qty` = 58.000, `stock_value` = 1786.40 WHERE `id` = 3;

-- Kardex de salida para los 3 productos
INSERT INTO `kardex_movements` (`product_id`, `movement_date`, `doc_type`, `doc_id`, `reference`, `qty_in`, `qty_out`, `unit_cost_in`, `unit_cost_out`, `total_in`, `total_out`, `balance_qty`, `balance_value`, `balance_unit_cost`) VALUES
(1, '2026-08-10 16:30:00', 'SALIDA', 1, 'SAL-2026-000001', 0.000, 2.000, 0.0000, 32.5000, 0.00, 65.00, 478.000, 15535.00, 32.5000),
(2, '2026-08-10 16:30:00', 'SALIDA', 1, 'SAL-2026-000001', 0.000, 2.000, 0.0000, 38.2000, 0.00, 76.40, 83.000, 3170.60, 38.2000),
(3, '2026-08-10 16:30:00', 'SALIDA', 1, 'SAL-2026-000001', 0.000, 2.000, 0.0000, 30.8000, 0.00, 61.60, 58.000, 1786.40, 30.8000);

-- Ajuste de inventario pendiente
INSERT INTO `adjustments` (`id`, `number`, `type`, `reason`, `act_number`, `adjustment_date`, `status`, `created_by`) VALUES
(1, 'AJ-2026-000001', 'FALTANTE', 'Diferencia detectada en conteo físico de material de limpieza del 09/08/2026', 'ACTA-AJ-001', '2026-08-15 10:00:00', 'EN_REVISION', 5);

-- Datos iniciales de adjustment_items: se conservan los registros originales.
INSERT INTO `adjustment_items` (`id`, `adjustment_id`, `product_id`, `qty`, `unit_cost`, `total_value`, `notes`) VALUES
(1, 1, 68, 2.000, 18.0000, 36.00, 'Faltante de papel institucional 500m');

-- Secuencias
INSERT INTO `sequences` (`key`, `year`, `current_value`) VALUES
('SOL', 2026, 1),
('DES', 2026, 1),
('ING', 2026, 1),
('AJ', 2026, 1)
ON DUPLICATE KEY UPDATE `current_value` = VALUES(`current_value`);

-- Configuración Institucional
INSERT INTO `settings` (`key`, `value`) VALUES
('institucion.nombre', '{"value": "Dirección Departamental de Educación - Cochabamba"}'),
('institucion.sigla', '{"value": "DDE-CBBA"}'),
('impresion.offsetX_mm', '{"value": 0}'),
('impresion.offsetY_mm', '{"value": 0}'),
('impresion.escala', '{"value": 100}'),
('impresion.hoja', '{"value": "carta"}'),
('general.zona_horaria', '{"value": "America/La_Paz"}'),
('general.moneda', '{"value": "BOB"}')
ON DUPLICATE KEY UPDATE `value` = VALUES(`value`);


SET FOREIGN_KEY_CHECKS = 1;

-- Fin del script MySQL Workbench SIGA-DDE