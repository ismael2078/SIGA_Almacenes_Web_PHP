<?php
// Carga datos iniciales necesarios para demostrar el sistema.

declare(strict_types=1);

use App\Core\Database;
use App\Core\Permission;

require dirname(__DIR__) . '/bootstrap.php';

/**
 * Cargador de datos iniciales de SIGA-DDE sobre MySQL.
 *
 * Uso:
 *   php database/seed.php            (solo sobre una base vacía)
 *   php database/seed.php --force    (limpia y vuelve a cargar los datos demo)
 */
final class Seeder
{
    private PDO $pdo;
    private int $year;
    private string $now;
    private string $openingDate;
    private string $dispatchDate;
    private string $adjustmentDate;

    /** @var array<string,int> */
    private array $permissionIds = [];
    /** @var array<string,int> */
    private array $roleIds = [];
    /** @var array<string,int> */
    private array $categoryIds = [];
    /** @var array<string,int> */
    private array $subcategoryIds = [];
    /** @var array<string,int> */
    private array $unitIds = [];
    /** @var array<string,int> */
    private array $locationIds = [];
    /** @var array<int,string> */
    private array $locationCodes = [];
    /** @var array<string,int> */
    private array $areaIds = [];
    /** @var array<string,string> */
    private array $areaNames = [];
    /** @var array<string,int> */
    private array $userIds = [];
    /** @var array<string,int> */
    private array $routeIds = [];
    /** @var array<int,array<string,mixed>> */
    private array $products = [];
    /** @var array<string,array<string,mixed>> */
    private array $productsByCode = [];
    /** @var array<int,int> */
    private array $layerIds = [];

    private int $openingEntryId = 0;
    private string $openingNumber = '';
    private float $openingTotal = 0.0;
    private int $dispatchId = 0;
    private string $dispatchNumber = '';
    private int $adjustmentId = 0;
    private string $adjustmentNumber = '';

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
        $this->year = (int) date('Y');
        $this->now = date('Y-m-d H:i:s');
        $this->openingDate = date('Y-m-d H:i:s', strtotime('-20 days 08:00:00'));
        $this->dispatchDate = date('Y-m-d H:i:s', strtotime('-4 days 16:30:00'));
        $this->adjustmentDate = date('Y-m-d H:i:s', strtotime('-2 days 10:00:00'));
    }

    public function userCount(): int
    {
        return (int) $this->pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    }

    /**
     * Limpia las tablas de datos. Se ejecuta antes de la transacción de carga.
     */
    public function clear(): void
    {
        $tables = [
            'layer_consumptions', 'dispatch_items', 'stock_dispatches',
            'adjustment_items', 'adjustments', 'request_approvals', 'request_items', 'requests',
            'kardex_movements', 'stock_layers', 'stock_entry_items', 'stock_entries',
            'stock_return_items', 'stock_returns',
            'physical_count_items', 'physical_counts', 'period_closes',
            'sessions', 'audit_log', 'notifications', 'attachments', 'backups',
            'user_roles', 'user_permissions', 'delegations', 'users',
            'role_permissions', 'permissions', 'roles',
            'approval_route_steps', 'approval_routes',
            'products', 'suppliers', 'areas', 'locations',
            'subcategories', 'categories', 'units', 'sequences', 'settings',
        ];

        $this->pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
        // Ejecuta el proceso controlando posibles errores durante la operación.
        try {
            foreach ($tables as $table) {
                $this->pdo->exec('TRUNCATE TABLE `' . $table . '`');
            }
        } finally {
            $this->pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
        }
    }

    public function run(): void
    {
        // Inicia una transacción: todas las escrituras de esta operación deben confirmarse juntas.
        $this->pdo->beginTransaction();
        try {
            $this->seedSecurity();
            $this->seedCatalogs();
            $this->seedAreas();
            $this->seedUsers();
            $this->seedProducts();
            $this->seedOpeningEntry();
            $this->seedApprovalRoutes();

            $requestIds = $this->seedDemoRequests();
            $this->seedDemoDispatch($requestIds['attended']);
            $this->seedDemoAdjustment();
            $this->seedPeriodSettingsSequences();
            $this->seedAuditLogs($requestIds);

            // Confirma los cambios después de completar las validaciones y registros.
            $this->pdo->commit();
        } catch (Throwable $exception) {
            // Solo revierte la operación cuando todavía existe una transacción abierta.
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $exception;
        }
    }

    private function seedSecurity(): void
    {
        echo "· Insertando permisos y roles...\n";

        $codes = [];
        // Recorre los elementos de la colección y procesa cada registro.
        foreach (Permission::MAP as $permissions) {
            foreach ($permissions as $code) {
                $codes[$code] = true;
            }
        }
        ksort($codes);

        // Recorre los elementos de la colección y procesa cada registro.
        foreach (array_keys($codes) as $code) {
            $this->permissionIds[$code] = $this->insert('permissions', [
                'code' => $code,
                'module' => explode('.', $code)[0],
                'description' => $code,
            ]);
        }

        $roles = [
            ['code' => 'ADMIN', 'name' => 'Administrador', 'description' => 'Administración técnica total', 'is_system' => 1],
            ['code' => 'SOLICITANTE', 'name' => 'Solicitante', 'description' => 'Solicita material', 'is_system' => 1],
            ['code' => 'JEFE_INMEDIATO', 'name' => 'Inmediato Superior', 'description' => 'Valida la necesidad (aprueba)', 'is_system' => 1],
            ['code' => 'JEFE_UAA', 'name' => 'Jefatura de UAA', 'description' => 'Autoriza la solicitud (decisión final)', 'is_system' => 1],
            ['code' => 'TECNICO_ALMACEN', 'name' => 'Técnica de Almacenes', 'description' => 'Prepara y entrega materiales', 'is_system' => 1],
            ['code' => 'CONSULTA', 'name' => 'Consulta', 'description' => 'Solo lectura', 'is_system' => 1],
            ['code' => 'AUDITOR', 'name' => 'Auditor del Sistema', 'description' => 'Auditoría global (solo lectura)', 'is_system' => 1],
        ];

        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($roles as $role) {
            $this->roleIds[$role['code']] = $this->insert('roles', $role);
        }

        // Recorre los elementos de la colección y procesa cada registro.
        foreach (Permission::MAP as $roleCode => $permissions) {
            $roleId = $this->roleIds[$roleCode] ?? null;
            // Distingue las acciones permitidas según el cargo o rol asignado.
            if ($roleId === null) {
                continue;
            }
            // Recorre los elementos de la colección y procesa cada registro.
            foreach (array_unique($permissions) as $code) {
                $permissionId = $this->permissionIds[$code] ?? null;
                // Comprueba el resultado recibido y evita continuar con datos inexistentes.
                if ($permissionId === null) {
                    continue;
                }
                $this->insert('role_permissions', [
                    'role_id' => $roleId,
                    'permission_id' => $permissionId,
                ]);
            }
        }
    }

    private function seedCatalogs(): void
    {
        echo "· Insertando catálogos base...\n";

        $categories = [
            ['PAP', 'Papelería y escritorio', 'Material de escritorio, papel y archivo'],
            ['TIN', 'Tintas y tóners', 'Insumos de impresión y fotocopiado'],
            ['LIM', 'Limpieza e higiene', 'Productos de limpieza y aseo'],
            ['INF', 'Informática', 'Accesorios y consumibles de computación'],
            ['ESC', 'Escritorio y mobiliario menor', 'Sellos, perforadoras y accesorios de oficina'],
            ['ELE', 'Eléctrico', 'Focos, extensiones y material eléctrico'],
        ];
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($categories as [$code, $name, $description]) {
            $this->categoryIds[$code] = $this->insert('categories', [
                'code' => $code,
                'name' => $name,
                'description' => $description,
                'is_active' => 1,
            ]);
        }

        $subcategories = [
            ['PAP', 'HOJ', 'Hojas y resmas'],
            ['PAP', 'BOL', 'Bolígrafos y lápices'],
            ['PAP', 'CAR', 'Carpetas y archivadores'],
            ['PAP', 'SOB', 'Sobres'],
            ['PAP', 'GRAP', 'Grapas y clips'],
            ['TIN', 'TIN-TIN', 'Tintas'],
            ['TIN', 'TIN-TON', 'Tóners'],
            ['LIM', 'LIM-PAP', 'Papel higiénico'],
            ['LIM', 'LIM-DET', 'Detergentes'],
            ['LIM', 'LIM-DES', 'Desinfectantes'],
            ['INF', 'INF-MOU', 'Mouse'],
            ['INF', 'INF-TEC', 'Teclados'],
            ['INF', 'INF-CAB', 'Cables'],
            ['INF', 'INF-USB', 'Memorias USB'],
            ['ESC', 'ESC-SEL', 'Sellos'],
            ['ESC', 'ESC-PER', 'Perforadoras'],
            ['ELE', 'ELE-FOC', 'Focos'],
            ['ELE', 'ELE-EXT', 'Extensiones'],
        ];
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($subcategories as [$categoryCode, $code, $name]) {
            $categoryId = $this->categoryIds[$categoryCode];
            $this->subcategoryIds[$categoryCode . '|' . $code] = $this->insert('subcategories', [
                'category_id' => $categoryId,
                'code' => $code,
                'name' => $name,
                'is_active' => 1,
            ]);
        }

        $units = [
            ['UND', 'Unidad'], ['RES', 'Resma'], ['CAJ', 'Caja'], ['PAQ', 'Paquete'],
            ['DOC', 'Docena'], ['M', 'Metro'], ['LT', 'Litro'], ['KG', 'Kilogramo'],
            ['GAL', 'Galón'], ['PAR', 'Par'],
        ];
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($units as [$code, $name]) {
            $this->unitIds[$code] = $this->insert('units', [
                'code' => $code,
                'name' => $name,
                'is_active' => 1,
            ]);
        }

        $locations = [
            ['A1', 'Almacén principal - Estante A1', 'Almacén principal', 'A', '1', '1'],
            ['A2', 'Almacén principal - Estante A2', 'Almacén principal', 'A', '2', '1'],
            ['B1', 'Almacén principal - Estante B1', 'Almacén principal', 'B', '1', '1'],
            ['B2', 'Almacén principal - Estante B2', 'Almacén principal', 'B', '2', '1'],
            ['C1', 'Almacén principal - Estante C1', 'Almacén principal', 'C', '1', '1'],
        ];
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($locations as [$code, $name, $warehouse, $aisle, $shelf, $level]) {
            $this->locationIds[$code] = $this->insert('locations', [
                'code' => $code,
                'name' => $name,
                'warehouse' => $warehouse,
                'aisle' => $aisle,
                'shelf' => $shelf,
                'level' => $level,
                'description' => 'Ubicación física del almacén institucional',
                'is_active' => 1,
            ]);
            $this->locationCodes[] = $code;
        }

        $suppliers = [
            ['1000123022', 'Librería Unión SRL', 'Luis Pérez', '4250001', 'ventas@libreriaunion.bo', 'Av. Ayacucho 123, Cochabamba'],
            ['1000234033', 'Distribuidora Andina SRL', 'María Gutiérrez', '4250002', 'contacto@andina.bo', 'Calle Jordán 456, Cochabamba'],
            ['1000345044', 'Suministros Cochabamba', 'Jorge Rojas', '4250003', 'ventas@suministros.com.bo', 'Av. Blanco Galindo km 3, Cochabamba'],
            ['1000456055', 'Tecnología del Sur', 'Andrea Salazar', '4250004', 'info@tecnologiasur.bo', 'Calle 25 de Mayo 789, Cochabamba'],
        ];
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($suppliers as [$nit, $name, $contact, $phone, $email, $address]) {
            $this->insert('suppliers', [
                'nit' => $nit,
                'name' => $name,
                'contact_name' => $contact,
                'phone' => $phone,
                'email' => $email,
                'address' => $address,
                'is_active' => 1,
            ]);
        }
    }

    private function seedAreas(): void
    {
        echo "· Insertando áreas institucionales...\n";

        $directions = [
            ['DDE', 'Dirección Departamental de Educación', 'DIRECCION'],
            ['ADM', 'Dirección Administrativa', 'DIRECCION'],
            ['ACA', 'Subdirección Académica', 'DIRECCION'],
        ];
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($directions as [$code, $name, $type]) {
            $this->areaIds[$code] = $this->insert('areas', [
                'parent_id' => null,
                'code' => $code,
                'name' => $name,
                'type' => $type,
                'jefe_uaa_id' => null,
                'is_active' => 1,
            ]);
            $this->areaNames[$code] = $name;
        }

        $dependencies = [
            ['ALM', 'Almacén', 'UNIDAD', 'ADM'],
            ['CON', 'Contrataciones', 'UNIDAD', 'ADM'],
            ['JAA', 'Jefatura de Asuntos Administrativos', 'UNIDAD', 'ADM'],
            ['FIN', 'Finanzas', 'UNIDAD', 'ADM'],
            ['REC', 'Recursos Humanos', 'DEPENDENCIA', 'DDE'],
        ];
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($dependencies as [$code, $name, $type, $parentCode]) {
            $this->areaIds[$code] = $this->insert('areas', [
                'parent_id' => $this->areaIds[$parentCode],
                'code' => $code,
                'name' => $name,
                'type' => $type,
                'jefe_uaa_id' => null,
                'is_active' => 1,
            ]);
            $this->areaNames[$code] = $name;
        }
    }

    private function seedUsers(): void
    {
        echo "· Creando usuarios y asignando roles...\n";

        $users = [
            [
                'username' => 'admin', 'password' => 'admin123', 'full_name' => 'María Pérez Vargas',
                'ci' => '1234567', 'email' => 'admin@dde.gob.bo', 'position' => 'Administrador del Sistema',
                'office' => 'Unidad de Sistemas', 'area' => 'ALM', 'role' => 'ADMIN',
            ],
            [
                'username' => 'solicitante', 'password' => 'sol123', 'full_name' => 'Carlos Quispe Mamani',
                'ci' => '3456789', 'email' => 'cquispe@dde.gob.bo', 'position' => 'Profesional III',
                'office' => 'Recursos Humanos', 'area' => 'REC', 'role' => 'SOLICITANTE',
            ],
            [
                'username' => 'jefe_inmediato', 'password' => 'jefe123', 'full_name' => 'Roberto Vargas Cruz',
                'ci' => '5678901', 'email' => 'rvargas@dde.gob.bo', 'position' => 'Jefe de Recursos Humanos',
                'office' => 'Recursos Humanos', 'area' => 'REC', 'role' => 'JEFE_INMEDIATO',
            ],
            [
                'username' => 'jefe_uaa', 'password' => 'uaa123', 'full_name' => 'Ana Flores Rojas',
                'ci' => '4567890', 'email' => 'aflores@dde.gob.bo', 'position' => 'Jefa de Asuntos Administrativos',
                'office' => 'Jefatura UAA', 'area' => 'JAA', 'role' => 'JEFE_UAA',
            ],
            [
                'username' => 'almacen', 'password' => 'almacen123', 'full_name' => 'Juana Mamani Lima',
                'ci' => '2345678', 'email' => 'almacen@dde.gob.bo', 'position' => 'Técnica de Almacenes',
                'office' => 'Almacén DDE', 'area' => 'ALM', 'role' => 'TECNICO_ALMACEN',
            ],
            [
                'username' => 'auditor', 'password' => 'auditor123', 'full_name' => 'Patricia Rojas Auditora',
                'ci' => '8888888', 'email' => 'auditor@dde.gob.bo', 'position' => 'Auditora Interna',
                'office' => 'Unidad de Auditoría', 'area' => null, 'role' => 'AUDITOR',
            ],
            [
                'username' => 'consulta', 'password' => 'consulta123', 'full_name' => 'Visitante Externo',
                'ci' => '0000000', 'email' => null, 'position' => 'Visitante',
                'office' => 'Externa', 'area' => null, 'role' => 'CONSULTA',
            ],
        ];

        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($users as $user) {
            $areaId = $user['area'] !== null ? $this->areaIds[$user['area']] : null;
            $this->userIds[$user['username']] = $this->insert('users', [
                'username' => $user['username'],
                'email' => $user['email'],
                'password_hash' => password_hash($user['password'], PASSWORD_BCRYPT, ['cost' => 10]),
                'full_name' => $user['full_name'],
                'ci' => $user['ci'],
                'position' => $user['position'],
                'office' => $user['office'],
                'area_id' => $areaId,
                'jefe_inmediato_id' => null,
                'role_id' => $this->roleIds[$user['role']],
                'is_active' => 1,
                'must_change_password' => 0,
                'failed_attempts' => 0,
                'locked_until' => null,
                'last_login_at' => null,
                'password_changed_at' => $this->now,
            ]);
        }

        $this->update('users', ['jefe_inmediato_id' => $this->userIds['jefe_inmediato']], 'id = ?', [$this->userIds['solicitante']]);
        $this->update('users', ['jefe_inmediato_id' => $this->userIds['jefe_uaa']], 'id = ?', [$this->userIds['jefe_inmediato']]);
        $this->update('users', ['jefe_inmediato_id' => $this->userIds['jefe_uaa']], 'id = ?', [$this->userIds['almacen']]);

        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($users as $user) {
            $this->insert('user_roles', [
                'user_id' => $this->userIds[$user['username']],
                'role_id' => $this->roleIds[$user['role']],
            ]);
        }

        $this->update('areas', ['jefe_uaa_id' => $this->userIds['jefe_uaa']], 'code IN (?, ?)', ['ADM', 'JAA']);
    }

    private function seedProducts(): void
    {
        echo "· Cargando productos desde database/products.json...\n";

        $path = BASE_PATH . '/database/products.json';
        if (!is_file($path)) {
            throw new RuntimeException('No se encontró database/products.json.');
        }
        $raw = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        // Valida que el dato obligatorio exista y tenga un formato utilizable.
        if (!is_array($raw) || $raw === []) {
            throw new RuntimeException('El archivo products.json está vacío o no es válido.');
        }

        $locationCount = count($this->locationCodes);
        // Recorre los registros consultados para preparar el resultado.
        foreach ($raw as $index => $row) {
            if (!is_array($row) || count($row) < 7) {
                throw new RuntimeException('Fila de producto inválida en products.json: ' . $index);
            }
            $code = trim((string) $row[0]);
            $name = trim((string) $row[1]);
            $categoryCode = trim((string) $row[2]);
            $subcategoryCode = trim((string) $row[3]);
            $unitCode = trim((string) $row[4]);
            $qty = (float) $row[5];
            $cost = (float) $row[6];

            $categoryId = $this->categoryIds[$categoryCode] ?? null;
            $subcategoryId = $this->subcategoryIds[$categoryCode . '|' . $subcategoryCode] ?? null;
            $unitId = $this->unitIds[$unitCode] ?? null;
            // Comprueba el resultado recibido y evita continuar con datos inexistentes.
            if ($categoryId === null || $subcategoryId === null || $unitId === null) {
                throw new RuntimeException('Catálogo no encontrado para el producto ' . $code . '.');
            }

            $locationCode = $this->locationCodes[$index % $locationCount];
            $locationId = $this->locationIds[$locationCode];
            $minStock = max(1, (int) floor($qty * 0.1));
            $maxStock = $qty * 3;
            $stockValue = $qty * $cost;

            $productId = $this->insert('products', [
                'code' => $code,
                'name' => $name,
                'description' => $name . ' - SKU institucional',
                'brand' => null,
                'model' => null,
                'barcode' => null,
                'category_id' => $categoryId,
                'subcategory_id' => $subcategoryId,
                'unit_id' => $unitId,
                'location_id' => $locationId,
                'min_stock' => number_format($minStock, 3, '.', ''),
                'max_stock' => number_format($maxStock, 3, '.', ''),
                'reference_cost' => number_format($cost, 4, '.', ''),
                'stock_qty' => number_format($qty, 3, '.', ''),
                'stock_value' => number_format($stockValue, 2, '.', ''),
                'status' => 'ACTIVO',
                'is_active' => 1,
                'deactivated_at' => null,
                'purged_at' => null,
            ]);

            $product = [
                'id' => $productId,
                'code' => $code,
                'name' => $name,
                'qty' => $qty,
                'cost' => $cost,
                'value' => $stockValue,
                'location_id' => $locationId,
            ];
            $this->products[] = $product;
            $this->productsByCode[$code] = $product;
        }

        echo '  → ' . count($this->products) . " productos cargados.\n";
    }

    private function seedOpeningEntry(): void
    {
        echo "· Creando ingreso de apertura, capas PEPS y kardex inicial...\n";

        $total = 0.0;
        // Procesa cada producto por separado para registrar o calcular su movimiento.
        foreach ($this->products as $product) {
            $total += $product['qty'] * $product['cost'];
        }
        $this->openingTotal = $total;
        $this->openingNumber = 'ING-' . $this->year . '-000001';

        $entryId = $this->insert('stock_entries', [
            'number' => $this->openingNumber,
            'type' => 'APERTURA',
            'supplier_id' => null,
            'doc_type' => 'INVENTARIO_INICIAL',
            'doc_number' => 'ACTA-' . $this->year . '-001',
            'doc_date' => $this->openingDate,
            'entry_date' => $this->openingDate,
            'posted_at' => $this->openingDate,
            'total_amount' => number_format($total, 2, '.', ''),
            'notes' => 'Acta de conciliación de apertura del sistema SIGA-DDE. Saldo valorado total conciliado contra el inventario institucional clasificado.',
            'status' => 'CONFIRMADO',
            'created_by' => $this->userIds['admin'],
            'created_at' => $this->openingDate,
        ]);
        $this->openingEntryId = $entryId;

        // Procesa cada producto por separado para registrar o calcular su movimiento.
        foreach ($this->products as $product) {
            $quantity = number_format($product['qty'], 3, '.', '');
            $unitCost = number_format($product['cost'], 4, '.', '');
            $lineTotal = number_format($product['qty'] * $product['cost'], 2, '.', '');

            $itemId = $this->insert('stock_entry_items', [
                'entry_id' => $entryId,
                'product_id' => $product['id'],
                'location_id' => $product['location_id'],
                'quantity' => $quantity,
                'unit_cost' => $unitCost,
                'total' => $lineTotal,
                'notes' => null,
            ]);

            $layerId = $this->insert('stock_layers', [
                'product_id' => $product['id'],
                'entry_id' => $entryId,
                'entry_item_id' => $itemId,
                'layer_date' => $this->openingDate,
                'sequence' => 1,
                'original_qty' => $quantity,
                'remaining_qty' => $quantity,
                'unit_cost' => $unitCost,
                'status' => 'ABIERTA',
            ]);
            $this->layerIds[$product['id']] = $layerId;

            $this->insert('kardex_movements', [
                'product_id' => $product['id'],
                'movement_date' => $this->openingDate,
                'doc_type' => 'INGRESO',
                'doc_id' => $entryId,
                'doc_item_id' => $itemId,
                'reference' => $this->openingNumber,
                'qty_in' => $quantity,
                'qty_out' => '0.000',
                'unit_cost_in' => $unitCost,
                'unit_cost_out' => '0.0000',
                'total_in' => $lineTotal,
                'total_out' => '0.00',
                'balance_qty' => $quantity,
                'balance_value' => $lineTotal,
                'balance_unit_cost' => $unitCost,
                'created_by' => $this->userIds['admin'],
                'created_at' => $this->openingDate,
            ]);
        }

        echo '  → ' . $this->openingNumber . ' por Bs ' . number_format($total, 2, '.', ',') . ".\n";
    }

    private function seedApprovalRoutes(): void
    {
        echo "· Configurando rutas de aprobación de tres niveles...\n";

        $steps = [
            ['JEFE_INMEDIATO', 1],
            ['TECNICO_ALMACEN', 2],
            ['JEFE_UAA', 3],
        ];

        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($this->areaIds as $areaCode => $areaId) {
            $routeId = $this->insert('approval_routes', [
                'area_id' => $areaId,
                'name' => 'Ruta estándar - ' . ($this->areaNames[$areaCode] ?? $areaCode),
                'is_active' => 1,
            ]);
            $this->routeIds[$areaId] = $routeId;

            // Recorre los pasos de aprobación conservando su orden y responsable.
            foreach ($steps as [$roleCode, $order]) {
                $this->insert('approval_route_steps', [
                    'route_id' => $routeId,
                    'step_order' => $order,
                    'role_id' => $this->roleIds[$roleCode],
                    'sla_hours' => 48,
                    'is_required' => 1,
                ]);
            }
        }
    }

    /**
     * @return array{attended:int,pending:int,approved:int}
     */
    private function seedDemoRequests(): array
    {
        echo "· Generando solicitudes de demostración...\n";

        $applicantId = $this->userIds['solicitante'];
        $areaId = $this->areaIds['REC'];
        $routeId = $this->routeIds[$areaId];
        $applicantRoleId = $this->roleIds['SOLICITANTE'];
        $jefeRoleId = $this->roleIds['JEFE_INMEDIATO'];
        $tecnicoRoleId = $this->roleIds['TECNICO_ALMACEN'];
        $uaaRoleId = $this->roleIds['JEFE_UAA'];

        $submitted1 = date('Y-m-d H:i:s', strtotime('-5 days 09:30:00'));
        $approved1 = date('Y-m-d H:i:s', strtotime('-5 days 14:20:00'));
        $pendingDate = date('Y-m-d H:i:s', strtotime('-2 days 11:15:00'));
        $approvedRequestSubmitted = date('Y-m-d H:i:s', strtotime('-3 days 09:00:00'));
        $approvedRequestApproved = date('Y-m-d H:i:s', strtotime('-3 days 15:00:00'));

        $attendedItems = [];
        // Procesa cada producto por separado para registrar o calcular su movimiento.
        foreach (array_slice($this->products, 0, 3) as $product) {
            $attendedItems[] = [
                'product_id' => $product['id'],
                'qty_requested' => '2.000',
                'qty_approved' => '2.000',
                'qty_proposed' => '2.000',
                'qty_authorized' => '2.000',
                'qty_delivered' => '2.000',
                'stock_at_request' => number_format($product['qty'], 3, '.', ''),
                'status' => 'ENTREGADO',
                'notes' => null,
            ];
        }

        $attended = $this->createRequest([
            'code' => 'SOL-' . $this->year . '-000001',
            'correspondence_number' => 'DDE-' . $this->year . '-00123',
            'applicant_id' => $applicantId,
            'area_id' => $areaId,
            'office' => 'Recursos Humanos',
            'justification' => 'Material de escritorio para inicio de gestión del área de Recursos Humanos.',
            'route_id' => $routeId,
            'current_step' => 3,
            'status' => 'ATENDIDA',
            'submitted_at' => $submitted1,
            'approved_at' => $approved1,
            'closed_at' => $this->dispatchDate,
            'rejection_reason' => null,
            'observation' => null,
            'printed_at' => null,
            'print_count' => 0,
            'created_at' => $submitted1,
        ], $attendedItems, [
            [
                'step_order' => 1,
                'approver_user_id' => $this->userIds['jefe_inmediato'],
                'role_id' => $jefeRoleId,
                'action' => 'APROBADO',
                'action_at' => date('Y-m-d H:i:s', strtotime('-5 days 10:10:00')),
                'comments' => 'Aprobado conforme a la disponibilidad presupuestaria del área.',
                'signature_hash' => hash('sha256', 'seed-attended-step-1'),
                'ip' => '127.0.0.1',
            ],
            [
                'step_order' => 2,
                'approver_user_id' => $this->userIds['almacen'],
                'role_id' => $tecnicoRoleId,
                'action' => 'APROBADO',
                'action_at' => date('Y-m-d H:i:s', strtotime('-5 days 11:30:00')),
                'comments' => 'Stock verificado. Se autoriza la propuesta de cantidades.',
                'signature_hash' => hash('sha256', 'seed-attended-step-2'),
                'ip' => '127.0.0.1',
            ],
            [
                'step_order' => 3,
                'approver_user_id' => $this->userIds['jefe_uaa'],
                'role_id' => $uaaRoleId,
                'action' => 'APROBADO',
                'action_at' => $approved1,
                'comments' => 'Autorización final de cantidades.',
                'signature_hash' => hash('sha256', 'seed-attended-step-3'),
                'ip' => '127.0.0.1',
            ],
        ], [
            [
                'from_state' => 'BORRADOR',
                'to_state' => 'EN_APROBACION',
                'actor_id' => $applicantId,
                'role_id' => $applicantRoleId,
                'comments' => 'Solicitud enviada a aprobación.',
                'created_at' => $submitted1,
            ],
            [
                'from_state' => 'EN_APROBACION',
                'to_state' => 'APROBADA',
                'actor_id' => $this->userIds['jefe_uaa'],
                'role_id' => $uaaRoleId,
                'comments' => 'Aprobación final completada.',
                'created_at' => $approved1,
            ],
            [
                'from_state' => 'APROBADA',
                'to_state' => 'ATENDIDA',
                'actor_id' => $this->userIds['almacen'],
                'role_id' => $tecnicoRoleId,
                'comments' => 'Despacho SAL-' . $this->year . '-000001 confirmado.',
                'created_at' => $this->dispatchDate,
            ],
        ]);

        $pendingItems = [];
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ([3, 4] as $index) {
            $product = $this->products[$index];
            $pendingItems[] = [
                'product_id' => $product['id'],
                'qty_requested' => $index === 3 ? '5.000' : '10.000',
                'qty_approved' => '0.000',
                'qty_proposed' => '0.000',
                'qty_authorized' => '0.000',
                'qty_delivered' => '0.000',
                'stock_at_request' => number_format($product['qty'], 3, '.', ''),
                'status' => 'PENDIENTE',
                'notes' => null,
            ];
        }

        $pending = $this->createRequest([
            'code' => 'SOL-' . $this->year . '-000002',
            'correspondence_number' => 'DDE-' . $this->year . '-00124',
            'applicant_id' => $applicantId,
            'area_id' => $areaId,
            'office' => 'Recursos Humanos',
            'justification' => 'Reposición de material para archivo y atención de ventanilla.',
            'route_id' => $routeId,
            'current_step' => 1,
            'status' => 'EN_APROBACION',
            'submitted_at' => $pendingDate,
            'approved_at' => null,
            'closed_at' => null,
            'rejection_reason' => null,
            'observation' => null,
            'printed_at' => null,
            'print_count' => 0,
            'created_at' => $pendingDate,
        ], $pendingItems, [
            ['step_order' => 1, 'approver_user_id' => null, 'role_id' => $jefeRoleId, 'action' => 'PENDIENTE', 'action_at' => null, 'comments' => null, 'signature_hash' => null, 'ip' => null],
            ['step_order' => 2, 'approver_user_id' => null, 'role_id' => $tecnicoRoleId, 'action' => 'PENDIENTE', 'action_at' => null, 'comments' => null, 'signature_hash' => null, 'ip' => null],
            ['step_order' => 3, 'approver_user_id' => null, 'role_id' => $uaaRoleId, 'action' => 'PENDIENTE', 'action_at' => null, 'comments' => null, 'signature_hash' => null, 'ip' => null],
        ], [
            [
                'from_state' => 'BORRADOR',
                'to_state' => 'EN_APROBACION',
                'actor_id' => $applicantId,
                'role_id' => $applicantRoleId,
                'comments' => 'Solicitud enviada a aprobación.',
                'created_at' => $pendingDate,
            ],
        ]);

        $approvedItems = [];
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ([5, 6] as $index) {
            $product = $this->products[$index];
            $quantity = $index === 5 ? '3.000' : '12.000';
            $approvedItems[] = [
                'product_id' => $product['id'],
                'qty_requested' => $quantity,
                'qty_approved' => $quantity,
                'qty_proposed' => $quantity,
                'qty_authorized' => $quantity,
                'qty_delivered' => '0.000',
                'stock_at_request' => number_format($product['qty'], 3, '.', ''),
                'status' => 'APROBADO',
                'notes' => null,
            ];
        }

        $approved = $this->createRequest([
            'code' => 'SOL-' . $this->year . '-000003',
            'correspondence_number' => 'DDE-' . $this->year . '-00125',
            'applicant_id' => $applicantId,
            'area_id' => $areaId,
            'office' => 'Recursos Humanos',
            'justification' => 'Material para cierre de gestión y archivo documental.',
            'route_id' => $routeId,
            'current_step' => 3,
            'status' => 'APROBADA',
            'submitted_at' => $approvedRequestSubmitted,
            'approved_at' => $approvedRequestApproved,
            'closed_at' => null,
            'rejection_reason' => null,
            'observation' => null,
            'printed_at' => null,
            'print_count' => 0,
            'created_at' => $approvedRequestSubmitted,
        ], $approvedItems, [
            [
                'step_order' => 1,
                'approver_user_id' => $this->userIds['jefe_inmediato'],
                'role_id' => $jefeRoleId,
                'action' => 'APROBADO',
                'action_at' => date('Y-m-d H:i:s', strtotime('-3 days 10:00:00')),
                'comments' => 'Necesidad validada para el cierre de gestión.',
                'signature_hash' => hash('sha256', 'seed-approved-step-1'),
                'ip' => '127.0.0.1',
            ],
            [
                'step_order' => 2,
                'approver_user_id' => $this->userIds['almacen'],
                'role_id' => $tecnicoRoleId,
                'action' => 'APROBADO',
                'action_at' => date('Y-m-d H:i:s', strtotime('-3 days 12:00:00')),
                'comments' => 'Existencias verificadas y disponibles.',
                'signature_hash' => hash('sha256', 'seed-approved-step-2'),
                'ip' => '127.0.0.1',
            ],
            [
                'step_order' => 3,
                'approver_user_id' => $this->userIds['jefe_uaa'],
                'role_id' => $uaaRoleId,
                'action' => 'APROBADO',
                'action_at' => $approvedRequestApproved,
                'comments' => 'Cantidades autorizadas para despacho.',
                'signature_hash' => hash('sha256', 'seed-approved-step-3'),
                'ip' => '127.0.0.1',
            ],
        ], [
            [
                'from_state' => 'BORRADOR',
                'to_state' => 'EN_APROBACION',
                'actor_id' => $applicantId,
                'role_id' => $applicantRoleId,
                'comments' => 'Solicitud enviada a aprobación.',
                'created_at' => $approvedRequestSubmitted,
            ],
            [
                'from_state' => 'EN_APROBACION',
                'to_state' => 'APROBADA',
                'actor_id' => $this->userIds['jefe_uaa'],
                'role_id' => $uaaRoleId,
                'comments' => 'Aprobación final completada.',
                'created_at' => $approvedRequestApproved,
            ],
        ]);

        echo "  → 1 atendida, 1 pendiente de aprobación y 1 aprobada lista para despacho.\n";

        return [
            'attended' => $attended['id'],
            'pending' => $pending['id'],
            'approved' => $approved['id'],
        ];
    }

    private function seedDemoDispatch(int $requestId): void
    {
        echo "· Registrando despacho PEPS de demostración...\n";

        $statement = $this->pdo->prepare(
            'SELECT ri.*, p.code AS product_code
             FROM request_items ri
             INNER JOIN products p ON p.id = ri.product_id
             WHERE ri.request_id = ?
             ORDER BY ri.id ASC'
        );
        $statement->execute([$requestId]);
        // Lee el resultado obtenido de la consulta SQL ejecutada.
        $items = $statement->fetchAll();
        if ($items === []) {
            throw new RuntimeException('La solicitud de demostración no tiene ítems para despachar.');
        }

        $total = 0.0;
        // Procesa cada producto por separado para registrar o calcular su movimiento.
        foreach ($items as $item) {
            $product = $this->productsByCode[$item['product_code']] ?? null;
            // Comprueba el resultado recibido y evita continuar con datos inexistentes.
            if ($product === null) {
                throw new RuntimeException('Producto no encontrado en el despacho demo.');
            }
            $total += (float) $item['qty_delivered'] * (float) $product['cost'];
        }

        $this->dispatchNumber = 'SAL-' . $this->year . '-000001';
        $dispatchId = $this->insert('stock_dispatches', [
            'number' => $this->dispatchNumber,
            'request_id' => $requestId,
            'dispatch_date' => $this->dispatchDate,
            'dispatched_by' => $this->userIds['almacen'],
            'received_by' => 'Carlos Quispe Mamani',
            'received_ci' => '3456789',
            'received_signature_at' => date('Y-m-d H:i:s', strtotime('-4 days 16:45:00')),
            'total_value' => number_format($total, 2, '.', ''),
            'status' => 'CONFIRMADO',
            'notes' => 'Entrega de materiales conforme a la solicitud aprobada.',
            'created_at' => $this->dispatchDate,
        ]);
        $this->dispatchId = $dispatchId;

        // Procesa cada producto por separado para registrar o calcular su movimiento.
        foreach ($items as $item) {
            $product = $this->productsByCode[$item['product_code']];
            $quantity = (float) $item['qty_delivered'];
            $unitCost = (float) $product['cost'];
            $lineTotal = $quantity * $unitCost;

            $dispatchItemId = $this->insert('dispatch_items', [
                'dispatch_id' => $dispatchId,
                'request_item_id' => (int) $item['id'],
                'product_id' => (int) $product['id'],
                'qty' => number_format($quantity, 3, '.', ''),
                'unit_cost' => number_format($unitCost, 4, '.', ''),
                'total_value' => number_format($lineTotal, 2, '.', ''),
            ]);

            $this->insert('layer_consumptions', [
                'dispatch_item_id' => $dispatchItemId,
                'layer_id' => $this->layerIds[(int) $product['id']],
                'qty' => number_format($quantity, 3, '.', ''),
                'unit_cost' => number_format($unitCost, 4, '.', ''),
                'total_value' => number_format($lineTotal, 2, '.', ''),
            ]);

            $newRemaining = (float) $product['qty'] - $quantity;
            $this->update('stock_layers', [
                'remaining_qty' => number_format($newRemaining, 3, '.', ''),
                'status' => $newRemaining <= 0.0001 ? 'AGOTADA' : 'ABIERTA',
            ], 'id = ?', [$this->layerIds[(int) $product['id']]]);

            $newQty = (float) $product['qty'] - $quantity;
            $newValue = (float) $product['value'] - $lineTotal;
            $this->update('products', [
                'stock_qty' => number_format($newQty, 3, '.', ''),
                'stock_value' => number_format($newValue, 2, '.', ''),
                'status' => $newQty <= 0.0001 ? 'INACTIVO' : 'ACTIVO',
            ], 'id = ?', [(int) $product['id']]);

            $this->productsByCode[$item['product_code']]['qty'] = $newQty;
            $this->productsByCode[$item['product_code']]['value'] = $newValue;

            $this->insert('kardex_movements', [
                'product_id' => (int) $product['id'],
                'movement_date' => $this->dispatchDate,
                'doc_type' => 'SALIDA',
                'doc_id' => $dispatchId,
                'doc_item_id' => $dispatchItemId,
                'reference' => $this->dispatchNumber,
                'qty_in' => '0.000',
                'qty_out' => number_format($quantity, 3, '.', ''),
                'unit_cost_in' => '0.0000',
                'unit_cost_out' => number_format($unitCost, 4, '.', ''),
                'total_in' => '0.00',
                'total_out' => number_format($lineTotal, 2, '.', ''),
                'balance_qty' => number_format($newQty, 3, '.', ''),
                'balance_value' => number_format($newValue, 2, '.', ''),
                'balance_unit_cost' => $newQty > 0 ? number_format($newValue / $newQty, 4, '.', '') : '0.0000',
                'created_by' => $this->userIds['almacen'],
                'created_at' => $this->dispatchDate,
            ]);

            $this->update('request_items', [
                'qty_delivered' => number_format($quantity, 3, '.', ''),
                'status' => 'ENTREGADO',
            ], 'id = ?', [(int) $item['id']]);
        }

        echo '  → ' . $this->dispatchNumber . ' por Bs ' . number_format($total, 2, '.', ',') . ".\n";
    }

    private function seedDemoAdjustment(): void
    {
        echo "· Registrando ajuste de inventario pendiente de firmas...\n";

        $product = $this->productsByCode[$this->products[3]['code']];
        $quantity = 1.0;
        $unitCost = (float) $product['cost'];
        $lineTotal = $quantity * $unitCost;
        $this->adjustmentNumber = 'AJ-' . $this->year . '-000001';

        $adjustmentId = $this->insert('adjustments', [
            'number' => $this->adjustmentNumber,
            'type' => 'FALTANTE',
            'reason' => 'Diferencia detectada en conteo físico de material de papelería.',
            'act_number' => 'ACTA-AJ-' . $this->year . '-001',
            'adjustment_date' => $this->adjustmentDate,
            'status' => 'EN_REVISION',
            'approved_almacenes_by' => null,
            'approved_almacenes_at' => null,
            'approved_contrataciones_by' => null,
            'approved_contrataciones_at' => null,
            'approved_admin_by' => null,
            'approved_admin_at' => null,
            'created_by' => $this->userIds['almacen'],
            'created_at' => $this->adjustmentDate,
        ]);
        $this->adjustmentId = $adjustmentId;

        $itemId = $this->insert('adjustment_items', [
            'adjustment_id' => $adjustmentId,
            'product_id' => (int) $product['id'],
            'qty' => number_format($quantity, 3, '.', ''),
            'unit_cost' => number_format($unitCost, 4, '.', ''),
            'total_value' => number_format($lineTotal, 2, '.', ''),
            'notes' => 'Faltante identificado en el conteo físico.',
        ]);

        $newRemaining = (float) $product['qty'] - $quantity;
        $this->update('stock_layers', [
            'remaining_qty' => number_format($newRemaining, 3, '.', ''),
            'status' => $newRemaining <= 0.0001 ? 'AGOTADA' : 'ABIERTA',
        ], 'id = ?', [$this->layerIds[(int) $product['id']]]);

        $newQty = (float) $product['qty'] - $quantity;
        $newValue = (float) $product['value'] - $lineTotal;
        $this->update('products', [
            'stock_qty' => number_format($newQty, 3, '.', ''),
            'stock_value' => number_format($newValue, 2, '.', ''),
            'status' => $newQty <= 0.0001 ? 'INACTIVO' : 'ACTIVO',
        ], 'id = ?', [(int) $product['id']]);

        $this->productsByCode[$product['code']]['qty'] = $newQty;
        $this->productsByCode[$product['code']]['value'] = $newValue;

        $this->insert('kardex_movements', [
            'product_id' => (int) $product['id'],
            'movement_date' => $this->adjustmentDate,
            'doc_type' => 'AJUSTE',
            'doc_id' => $adjustmentId,
            'doc_item_id' => $itemId,
            'reference' => $this->adjustmentNumber,
            'qty_in' => '0.000',
            'qty_out' => number_format($quantity, 3, '.', ''),
            'unit_cost_in' => '0.0000',
            'unit_cost_out' => number_format($unitCost, 4, '.', ''),
            'total_in' => '0.00',
            'total_out' => number_format($lineTotal, 2, '.', ''),
            'balance_qty' => number_format($newQty, 3, '.', ''),
            'balance_value' => number_format($newValue, 2, '.', ''),
            'balance_unit_cost' => $newQty > 0 ? number_format($newValue / $newQty, 4, '.', '') : '0.0000',
            'created_by' => $this->userIds['almacen'],
            'created_at' => $this->adjustmentDate,
        ]);

        echo '  → ' . $this->adjustmentNumber . " pendiente de las tres firmas.\n";
    }

    private function seedPeriodSettingsSequences(): void
    {
        echo "· Abriendo periodo, secuencias y configuración...\n";

        $period = $this->pdo->prepare(
            'INSERT INTO period_closes (year, month, status, total_qty_snapshot, total_value_snapshot)
             VALUES (?, ?, ?, 0, 0)
             ON DUPLICATE KEY UPDATE status = VALUES(status)'
        );
        $period->execute([$this->year, (int) date('n'), 'ABIERTO']);

        $settings = [
            'institucion.nombre' => 'Dirección Departamental de Educación - Cochabamba',
            'institucion.sigla' => 'DDE-CBBA',
            'impresion.offsetX_mm' => 0,
            'impresion.offsetY_mm' => 0,
            'impresion.escala' => 1,
            'impresion.hoja' => 'letter',
            'general.zona_horaria' => 'America/La_Paz',
            'general.moneda' => 'BOB',
            'alertas.stock_bajo' => 1,
            'seguridad.sesion_horas' => 8,
        ];
        $settingStatement = $this->pdo->prepare(
            'INSERT INTO settings (`config_key`, `value`) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)'
        );
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($settings as $key => $value) {
            $settingStatement->execute([$key, $this->encode(['value' => $value])]);
        }

        $sequences = [
            'ING' => 1,
            'SOL' => 3,
            'SAL' => 1,
            'AJ' => 1,
        ];
        $sequenceStatement = $this->pdo->prepare(
            'INSERT INTO sequences (sequence_key, year, current_value) VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE current_value = VALUES(current_value)'
        );
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($sequences as $key => $value) {
            $sequenceStatement->execute([$key, $this->year, $value]);
        }
    }

    /**
     * @param array{attended:int,pending:int,approved:int} $requestIds
     */
    private function seedAuditLogs(array $requestIds): void
    {
        echo "· Registrando trazabilidad inicial...\n";

        $this->insert('audit_log', [
            'user_id' => $this->userIds['admin'],
            'action' => 'SEED',
            'entity' => 'system',
            'entity_id' => null,
            'before' => null,
            'after' => $this->encode([
                'productos' => count($this->products),
                'usuarios' => count($this->userIds),
                'ingreso' => $this->openingNumber,
            ]),
            'ip' => '127.0.0.1',
            'user_agent' => 'Seeder SIGA-DDE',
            'created_at' => $this->now,
        ]);

        $records = [
            [
                'user_id' => $this->userIds['admin'],
                'action' => 'INGRESO_CONFIRMADO',
                'entity' => 'stock_entries',
                'entity_id' => $this->openingEntryId,
                'after' => ['number' => $this->openingNumber, 'total' => number_format($this->openingTotal, 2, '.', '')],
                'created_at' => $this->openingDate,
            ],
            [
                'user_id' => $this->userIds['solicitante'],
                'action' => 'SOLICITUD_CREADA',
                'entity' => 'requests',
                'entity_id' => $requestIds['attended'],
                'after' => ['code' => 'SOL-' . $this->year . '-000001'],
                'created_at' => date('Y-m-d H:i:s', strtotime('-5 days 09:30:00')),
            ],
            [
                'user_id' => $this->userIds['jefe_uaa'],
                'action' => 'SOLICITUD_APROBADA',
                'entity' => 'requests',
                'entity_id' => $requestIds['attended'],
                'after' => ['code' => 'SOL-' . $this->year . '-000001'],
                'created_at' => date('Y-m-d H:i:s', strtotime('-5 days 14:20:00')),
            ],
            [
                'user_id' => $this->userIds['almacen'],
                'action' => 'DESPACHO_CONFIRMADO',
                'entity' => 'stock_dispatches',
                'entity_id' => $this->dispatchId,
                'after' => ['number' => $this->dispatchNumber],
                'created_at' => $this->dispatchDate,
            ],
            [
                'user_id' => $this->userIds['almacen'],
                'action' => 'AJUSTE_CREADO',
                'entity' => 'adjustments',
                'entity_id' => $this->adjustmentId,
                'after' => ['number' => $this->adjustmentNumber],
                'created_at' => $this->adjustmentDate,
            ],
            [
                'user_id' => $this->userIds['solicitante'],
                'action' => 'SOLICITUD_CREADA',
                'entity' => 'requests',
                'entity_id' => $requestIds['pending'],
                'after' => ['code' => 'SOL-' . $this->year . '-000002'],
                'created_at' => date('Y-m-d H:i:s', strtotime('-2 days 11:15:00')),
            ],
            [
                'user_id' => $this->userIds['solicitante'],
                'action' => 'SOLICITUD_CREADA',
                'entity' => 'requests',
                'entity_id' => $requestIds['approved'],
                'after' => ['code' => 'SOL-' . $this->year . '-000003'],
                'created_at' => date('Y-m-d H:i:s', strtotime('-3 days 09:00:00')),
            ],
        ];

        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($records as $record) {
            $this->insert('audit_log', [
                'user_id' => $record['user_id'],
                'action' => $record['action'],
                'entity' => $record['entity'],
                'entity_id' => $record['entity_id'],
                'before' => null,
                'after' => $this->encode($record['after']),
                'ip' => '127.0.0.1',
                'user_agent' => 'Seeder SIGA-DDE',
                'created_at' => $record['created_at'],
            ]);
        }
    }

    /**
     * @param array<int,array<string,mixed>> $items
     * @param array<int,array<string,mixed>> $approvals
     * @param array<int,array<string,mixed>> $history
     * @return array{id:int,item_ids:array<int,int>}
     */
    private function createRequest(array $request, array $items, array $approvals, array $history): array
    {
        $requestId = $this->insert('requests', $request);
        $itemIds = [];
        // Procesa cada producto por separado para registrar o calcular su movimiento.
        foreach ($items as $item) {
            $itemIds[] = $this->insert('request_items', array_merge(['request_id' => $requestId], $item));
        }
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($approvals as $approval) {
            $this->insert('request_approvals', array_merge(['request_id' => $requestId], $approval));
        }
        // Recorre los elementos de la colección y procesa cada registro.
        foreach ($history as $entry) {
            $this->insert('request_history', array_merge(['request_id' => $requestId], $entry));
        }
        return ['id' => $requestId, 'item_ids' => $itemIds];
    }

    private function insert(string $table, array $data): int
    {
        $columns = array_keys($data);
        // Define los datos que se almacenarán en el registro nuevo.
        $sql = 'INSERT INTO `' . $table . '` (`' . implode('`, `', $columns) . '`) VALUES ('
            . implode(', ', array_fill(0, count($columns), '?')) . ')';
        $statement = $this->pdo->prepare($sql);
        $statement->execute(array_values($data));
        return (int) $this->pdo->lastInsertId();
    }

    private function update(string $table, array $data, string $where, array $params = []): void
    {
        if ($data === []) {
            return;
        }
        $sets = [];
        // Recorre los elementos de la colección y procesa cada registro.
        foreach (array_keys($data) as $column) {
            $sets[] = '`' . $column . '` = ?';
        }
        // Define los campos que serán actualizados en la base de datos.
        $sql = 'UPDATE `' . $table . '` SET ' . implode(', ', $sets) . ' WHERE ' . $where;
        $statement = $this->pdo->prepare($sql);
        $statement->execute(array_merge(array_values($data), $params));
    }

    private function encode(mixed $value): string
    {
        return json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: 'null';
    }
}

$options = getopt('', ['force']);
$force = isset($options['force']);

// Ejecuta el proceso controlando posibles errores durante la operación.
try {
    $pdo = Database::connection();
    $seeder = new Seeder($pdo);
    $existingUsers = $seeder->userCount();
// Captura el error para informar el problema y mantener los datos consistentes.
} catch (Throwable $exception) {
    fwrite(STDERR, "ERROR: no se pudo conectar con la base de datos o falta el esquema.\n");
    fwrite(STDERR, "Importe primero database/schema.sql en MySQL Workbench.\n");
    fwrite(STDERR, $exception->getMessage() . "\n");
    exit(1);
}

// Comprueba el resultado recibido y evita continuar con datos inexistentes.
if ($existingUsers > 0 && !$force) {
    fwrite(STDERR, "La base de datos ya contiene usuarios. Use --force para limpiar y recargar los datos demo.\n");
    exit(1);
}

// Ejecuta el proceso controlando posibles errores durante la operación.
try {
    echo "SIGA-DDE · Cargando datos iniciales\n";
    $seeder->clear();
    $seeder->run();
    echo "\nSeed completado correctamente.\n";
    echo "Usuarios demo:\n";
    echo "  admin / admin123                 (Administrador)\n";
    echo "  almacen / almacen123             (Técnica de Almacenes)\n";
    echo "  solicitante / sol123             (Solicitante)\n";
    echo "  jefe_inmediato / jefe123         (Inmediato Superior)\n";
    echo "  jefe_uaa / uaa123                (Jefatura de UAA)\n";
    echo "  auditor / auditor123             (Auditor)\n";
    echo "  consulta / consulta123           (Consulta)\n";
    echo "\nDatos demo: 181 productos, ingreso de apertura, 3 solicitudes, 1 despacho PEPS y 1 ajuste pendiente.\n";
// Captura el error para informar el problema y mantener los datos consistentes.
} catch (Throwable $exception) {
    fwrite(STDERR, "ERROR durante la carga de datos: " . $exception->getMessage() . "\n");
    fwrite(STDERR, $exception->getFile() . ':' . $exception->getLine() . "\n");
    exit(1);
}
