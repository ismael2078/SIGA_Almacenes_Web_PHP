-- Estructura y datos de SIGA-DDE. Los comentarios describen las secciones, no cambian registros.
-- =====================================================================
-- SIGA-DDE · Sistema Integrado de Gestión de Almacenes
-- Esquema MySQL 8.x para importar directamente en MySQL Workbench
-- Conversión del esquema PostgreSQL/Drizzle original
-- Codificación: utf8mb4 / utf8mb4_unicode_ci
-- =====================================================================

CREATE DATABASE IF NOT EXISTS `siga_dde`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `siga_dde`;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- 1. CATÁLOGOS
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `categories`;
-- Tabla categories: almacena información de este componente del sistema.
-- Función: Clasificación principal del catálogo de productos.
CREATE TABLE `categories` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(20) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `description` TEXT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_categories_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `subcategories`;
-- Tabla subcategories: almacena información de este componente del sistema.
-- Función: Clasificación detallada vinculada a las categorías.
CREATE TABLE `subcategories` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_id` BIGINT UNSIGNED NOT NULL,
  `code` VARCHAR(20) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_subcategories_category_code` (`category_id`, `code`),
  CONSTRAINT `fk_subcategories_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `units`;
-- Tabla units: almacena información de este componente del sistema.
-- Función: Unidades de medida utilizadas en los movimientos.
CREATE TABLE `units` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(10) NOT NULL,
  `name` VARCHAR(60) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_units_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `locations`;
-- Tabla locations: almacena información de este componente del sistema.
-- Función: Ubicaciones físicas de los productos dentro del almacén.
CREATE TABLE `locations` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(30) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `warehouse` VARCHAR(80) NULL,
  `aisle` VARCHAR(20) NULL,
  `shelf` VARCHAR(20) NULL,
  `level` VARCHAR(20) NULL,
  `description` TEXT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_locations_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `suppliers`;
-- Tabla suppliers: almacena información de este componente del sistema.
-- Función: Proveedores registrados para los ingresos de materiales.
CREATE TABLE `suppliers` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nit` VARCHAR(30) NULL,
  `name` VARCHAR(200) NOT NULL,
  `contact_name` VARCHAR(120) NULL,
  `phone` VARCHAR(50) NULL,
  `email` VARCHAR(120) NULL,
  `address` TEXT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_suppliers_nit` (`nit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `areas`;
-- Tabla areas: almacena información de este componente del sistema.
-- Función: Dependencias institucionales que solicitan materiales.
CREATE TABLE `areas` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `parent_id` BIGINT UNSIGNED NULL,
  `code` VARCHAR(30) NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `type` VARCHAR(30) NOT NULL DEFAULT 'UNIDAD',
  `jefe_uaa_id` BIGINT UNSIGNED NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_areas_code` (`code`),
  KEY `idx_areas_parent` (`parent_id`),
  CONSTRAINT `fk_areas_parent` FOREIGN KEY (`parent_id`) REFERENCES `areas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `products`;
-- Tabla products: almacena información de este componente del sistema.
-- Función: Catálogo de artículos con existencias y valores referenciales.
CREATE TABLE `products` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(30) NOT NULL,
  `name` VARCHAR(200) NOT NULL,
  `description` TEXT NULL,
  `brand` VARCHAR(80) NULL,
  `model` VARCHAR(80) NULL,
  `barcode` VARCHAR(50) NULL,
  `category_id` BIGINT UNSIGNED NOT NULL,
  `subcategory_id` BIGINT UNSIGNED NOT NULL,
  `unit_id` BIGINT UNSIGNED NOT NULL,
  `location_id` BIGINT UNSIGNED NULL,
  `min_stock` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `max_stock` DECIMAL(14,3) NULL DEFAULT 0.000,
  `reference_cost` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `stock_qty` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `stock_value` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `status` ENUM('ACTIVO','INACTIVO','ARCHIVADO') NOT NULL DEFAULT 'ACTIVO',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `deactivated_at` DATETIME NULL,
  `purged_at` DATETIME NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_products_code` (`code`),
  KEY `idx_products_status` (`status`),
  KEY `idx_products_category` (`category_id`, `subcategory_id`),
  KEY `idx_products_name` (`name`),
  CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_products_subcategory` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_products_unit` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_products_location` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 2. SEGURIDAD Y USUARIOS
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `roles`;
-- Tabla roles: almacena información de este componente del sistema.
-- Función: Perfiles que determinan responsabilidades dentro del sistema.
CREATE TABLE `roles` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(30) NOT NULL,
  `name` VARCHAR(80) NOT NULL,
  `description` TEXT NULL,
  `is_system` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_roles_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `permissions`;
-- Tabla permissions: almacena información de este componente del sistema.
-- Función: Acciones protegidas que puede ejecutar cada perfil.
CREATE TABLE `permissions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(60) NOT NULL,
  `module` VARCHAR(40) NOT NULL,
  `description` VARCHAR(200) NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_permissions_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `role_permissions`;
-- Tabla role_permissions: almacena información de este componente del sistema.
-- Función: Relación entre roles y permisos asignados.
CREATE TABLE `role_permissions` (
  `role_id` BIGINT UNSIGNED NOT NULL,
  `permission_id` BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (`role_id`, `permission_id`),
  CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_role_permissions_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `users`;
-- Tabla users: almacena información de este componente del sistema.
-- Función: Cuentas del personal, datos de acceso, área y responsable inmediato.
CREATE TABLE `users` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(40) NOT NULL,
  `email` VARCHAR(120) NULL,
  `password_hash` VARCHAR(200) NOT NULL,
  `full_name` VARCHAR(200) NOT NULL,
  `ci` VARCHAR(30) NULL,
  `position` VARCHAR(120) NULL,
  `office` VARCHAR(120) NULL,
  `area_id` BIGINT UNSIGNED NULL,
  `jefe_inmediato_id` BIGINT UNSIGNED NULL,
  `role_id` BIGINT UNSIGNED NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `must_change_password` TINYINT(1) NOT NULL DEFAULT 1,
  `failed_attempts` INT NOT NULL DEFAULT 0,
  `locked_until` DATETIME NULL,
  `last_login_at` DATETIME NULL,
  `password_changed_at` DATETIME NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_users_username` (`username`),
  KEY `idx_users_area` (`area_id`),
  KEY `idx_users_role` (`role_id`),
  KEY `idx_users_jefe` (`jefe_inmediato_id`),
  CONSTRAINT `fk_users_area` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_users_jefe` FOREIGN KEY (`jefe_inmediato_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `user_roles`;
-- Tabla user_roles: almacena información de este componente del sistema.
CREATE TABLE `user_roles` (
  `user_id` BIGINT UNSIGNED NOT NULL,
  `role_id` BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (`user_id`, `role_id`),
  CONSTRAINT `fk_user_roles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_user_roles_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `user_permissions`;
-- Tabla user_permissions: almacena información de este componente del sistema.
CREATE TABLE `user_permissions` (
  `user_id` BIGINT UNSIGNED NOT NULL,
  `permission_id` BIGINT UNSIGNED NOT NULL,
  `granted` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`user_id`, `permission_id`),
  CONSTRAINT `fk_user_permissions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_user_permissions_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `delegations`;
-- Tabla delegations: almacena información de este componente del sistema.
CREATE TABLE `delegations` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `from_user_id` BIGINT UNSIGNED NOT NULL,
  `to_user_id` BIGINT UNSIGNED NOT NULL,
  `starts_at` DATETIME NOT NULL,
  `ends_at` DATETIME NOT NULL,
  `reason` TEXT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_delegations_from` (`from_user_id`),
  KEY `idx_delegations_to` (`to_user_id`),
  CONSTRAINT `fk_delegations_from` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_delegations_to` FOREIGN KEY (`to_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `sessions`;
-- Tabla sessions: almacena información de este componente del sistema.
CREATE TABLE `sessions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `token_hash` VARCHAR(200) NOT NULL,
  `ip` VARCHAR(60) NULL,
  `user_agent` TEXT NULL,
  `expires_at` DATETIME NOT NULL,
  `revoked_at` DATETIME NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sessions_token` (`token_hash`),
  KEY `idx_sessions_user` (`user_id`),
  KEY `idx_sessions_expiry` (`expires_at`),
  CONSTRAINT `fk_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 3. INGRESOS Y CAPAS PEPS
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `stock_entries`;
-- Tabla stock_entries: almacena información de este componente del sistema.
-- Función: Documentos de ingreso al almacén.
CREATE TABLE `stock_entries` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `number` VARCHAR(30) NOT NULL,
  `type` ENUM('APERTURA','COMPRA','DONACION','DEVOLUCION','AJUSTE_SOBRANTE','RECLASIFICACION') NOT NULL,
  `supplier_id` BIGINT UNSIGNED NULL,
  `doc_type` VARCHAR(40) NULL,
  `doc_number` VARCHAR(60) NULL,
  `doc_date` DATETIME NULL,
  `entry_date` DATETIME NOT NULL,
  `posted_at` DATETIME NULL,
  `total_amount` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `notes` TEXT NULL,
  `status` ENUM('BORRADOR','CONFIRMADO','ANULADO') NOT NULL DEFAULT 'BORRADOR',
  `voided_by` BIGINT UNSIGNED NULL,
  `voided_at` DATETIME NULL,
  `void_reason` TEXT NULL,
  `created_by` BIGINT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_stock_entries_number` (`number`),
  KEY `idx_stock_entries_date` (`entry_date`),
  KEY `idx_stock_entries_status` (`status`),
  CONSTRAINT `fk_stock_entries_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_stock_entries_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_stock_entries_voided_by` FOREIGN KEY (`voided_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `stock_entry_items`;
-- Tabla stock_entry_items: almacena información de este componente del sistema.
-- Función: Detalle de productos, cantidades y costos ingresados.
CREATE TABLE `stock_entry_items` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `entry_id` BIGINT UNSIGNED NOT NULL,
  `product_id` BIGINT UNSIGNED NOT NULL,
  `location_id` BIGINT UNSIGNED NULL,
  `quantity` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `total` DECIMAL(16,2) NOT NULL,
  `notes` TEXT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entry_items_entry` (`entry_id`),
  KEY `idx_entry_items_product` (`product_id`),
  CONSTRAINT `fk_entry_items_entry` FOREIGN KEY (`entry_id`) REFERENCES `stock_entries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_entry_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_entry_items_location` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `stock_layers`;
-- Tabla stock_layers: almacena información de este componente del sistema.
-- Función: Capas de ingreso que permiten valorar existencias según PEPS.
CREATE TABLE `stock_layers` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` BIGINT UNSIGNED NOT NULL,
  `entry_id` BIGINT UNSIGNED NULL,
  `entry_item_id` BIGINT UNSIGNED NULL,
  `layer_date` DATETIME NOT NULL,
  `sequence` INT NOT NULL DEFAULT 1,
  `original_qty` DECIMAL(14,3) NOT NULL,
  `remaining_qty` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'ABIERTA',
  PRIMARY KEY (`id`),
  KEY `idx_layers_product_date` (`product_id`, `layer_date`, `sequence`),
  KEY `idx_layers_entry` (`entry_id`),
  CONSTRAINT `fk_layers_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_layers_entry` FOREIGN KEY (`entry_id`) REFERENCES `stock_entries` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_layers_entry_item` FOREIGN KEY (`entry_item_id`) REFERENCES `stock_entry_items` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 4. RUTAS DE APROBACIÓN Y SOLICITUDES
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `approval_routes`;
-- Tabla approval_routes: almacena información de este componente del sistema.
-- Función: Rutas institucionales de aprobación definidas por área.
CREATE TABLE `approval_routes` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `area_id` BIGINT UNSIGNED NULL,
  `name` VARCHAR(100) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_routes_area` (`area_id`),
  CONSTRAINT `fk_routes_area` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `approval_route_steps`;
-- Tabla approval_route_steps: almacena información de este componente del sistema.
-- Función: Orden y rol responsable de cada etapa de aprobación.
CREATE TABLE `approval_route_steps` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `route_id` BIGINT UNSIGNED NOT NULL,
  `step_order` INT NOT NULL,
  `role_id` BIGINT UNSIGNED NOT NULL,
  `sla_hours` INT NOT NULL DEFAULT 48,
  `is_required` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_route_step` (`route_id`, `step_order`),
  CONSTRAINT `fk_route_steps_route` FOREIGN KEY (`route_id`) REFERENCES `approval_routes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_route_steps_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `requests`;
-- Tabla requests: almacena información de este componente del sistema.
-- Función: Cabeceras de pedidos con estado, solicitante y ruta.
CREATE TABLE `requests` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(30) NOT NULL,
  `correspondence_number` VARCHAR(60) NOT NULL,
  `applicant_id` BIGINT UNSIGNED NOT NULL,
  `area_id` BIGINT UNSIGNED NOT NULL,
  `office` VARCHAR(120) NULL,
  `justification` TEXT NULL,
  `route_id` BIGINT UNSIGNED NULL,
  `current_step` INT NOT NULL DEFAULT 0,
  `status` ENUM('BORRADOR','EN_APROBACION','APROBADA','OBSERVADA','ATENDIDA','RECHAZADA','ANULADA') NOT NULL DEFAULT 'BORRADOR',
  `submitted_at` DATETIME NULL,
  `approved_at` DATETIME NULL,
  `closed_at` DATETIME NULL,
  `rejection_reason` TEXT NULL,
  `observation` TEXT NULL,
  `printed_at` DATETIME NULL,
  `print_count` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_requests_code` (`code`),
  UNIQUE KEY `uk_requests_correspondence` (`correspondence_number`),
  KEY `idx_requests_applicant` (`applicant_id`),
  KEY `idx_requests_area` (`area_id`),
  KEY `idx_requests_status` (`status`),
  KEY `idx_requests_created` (`created_at`),
  CONSTRAINT `fk_requests_applicant` FOREIGN KEY (`applicant_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_requests_area` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_requests_route` FOREIGN KEY (`route_id`) REFERENCES `approval_routes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `request_items`;
-- Tabla request_items: almacena información de este componente del sistema.
-- Función: Productos y cantidades solicitadas y autorizadas.
CREATE TABLE `request_items` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `request_id` BIGINT UNSIGNED NOT NULL,
  `product_id` BIGINT UNSIGNED NOT NULL,
  `qty_requested` DECIMAL(14,3) NOT NULL,
  `qty_approved` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `qty_proposed` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `qty_authorized` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `qty_delivered` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `stock_at_request` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `status` VARCHAR(20) NOT NULL DEFAULT 'PENDIENTE',
  `notes` TEXT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_request_items_request` (`request_id`),
  KEY `idx_request_items_product` (`product_id`),
  CONSTRAINT `fk_request_items_request` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_request_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `request_approvals`;
-- Tabla request_approvals: almacena información de este componente del sistema.
-- Función: Decisiones, observaciones y responsables de cada etapa.
CREATE TABLE `request_approvals` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `request_id` BIGINT UNSIGNED NOT NULL,
  `step_order` INT NOT NULL,
  `approver_user_id` BIGINT UNSIGNED NULL,
  `role_id` BIGINT UNSIGNED NOT NULL,
  `action` VARCHAR(20) NOT NULL DEFAULT 'PENDIENTE',
  `action_at` DATETIME NULL,
  `comments` TEXT NULL,
  `signature_hash` VARCHAR(200) NULL,
  `ip` VARCHAR(60) NULL,
  PRIMARY KEY (`id`),
  KEY `idx_request_approvals_request` (`request_id`, `step_order`),
  KEY `idx_request_approvals_role` (`role_id`, `action`),
  CONSTRAINT `fk_request_approvals_request` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_request_approvals_user` FOREIGN KEY (`approver_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_request_approvals_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `request_history`;
-- Tabla request_history: almacena información de este componente del sistema.
-- Función: Historial de cambios de estado de las solicitudes.
CREATE TABLE `request_history` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `request_id` BIGINT UNSIGNED NOT NULL,
  `from_state` VARCHAR(30) NOT NULL,
  `to_state` VARCHAR(30) NOT NULL,
  `actor_id` BIGINT UNSIGNED NOT NULL,
  `role_id` BIGINT UNSIGNED NOT NULL,
  `comments` TEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_request_history_request` (`request_id`, `created_at`),
  CONSTRAINT `fk_request_history_request` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_request_history_actor` FOREIGN KEY (`actor_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_request_history_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 5. DESPACHOS / SALIDAS PEPS
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `stock_dispatches`;
-- Tabla stock_dispatches: almacena información de este componente del sistema.
-- Función: Documentos de salida y entregas de inventario.
CREATE TABLE `stock_dispatches` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `number` VARCHAR(30) NOT NULL,
  `request_id` BIGINT UNSIGNED NOT NULL,
  `dispatch_date` DATETIME NOT NULL,
  `dispatched_by` BIGINT UNSIGNED NOT NULL,
  `received_by` VARCHAR(200) NULL,
  `received_ci` VARCHAR(30) NULL,
  `received_signature_at` DATETIME NULL,
  `total_value` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `status` ENUM('BORRADOR','CONFIRMADO','ANULADO') NOT NULL DEFAULT 'BORRADOR',
  `voided_by` BIGINT UNSIGNED NULL,
  `voided_at` DATETIME NULL,
  `void_reason` TEXT NULL,
  `notes` TEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dispatches_number` (`number`),
  KEY `idx_dispatches_request` (`request_id`),
  KEY `idx_dispatches_date` (`dispatch_date`),
  KEY `idx_dispatches_status` (`status`),
  CONSTRAINT `fk_dispatches_request` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_dispatches_user` FOREIGN KEY (`dispatched_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_dispatches_voided` FOREIGN KEY (`voided_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `dispatch_items`;
-- Tabla dispatch_items: almacena información de este componente del sistema.
CREATE TABLE `dispatch_items` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `dispatch_id` BIGINT UNSIGNED NOT NULL,
  `request_item_id` BIGINT UNSIGNED NOT NULL,
  `product_id` BIGINT UNSIGNED NOT NULL,
  `qty` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `total_value` DECIMAL(16,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dispatch_items_dispatch` (`dispatch_id`),
  KEY `idx_dispatch_items_product` (`product_id`),
  CONSTRAINT `fk_dispatch_items_dispatch` FOREIGN KEY (`dispatch_id`) REFERENCES `stock_dispatches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_dispatch_items_request_item` FOREIGN KEY (`request_item_id`) REFERENCES `request_items` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_dispatch_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `layer_consumptions`;
-- Tabla layer_consumptions: almacena información de este componente del sistema.
CREATE TABLE `layer_consumptions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `dispatch_item_id` BIGINT UNSIGNED NOT NULL,
  `layer_id` BIGINT UNSIGNED NOT NULL,
  `qty` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `total_value` DECIMAL(16,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_consumptions_item` (`dispatch_item_id`),
  KEY `idx_consumptions_layer` (`layer_id`),
  CONSTRAINT `fk_consumptions_item` FOREIGN KEY (`dispatch_item_id`) REFERENCES `dispatch_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_consumptions_layer` FOREIGN KEY (`layer_id`) REFERENCES `stock_layers` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 6. KARDEX, AJUSTES, DEVOLUCIONES Y ARQUEO
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `kardex_movements`;
-- Tabla kardex_movements: almacena información de este componente del sistema.
-- Función: Movimientos históricos de entrada, salida y saldo.
CREATE TABLE `kardex_movements` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` BIGINT UNSIGNED NOT NULL,
  `movement_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `doc_type` VARCHAR(20) NOT NULL,
  `doc_id` BIGINT UNSIGNED NULL,
  `doc_item_id` BIGINT UNSIGNED NULL,
  `reference` VARCHAR(60) NULL,
  `qty_in` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `qty_out` DECIMAL(14,3) NOT NULL DEFAULT 0.000,
  `unit_cost_in` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `unit_cost_out` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `total_in` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `total_out` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `balance_qty` DECIMAL(14,3) NOT NULL,
  `balance_value` DECIMAL(16,2) NOT NULL,
  `balance_unit_cost` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `period_year` INT GENERATED ALWAYS AS (YEAR(`movement_date`)) STORED,
  `period_month` INT GENERATED ALWAYS AS (MONTH(`movement_date`)) STORED,
  `created_by` BIGINT UNSIGNED NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_kardex_product_date` (`product_id`, `movement_date`, `id`),
  KEY `idx_kardex_period` (`period_year`, `period_month`),
  KEY `idx_kardex_doctype` (`doc_type`),
  CONSTRAINT `fk_kardex_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_kardex_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `adjustments`;
-- Tabla adjustments: almacena información de este componente del sistema.
-- Función: Ajustes autorizados sobre las cantidades de inventario.
CREATE TABLE `adjustments` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `number` VARCHAR(30) NOT NULL,
  `type` ENUM('SOBRANTE','FALTANTE') NOT NULL,
  `reason` TEXT NOT NULL,
  `act_number` VARCHAR(60) NULL,
  `adjustment_date` DATETIME NOT NULL,
  `status` ENUM('BORRADOR','EN_REVISION','APROBADO','RECHAZADO','ANULADO') NOT NULL DEFAULT 'BORRADOR',
  `approved_almacenes_by` BIGINT UNSIGNED NULL,
  `approved_almacenes_at` DATETIME NULL,
  `approved_contrataciones_by` BIGINT UNSIGNED NULL,
  `approved_contrataciones_at` DATETIME NULL,
  `approved_admin_by` BIGINT UNSIGNED NULL,
  `approved_admin_at` DATETIME NULL,
  `created_by` BIGINT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_adjustments_number` (`number`),
  KEY `idx_adjustments_status` (`status`),
  CONSTRAINT `fk_adjustments_created` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_adjustments_almacenes` FOREIGN KEY (`approved_almacenes_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_adjustments_contrataciones` FOREIGN KEY (`approved_contrataciones_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_adjustments_admin` FOREIGN KEY (`approved_admin_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `adjustment_items`;
-- Tabla adjustment_items: almacena información de este componente del sistema.
CREATE TABLE `adjustment_items` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `adjustment_id` BIGINT UNSIGNED NOT NULL,
  `product_id` BIGINT UNSIGNED NOT NULL,
  `qty` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `total_value` DECIMAL(16,2) NOT NULL,
  `notes` TEXT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_adjustment_items_adjustment` (`adjustment_id`),
  CONSTRAINT `fk_adjustment_items_adjustment` FOREIGN KEY (`adjustment_id`) REFERENCES `adjustments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_adjustment_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `stock_returns`;
-- Tabla stock_returns: almacena información de este componente del sistema.
CREATE TABLE `stock_returns` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `number` VARCHAR(30) NOT NULL,
  `dispatch_id` BIGINT UNSIGNED NOT NULL,
  `return_date` DATETIME NOT NULL,
  `reason` TEXT NOT NULL,
  `received_by` BIGINT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_returns_number` (`number`),
  CONSTRAINT `fk_returns_dispatch` FOREIGN KEY (`dispatch_id`) REFERENCES `stock_dispatches` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_returns_received` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `stock_return_items`;
-- Tabla stock_return_items: almacena información de este componente del sistema.
CREATE TABLE `stock_return_items` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `return_id` BIGINT UNSIGNED NOT NULL,
  `product_id` BIGINT UNSIGNED NOT NULL,
  `qty` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `new_layer_id` BIGINT UNSIGNED NULL,
  PRIMARY KEY (`id`),
  KEY `idx_return_items_return` (`return_id`),
  CONSTRAINT `fk_return_items_return` FOREIGN KEY (`return_id`) REFERENCES `stock_returns` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_return_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_return_items_layer` FOREIGN KEY (`new_layer_id`) REFERENCES `stock_layers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `physical_counts`;
-- Tabla physical_counts: almacena información de este componente del sistema.
-- Función: Cabecera de los arqueos o conteos físicos.
CREATE TABLE `physical_counts` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `period_year` INT NOT NULL,
  `period_month` INT NOT NULL,
  `count_date` DATETIME NOT NULL,
  `participants` JSON NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'REGISTRADO',
  `created_by` BIGINT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_physical_counts_period` (`period_year`, `period_month`),
  CONSTRAINT `fk_physical_counts_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `physical_count_items`;
-- Tabla physical_count_items: almacena información de este componente del sistema.
-- Función: Resultados del conteo físico de cada artículo.
CREATE TABLE `physical_count_items` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `count_id` BIGINT UNSIGNED NOT NULL,
  `product_id` BIGINT UNSIGNED NOT NULL,
  `system_qty` DECIMAL(14,3) NOT NULL,
  `counted_qty` DECIMAL(14,3) NOT NULL,
  `difference` DECIMAL(14,3) NOT NULL,
  `unit_cost` DECIMAL(14,4) NOT NULL,
  `difference_value` DECIMAL(16,2) NOT NULL,
  `observations` TEXT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_physical_count_items_count` (`count_id`),
  CONSTRAINT `fk_physical_count_items_count` FOREIGN KEY (`count_id`) REFERENCES `physical_counts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_physical_count_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `period_closes`;
-- Tabla period_closes: almacena información de este componente del sistema.
CREATE TABLE `period_closes` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `year` INT NOT NULL,
  `month` INT NOT NULL,
  `closed_at` DATETIME NULL,
  `closed_by` BIGINT UNSIGNED NULL,
  `total_qty_snapshot` DECIMAL(14,3) NULL DEFAULT 0.000,
  `total_value_snapshot` DECIMAL(16,2) NULL DEFAULT 0.00,
  `status` ENUM('ABIERTO','CERRADO','REABIERTO') NOT NULL DEFAULT 'ABIERTO',
  `reopen_reason` TEXT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_period_closes_year_month` (`year`, `month`),
  CONSTRAINT `fk_period_closes_user` FOREIGN KEY (`closed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 7. TRANSVERSALES
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `audit_log`;
-- Tabla audit_log: almacena información de este componente del sistema.
CREATE TABLE `audit_log` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NULL,
  `action` VARCHAR(60) NOT NULL,
  `entity` VARCHAR(60) NULL,
  `entity_id` BIGINT UNSIGNED NULL,
  `before` JSON NULL,
  `after` JSON NULL,
  `ip` VARCHAR(60) NULL,
  `user_agent` TEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_action` (`action`),
  KEY `idx_audit_created` (`created_at`),
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `sequences`;
-- Tabla sequences: almacena información de este componente del sistema.
CREATE TABLE `sequences` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `sequence_key` VARCHAR(30) NOT NULL,
  `year` INT NOT NULL,
  `current_value` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sequences_key_year` (`sequence_key`, `year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `settings`;
-- Tabla settings: almacena información de este componente del sistema.
CREATE TABLE `settings` (
  `config_key` VARCHAR(80) NOT NULL,
  `value` JSON NULL,
  PRIMARY KEY (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `notifications`;
-- Tabla notifications: almacena información de este componente del sistema.
CREATE TABLE `notifications` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `type` VARCHAR(40) NOT NULL,
  `title` VARCHAR(200) NOT NULL,
  `body` TEXT NULL,
  `link` VARCHAR(255) NULL,
  `read_at` DATETIME NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user` (`user_id`, `read_at`),
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `attachments`;
-- Tabla attachments: almacena información de este componente del sistema.
CREATE TABLE `attachments` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `entity` VARCHAR(60) NOT NULL,
  `entity_id` BIGINT UNSIGNED NOT NULL,
  `file_name` VARCHAR(255) NOT NULL,
  `mime` VARCHAR(100) NULL,
  `size` BIGINT UNSIGNED NULL,
  `storage_path` VARCHAR(500) NOT NULL,
  `uploaded_by` BIGINT UNSIGNED NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_attachments_entity` (`entity`, `entity_id`),
  CONSTRAINT `fk_attachments_user` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `backups`;
-- Tabla backups: almacena información de este componente del sistema.
CREATE TABLE `backups` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `file_name` VARCHAR(255) NOT NULL,
  `size` BIGINT UNSIGNED NULL,
  `type` VARCHAR(20) NOT NULL DEFAULT 'MANUAL',
  `status` VARCHAR(20) NOT NULL DEFAULT 'OK',
  `notes` TEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- FIN DEL ESQUEMA
-- Importar este archivo en MySQL Workbench: Server > Data Import
-- o abrir como script SQL y ejecutar.
-- Después ejecutar: php database/seed.php
-- =====================================================================
