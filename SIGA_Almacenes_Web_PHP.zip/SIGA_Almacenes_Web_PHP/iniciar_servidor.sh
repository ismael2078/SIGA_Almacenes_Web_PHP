#!/usr/bin/env bash
# ==============================================================================
# SIGA-DDE - SISTEMA INTEGRADO DE GESTIÓN DE ALMACENES
# Proyecto Web Independiente (PHP Orientado a Objetos + MVC + MySQL Workbench)
# Script de lanzamiento para demostración inmediata en navegador
# ==============================================================================

PORT=${1:-8080}
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
PHP_BIN="/opt/homebrew/bin/php"

if [ ! -x "$PHP_BIN" ]; then
    PHP_BIN="$(which php)"
fi

if [ -z "$PHP_BIN" ]; then
    echo "Error: No se encontró el binario de PHP en el sistema."
    exit 1
fi

if [ -d "${BASE_DIR}/public" ]; then
    PUBLIC_DIR="${BASE_DIR}/public"
else
    PUBLIC_DIR="${BASE_DIR}/siga-php/public"
fi

echo "=========================================================================="
echo "  SIGA-DDE — Sistema Integrado de Gestión de Almacenes (DDE Cochabamba)"
echo "  Tecnología: PHP Orientado a Objetos (MVC) + Bootstrap 5 + MySQL Workbench"
echo "  Ubicación:  ${BASE_DIR}"
echo "=========================================================================="
echo ""
echo "  Servidor Web Activo:  http://localhost:${PORT}"
echo "  Endpoints API:        http://localhost:${PORT}/api/rates"
echo "                        http://localhost:${PORT}/api/health"
echo ""
echo "  Script SQL MySQL:     ${BASE_DIR}/database/mysql_schema_and_seed.sql"
echo ""
echo "  Cuentas preconfiguradas para demostración:"
echo "    * Administrador:       admin / admin123"
echo "    * Técnica Almacén:     almacen / almacen123"
echo "    * Solicitante:         solicitante / sol123"
echo "    * Inmediato Superior:  jefe_inmediato / jefe123"
echo "    * Jefatura UAA:        jefe_uaa / uaa123"
echo "    * Auditor Interno:     auditor / auditor123"
echo "    * Consulta Externa:    consulta / consulta123"
echo ""
echo "  Presione Ctrl+C para finalizar."
echo "=========================================================================="
echo ""

# Abrir automáticamente en el navegador si es macOS
if [[ "$OSTYPE" == "darwin"* ]]; then
    (sleep 1 && open "http://localhost:${PORT}") &
fi

exec "$PHP_BIN" -S 0.0.0.0:${PORT} -t "${PUBLIC_DIR}" "${PUBLIC_DIR}/index.php"
