<?php
// Inicializa el autoload, la configuración y las funciones compartidas del proyecto.

declare(strict_types=1);

/**
 * SIGA-DDE - Arranque de la aplicación.
 * Autoload PSR-4 sin dependencias externas (también compatible con Composer).
 */

define('BASE_PATH', __DIR__);

// Carga de variables de entorno (.env)
require BASE_PATH . '/app/Core/Env.php';
App\Core\Env::load(BASE_PATH . '/.env');

// Autoload PSR-4 para el namespace App\
spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }
    $relative = substr($class, strlen($prefix));
    $file = BASE_PATH . '/app/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

require BASE_PATH . '/app/Support/helpers.php';

$config = require BASE_PATH . '/config/app.php';
date_default_timezone_set($config['timezone']);
if (function_exists('mb_internal_encoding')) {
    mb_internal_encoding('UTF-8');
}
setlocale(LC_ALL, 'es_BO.UTF-8', 'es_BO', 'es_ES.UTF-8', 'es_ES');

if ($config['debug']) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(E_ALL & ~E_DEPRECATED);
}

// Sesión PHP para CSRF y mensajes flash. La autenticación se valida contra la tabla sessions.
if (PHP_SAPI !== 'cli' && session_status() === PHP_SESSION_NONE) {
    session_name($config['session_name']);
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    ]);
    session_start();
}
