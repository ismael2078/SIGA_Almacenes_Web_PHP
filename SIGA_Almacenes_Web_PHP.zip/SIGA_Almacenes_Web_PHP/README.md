# SIGA-DDE — Sistema Integrado de Gestión de Almacenes

Sistema Web oficial para la gestión de almacenes e inventarios de la **Dirección Departamental de Educación (DDE Cochabamba)**.

---

## 🚀 Base Tecnológica Implementada

El proyecto ha sido completamente transformado y reconstruido bajo la siguiente arquitectura tecnológica:

- **Backend:** PHP 8+ Orientado a Objetos (POO estricto, namespaces, encapsulamiento y transacciones atómicas).
- **Base de Datos:** MySQL (con script oficial DDL + Seed completo para **MySQL Workbench**).
- **Arquitectura:** Modelo – Vista – Controlador (**MVC**).
- **Frontend:** HTML5 semántico, CSS3 personalizado, JavaScript interactivo (ES6+), **Bootstrap 5.3**, Bootstrap Icons y **Chart.js**.
- **Integraciones de API:** Consumo en vivo de **API RESTful de Tasas de Cambio y Divisas** (`open.er-api.com` / `frankfurter.app`) para valoración multi-moneda instantánea del inventario (BOB / USD).
- **Publicación y Demostración:** Ejecutable de inmediato en cualquier navegador web mediante servidor embebido o Apache/Nginx.

---

## 🗄️ Base de Datos: MySQL & MySQL Workbench

El script completo de creación e inserción de datos se encuentra disponible en:
📁 `database/SIGA_DDE_MYSQL_TODOS_LOS_REGISTROS.sql`

### ¿Cómo abrir e importar en MySQL Workbench?
1. Abra **MySQL Workbench**.
2. Conéctese a su instancia local o remota de MySQL (puerto 3306).
3. Vaya al menú superior: **File &rarr; Open SQL Script...**
4. Seleccione el archivo `database/SIGA_DDE_MYSQL_TODOS_LOS_REGISTROS.sql`.
5. Haga clic en el botón de ejecución (ícono de rayo ⚡) o presione `Ctrl + Shift + Enter`.
6. Se creará automáticamente la base de datos `siga_db` con todas las 32 tablas relacionales, llaves foráneas, índices y la carga completa de datos iniciales:
   - 7 Roles y 38 Permisos del sistema RBAC.
   - 6 Categorías y 18 Subcategorías oficiales.
   - 10 Unidades de medida y 5 Ubicaciones de almacén.
   - 4 Proveedores y 8 Áreas institucionales jerárquicas.
   - 7 Cuentas de usuario con contraseñas encriptadas mediante Bcrypt.
   - **181 Productos de catálogo** con costos referenciales y saldos físicos iniciales.
   - Ingreso de Apertura (`ING-2026-000001`), 181 capas contables PEPS (`stock_layers`) y 181 asientos de Kardex físico-valorado.
   - Solicitud de demostración atendida (`SOL-2026-000001`) y comprobante de despacho (`SAL-2026-000001`).
   - Ajuste de inventario en revisión (`AJ-2026-000001`).
   - Secuencias correlativas anuales y parámetros de configuración del sistema.

---

## 📂 Arquitectura del Proyecto (MVC en PHP POO)

```text
siga-php/
├── app/
│   ├── Core/                         # Núcleo del Framework MVC
│   │   ├── Router.php                # Enrutador RESTful y de vistas
│   │   ├── Controller.php            # Controlador base (render, json, auth, flashes)
│   │   ├── Model.php                 # Modelo base ORM/PDO
│   │   ├── Database.php              # Singleton PDO MySQL con fallback inteligente
│   │   ├── Auth.php                  # Autenticación, sesiones y matriz de permisos RBAC
│   │   └── PepsEngine.php            # Motor contable PEPS (FIFO), capas y Kardex
│   ├── Models/                       # Modelos de Datos (Entidades POO)
│   │   ├── Product.php               # Catálogo de productos y capas
│   │   ├── Request.php               # Solicitudes de material y flujo de aprobación
│   │   ├── StockEntry.php            # Ingresos a almacén
│   │   ├── StockDispatch.php         # Salidas y actas de entrega
│   │   ├── KardexMovement.php        # Kardex Físico-Valorado
│   │   ├── Adjustment.php            # Ajustes por faltante/sobrante
│   │   ├── User.php, Area.php...     # Catálogos y usuarios
│   ├── Controllers/                  # Controladores de la Lógica de Negocio
│   │   ├── DashboardController.php   # KPIs, alertas de stock mínimo y gráficos
│   │   ├── SolicitudesController.php # Flujo completo de pedidos de material
│   │   ├── AprobacionesController.php# Bandeja de decisión jerárquica (V°B° / Autorización)
│   │   ├── IngresosController.php    # Recepción de material y generación de capas PEPS
│   │   ├── SalidasController.php     # Despacho físico con consumo PEPS y acta
│   │   ├── InventarioController.php  # Existencias físicas y detalle técnico
│   │   ├── KardexController.php      # Kardex individual y resumen contable
│   │   ├── AjustesController.php     # Ajustes físicos y aprobación tripartita
│   │   ├── ArqueoController.php      # Toma física mensual y diferencias
│   │   ├── ReportesController.php    # Reportes valorados y exportación CSV/Excel
│   │   ├── CatalogosController.php   # Paramétricas del sistema
│   │   ├── UsuariosController.php    # Gestión de usuarios y perfiles
│   │   ├── AuditoriaController.php   # Bitácora inmutable de eventos
│   │   ├── ConfiguracionController.php# Calibración de impresión y parámetros DDE
│   │   ├── ImprimirController.php    # Formatos oficiales (Hoja Membretada DDE)
│   │   └── ApiController.php         # Endpoints JSON y consumo de API externa
│   ├── Services/
│   │   └── ExternalApiService.php    # Integración con API de divisas y cotizaciones
│   └── Views/                        # Vistas HTML5 + Bootstrap 5.3
│       ├── layouts/                  # Plantillas maestras (header, footer, print)
│       ├── auth/login.php            # Pantalla de acceso con selector rápido
│       ├── dashboard/index.php       # Tablero principal con Chart.js
│       ├── solicitudes/              # Vistas de pedidos de material
│       ├── aprobaciones/             # Bandeja de firmas
│       ├── ingresos/                 # Comprobantes de entrada
│       ├── salidas/                  # Despachos y actas
│       ├── inventario/               # Existencias y fichas
│       ├── kardex/                   # Kardex físico-valorado
│       ├── reportes/                 # Planillas oficiales
│       ├── imprimir/                 # Plantillas de impresión calibradas
│       └── ...                       # Ajustes, arqueo, usuarios, auditoría
├── config/
│   └── database.php                  # Configuración de conexión MySQL / SQLite
├── database/
│   └── SIGA_DDE_MYSQL_TODOS_LOS_REGISTROS.sql  # SQL con todos los registros de ejemplo
├── public/                           # Directorio Público Web
│   ├── index.php                     # Front Controller
│   ├── css/custom.css                # Estilos institucionales DDE-CBBA
│   ├── js/app.js                     # Búsqueda en vivo y conversor de divisas
│   └── plantillas/                   # Logos y fondos de pedidos membretados
└── iniciar_servidor.sh               # Lanzador para demostración inmediata
```

---

## 🌐 Demostración Inmediata en Navegador

Para iniciar y probar el sistema web en el navegador de inmediato, ejecute:

```bash
./iniciar_servidor.sh
```

El servidor web se levantará en:  
👉 **http://localhost:8080**

### Cuentas preconfiguradas para pruebas:

| Rol | Usuario | Contraseña | Permisos Clave |
|---|---|---|---|
| **Administrador** | `admin` | `admin123` | Control total del sistema, configuración y auditoría |
| **Técnica de Almacén** | `almacen` | `almacen123` | Despachos PEPS, comprobantes de ingreso, arqueo y salidas |
| **Solicitante** | `solicitante` | `sol123` | Registro y seguimiento de solicitudes de materiales |
| **Inmediato Superior** | `jefe_inmediato` | `jefe123` | Validación y visto bueno inicial de pedidos del área |
| **Jefatura UAA** | `jefe_uaa` | `uaa123` | Autorización final de solicitudes de almacén |
| **Auditor Interno** | `auditor` | `auditor123` | Solo lectura global y revisión de bitácora de auditoría |
| **Consulta Externa** | `consulta` | `consulta123` | Consulta de existencias y reportes |

---

## 🌟 Características Destacadas

1. **Motor Contable PEPS (FIFO) Estricto:**
   - Cada ingreso crea capas individuales con fecha contable, secuencia, cantidad remanente y costo unitario.
   - Cada despacho consume automáticamente las existencias de la capa más antigua disponible.
   - Registro inmutable de cada consumo en `layer_consumptions` y en el **Kardex Físico-Valorado**.

2. **Integración con API Externa (Valor Agregado Real):**
   - El sistema consulta la API pública de tipo de cambio en tiempo real (`open.er-api.com`).
   - Muestra el valor total de las existencias tanto en **Bolivianos (BOB)** como en **Dólares Estadounidenses (USD)**.
   - Permite alternar la moneda con un solo clic en el tablero y en los reportes de inventario.

3. **Impresión Oficial Calibrada:**
   - Generación de pedidos sobre la **Hoja Membretada Oficial** de la DDE con coordenadas exactas en milímetros.
   - Comprobantes de salida con acta de entrega, firmas institucionales y número correlativo anual sin huecos (`SAL-2026-00000X`).
