<?php
// Rutas de referencia: la aplicación activa registra sus rutas en public/index.php.

declare(strict_types=1);

use App\Controllers\AdjustmentController;
use App\Controllers\AdminController;
use App\Controllers\ApiController;
use App\Controllers\ApprovalController;
use App\Controllers\ArqueoController;
use App\Controllers\AuthController;
use App\Controllers\CatalogController;
use App\Controllers\DashboardController;
use App\Controllers\DispatchController;
use App\Controllers\EntryController;
use App\Controllers\InventoryController;
use App\Controllers\PrintController;
use App\Controllers\ReportController;
use App\Controllers\RequestController;

/** @var App\Core\Router $router */

// ---------------------------------------------------------------------
// Autenticación y perfil
// ---------------------------------------------------------------------
$router->get('/', [AuthController::class, 'home']);
$router->get('/login', [AuthController::class, 'showLogin']);
$router->post('/login', [AuthController::class, 'login']);
$router->post('/logout', [AuthController::class, 'logout']);
$router->get('/perfil', [AuthController::class, 'profile']);
$router->post('/perfil/password', [AuthController::class, 'changePassword']);

// ---------------------------------------------------------------------
// Panel de control
// ---------------------------------------------------------------------
$router->get('/dashboard', [DashboardController::class, 'index']);

// ---------------------------------------------------------------------
// Inventario y productos
// ---------------------------------------------------------------------
$router->get('/inventario', [InventoryController::class, 'index'], 'productos.ver');
$router->get('/inventario/nuevo', [InventoryController::class, 'create'], 'productos.crear');
$router->post('/inventario', [InventoryController::class, 'store'], 'productos.crear');
$router->get('/inventario/{id}/editar', [InventoryController::class, 'edit'], 'productos.editar');
$router->post('/inventario/{id}', [InventoryController::class, 'update'], 'productos.editar');
$router->get('/inventario/{id}', [InventoryController::class, 'show'], 'productos.ver');

// ---------------------------------------------------------------------
// Ingresos al almacén
// ---------------------------------------------------------------------
$router->get('/ingresos', [EntryController::class, 'index'], 'ingresos.ver');
$router->get('/ingresos/nuevo', [EntryController::class, 'create'], 'ingresos.crear');
$router->post('/ingresos', [EntryController::class, 'store'], 'ingresos.crear');
$router->get('/ingresos/{id}', [EntryController::class, 'show'], 'ingresos.ver');
$router->post('/ingresos/{id}/confirmar', [EntryController::class, 'confirm'], 'ingresos.confirmar');
$router->post('/ingresos/{id}/anular', [EntryController::class, 'cancel'], 'ingresos.anular');

// ---------------------------------------------------------------------
// Solicitudes
// ---------------------------------------------------------------------
$router->get('/solicitudes', [RequestController::class, 'index']);
$router->get('/solicitudes/nueva', [RequestController::class, 'create'], 'solicitudes.crear');
$router->post('/solicitudes', [RequestController::class, 'store'], 'solicitudes.crear');
$router->get('/solicitudes/{id}/editar', [RequestController::class, 'edit'], 'solicitudes.crear');
$router->post('/solicitudes/{id}/enviar', [RequestController::class, 'submit'], 'solicitudes.crear');
$router->post('/solicitudes/{id}/anular', [RequestController::class, 'cancel']);
$router->post('/solicitudes/{id}/decidir', [RequestController::class, 'decide'], 'aprobaciones.decidir');
$router->post('/solicitudes/{id}', [RequestController::class, 'update'], 'solicitudes.crear');
$router->get('/solicitudes/{id}', [RequestController::class, 'show']);

// ---------------------------------------------------------------------
// Aprobaciones
// ---------------------------------------------------------------------
$router->get('/aprobaciones', [ApprovalController::class, 'index'], 'aprobaciones.ver');
$router->post('/aprobaciones/{id}/decidir', [ApprovalController::class, 'decide'], 'aprobaciones.decidir');

// ---------------------------------------------------------------------
// Salidas / despachos PEPS
// ---------------------------------------------------------------------
$router->get('/salidas', [DispatchController::class, 'index'], 'salidas.ver');
$router->get('/salidas/nueva', [DispatchController::class, 'create']);
$router->get('/salidas/nueva/{requestId}', [DispatchController::class, 'create']);
$router->post('/salidas', [DispatchController::class, 'store'], 'salidas.confirmar');
$router->get('/salidas/{id}', [DispatchController::class, 'show'], 'salidas.ver');
$router->post('/salidas/{id}/anular', [DispatchController::class, 'cancel'], 'salidas.anular');

// ---------------------------------------------------------------------
// Ajustes de inventario
// ---------------------------------------------------------------------
$router->get('/ajustes', [AdjustmentController::class, 'index'], 'ajustes.ver');
$router->get('/ajustes/nuevo', [AdjustmentController::class, 'create'], 'ajustes.crear');
$router->post('/ajustes', [AdjustmentController::class, 'store'], 'ajustes.crear');
$router->get('/ajustes/{id}', [AdjustmentController::class, 'show'], 'ajustes.ver');
$router->post('/ajustes/{id}/aprobar', [AdjustmentController::class, 'approve'], 'ajustes.aprobar');

// ---------------------------------------------------------------------
// Reportes
// ---------------------------------------------------------------------
$router->get('/reportes', [ReportController::class, 'index'], 'reportes.ver');
$router->get('/reportes/kardex', [ReportController::class, 'kardex'], 'reportes.ver');
$router->get('/reportes/inventario', [ReportController::class, 'inventory'], 'reportes.ver');
$router->get('/reportes/kardex-resumen', [ReportController::class, 'kardexSummary'], 'reportes.ver');

// ---------------------------------------------------------------------
// Arqueo y cierre de periodos
// ---------------------------------------------------------------------
$router->get('/arqueo', [ArqueoController::class, 'index'], 'arqueo.ver');
$router->post('/arqueo/periodos/{id}/cerrar', [ArqueoController::class, 'closePeriod'], 'arqueo.cerrar');
$router->post('/arqueo/periodos/{id}/reabrir', [ArqueoController::class, 'reopenPeriod'], 'arqueo.reabrir');
$router->post('/arqueo/conteo', [ArqueoController::class, 'registerCount'], 'arqueo.registrar');

// ---------------------------------------------------------------------
// Catálogos
// ---------------------------------------------------------------------
$router->get('/catalogos', [CatalogController::class, 'index'], 'catalogos.ver');
$router->post('/catalogos/{tipo}', [CatalogController::class, 'store'], 'catalogos.editar');

// ---------------------------------------------------------------------
// Administración
// ---------------------------------------------------------------------
$router->get('/admin/usuarios', [AdminController::class, 'users'], 'usuarios.ver');
$router->post('/admin/usuarios', [AdminController::class, 'storeUser'], 'usuarios.gestionar');
$router->post('/admin/usuarios/{id}/estado', [AdminController::class, 'toggleUser'], 'usuarios.gestionar');
$router->post('/admin/usuarios/{id}', [AdminController::class, 'updateUser'], 'usuarios.gestionar');
$router->get('/admin/auditoria', [AdminController::class, 'audit'], 'auditoria.ver');
$router->get('/admin/configuracion', [AdminController::class, 'settings'], 'config.ver');
$router->post('/admin/configuracion', [AdminController::class, 'saveSettings'], 'config.editar');

// ---------------------------------------------------------------------
// Impresión
// ---------------------------------------------------------------------
$router->get('/imprimir/solicitud/{id}', [PrintController::class, 'request']);
$router->get('/imprimir/salida/{id}', [PrintController::class, 'dispatch']);

// ---------------------------------------------------------------------
// Endpoints JSON auxiliares
// ---------------------------------------------------------------------
$router->get('/api/productos', [ApiController::class, 'products']);
$router->get('/api/subcategorias', [ApiController::class, 'subcategories']);
