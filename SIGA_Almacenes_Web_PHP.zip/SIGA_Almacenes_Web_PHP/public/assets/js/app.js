// Interacciones del cliente: facilita la navegación y el llenado de formularios.
(() => {
    "use strict";
// Ejecuta la función cuando la estructura HTML ya está disponible.

    const ready = (fn) => {
        if (document.readyState === "loading") {
            // Espera a que el documento esté construido antes de buscar sus elementos.
            document.addEventListener("DOMContentLoaded", fn);
        } else {
            fn();
        }
    };
// Presenta importes con separadores y decimales usados en Bolivia.

    const money = (value) => {
        const number = Number(value || 0);
        // Presenta el número con el formato adecuado sin alterar el dato original.
        return number.toLocaleString("es-BO", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    };
// Formatea cantidades de inventario sin alterar su valor real.

    const qty = (value) => {
        const number = Number(value || 0);
        // Presenta el número con el formato adecuado sin alterar el dato original.
        return number.toLocaleString("es-BO", { minimumFractionDigits: 0, maximumFractionDigits: 3 });
    };
// Conecta botones, formularios y tablas con sus eventos del navegador.

    ready(() => {
        // Sidebar responsive
        const body = document.body;
        const menuToggle = document.getElementById("menuToggle");
        const overlay = document.getElementById("sidebarOverlay");
        if (menuToggle) {
            // Atiende el clic y ejecuta la acción asociada con este control.
            menuToggle.addEventListener("click", () => body.classList.toggle("sidebar-open"));
        }
        if (overlay) {
            // Atiende el clic y ejecuta la acción asociada con este control.
            overlay.addEventListener("click", () => body.classList.remove("sidebar-open"));
        }
        // Localiza los componentes que se deben actualizar en la interfaz.
        document.querySelectorAll(".sidebar .nav-link").forEach((link) => {
            link.addEventListener("click", () => {
                if (window.innerWidth < 992) {
                    body.classList.remove("sidebar-open");
                }
            });
        });

        // Auto-cerrar mensajes flash
        document.querySelectorAll(".js-auto-dismiss").forEach((alert) => {
            window.setTimeout(() => {
                alert.classList.remove("show");
                alert.classList.add("fade");
                window.setTimeout(() => alert.remove(), 300);
            }, 6500);
        });

        // Confirmaciones
        document.querySelectorAll("form[data-confirm]").forEach((form) => {
            // Intercepta el envío para comprobar o preparar los datos del formulario.
            form.addEventListener("submit", (event) => {
                const message = form.getAttribute("data-confirm") || "¿Confirma esta operación?";
                if (!window.confirm(message)) {
                    event.preventDefault();
                }
            });
        });

        // Impresión
        document.querySelectorAll("[data-print]").forEach((button) => {
            // Atiende el clic y ejecuta la acción asociada con este control.
            button.addEventListener("click", () => window.print());
        });

        // Filas dinámicas (ingresos, solicitudes, ajustes)
        document.querySelectorAll("[data-rows]").forEach((container) => {
            const tbody = document.querySelector(container.getAttribute("data-rows"));
            const templateSelector = container.getAttribute("data-template");
            const template = templateSelector ? document.querySelector(templateSelector) : null;
            const addButton = document.querySelector(container.getAttribute("data-add-row"));
            if (!tbody || !template) {
                return;
            }

            const recalc = () => {
                let grandTotal = 0;
                // Localiza los componentes que se deben actualizar en la interfaz.
                tbody.querySelectorAll("tr[data-item-row]").forEach((row) => {
                    const qtyInput = row.querySelector(".qty-input");
                    const costInput = row.querySelector(".cost-input");
                    const lineTotal = row.querySelector("[data-line-total]");
                    const quantity = parseFloat((qtyInput && qtyInput.value) || 0) || 0;
                    const cost = parseFloat((costInput && costInput.value) || 0) || 0;
                    const total = quantity * cost;
                    if (lineTotal) {
                        lineTotal.textContent = money(total);
                    }
                    grandTotal += total;
                });
                // Localiza los componentes que se deben actualizar en la interfaz.
                document.querySelectorAll("[data-grand-total]").forEach((el) => {
                    el.textContent = money(grandTotal);
                });
            };

            const bindRow = (row) => {
                const productSelect = row.querySelector(".product-select");
                const qtyInput = row.querySelector(".qty-input");
                const costInput = row.querySelector(".cost-input");
                const unitLabel = row.querySelector("[data-unit-label]");
                const stockLabel = row.querySelector("[data-stock-label]");
                const removeButton = row.querySelector("[data-remove-row]");

                if (productSelect) {
                    // Relaciona el evento del navegador con la reacción de esta pantalla.
                    productSelect.addEventListener("change", () => {
                        const option = productSelect.options[productSelect.selectedIndex];
                        if (!option) {
                            return;
                        }
                        if (costInput && option.dataset.cost !== undefined) {
                            // Presenta el número con el formato adecuado sin alterar el dato original.
                            costInput.value = Number(option.dataset.cost || 0).toFixed(4);
                        }
                        if (unitLabel) {
                            unitLabel.textContent = option.dataset.unit || "UND";
                        }
                        if (stockLabel) {
                            stockLabel.textContent = qty(option.dataset.stock || 0);
                        }
                        recalc();
                    });
                }
                [qtyInput, costInput].forEach((input) => {
                    if (input) {
                        // Actualiza el resultado mientras el usuario escribe.
                        input.addEventListener("input", recalc);
                    }
                });
                if (removeButton) {
                    // Atiende el clic y ejecuta la acción asociada con este control.
                    removeButton.addEventListener("click", () => {
                        const rows = tbody.querySelectorAll("tr[data-item-row]");
                        if (rows.length <= 1) {
                            // Localiza los componentes que se deben actualizar en la interfaz.
                            row.querySelectorAll("input, select").forEach((field) => {
                                if (field.tagName === "SELECT") {
                                    field.selectedIndex = 0;
                                } else {
                                    field.value = "";
                                }
                            });
                        } else {
                            row.remove();
                        }
                        recalc();
                    });
                }
            };

            const addRow = () => {
                const fragment = template.content.cloneNode(true);
                const row = fragment.querySelector("tr[data-item-row]");
                if (!row) {
                    return;
                }
                tbody.appendChild(fragment);
                const appended = tbody.lastElementChild;
                bindRow(appended);
                const firstField = appended.querySelector("select, input");
                if (firstField) {
                    firstField.focus();
                }
                recalc();
            };

            if (addButton) {
                // Atiende el clic y ejecuta la acción asociada con este control.
                addButton.addEventListener("click", addRow);
            }
            // Localiza los componentes que se deben actualizar en la interfaz.
            tbody.querySelectorAll("tr[data-item-row]").forEach(bindRow);
            recalc();
        });

        // Modal de edición de usuarios
        const editUserModal = document.getElementById("editUserModal");
        if (editUserModal) {
            // Relaciona el evento del navegador con la reacción de esta pantalla.
            editUserModal.addEventListener("show.bs.modal", (event) => {
                const button = event.relatedTarget;
                if (!button) {
                    return;
                }
                let data = {};
                try {
                    data = JSON.parse(button.getAttribute("data-user") || "{}");
                } catch (error) {
                    data = {};
                }
                const form = document.getElementById("editUserForm");
                if (form) {
                    form.setAttribute("action", button.getAttribute("data-action") || "#");
                }
                Object.entries(data).forEach(([key, value]) => {
                    const field = editUserModal.querySelector(`[name="${key}"]`);
                    if (field) {
                        field.value = value === null || value === undefined ? "" : value;
                    }
                });
                const password = editUserModal.querySelector('[name="password"]');
                if (password) {
                    password.value = "";
                }
            });
        }

        // Filtro rápido de productos en arqueo
        const productFilter = document.getElementById("countProductFilter");
        if (productFilter) {
            // Actualiza el resultado mientras el usuario escribe.
            productFilter.addEventListener("input", () => {
                const term = productFilter.value.toLowerCase().trim();
                // Localiza los componentes que se deben actualizar en la interfaz.
                document.querySelectorAll("#countProductsTable tbody tr").forEach((row) => {
                    row.style.display = row.textContent.toLowerCase().includes(term) ? "" : "none";
                });
            });
        }

        // Habilitar comentario cuando se rechaza o devuelve
        document.querySelectorAll("[data-decision-form]").forEach((form) => {
            const action = form.querySelector('[name="action"]');
            const comments = form.querySelector('[name="comments"]');
            if (!action || !comments) {
                return;
            }
            const sync = () => {
                const required = action.value === "RECHAZAR" || action.value === "DEVOLVER";
                comments.required = required;
                comments.placeholder = required
                    ? "Comentario obligatorio (mínimo 5 caracteres)"
                    : "Comentario opcional";
            };
            // Relaciona el evento del navegador con la reacción de esta pantalla.
            action.addEventListener("change", sync);
            sync();
        });

        // Mostrar/ocultar contraseña
        document.querySelectorAll("[data-toggle-password]").forEach((button) => {
            // Atiende el clic y ejecuta la acción asociada con este control.
            button.addEventListener("click", () => {
                const target = document.querySelector(button.getAttribute("data-toggle-password"));
                if (!target) {
                    return;
                }
                const type = target.getAttribute("type") === "password" ? "text" : "password";
                target.setAttribute("type", type);
                button.innerHTML = type === "password"
                    ? '<i class="bi bi-eye"></i>'
                    : '<i class="bi bi-eye-slash"></i>';
            });
        });
    });
})();
