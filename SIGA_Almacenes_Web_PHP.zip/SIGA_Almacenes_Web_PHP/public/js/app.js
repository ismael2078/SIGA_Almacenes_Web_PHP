// Interacciones del cliente: facilita la navegación y el llenado de formularios.
/**
 * SIGA-DDE - Lógica Frontend JavaScript
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. Filtrado instantáneo en tablas con data-table-search
    const searchInputs = document.querySelectorAll('[data-table-search]');
    // Recorre los elementos encontrados y aplica el comportamiento a cada uno.
    searchInputs.forEach(input => {
        const tableId = input.getAttribute('data-table-search');
        const table = document.getElementById(tableId);
        // Evita operar sobre un elemento que no está presente en esta pantalla.
        if (!table) return;

        // Actualiza el resultado mientras el usuario escribe.
        input.addEventListener('keyup', function () {
            const query = input.value.toLowerCase();
            // Localiza los componentes que se deben actualizar en la interfaz.
            const rows = table.querySelectorAll('tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(query) ? '' : 'none';
            });
        });
    });

    // 2. Auto-cierre de alertas tras 5 segundos
    const alerts = document.querySelectorAll('.alert-dismissible');
    // Recorre los elementos encontrados y aplica el comportamiento a cada uno.
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) bsAlert.close();
        }, 6000);
    });

    // 3. Conversor de divisas en vivo (BOB / USD)
    const currencyToggle = document.getElementById('currencyToggleBtn');
    if (currencyToggle) {
        // Atiende el clic y ejecuta la acción asociada con este control.
        currencyToggle.addEventListener('click', function () {
            const isUsd = this.getAttribute('data-active') === 'USD';
            const newMode = isUsd ? 'BOB' : 'USD';
            this.setAttribute('data-active', newMode);
            this.innerHTML = isUsd ? '<i class="bi bi-currency-dollar me-1"></i>Ver en USD' : '<i class="bi bi-cash me-1"></i>Ver en BOB';

            const rate = parseFloat(this.getAttribute('data-rate') || '6.96');
            // Localiza los componentes que se deben actualizar en la interfaz.
            document.querySelectorAll('[data-bob-amount]').forEach(el => {
                const bobVal = parseFloat(el.getAttribute('data-bob-amount'));
                // Distingue la moneda elegida para mostrar el importe correspondiente.
                if (newMode === 'USD') {
                    const usdVal = (bobVal / rate).toFixed(2);
                    // Presenta el número con el formato adecuado sin alterar el dato original.
                    el.textContent = '$ ' + Number(usdVal).toLocaleString('en-US', { minimumFractionDigits: 2 });
                } else {
                    // Presenta el número con el formato adecuado sin alterar el dato original.
                    el.textContent = 'Bs ' + Number(bobVal).toLocaleString('es-BO', { minimumFractionDigits: 2 });
                }
            });
        });
    }
});

// Helper global para agregar filas dinámicas en formularios de solicitudes / ingresos
window.addRequestItemRow = function (productsJson) {
    const tableBody = document.querySelector('#itemsTable tbody');
    // Evita operar sobre un elemento que no está presente en esta pantalla.
    if (!tableBody) return;

    const rowIdx = tableBody.children.length;
    const tr = document.createElement('tr');

    let options = '<option value="">-- Seleccione un producto --</option>';
    // Recorre los elementos encontrados y aplica el comportamiento a cada uno.
    productsJson.forEach(p => {
        options += `<option value="${p.id}" data-stock="${parseInt(p.stock_qty, 10)}" data-unit="${p.unit_name || 'UND'}">${p.code} - ${p.name} (Stock: ${parseInt(p.stock_qty, 10)})</option>`;
    });

    // Construye el contenido HTML de una nueva fila de forma dinámica.
    tr.innerHTML = `
        <td>
            <select name="items[${rowIdx}][product_id]" class="form-select form-select-sm product-select" required onchange="handleProductChange(this, ${rowIdx})">
                ${options}
            </select>
        </td>
        <td>
            <input type="text" id="unit_${rowIdx}" class="form-control form-control-sm text-center bg-light" readonly value="-">
        </td>
        <td>
            <input type="text" id="stock_${rowIdx}" class="form-control form-control-sm text-center bg-light" readonly value="0">
        </td>
        <td>
            <input type="number" step="1" min="1" name="items[${rowIdx}][qty]" class="form-control form-control-sm text-end" required value="1">
        </td>
        <td>
            <input type="text" name="items[${rowIdx}][notes]" class="form-control form-control-sm" placeholder="Observación / justificación">
        </td>
        <td class="text-center">
            <button type="button" class="btn btn-outline-danger btn-sm" onclick="this.closest('tr').remove()"><i class="bi bi-trash"></i></button>
        </td>
    `;
    tableBody.appendChild(tr);
};

// Al cambiar el producto, rellena su unidad de medida y existencia visible.
window.handleProductChange = function (select, rowIdx) {
    const selectedOption = select.options[select.selectedIndex];
    const unit = selectedOption.getAttribute('data-unit') || '-';
    const stock = parseInt(selectedOption.getAttribute('data-stock') || '0', 10);

    const unitField = document.getElementById(`unit_${rowIdx}`);
    const stockField = document.getElementById(`stock_${rowIdx}`);

    if (unitField) unitField.value = unit;
    if (stockField) stockField.value = stock;
};
