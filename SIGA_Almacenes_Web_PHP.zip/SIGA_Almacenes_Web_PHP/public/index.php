<?php
// Punto de entrada web: inicia la sesión, declara rutas y despacha cada petición.
/**
 * SIGA-DDE - Front Controller
 * Arquitectura Modelo - Vista - Controlador (MVC) en PHP POO
 */

declare(strict_types=1);

// Servir archivos estáticos en servidor integrado de PHP
if (php_sapi_name() === 'cli-server') {
    $url = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
    $file = __DIR__ . $url;
    if ($url !== '/' && is_file($file)) {
        return false;
    }
}

// Configuración, autoload y utilidades compartidas (sin cambiar las rutas MVC).
require_once __DIR__ . '/../bootstrap.php';

use App\Core\Router;
use App\Core\Auth;

// Iniciar sesión
Auth::init();

// Crear enrutador
$router = new Router();

// ================= RUTAS DE AUTENTICACIÓN =================
$router->get('/login', 'AuthController@showLogin');
$router->post('/login', 'AuthController@login');
$router->post('/logout', 'AuthController@logout');
$router->post('/auth/cambiar-password', 'AuthController@changePassword');

// ================= TABLERO PRINCIPAL =================
$router->get('/', 'DashboardController@index');
$router->get('/dashboard', 'DashboardController@index');

// ================= SOLICITUDES =================
$router->get('/solicitudes', 'SolicitudesController@index');
$router->get('/solicitudes/nueva', 'SolicitudesController@nueva');
$router->post('/solicitudes/guardar', 'SolicitudesController@store');
$router->post('/solicitudes/{id}/enviar', 'SolicitudesController@enviar');
$router->get('/solicitudes/{id}', 'SolicitudesController@ver');
$router->post('/solicitudes/{id}/anular', 'SolicitudesController@anular');

// ================= APROBACIONES =================
$router->get('/aprobaciones', 'AprobacionesController@index');
$router->post('/aprobaciones/decidir', 'AprobacionesController@decidir');

// ================= INGRESOS & CAPAS PEPS =================
$router->get('/ingresos', 'IngresosController@index');
$router->get('/ingresos/nuevo', 'IngresosController@nuevo');
$router->post('/ingresos/guardar', 'IngresosController@store');
$router->get('/ingresos/{id}', 'IngresosController@ver');

// ================= SALIDAS / DESPACHOS =================
$router->get('/salidas', 'SalidasController@index');
$router->get('/salidas/nueva', 'SalidasController@nueva');
$router->post('/salidas/guardar', 'SalidasController@store');
$router->get('/salidas/{id}', 'SalidasController@ver');

// ================= INVENTARIO & EXISTENCIAS =================
$router->get('/inventario', 'InventarioController@index');
$router->get('/inventario/{id}', 'InventarioController@ver');

// ================= KARDEX =================
$router->get('/kardex/producto/{id}', 'KardexController@producto');
$router->get('/kardex/resumen', 'KardexController@resumen');

// ================= AJUSTES =================
$router->get('/ajustes', 'AjustesController@index');
$router->get('/ajustes/nuevo', 'AjustesController@nuevo');
$router->post('/ajustes/guardar', 'AjustesController@store');
$router->post('/ajustes/{id}/aprobar', 'AjustesController@aprobar');

// ================= ARQUEO =================
$router->get('/arqueo', 'ArqueoController@index');

// ================= REPORTES =================
$router->get('/reportes', 'ReportesController@index');
$router->get('/reportes/exportar-csv', 'ReportesController@exportarCsv');

// ================= CATÁLOGOS =================
$router->get('/catalogos', 'CatalogosController@index');

// ================= USUARIOS =================
$router->get('/usuarios', 'UsuariosController@index');

// ================= AUDITORÍA =================
$router->get('/auditoria', 'AuditoriaController@index');

// ================= CONFIGURACIÓN =================
$router->get('/configuracion', 'ConfiguracionController@index');
$router->post('/configuracion/guardar', 'ConfiguracionController@update');

// ================= IMPRESIÓN OFICIAL =================
$router->get('/imprimir/{id}', 'ImprimirController@solicitud');
$router->get('/imprimir/salida/{id}', 'ImprimirController@salida');
$router->post('/imprimir/calibrar', 'ImprimirController@calibrar');

// ================= API ENDPOINTS =================
$router->get('/api/health', 'ApiController@health');
$router->get('/api/rates', 'ApiController@getRates');
$router->get('/api/productos', 'ApiController@searchProducts');
$router->get('/api/productos/{id}', 'ApiController@getProduct');
$router->get('/api/solicitudes/check-correspondence', 'ApiController@checkCorrespondence');

// Proteger las operaciones POST contra envíos externos no autorizados (CSRF).
// Los formularios activos incluyen csrf_field() y el servidor verifica el token.
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $token = (string) ($_POST['_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!\App\Core\Csrf::verify($token)) {
        http_response_code(419);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Sesión del formulario vencida o token de seguridad inválido. Recargue la página e intente nuevamente.';
        exit;
    }
}

// Despachar petición
$requestUri = $_SERVER['REQUEST_URI'] ?? '/';
$requestMethod = $_SERVER['REQUEST_METHOD'] ?? 'GET';

$router->dispatch($requestUri, $requestMethod);
